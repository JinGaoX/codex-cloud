import type { CapacitorConfig } from '@capacitor/cli';

const androidTarget = process.env.CAPACITOR_PLATFORM === 'android';

/** All application code ships inside the app. Never set a remote server.url. */
const config: CapacitorConfig = {
  appId: 'org.libretv.personal',
  appName: 'PPS影音',
  webDir: androidTarget ? 'android-dist' : 'native-dist',
  backgroundColor: '#0b0e14',
  server: { hostname: 'localhost', iosScheme: 'capacitor', androidScheme: 'https' },
  ...(androidTarget ? {
    android: {
      allowMixedContent: false,
      webContentsDebuggingEnabled: false,
    },
  } : {}),
  ios: {
    contentInset: 'never',
    allowsLinkPreview: false,
    scrollEnabled: true,
    preferredContentMode: 'mobile',
    webContentsDebuggingEnabled: false,
  },
  plugins: {
    // Preserve normal fetch/AbortSignal and media behavior. No global HTTP patch.
    CapacitorHttp: { enabled: false },
    ...(androidTarget ? {
      // Let the native container reserve bars/cutouts on every WebView version.
      // This also protects existing fixed drawers, not just the page header.
      SystemBars: { insetsHandling: 'native', initialViewportFitValueHint: 'contain', style: 'DARK' },
    } : {}),
  },
};

export default config;
