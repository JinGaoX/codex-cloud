# 首页宽图来源

personal.19 的三张横图对应项目原有平台精选目录里的真实影片，未新增推荐 API 或播放片源。只用于个人版首页内容展示，不代表影片在用户配置的片源中一定可播放。按钮仍搜索已有片源。

| 作品 | 正式文件（public/posters/platform/） | 原图尺寸 | 核对页面 |
|---|---|---|---|
| 狂飙 | feature-knockout.webp | 1920×1080 | [爱奇艺官方页面](https://www.iqiyi.com/a_1fkgtbddd2x.html) |
| 星际穿越 | feature-interstellar.webp | 1366×768 | [优酷官方页面](https://v.youku.com/v_nextstage/id_cc0b6e2e962411de83b1.html?s=cc0b6e2e962411de83b1) |
| 白夜破晓 | feature-daybreak.webp | 1366×768 | [优酷官方页面](https://v.youku.com/v_nextstage/id_2cefbfbd6113efbfbd6c.html?s=2cefbfbd6113efbfbd6c) |
| 浪浪山小妖怪 | feature-nobody.webp | 1366×768 | [优酷官方页面](https://v.youku.com/v_nextstage/id_adbf5c397de94de2bc2a.html?s=adbf5c397de94de2bc2a) |

核对日期：2026-10-29。使用官方横向宣传素材，实际查看后才采用；不把竖海报拉伸为横图，不使用三体探测到的占位图。使用已有 Sharp 以 quality 90 转为 WebP，保留原始尺寸和内容；三张约 941 KB，随独立 PWA 缓存。页面通过 object-fit 和渐变适配，没有新增网络图床依赖。

原图地址：

- 狂飙：`https://pic0.iqiyipic.com/image/20231113/8b/04/a_100476174_m_601_m44_1920_1080.jpg`
- 星际穿越：`https://m.ykimg.com/058300005E773D984265930CD5AF28E3`
- 白夜破晓：`https://m.ykimg.com/0583000067564F191417E414528AD320`
- 浪浪山小妖怪：`https://m.ykimg.com/05830000691C235170A43D1408ABDEB0`

personal.22 增加《浪浪山小妖怪》宽图（196,722 字节），经过实际查看，保留原图右下角版权标记。只匹配同名最近观看内容的展示，不加入原有三部精选序列，也不影响观看历史的选择和排序。其余只有竖海报的影片使用清晰大海报配柔和背景，不把竖海报拉伸，也不凭空补横图。新增横图与原有素材一同随独立 PWA 打包缓存。

标题、类型与简介根据以上官方页面核对，简介为简短转述，没有复制完整剧情介绍。狂飙标注2023；另两部不把素材上传日期当上映日期。没有增加评分、热度、4K、HDR、VIP播放权限等未经证实的标签。

宣传图片及影视内容的版权归原权利人所有，项目 AGPL-3.0-or-later 代码许可不授予这些图片的版权。保留现有上游署名与 AGPL 声明。此次本地开发没有在线发布；如需公开或商业分发这些素材，应另行核实授权。
