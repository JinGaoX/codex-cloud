# personal.19 沉浸式首页

2026-10-29，本地开发。沿用 Next.js 15 / React / TypeScript / Tailwind，一套响应式前端适配手机、平板、桌面，不新增依赖。

## 本轮结构变化

personal.18 的侧栏、框内横幅、独立大搜索区和多排分类控件未达到用户要求。本轮重新组织首页：

- 删除常驻侧栏。1000px起显示轻量顶部首页、收藏、历史与设置，窄屏保留原四项底栏；直播、下载、片源与关于收纳到更多菜单，独立版原有能力限制不变。
- 原搜索组件移到顶栏，桌面/平板为紧凑输入框，手机点击搜索图标展开并聚焦。URL、最近搜索、结果页处理及输入时隐藏底栏的行为保留。
- 原卡片内横幅改成铺满页面的真实宽图，使用方向渐变融合标题、简介和操作；删除叠加小海报，无边框、无侧栏腾挪。横幅手机480px、平板竖屏500px、横屏/桌面460px，片架紧接其后。
- 续播由边框小条改成16:9封面卡、图内轻进度条和图下标题/时间，仅读取最近3条真实记录；已核实横图可用于匹配影片，否则仍用原封面，无历史则不展示。
- 榜单和固定精选变成横向片架：手机约2.2张、平板竖屏4张、横屏5张、桌面6张；触控可滑动，鼠标可用箭头。豆瓣找片仍为可分页网格。
- 电影、电视剧、动漫、综艺保留轻文字导航；榜单、豆瓣找片、固定精选及标签/评分筛选放入片单选项。原查询、排序、缓存、会话分类和纵向位置保持；片架的横向坐标仅在当前应用内存保存，最多12个视图，不增加持久存储身份。

底色#060709，主操作为白色，仅原品牌图标保留金色；统一 gutter 24–72px、海报/控件8px圆角、16/20px片架间距、44px触控区域。系统中文字体，无新字体请求、重模糊、自动轮播、视差动画或组件库。样式仅在无搜索词首页的 .cinema-home 生效。

## 真实数据与保留范围

横幅取既有目录的狂飙、星际穿越、白夜破晓，官方素材和简短转述依据见 [横图来源](home-artwork.zh-CN.md)。主按钮“观看选项”搜索现有源，不保证某源可用，不显示未经核实的画质。固定精选明确标注“随版本更新”，不伪装实时榜；真实榜单仍保留原条数和请求方式，不并行拉多个新榜。

动漫沿用既有豆瓣电影/动画标签。关闭首页推荐后同时隐藏横幅及发现区，仍可展开搜索。API、播放器、换源选集、代理、跨域、视频解析、广告过滤、下载、存储键和数据库结构不在本次修改范围。搜索结果、详情、播放和设置没有重做。

## 修改文件

| 范围 | 文件 |
|---|---|
| 首页编排/搜索位置 | src/app/page.tsx、src/components/header.tsx |
| 导航与首页变量 | src/components/home-navigation.tsx、src/app/home.css |
| 横幅与续播 | src/components/home-spotlight.tsx、home-featured.ts、home-media.css、continue-watching.tsx |
| 发现区展示 | src/components/discovery-section.tsx、discovery-home.css |
| 素材 | public/posters/platform/feature-{knockout,interstellar,daybreak}.webp |
| 版本和记录 | package.json、package-lock.json、harmony/AppScope/app.json5、README.md、CHANGELOG.private.zh-CN.md、本文及素材说明 |

## 验证依据

实际检查记录、截图、构建报告及回退文件保存在本机 Git 忽略目录 artifacts/immersive-home-2026-10-29/。capture-report-v2.json 记录390×844、834×1194、1194×834、1440×900，另加320px小屏：无横向页面溢出、无常驻侧栏、按钮不小于44px、横幅按钮未裁切、一个h1、随包宽图与海报正常加载。

workflow-report-v5.json 使用隔离浏览器配置和受控响应，验证四尺寸搜索→详情→精确选集→本机合成HLS实际解码、抽屉Escape归焦、更多片源入口、输入键盘避让、动漫旧请求、韩剧分类和返回滚动。续播来源/集数/25%进度及点击播放用隔离IndexedDB在四尺寸测试，没有写入用户数据库。关闭推荐的检查通过。extras-report-final.json 另验证三幅精选切换、锚点可见、片架返回横坐标、选项Escape归焦和125%基础字体。横幅浏览链接和键盘跳转链接采用原框架 Link，避免原生hash历史导致返回时URL与界面不同步。受控响应不能证明每一个私人API或外部图床可达。

正式 after-*.png 使用既有随包精选，没有伪造观看记录。续播单独验证截图会明确标注隔离测试数据。before-desktop.png、before-phone.png 为本轮改造前 personal.18 实际页面；新截图可直接对比导航、构图、搜索和片架结构。

类型检查、ESLint和72文件1064项单元测试通过。原插播过滤回归 default-filter-decoding、source-time-persist-and-restore、filter-off-original-playback 通过。最终构建/运行检查见同目录 delivery.json；未完成的构建不得视为成功。Chromium触控模拟不能代替真实 iPhone Safari、华为浏览器、软键盘或设备横屏测试。

## 本地预览和回退

本地全栈网页：http://localhost:8080/；独立PWA：http://127.0.0.1:8082/。独立PWA用 npm run build:iphone 构建，用 STANDALONE_PORT=8082 运行 npm run preview:iphone。网页用 npm run build 后运行 scripts/manage-local.ps1 -Action Start。HTTP本地预览不等于手机HTTPS安装验收；未发布线上。

当前分支 codex/immersive-home。新回退点 before-manifest.json 记录原分支 codex/home-ui-refresh、HEAD e324bcab70dedb4f7028932f0531c28041691db1 和454个非忽略文件的逐字节备份，含此前未提交工作。

在项目根目录运行 powershell -NoProfile -ExecutionPolicy Bypass -File artifacts/immersive-home-2026-10-29/restore-home-ui.ps1 默认只核验，不修改。加 -Apply 才恢复本次首页文件至 personal.18；检测到后续修改会拒绝覆盖。恢复后重新构建并启动。不要 git reset --hard，不要用旧 personal.18 任务的回退脚本撤销本次修改；这会混淆基线。浏览器收藏、历史、配置不在回退操作范围内。
