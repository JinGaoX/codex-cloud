# PPS影音品牌更新

2026-10-29，personal.20，本地分支 codex/pps-brand。按用户明确要求，应用名称由 VIP影视 改为 PPS影音，采用用户提供的1280×1280 PPS图片。图标只做尺寸和格式转换，不重绘、不裁剪；原始文件保存在 public/icons/pps-original.jpg，来源摘要见 branding/pps-icon.json。

公开母图已移除EXIF照片元数据，JPEG压缩图像段不变，并逐字节核对解码后的像素与用户原图相同。带元数据的原始附件只保留在本机忽略目录；导出的PNG和ICO不携带这些照片元数据。

网页标题仅显示 PPS影音，不再附带“为家人准备的私人影视播放器”。移除关于页、安装页的“一方银幕，一起看好片”“为相聚留一点好时光”等宣传语；保留功能说明、本机数据说明、LibreTV来源、AGPL与对应源码入口。没有把用户提供的图像宣称为原创。

统一范围：网页品牌、浏览器favicon、PWA名称与图标、离线页、安装页、可选WebClip生成器、iOS显示名及图标、Harmony显示名及图标。保留旧vip-icon文件路径作为兼容资源名；不是数据或应用身份迁移。原金色V图标来源记录仅作历史说明。

继续保留 libretv 数据库、libretv-settings 等存储键、org.libretv.personal、Harmony的 https://vip.localhost、PWA id/start_url/scope、URL路径和原播放/API/广告过滤逻辑。全栈Service Worker公开静态资源缓存从v1升至v2，避免旧图标被缓存；仅淘汰旧的公开资源缓存，不清理个人配置、历史、视频缓存或数据库。独立PWA仍由现有构建脚本按资源内容生成新版缓存。

scripts/export-brand-icons.mjs 改用项目已有Sharp导出PNG、含16/32/48/256尺寸的ICO和两端原生资源，无新依赖。新图标沿用用户图片原有底色和边角。原生工程资源更新不代表已编译或签名安装包。

本机两个既有桌面快捷方式只更新显示名称、说明及图标，保留启动目标、参数和Chrome应用ID；旧保存HTML文件不覆盖。修改前文件和快捷方式备份在 artifacts/pps-brand-2026-10-29/before/ 及 desktop-before/，同目录 before-manifest.json 记录原分支与哈希。

本地预览 http://localhost:8080/；独立PWA预览 http://127.0.0.1:8082/。本次未发布线上，手机/平板现有线上安装不会因本地构建自动换品牌。后续发布后，iOS桌面图标或名称仍可能由系统保留，可先保留旧入口，再从Safari添加新入口并确认记录；不要为更新图标清除网站数据。

实际检查、构建与截图见同目录 delivery.json。回退脚本 restore-brand.ps1 默认只核对，加 -Apply 才恢复本轮源码文件至 personal.19；不会清理浏览器数据，检测到后续修改会拒绝覆盖。桌面原始lnk保存在 desktop-before/，可在确认目标文件后手动恢复。恢复源码后重新构建本地网页和PWA。
