# Upstream and licensing

- Project: [LibreSpark/LibreTV](https://github.com/LibreSpark/LibreTV)
- Baseline: v2.20.2, commit `f01d331e9ec7b5c1cc0822747cdd4c486601dbc2`
- Retrieved: 2026-10-22
- Development branch: `feat/private-iphone-pwa`
- License: AGPL-3.0-or-later; original [LICENSE](LICENSE) and attribution retained.

This is an independently modified personal app. It is not an official LibreTV release.
Changes are recorded in [CHANGELOG.private.zh-CN.md](CHANGELOG.private.zh-CN.md).
The upstream repository has not been modified.

## HLS PTS interstitial detection

The timestamp-continuity approach and parts of `src/lib/hls-pts-filter.ts` are
adapted from [OpenAni / Animeko](https://github.com/open-ani/animeko), copyright
(C) 2024-2026 OpenAni and contributors, under GNU AGPL version 3.
Original implementation: [PR #3471](https://github.com/open-ani/animeko/pull/3471),
merged as `c173844ab5fab4a04fea2e31289f4be3fad56453`.
Original files: `HlsManifestFilter.kt` and `HlsPtsContinuity.kt` under
`app/shared/app-data/src/commonMain/kotlin/domain/media/hls/`.
Their attribution and AGPLv3 terms are retained in the adaptation and the source offer.

构建时 `scripts/source-distribution.mjs` 从公开源码白名单生成
`public/source-code.tar.gz`，页脚「本修改版源码」向网络使用者提供对应源码。
也可通过公开构建变量 `NEXT_PUBLIC_SOURCE_URL` 指向本修改版的源码仓库。
不要把该地址指向仅上游代码，或使用者无权访问的私有仓库。
服务器密码及密钥仅配置在部署平台运行环境；源地址、收藏及观看记录保存在设备端，
不要放进源码目录或 `public/`。分享配置文件可能含私人源 URL，请妥善保管。
