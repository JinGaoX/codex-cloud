package org.libretv.personal;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import java.util.Collections;
import org.junit.Test;

public class LocalRouteMapperTest {
    private String map(String url, boolean main) {
        return LocalRouteMapper.map(url, "GET", main, Collections.emptyMap());
    }

    @Test public void mapsOnlyKnownLocalDocumentsAndKeepsTheirAddressSemantics() {
        for (String route : new String[] {"watch", "live", "library", "about"}) {
            assertEquals("https://localhost/" + route + ".html?source=a%2Fb&title=%E5%AE%B6#part",
                map("https://localhost/" + route + "?source=a%2Fb&title=%E5%AE%B6#part", true));
            assertEquals("https://localhost/" + route + ".html", map("https://localhost/" + route + "/", true));
        }
    }

    @Test public void mapsFlightFetchesToTheActualExportedTextAssets() {
        assertEquals("https://localhost/watch.txt?_rsc=token&url=https%3A%2F%2Fcdn.example%2Fa.m3u8",
            map("https://localhost/watch/?_rsc=token&url=https%3A%2F%2Fcdn.example%2Fa.m3u8", false));
        assertEquals("https://localhost/index.txt?_rsc=1", map("https://localhost/?_rsc=1", false));
        assertEquals("https://localhost/live.txt?query=1",
            LocalRouteMapper.map("https://localhost/live?query=1", "GET", false, Collections.singletonMap("rSc", "1")));
    }

    @Test public void documentQueryCannotAccidentallyBecomeAFlightResponse() {
        assertEquals("https://localhost/watch.html?_rsc=1", map("https://localhost/watch?_rsc=1", true));
        assertEquals("https://localhost/watch.html?x_rsc=1", map("https://localhost/watch?x_rsc=1", false));
    }

    @Test public void doesNotRewriteRemotePrivateAlternateOriginOrUnknownResources() {
        for (String original : new String[] {
            "https://cdn.example/watch", "https://localhost.evil.example/watch", "http://localhost/watch",
            "https://localhost:8080/watch", "https://user:pass@localhost/watch", "capacitor://localhost/watch",
            "https://127.0.0.1/watch", "https://localhost/watch.html", "https://localhost/_next/chunk.js",
            "https://localhost/unknown", "https://localhost//watch", "https://localhost/w%61tch",
            "https://localhost/watch/../live", "not a URL"
        }) assertEquals(original, map(original, true));
    }

    @Test public void keepsNormalRootAndNonGetRequestsUnderCapacitorControl() {
        assertEquals("https://localhost/", map("https://localhost/", true));
        assertEquals("https://localhost/watch", LocalRouteMapper.map("https://localhost/watch", "POST", true, null));
        assertEquals("https://localhost/watch", LocalRouteMapper.map("https://localhost/watch", null, true, null));
        assertEquals(null, map(null, true));
    }

    @Test public void recognizesOnlyBundledFlightAssetsForResponseMimeCorrection() {
        assertTrue(LocalRouteMapper.isFlightAsset("https://localhost/watch.txt?_rsc=1"));
        assertTrue(LocalRouteMapper.isFlightAsset("https://localhost/index.txt"));
        assertFalse(LocalRouteMapper.isFlightAsset("https://cdn.example/watch.txt"));
        assertFalse(LocalRouteMapper.isFlightAsset("http://localhost/watch.txt"));
        assertFalse(LocalRouteMapper.isFlightAsset("https://localhost/unknown.txt"));
        assertFalse(LocalRouteMapper.isFlightAsset("https://localhost/user-data/watch.txt"));
    }
}
