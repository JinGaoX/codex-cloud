package org.libretv.personal;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;

public class ExternalUrlPolicyTest {
    @Test public void permitsPublicHttpsReleaseLinksWithoutChangingQueries() {
        assertTrue(ExternalUrlPolicy.allows("https://github.com/JinGaoX/codex-cloud/releases/download/android-1/PPS.apk?download=1"));
        assertTrue(ExternalUrlPolicy.allows("https://jingaox.github.io/codex-cloud/?version=1#install"));
        assertTrue(ExternalUrlPolicy.allows("https://8.8.8.8/app.apk"));
    }

    @Test public void rejectsSchemesCredentialsAndMalformedUrls() {
        for (String value : new String[] {
            "http://github.com/app.apk", "file:///sdcard/app.apk", "intent://install", "javascript:alert(1)",
            "https://user:password@github.com/app.apk", "https://@github.com/app.apk", "https://github.com:99999/app.apk",
            " https://github.com/app.apk", "https://github.com/app.apk\n", "https://bad host/app.apk", ""
        }) assertFalse(value, ExternalUrlPolicy.allows(value));
        assertFalse(ExternalUrlPolicy.allows(null));
    }

    @Test public void rejectsLocalAndReservedIpLiteralForms() {
        for (String host : new String[] {
            "127.0.0.1", "10.0.0.1", "192.168.100.1", "172.16.0.1", "169.254.1.1", "100.64.0.1",
            "0.0.0.0", "198.18.0.1", "224.0.0.1", "255.255.255.255", "2130706433", "127.1",
            "0177.0.0.1", "0x7f.0.0.1", "0x7f000001", "[::1]", "[fd00::1]", "[::ffff:127.0.0.1]"
        }) assertFalse(host, ExternalUrlPolicy.allows("https://" + host + "/app.apk"));
    }

    @Test public void rejectsLocalHostnamesAndInvalidLabels() {
        for (String host : new String[] {"localhost", "router.local", "router.lan", "device.internal", "-bad.example.com", "bad..example.com"}) {
            assertFalse(host, ExternalUrlPolicy.allows("https://" + host + "/app.apk"));
        }
    }
}
