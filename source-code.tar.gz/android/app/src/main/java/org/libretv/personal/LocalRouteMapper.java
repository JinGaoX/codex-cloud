package org.libretv.personal;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Map;

/** Exact local static routes only; never rewrites a remote media/API request. */
public final class LocalRouteMapper {
    private LocalRouteMapper() {}

    public static String map(String rawUrl, String method, boolean mainFrame, Map<String, String> headers) {
        if (rawUrl == null || !"GET".equalsIgnoreCase(method)) return rawUrl;
        try {
            URI uri = new URI(rawUrl);
            if (!isLocal(uri)) return rawUrl;
            boolean rsc = !mainFrame && (hasRscQuery(uri.getRawQuery()) || hasRscHeader(headers));
            String resource;
            switch (uri.getRawPath()) {
                case "/watch": case "/watch/": resource = "watch"; break;
                case "/live": case "/live/": resource = "live"; break;
                case "/library": case "/library/": resource = "library"; break;
                case "/about": case "/about/": resource = "about"; break;
                case "/": case "":
                    if (!rsc) return rawUrl;
                    resource = "index";
                    break;
                default: return rawUrl;
            }
            // Build from already-encoded URI components: the multi-argument URI
            // constructor would escape '%' again and corrupt signed query URLs.
            return uri.getScheme() + "://" + uri.getRawAuthority() + "/" + resource + (rsc ? ".txt" : ".html")
                + (uri.getRawQuery() == null ? "" : "?" + uri.getRawQuery())
                + (uri.getRawFragment() == null ? "" : "#" + uri.getRawFragment());
        } catch (URISyntaxException | IllegalArgumentException error) {
            return rawUrl;
        }
    }

    /** Static-export navigation can request the .txt URL directly as well. */
    public static boolean isFlightAsset(String rawUrl) {
        if (rawUrl == null) return false;
        try {
            URI uri = new URI(rawUrl);
            if (!isLocal(uri)) return false;
            String path = uri.getRawPath();
            return "/index.txt".equals(path) || "/watch.txt".equals(path) || "/live.txt".equals(path)
                || "/library.txt".equals(path) || "/about.txt".equals(path);
        } catch (URISyntaxException | IllegalArgumentException error) {
            return false;
        }
    }

    private static boolean isLocal(URI uri) {
        return "https".equalsIgnoreCase(uri.getScheme()) && "localhost".equalsIgnoreCase(uri.getHost())
            && uri.getRawUserInfo() == null && (uri.getPort() == -1 || uri.getPort() == 443);
    }

    private static boolean hasRscQuery(String query) {
        if (query == null) return false;
        for (String pair : query.split("&")) {
            if (pair.equals("_rsc") || pair.startsWith("_rsc=")) return true;
        }
        return false;
    }

    private static boolean hasRscHeader(Map<String, String> headers) {
        if (headers == null) return false;
        for (Map.Entry<String, String> header : headers.entrySet()) {
            if ("RSC".equalsIgnoreCase(header.getKey()) && "1".equals(header.getValue())) return true;
        }
        return false;
    }
}
