package org.libretv.personal;

import android.app.Activity;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.FrameLayout;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import com.getcapacitor.Bridge;
import com.getcapacitor.BridgeWebChromeClient;

/** Add fullscreen without replacing Capacitor's file picker or permission callbacks. */
public final class PpsWebChromeClient extends BridgeWebChromeClient {
    public interface FullscreenStateListener { void onFullscreenChanged(boolean active); }

    private final Activity activity;
    private final WebView webView;
    private final FullscreenStateListener listener;
    private View customView;
    private FrameLayout overlay;
    private CustomViewCallback customViewCallback;
    private int previousWebVisibility;
    private boolean previousWebFocus;
    private boolean previousKeepScreenOn;
    private boolean previousStatusVisible;
    private boolean previousNavigationVisible;
    private boolean previousCaptionVisible;
    private boolean previousLightStatus;
    private boolean previousLightNavigation;
    private int previousBarsBehavior;

    public PpsWebChromeClient(Bridge bridge, Activity activity, FullscreenStateListener listener) {
        // The constructor registers ActivityResult launchers. MainActivity calls
        // this while BridgeActivity.onCreate is loading, before STARTED.
        super(bridge);
        this.activity = activity;
        this.webView = bridge.getWebView();
        this.listener = listener;
    }

    @Override
    public void onShowCustomView(View view, CustomViewCallback callback) {
        if (callback == null) return;
        if (view == null) { callback.onCustomViewHidden(); return; }
        if (customView != null || activity.isFinishing() || activity.isDestroyed() || view.getParent() != null) {
            callback.onCustomViewHidden();
            return;
        }
        Window window = activity.getWindow();
        View decor = window.getDecorView();
        if (!(decor instanceof ViewGroup)) { callback.onCustomViewHidden(); return; }
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, decor);
        WindowInsetsCompat insets = ViewCompat.getRootWindowInsets(decor);
        previousStatusVisible = insets == null || insets.isVisible(WindowInsetsCompat.Type.statusBars());
        previousNavigationVisible = insets == null || insets.isVisible(WindowInsetsCompat.Type.navigationBars());
        previousCaptionVisible = insets != null && insets.isVisible(WindowInsetsCompat.Type.captionBar());
        previousBarsBehavior = controller.getSystemBarsBehavior();
        previousLightStatus = controller.isAppearanceLightStatusBars();
        previousLightNavigation = controller.isAppearanceLightNavigationBars();
        previousKeepScreenOn = (window.getAttributes().flags & WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) != 0;
        previousWebVisibility = webView.getVisibility();
        previousWebFocus = webView.hasFocus();
        customView = view;
        customViewCallback = callback;
        overlay = new FrameLayout(activity);
        overlay.setBackgroundColor(Color.BLACK);
        overlay.setKeepScreenOn(true);
        overlay.setFocusableInTouchMode(true);
        try {
            overlay.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            ((ViewGroup) decor).addView(overlay, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            webView.setVisibility(View.INVISIBLE);
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            keepFullscreenBarsHidden();
            overlay.requestFocus();
            listener.onFullscreenChanged(true);
        } catch (RuntimeException error) {
            onHideCustomView();
        }
        // Do not call BridgeWebChromeClient's implementation: it immediately
        // closes the view. The original WebView and player stay alive underneath.
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onShowCustomView(View view, int requestedOrientation, CustomViewCallback callback) {
        // Respect the user's current rotation rather than locking a tablet.
        onShowCustomView(view, callback);
    }

    public void keepFullscreenBarsHidden() {
        if (customView == null) return;
        Window window = activity.getWindow();
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, window.getDecorView());
        controller.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        controller.hide(WindowInsetsCompat.Type.systemBars());
    }

    @Override
    public void onHideCustomView() {
        if (customView == null) return;
        FrameLayout oldOverlay = overlay;
        CustomViewCallback callback = customViewCallback;
        customView = null;
        overlay = null;
        customViewCallback = null;
        listener.onFullscreenChanged(false);
        if (oldOverlay != null) {
            oldOverlay.removeAllViews();
            if (oldOverlay.getParent() instanceof ViewGroup) ((ViewGroup) oldOverlay.getParent()).removeView(oldOverlay);
        }
        webView.setVisibility(previousWebVisibility);
        Window window = activity.getWindow();
        if (!previousKeepScreenOn) window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(window, window.getDecorView());
        controller.setSystemBarsBehavior(previousBarsBehavior);
        controller.setAppearanceLightStatusBars(previousLightStatus);
        controller.setAppearanceLightNavigationBars(previousLightNavigation);
        if (previousStatusVisible) controller.show(WindowInsetsCompat.Type.statusBars());
        else controller.hide(WindowInsetsCompat.Type.statusBars());
        if (previousNavigationVisible) controller.show(WindowInsetsCompat.Type.navigationBars());
        else controller.hide(WindowInsetsCompat.Type.navigationBars());
        if (previousCaptionVisible) controller.show(WindowInsetsCompat.Type.captionBar());
        else controller.hide(WindowInsetsCompat.Type.captionBar());
        ViewCompat.requestApplyInsets(window.getDecorView());
        if (previousWebFocus && !activity.isFinishing() && !activity.isDestroyed()) webView.requestFocus();
        try { if (callback != null) callback.onCustomViewHidden(); }
        catch (RuntimeException ignored) { /* The renderer may already have closed its view. */ }
    }
}
