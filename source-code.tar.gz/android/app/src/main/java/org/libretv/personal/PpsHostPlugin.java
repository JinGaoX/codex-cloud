package org.libretv.personal;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebBackForwardList;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/** Minimal external HTTPS handoff; it does not download or silently install APKs. */
@CapacitorPlugin(name = "PpsHost")
public final class PpsHostPlugin extends Plugin {
    /** Current index only: App.canGoBack may skip SPA entries after reload. */
    @PluginMethod
    public void getNavigationState(PluginCall call) {
        Activity activity = getActivity();
        if (activity == null) {
            call.reject("应用已退出，请重新打开", "ACTIVITY_UNAVAILABLE");
            return;
        }
        activity.runOnUiThread(() -> {
            if (activity.isFinishing() || activity.isDestroyed() || getBridge().getWebView() == null) {
                call.reject("应用已退出，请重新打开", "ACTIVITY_UNAVAILABLE");
                return;
            }
            WebBackForwardList history = getBridge().getWebView().copyBackForwardList();
            JSObject result = new JSObject();
            result.put("historyIndex", history.getCurrentIndex());
            call.resolve(result);
        });
    }

    @PluginMethod
    public void openExternal(PluginCall call) {
        String url = call.getString("url");
        if (!ExternalUrlPolicy.allows(url)) {
            call.reject("仅允许不含账号密码的公网 HTTPS 地址", "URL_NOT_ALLOWED");
            return;
        }
        Activity activity = getActivity();
        if (activity == null) {
            call.reject("应用已退出，请重新打开", "ACTIVITY_UNAVAILABLE");
            return;
        }
        activity.runOnUiThread(() -> {
            if (activity.isFinishing() || activity.isDestroyed()) {
                call.reject("应用已退出，请重新打开", "ACTIVITY_UNAVAILABLE");
                return;
            }
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                activity.startActivity(intent);
                call.resolve();
            } catch (ActivityNotFoundException | SecurityException error) {
                call.reject("没有可用的外部浏览器", "BROWSER_UNAVAILABLE");
            }
        });
    }
}
