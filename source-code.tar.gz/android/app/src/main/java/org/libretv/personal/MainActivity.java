package org.libretv.personal;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    private PpsWebChromeClient ppsChromeClient;
    private OnBackPressedCallback fullscreenBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        registerPlugin(PpsHostPlugin.class);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void load() {
        // Run before Bridge creates SystemBars and installs its inset listener.
        EdgeToEdge.enable(this);
        super.load();
        if (bridge == null) return;

        bridge.setWebViewClient(new PpsWebViewClient(bridge));
        fullscreenBack = new OnBackPressedCallback(false) {
            @Override
            public void handleOnBackPressed() {
                if (ppsChromeClient != null) ppsChromeClient.onHideCustomView();
            }
        };
        // App's callback was registered while Bridge loaded its plugins. This
        // later callback is enabled only for a native fullscreen view; all other
        // back presses therefore continue to Capacitor App's existing handler.
        getOnBackPressedDispatcher().addCallback(this, fullscreenBack);
        ppsChromeClient = new PpsWebChromeClient(bridge, this, active -> fullscreenBack.setEnabled(active));
        bridge.getWebView().setWebChromeClient(ppsChromeClient);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && ppsChromeClient != null) ppsChromeClient.keepFullscreenBarsHidden();
    }

    @Override
    public void onDestroy() {
        if (ppsChromeClient != null) ppsChromeClient.onHideCustomView();
        if (fullscreenBack != null) fullscreenBack.remove();
        super.onDestroy();
    }
}
