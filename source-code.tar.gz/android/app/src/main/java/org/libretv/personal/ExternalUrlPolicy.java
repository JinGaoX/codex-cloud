package org.libretv.personal;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;

/** Browser handoff only: no custom schemes, credentials, or local IP literals. */
public final class ExternalUrlPolicy {
    private ExternalUrlPolicy() {}

    public static boolean allows(String value) {
        if (value == null || value.length() > 8192 || !value.equals(value.trim())) return false;
        try {
            URI uri = new URI(value);
            String host = uri.getHost();
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getRawUserInfo() != null || host == null
                || (uri.getPort() != -1 && (uri.getPort() < 1 || uri.getPort() > 65535))) return false;
            host = host.toLowerCase(Locale.ROOT);
            if (host.endsWith(".")) host = host.substring(0, host.length() - 1);
            // IPv6 and noncanonical browser numeric forms are intentionally not
            // supported by this small external-update URL surface.
            if (host.contains(":") || !host.contains(".") || host.matches("[0-9.]+") && !publicIpv4(host)) return false;
            if (host.matches("[0-9.]+")) return true;
            if (host.matches("(?i)(?:0x[0-9a-f]+|[0-9]+)(?:\\.(?:0x[0-9a-f]+|[0-9]+))+")) return false;
            if (!host.matches("[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?")) return false;
            for (String suffix : new String[] {"localhost", "local", "internal", "lan", "home", "test", "invalid", "example"}) {
                if (host.equals(suffix) || host.endsWith("." + suffix)) return false;
            }
            for (String label : host.split("\\.", -1)) {
                if (label.isEmpty() || label.length() > 63 || label.startsWith("-") || label.endsWith("-")) return false;
            }
            return true;
        } catch (URISyntaxException | IllegalArgumentException error) {
            return false;
        }
    }

    private static boolean publicIpv4(String host) {
        String[] parts = host.split("\\.", -1);
        if (parts.length != 4) return false;
        int[] octets = new int[4];
        for (int i = 0; i < 4; i++) {
            if (parts[i].length() > 1 && parts[i].startsWith("0")) return false;
            try { octets[i] = Integer.parseInt(parts[i]); }
            catch (NumberFormatException error) { return false; }
            if (octets[i] < 0 || octets[i] > 255) return false;
        }
        int a = octets[0], b = octets[1], c = octets[2];
        return !(a == 0 || a == 10 || a == 127 || a >= 224
            || (a == 100 && b >= 64 && b <= 127) || (a == 169 && b == 254)
            || (a == 172 && b >= 16 && b <= 31) || (a == 192 && (b == 0 || b == 168))
            || (a == 198 && (b == 18 || b == 19 || b == 51)) || (a == 203 && b == 0 && c == 113));
    }
}
