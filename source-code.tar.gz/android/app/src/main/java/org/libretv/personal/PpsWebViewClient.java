package org.libretv.personal;

import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import com.getcapacitor.Bridge;
import com.getcapacitor.BridgeWebViewClient;
import java.util.LinkedHashMap;
import java.util.Map;

/** Keep Capacitor's bridge injection and navigation handling around static Next pages. */
public final class PpsWebViewClient extends BridgeWebViewClient {
    public PpsWebViewClient(Bridge bridge) {
        super(bridge);
    }

    @Override
    public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        String original = request.getUrl().toString();
        String mapped = LocalRouteMapper.map(original, request.getMethod(), request.isForMainFrame(), request.getRequestHeaders());
        WebResourceRequest servedRequest = original.equals(mapped) ? request : new MappedRequest(request, Uri.parse(mapped));
        WebResourceResponse response = super.shouldInterceptRequest(view, servedRequest);
        if (response != null && LocalRouteMapper.isFlightAsset(mapped)) {
            // Next's router must receive a Flight response, not a generic text
            // asset that it would mistake for a document navigation fallback.
            response.setMimeType("text/x-component");
            response.setEncoding("UTF-8");
            Map<String, String> headers = response.getResponseHeaders() == null
                ? new LinkedHashMap<>() : new LinkedHashMap<>(response.getResponseHeaders());
            headers.put("Content-Type", "text/x-component; charset=utf-8");
            response.setResponseHeaders(headers);
        }
        return response;
    }

    private static final class MappedRequest implements WebResourceRequest {
        private final WebResourceRequest original;
        private final Uri url;

        MappedRequest(WebResourceRequest original, Uri url) { this.original = original; this.url = url; }
        @Override public Uri getUrl() { return url; }
        @Override public boolean isForMainFrame() { return original.isForMainFrame(); }
        @Override public boolean isRedirect() { return original.isRedirect(); }
        @Override public boolean hasGesture() { return original.hasGesture(); }
        @Override public String getMethod() { return original.getMethod(); }
        @Override public Map<String, String> getRequestHeaders() { return original.getRequestHeaders(); }
    }
}
