package org.libretv.personal;

import static org.junit.Assert.*;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import androidx.test.core.app.ActivityScenario;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;
import com.getcapacitor.Bridge;
import com.getcapacitor.BridgeWebViewClient;
import com.getcapacitor.Plugin;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.junit.runner.RunWith;

/** Runs against the signed release APK on a disposable Android emulator only. */
@RunWith(AndroidJUnit4.class)
public class PpsReleaseIntegrationTest {
    private static final String SOURCE_NAME = "QA Android public sample";
    private static final String SOURCE_URL = "https://pps-android-qa.example.net/api.php/provide/vod";
    private static final String SAMPLE_TITLE = "PPS Android QA public sample";
    private static final String SAMPLE_HLS = "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8";
    private static final String JS_HELPERS = "const visible=e=>!!e&&e.getBoundingClientRect().width>0&&e.getBoundingClientRect().height>0&&getComputedStyle(e).visibility!=='hidden';"
        + "const pick=(selector,label,scope=document)=>[...scope.querySelectorAll(selector)].find(e=>visible(e)&&((e.getAttribute('aria-label')||'').trim()===label||(e.innerText||'').trim()===label));"
        + "const click=(selector,label,scope=document)=>{const e=pick(selector,label,scope);if(!e)throw new Error('Missing visible control: '+label);e.click();return true;};"
        + "const setInput=(e,value)=>{if(!e)throw new Error('Missing input');Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set.call(e,value);e.dispatchEvent(new Event('input',{bubbles:true}));};";
    private ActivityScenario<MainActivity> scenario;
    private JSONObject report;
    private JSONArray checkpoints;
    private File output;
    @Rule public TestName testName = new TestName();

    @Before public void launchRelease() throws Exception {
        Context target = InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertEquals("org.libretv.personal", target.getPackageName());
        PackageInfo info = target.getPackageManager().getPackageInfo(target.getPackageName(), 0);
        report = new JSONObject().put("test", testName.getMethodName()).put("versionName", info.versionName)
            .put("versionCode", info.getLongVersionCode()).put("completed", false)
            .put("cms", "Instrumentation-only fixture; not proof of public Mango API search")
            .put("media", SAMPLE_HLS);
        checkpoints = new JSONArray();
        report.put("checkpoints", checkpoints);
        output = target.getExternalFilesDir("pps-release-qa");
        assertNotNull(output);
        assertTrue(output.isDirectory() || output.mkdirs());
        Intent intent = new Intent(target, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        scenario = ActivityScenario.launch(intent);
        scenario.onActivity(activity -> {
            Bridge bridge = activity.getBridge();
            assertNotNull(bridge);
            WebView web = bridge.getWebView();
            assertTrue("Document-start error collection unavailable", WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT));
            WebViewCompat.addDocumentStartJavaScript(web,
                "window.__ppsQa={errors:[],docId:Date.now()+Math.random()};window.addEventListener('error',e=>{if(e.message)window.__ppsQa.errors.push(String(e.message).slice(0,240))});window.addEventListener('unhandledrejection',e=>window.__ppsQa.errors.push(String(e.reason?.message||e.reason).slice(0,240)));",
                Collections.singleton("https://localhost"));
            bridge.setWebViewClient(new FixtureClient(bridge, bridge.getWebViewClient()));
            web.loadUrl("https://localhost/");
        });
        waitJs("home boot", "location.pathname==='/'&&document.querySelector('input[aria-label=\"搜索影片\"]')&&document.documentElement.dataset.androidNative==='true'", 30000);
        waitPageReady();
        checkpoint("home");
        screenshot("home");
    }

    @After public void saveEvidenceAndClose() throws Exception {
        if (report != null && output != null) {
            try { report.put("final", state()); screenshot("final"); } catch (Throwable error) { report.put("captureError", error.getClass().getSimpleName()); }
            try (FileOutputStream stream = new FileOutputStream(new File(output, testName.getMethodName() + ".json"))) {
                stream.write(report.toString(2).getBytes(StandardCharsets.UTF_8));
            }
        }
        if (scenario != null) scenario.close();
    }

    @Test(timeout = 180000) public void coreBootRoutesSourcesBackAndUpdate() throws Exception {
        Object firstDocument = eval("return window.__ppsQa.docId;");
        eval("const a=[...document.querySelectorAll('a')].find(e=>visible(e)&&/\\/live\\/?$/.test(e.getAttribute('href')||''));if(!a)throw new Error('Missing live navigation');a.click();return true;");
        waitJs("live client navigation", "/^\\/live\\/?$/.test(location.pathname)&&document.querySelector('main')&&!document.body.innerText.includes('直播暂不可用')", 20000);
        assertEquals("Live navigation must use the shared client router", firstDocument, eval("return window.__ppsQa.docId;"));
        checkpoint("live-client-route");
        reload();
        waitJs("live reload", "/^\\/live\\/?$/.test(location.pathname)&&document.querySelector('main')&&!document.body.innerText.includes('直播暂不可用')", 20000);
        checkpoint("live-reload");
        screenshot("live");
        eval("window.Capacitor.nativePromise('App','getInfo',{}).then(i=>window.__ppsQa.hostInfo=i);return true;");
        waitJs("host bridge after reload", "window.__ppsQa.hostInfo", 10000);
        AtomicReference<JSONObject> history = new AtomicReference<>();
        scenario.onActivity(activity -> {
            android.webkit.WebBackForwardList entries = activity.getBridge().getWebView().copyBackForwardList();
            JSONObject info = new JSONObject();
            try {
                JSONArray urls = new JSONArray();
                for (int index = 0; index < entries.getSize(); index++) urls.put(entries.getItemAtIndex(index).getUrl());
                info.put("nativeCanGoBack", activity.getBridge().getWebView().canGoBack()).put("index", entries.getCurrentIndex()).put("urls", urls);
            } catch (Exception error) { throw new AssertionError(error); }
            history.set(info);
        });
        report.put("beforeLiveBackNative", history.get());
        report.put("beforeLiveBackJs", state());
        pressBack();
        SystemClock.sleep(500);
        report.put("afterLiveBackJs", state());
        waitJs("native back from live", "location.pathname==='/'&&document.querySelector('input[aria-label=\"搜索影片\"]')", 15000);

        openSettings();
        clickTab("片源管理");
        clickTab("点播源");
        ensureSource();
        pressBack();
        waitJs("back closes settings without exiting", "!document.querySelector('[role=\"dialog\"]')&&location.pathname==='/'", 10000);
        reload();
        waitJs("home after source reload", "location.pathname==='/'&&document.querySelector('input[aria-label=\"搜索影片\"]')", 20000);
        openSettings();
        clickTab("片源管理");
        clickTab("点播源");
        assertTrue((Boolean) eval("return document.querySelector('[role=\"dialog\"]').innerText.includes(" + JSONObject.quote(SOURCE_NAME) + ");"));
        checkpoint("source-persists-after-reload");
        clickTab("数据");
        clickTab("应用更新");
        eval("window.Capacitor.nativePromise('App','getInfo',{}).then(i=>window.__ppsQa.hostInfo=i).catch(e=>window.__ppsQa.hostError=String(e));return true;");
        waitJs("native package version", "window.__ppsQa.hostInfo&&window.__ppsQa.hostInfo.build", 12000);
        JSONObject host = (JSONObject) eval("return window.__ppsQa.hostInfo;");
        assertEquals(report.getLong("versionCode"), Long.parseLong(host.getString("build")));
        assertEquals(report.getString("versionName"), host.getString("version"));
        waitJs("installed version shown by settings", "document.querySelector('[role=\"dialog\"]').innerText.includes(" + JSONObject.quote(host.getString("version")) + ")", 10000);
        report.put("installedAppGetInfo", host);
        eval("return click('button','检查更新',document.querySelector('[role=\"dialog\"]')); ");
        waitJs("update check settles", "(()=>{const d=document.querySelector('[role=\"dialog\"]');return d&&!d.innerText.includes('正在检查')&&!!pick('button','检查更新',d)&&!pick('button','检查更新',d).disabled&&!!d.querySelector('[role=\"status\"]')})()", 14000);
        report.put("updateMessage", eval("return document.querySelector('[role=\"dialog\"] [role=\"status\"]').innerText;"));
        checkpoint("update-settled-with-installed-version");
        screenshot("update");
        report.put("completed", true);
    }

    @Test(timeout = 240000) public void fixtureSearchRealHlsWatchReloadAndFullscreen() throws Exception {
        openSettings();
        clickTab("片源管理");
        clickTab("点播源");
        ensureSource();
        pressBack();
        waitJs("settings dismissed", "!document.querySelector('[role=\"dialog\"]')", 10000);
        eval("const e=document.querySelector('input[aria-label=\"搜索影片\"]');setInput(e," + JSONObject.quote(SAMPLE_TITLE) + ");return true;");
        eval("document.querySelector('input[aria-label=\"搜索影片\"]').closest('form').requestSubmit();return true;");
        waitJs("fixture CMS search result", "[...document.querySelectorAll('[role=\"button\"]')].some(e=>e.innerText.includes(" + JSONObject.quote(SAMPLE_TITLE) + "))", 20000);
        eval("[...document.querySelectorAll('[role=\"button\"]')].find(e=>e.innerText.includes(" + JSONObject.quote(SAMPLE_TITLE) + ")).click();return true;");
        waitJs("fixture detail episodes", "document.querySelector('[role=\"dialog\"] button[aria-label^=\"第1集\"]')", 20000);
        Object previousDoc = eval("return window.__ppsQa.docId;");
        eval("document.querySelector('[role=\"dialog\"] button[aria-label^=\"第1集\"]').click();return true;");
        waitJs("watch client route", "/^\\/watch\\/?$/.test(location.pathname)&&document.querySelector('video')", 20000);
        assertEquals("Watch navigation must retain the shared document", previousDoc, eval("return window.__ppsQa.docId;"));
        checkpoint("watch-client-route");
        reload();
        waitJs("watch reload retains player route", "/^\\/watch\\/?$/.test(location.pathname)&&document.querySelector('video')", 20000);
        waitJs("public HLS metadata", "(()=>{const v=document.querySelector('video');return !!v&&v.readyState>=2&&v.videoWidth>0&&!v.error})()", 60000);
        eval("const v=document.querySelector('video');v.muted=true;v.play().catch(()=>{});return true;");
        Object playButton = eval("const b=pick('button','点击播放视频');return b?true:false;");
        if (Boolean.TRUE.equals(playButton)) tapSelector("button[aria-label=\"点击播放视频\"]");
        waitJs("actual video starts", "(()=>{const v=document.querySelector('video');return !!v&&!v.paused&&v.currentTime>0.2&&v.videoWidth>0&&!v.error})()", 30000);
        double start = ((Number) eval("return document.querySelector('video').currentTime;")).doubleValue();
        waitJs("actual playback time advances", "document.querySelector('video').currentTime>" + (start + 0.7), 15000);
        JSONObject playing = (JSONObject) eval("const v=document.querySelector('video');return {time:v.currentTime,width:v.videoWidth,height:v.videoHeight,duration:v.duration,paused:v.paused,error:v.error?{code:v.error.code,message:v.error.message}:null,src:v.currentSrc};");
        report.put("realHlsPlayback", playing);
        checkpoint("real-public-hls-playing");
        eval("window.__ppsQaVideo=document.querySelector('video');window.__ppsQaVideo.pause();return true;");
        screenshot("playing");
        tapSelector(".art-control-fullscreen");
        waitNativeFullscreen(true);
        screenshot("fullscreen");
        pressBack();
        waitNativeFullscreen(false);
        assertTrue((Boolean) eval("return window.__ppsQaVideo===document.querySelector('video')&&/^\\/watch\\/?$/.test(location.pathname);"));
        checkpoint("fullscreen-back-preserves-video-instance");
        report.put("completed", true);
    }

    @Test(timeout = 120000) public void compactHomeLayoutAndNavigation() throws Exception {
        openSettings(); clickTab("片源管理"); clickTab("点播源"); ensureSource(); pressBack();
        eval("window.__ppsSeed=false;const r=indexedDB.open('libretv');r.onsuccess=()=>{const d=r.result;const t=d.transaction('history','readwrite');['疯狂动物城4K','楚门的世界','阿甘正传','星际穿越','盗梦空间'].forEach((title,i)=>t.objectStore('history').put({id:'qa-ui_'+i,sourceKey:'qa-ui',sourceUrl:" + JSONObject.quote(SOURCE_URL) + ",vodId:String(i),title,pic:'https://localhost/posters/platform/'+['poster-d75ccfc268b4dc32ee7139c0.webp','poster-35a41ca44c016fbc0bed145d.webp','poster-c69e26715ffe4782a1f8b40f.webp','poster-65fa3d98c0884c60ef0106df.webp','poster-065da94d05602473c985dfca.webp'][i],episodeIndex:0,totalEpisodes:1,playbackPosition:177+i*60,duration:6512,timestamp:Date.now()-i*1000}));t.oncomplete=()=>{d.close();window.__ppsSeed=true;};t.onerror=()=>{window.__ppsSeedError=String(t.error);};};return true;");
        waitJs("layout history fixture", "window.__ppsSeed", 10000); reload();
        waitJs("resume and library", "document.querySelectorAll('.home-resume-card').length===4&&document.querySelectorAll('.library-poster').length>=6", 20000);
        waitJs("covers rendered", "[...document.querySelectorAll('.library-poster-image')].slice(0,6).every(e=>e.complete&&e.naturalWidth>0)", 15000);
        eval("window.scrollTo(0,0);return true;"); SystemClock.sleep(300);
        JSONObject layout = (JSONObject) eval("const box=s=>{const e=document.querySelector(s);if(!e)return null;const r=e.getBoundingClientRect();return{x:r.x,y:r.y,w:r.width,h:r.height,display:getComputedStyle(e).display}};const cards=[...document.querySelectorAll('.library-poster-art')].slice(0,7).map(e=>{const r=e.getBoundingClientRect();return{x:r.x,y:r.y,w:r.width,h:r.height}});return{width:innerWidth,height:innerHeight,overflow:document.documentElement.scrollWidth-innerWidth,rail:box('.home-sidebar'),brand:box('.home-sidebar-brand img'),search:box('.home-header-search'),hero:box('.home-spotlight'),heroCopy:box('.home-spotlight-copy'),continue:box('.home-continue'),discovery:box('.library-embedded'),grid:box('.library-poster-grid'),cards,labels:[...document.querySelectorAll('.home-sidebar-label')].map(e=>({text:e.textContent,display:getComputedStyle(e).display,width:e.getBoundingClientRect().width})),collapse:!!document.querySelector('.home-sidebar-toggle,.home-sidebar-scrim'),columns:getComputedStyle(document.querySelector('.library-poster-grid')).gridTemplateColumns,portraitTabs:box('.vip-bottom-nav')};");
        report.put("layout", layout); assertFalse("No sidebar collapse or overlay",layout.getBoolean("collapse"));
        assertTrue("No viewport overflow",layout.getDouble("overflow")<=1);
        boolean landscape = (Boolean) eval("return matchMedia('(min-width:1000px) and (orientation:landscape)').matches;");
        if (landscape) {
            assertEquals(176,layout.getJSONObject("rail").getDouble("w"),1);
            assertEquals(32,layout.getJSONObject("brand").getDouble("w"),1);
            assertEquals(layout.getJSONObject("search").getDouble("x"),layout.getJSONObject("heroCopy").getDouble("x"),1);
            assertEquals(layout.getJSONObject("search").getDouble("x"),layout.getJSONObject("grid").getDouble("x"),1);
            assertTrue("Compact resume hero",layout.getJSONObject("hero").getDouble("h")<=260);
            JSONArray labels=layout.getJSONArray("labels"); for(int i=0;i<labels.length();i++)assertTrue("Permanent text label",labels.getJSONObject(i).getDouble("width")>0);
            if(layout.getInt("width")==1280)assertEquals("Six catalog columns",6,layout.getString("columns").trim().split(" +").length);
            assertTrue("Posters visible on first screen",layout.getJSONObject("grid").getDouble("y")<layout.getInt("height")-100);
        } else { assertEquals("none",layout.getJSONObject("rail").getString("display")); assertFalse("Phone bottom navigation remains",layout.getJSONObject("portraitTabs").getString("display").equals("none")); }
        JSONArray cards=layout.getJSONArray("cards"); for(int i=0;i<cards.length();i++)assertEquals("Natural poster ratio",1.5,cards.getJSONObject(i).getDouble("h")/cards.getJSONObject(i).getDouble("w"),0.02);
        screenshot("compact-home"); checkpoint("compact-home-layout");
        eval("document.querySelector('.library-filters summary').click();return true;"); waitJs("filters expand","document.querySelector('.library-filters[open]')",5000); screenshot("filters-open");
        eval("document.querySelector('.library-filters summary').click();const s=document.querySelector('select[aria-label=\"排序\"]');s.value='T';s.dispatchEvent(new Event('change',{bubbles:true}));return true;");
        waitJs("sort retains state","document.querySelector('select[aria-label=\"排序\"]').value==='T'",10000);
        eval("return click('button','我的收藏');");waitJs("favorites open","document.querySelector('[role=\"dialog\"]')",10000);pressBack();
        if(landscape){eval("return click('button','发现电视剧');");waitJs("TV category selected","document.querySelector('.home-sidebar-categories button[aria-label=\"发现电视剧\"][aria-current]')",10000);}
        checkpoint("home-controls-work"); report.put("completed",true);
    }

    private void openSettings() throws Exception {
        waitPageReady();
        eval("const b=pick('button','设置');if(b){b.click();return true;}click('summary','更多功能');return click('button','设置',document.querySelector('details[open]')); ");
        waitJs("settings drawer", "!!document.querySelector('[role=\"dialog\"]')&&document.querySelector('[role=\"dialog\"]').innerText.includes('片源管理')", 10000);
    }

    private void clickTab(String label) throws Exception {
        eval("return click('[role=\"tab\"]'," + JSONObject.quote(label) + ",document.querySelector('[role=\"dialog\"]')); ");
        waitJs("tab " + label, "(()=>{const t=pick('[role=\"tab\"]'," + JSONObject.quote(label) + ",document.querySelector('[role=\"dialog\"]'));return t&&t.getAttribute('aria-selected')==='true'})()", 10000);
    }

    private void ensureSource() throws Exception {
        boolean exists = (Boolean) eval("return document.querySelector('[role=\"dialog\"]').innerText.includes(" + JSONObject.quote(SOURCE_NAME) + ");");
        report.put("sourceAlreadyPresent", exists);
        if (exists) return;
        assertFalse("Existing QA source was lost after APK overwrite", Boolean.parseBoolean(InstrumentationRegistry.getArguments().getString("ppsRequireExistingSource")));
        eval("return click('button','添加 API',document.querySelector('[role=\"dialog\"]')); ");
        waitJs("source editor", "document.querySelector('input[aria-label=\"点播源名称\"]')", 10000);
        eval("setInput(document.querySelector('input[aria-label=\"点播源名称\"]')," + JSONObject.quote(SOURCE_NAME) + ");setInput(document.querySelector('input[aria-label=\"API 地址\"]')," + JSONObject.quote(SOURCE_URL) + ");return true;");
        eval("return click('button','添加',document.querySelector('[role=\"dialog\"]')); ");
        waitJs("source saved", "!document.querySelector('input[aria-label=\"点播源名称\"]')&&document.querySelector('[role=\"dialog\"]').innerText.includes(" + JSONObject.quote(SOURCE_NAME) + ")", 10000);
    }

    private void reload() throws Exception {
        Object previousDocument = eval("return window.__ppsQa.docId;");
        scenario.onActivity(activity -> activity.getBridge().getWebView().reload());
        waitJs("new reload document", "window.__ppsQa&&window.__ppsQa.docId!==" + JSONObject.numberToString((Number) previousDocument), 30000);
        waitPageReady();
    }

    private void waitPageReady() throws Exception {
        String condition = "window.__ppsQa&&document.documentElement.dataset.androidNative==='true'&&!document.body.innerText.includes('正在准备应用')";
        waitJs("hydrated app", condition, 30000);
        // SSR markup can be briefly present before account-scope hydration.
        // Wait for the product tree and the real native subscription, not just HTML.
        SystemClock.sleep(300);
        waitJs("stable hydrated app", condition, 30000);
        java.lang.reflect.Method listeners = Plugin.class.getDeclaredMethod("hasListeners", String.class);
        listeners.setAccessible(true);
        long deadline = SystemClock.elapsedRealtime() + 10000;
        while (SystemClock.elapsedRealtime() < deadline) {
            AtomicReference<Boolean> ready = new AtomicReference<>(false);
            scenario.onActivity(activity -> {
                try { ready.set((Boolean) listeners.invoke(activity.getBridge().getPlugin("App").getInstance(), "backButton")); }
                catch (Exception error) { throw new AssertionError("Cannot inspect native back listener", error); }
            });
            if (ready.get()) return;
            SystemClock.sleep(100);
        }
        throw new AssertionError("Native back listener did not become ready");
    }

    private void pressBack() throws Exception {
        waitPageReady();
        scenario.onActivity(activity -> activity.getOnBackPressedDispatcher().onBackPressed());
    }

    private Object eval(String body) throws Exception {
        AtomicReference<String> value = new AtomicReference<>();
        CountDownLatch done = new CountDownLatch(1);
        String script = "(()=>{try{" + JS_HELPERS + "const value=(()=>{" + body + "})();return JSON.stringify({ok:true,value:value===undefined?null:value});}catch(e){return JSON.stringify({ok:false,error:String(e.message||e)})}})()";
        scenario.onActivity(activity -> activity.getBridge().getWebView().evaluateJavascript(script, result -> { value.set(result); done.countDown(); }));
        assertTrue("WebView JS callback timed out", done.await(10, TimeUnit.SECONDS));
        Object decoded = new JSONTokener(value.get()).nextValue();
        assertTrue("No active page returned JavaScript state: " + value.get(), decoded instanceof String);
        JSONObject result = new JSONObject((String) decoded);
        assertTrue("DOM operation failed: " + result.optString("error"), result.optBoolean("ok"));
        return result.opt("value");
    }

    private void waitJs(String name, String condition, long timeout) throws Exception {
        long deadline = SystemClock.elapsedRealtime() + timeout;
        while (SystemClock.elapsedRealtime() < deadline) {
            if (Boolean.TRUE.equals(eval("return Boolean(" + condition + ");"))) return;
            SystemClock.sleep(150);
        }
        throw new AssertionError(name + " timed out. " + state().toString());
    }

    private JSONObject state() throws Exception {
        return (JSONObject) eval("return {href:location.href,origin:location.origin,title:document.title,body:document.body?.innerText.slice(0,1800),width:innerWidth,height:innerHeight,android:document.documentElement.dataset.androidNative,historyLength:history.length,historyState:history.state,backEvent:window.__ppsQa?.backEvent,hostInfo:window.__ppsQa?.hostInfo,errors:window.__ppsQa?.errors||[]};");
    }

    private void checkpoint(String name) throws Exception {
        JSONObject snapshot = state().put("checkpoint", name);
        checkpoints.put(snapshot);
        assertEquals(name + " JavaScript errors: " + snapshot.getJSONArray("errors"), 0, snapshot.getJSONArray("errors").length());
        assertEquals("https://localhost", snapshot.getString("origin"));
    }

    private void screenshot(String name) throws Exception {
        Bitmap bitmap = InstrumentationRegistry.getInstrumentation().getUiAutomation().takeScreenshot();
        if (bitmap == null) return;
        try (FileOutputStream stream = new FileOutputStream(new File(output, testName.getMethodName() + "-" + name + ".png"))) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        } finally { bitmap.recycle(); }
    }

    private void tapSelector(String selector) throws Exception {
        JSONObject box = (JSONObject) eval("const e=document.querySelector(" + JSONObject.quote(selector) + ");if(!e)throw new Error('Missing tap target');e.scrollIntoView({block:'center'});const r=e.getBoundingClientRect();return{x:r.left+r.width/2,y:r.top+r.height/2,width:innerWidth};");
        AtomicReference<float[]> point = new AtomicReference<>();
        scenario.onActivity(activity -> {
            WebView web = activity.getBridge().getWebView();
            int[] location = new int[2]; web.getLocationOnScreen(location);
            float scale = web.getWidth() / (float) box.optDouble("width");
            point.set(new float[] { location[0] + (float) box.optDouble("x") * scale, location[1] + (float) box.optDouble("y") * scale });
        });
        long down = SystemClock.uptimeMillis();
        MotionEvent press = MotionEvent.obtain(down, down, MotionEvent.ACTION_DOWN, point.get()[0], point.get()[1], 0);
        MotionEvent release = MotionEvent.obtain(down, down + 80, MotionEvent.ACTION_UP, point.get()[0], point.get()[1], 0);
        try {
            InstrumentationRegistry.getInstrumentation().sendPointerSync(press);
            InstrumentationRegistry.getInstrumentation().sendPointerSync(release);
        } finally { press.recycle(); release.recycle(); }
    }

    private void waitNativeFullscreen(boolean active) {
        long deadline = SystemClock.elapsedRealtime() + 10000;
        while (SystemClock.elapsedRealtime() < deadline) {
            AtomicReference<Boolean> state = new AtomicReference<>(false);
            scenario.onActivity(activity -> state.set(activity.getBridge().getWebView().getVisibility() == View.INVISIBLE));
            if (state.get() == active) {
                if (active) scenario.onActivity(activity -> assertTrue((activity.getWindow().getAttributes().flags & WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) != 0));
                return;
            }
            SystemClock.sleep(100);
        }
        throw new AssertionError("Native fullscreen state did not become " + active);
    }

    private static final class FixtureClient extends BridgeWebViewClient {
        private final BridgeWebViewClient original;
        FixtureClient(Bridge bridge, BridgeWebViewClient original) { super(bridge); this.original = original; }
        @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            if (request.getUrl().getPath().equals("/j/new_search_subjects")) {
                String[] names={"楚门的世界","阿甘正传","星际穿越","盗梦空间","疯狂动物城","哪吒之魔童闹海"};
                String[] covers={"35a41ca44c016fbc0bed145d","c69e26715ffe4782a1f8b40f","65fa3d98c0884c60ef0106df","065da94d05602473c985dfca","d75ccfc268b4dc32ee7139c0","959be32a67d1dc7333f0efa9"};
                try {
                    JSONArray data=new JSONArray();int offset=Integer.parseInt(request.getUrl().getQueryParameter("start"));
                    for(int i=0;i<20;i++)data.put(new JSONObject().put("id",900000+offset+i).put("title",names[i%6]).put("cover","https://localhost/posters/platform/poster-"+covers[i%6]+".webp").put("rate","8.8"));
                    Map<String,String> headers=new LinkedHashMap<>();headers.put("Access-Control-Allow-Origin","https://localhost");headers.put("Cache-Control","no-store");
                    return new WebResourceResponse("application/json","UTF-8",200,"OK",headers,new ByteArrayInputStream(new JSONObject().put("data",data).toString().getBytes(StandardCharsets.UTF_8)));
                }catch(Exception error){throw new AssertionError(error);}
            }
            if (!SOURCE_URL.equals(request.getUrl().buildUpon().clearQuery().fragment(null).build().toString())) {
                return original.shouldInterceptRequest(view, request);
            }
            try {
                JSONObject item = new JSONObject().put("vod_id", 430001).put("vod_name", SAMPLE_TITLE).put("type_name", "公开测试样片")
                    .put("vod_year", "2026").put("vod_pic", "").put("vod_remarks", "2集")
                    .put("vod_play_from", "m3u8").put("vod_play_url", "公开样片1$" + SAMPLE_HLS + "#公开样片2$" + SAMPLE_HLS);
                JSONObject body = new JSONObject().put("code", 1).put("msg", "QA fixture only").put("page", 1).put("pagecount", 1).put("limit", 20).put("total", 1).put("list", new JSONArray().put(item));
                Map<String, String> headers = new LinkedHashMap<>();
                headers.put("Access-Control-Allow-Origin", "https://localhost");
                headers.put("Cache-Control", "no-store");
                return new WebResourceResponse("application/json", "UTF-8", 200, "OK", headers,
                    new ByteArrayInputStream(body.toString().getBytes(StandardCharsets.UTF_8)));
            } catch (Exception error) { throw new AssertionError("Could not create instrumentation CMS fixture", error); }
        }
    }
}
