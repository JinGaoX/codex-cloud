import { describe, expect, it } from 'vitest';
import { PLAYBACK_INFO_MAX_SAMPLES, PlaybackInfoTracker, type PlaybackSegmentSample } from './playback-info';

function segment(overrides: Partial<PlaybackSegmentSample> = {}): PlaybackSegmentSample {
  return {
    key: 'first',
    start: 0,
    duration: 10,
    level: 0,
    continuity: 0,
    bytes: 1_000_000,
    ...overrides,
  };
}

describe('PlaybackInfoTracker', () => {
  it('尚无对应播放片段时返回未知，不展示最近下载的片段', () => {
    const tracker = new PlaybackInfoTracker();
    expect(tracker.at(0)).toBeNull();
    tracker.add(segment({ start: 20 }));
    expect(tracker.at(5)).toBeNull();
    expect(tracker.at(30)).toBeNull();
  });

  it.each([NaN, Infinity, -Infinity, -1])('非法播放时间 %s 返回未知', (time) => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment());
    expect(tracker.at(time)).toBeNull();
  });

  it.each<Partial<PlaybackSegmentSample>>([
    { key: '' },
    { start: NaN }, { start: Infinity }, { start: -Infinity },
    { duration: 0 }, { duration: -1 }, { duration: NaN }, { duration: Infinity },
    { bytes: 0 }, { bytes: -1 }, { bytes: NaN }, { bytes: Infinity },
  ])('不接纳非法片段 %j', (invalid) => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment(invalid));
    expect(tracker.at(1)).toBeNull();
  });

  it('重复缓冲替换同一片段，不重复计入码率或样本数', () => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment({ bytes: 500_000 }));
    tracker.add(segment({ bytes: 2_000_000, videoCodec: 'HEVC' }));

    expect(tracker.at(5)).toMatchObject({
      bitrate: 1_600_000,
      bitrateSampleCount: 1,
      bitrateSampleSeconds: 10,
      videoCodec: 'HEVC',
    });
  });

  it('无效重试不能覆盖已有有效片段', () => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment());
    tracker.add(segment({ bytes: 0 }));
    expect(tracker.at(5)?.bitrate).toBe(800_000);
  });

  it('按媒体时长合并字节和视频样本，不对各片码率或帧率简单求平均', () => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment({ duration: 4, bytes: 1_000_000, videoSampleCount: 80, videoSampleSeconds: 4 }));
    tracker.add(segment({ key: 'second', start: 4, duration: 6, bytes: 3_000_000, videoSampleCount: 180, videoSampleSeconds: 6 }));

    const info = tracker.at(7);
    expect(info?.bitrate).toBe(3_200_000);
    expect(info?.frameRate).toBe(26);
    expect(info?.bitrateSampleCount).toBe(2);
    expect(info?.bitrateSampleSeconds).toBe(10);
  });

  it('未来缓冲不改变当前片段的码率、编码或帧率', () => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment({ videoCodec: 'H.264', audioCodec: 'AAC', videoSampleCount: 240, videoSampleSeconds: 10 }));
    const before = tracker.at(5);
    tracker.add(segment({ key: 'future', start: 100, bytes: 99_000_000, videoCodec: 'AV1', videoSampleCount: 600, videoSampleSeconds: 10 }));
    expect(tracker.at(5)).toEqual(before);
  });

  it('在片段真实边界切换，缓冲中的下一片不能提前成为当前片段', () => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment({ videoCodec: 'H.264' }));
    tracker.add(segment({ key: 'next', start: 10, level: 1, videoCodec: 'HEVC', bytes: 2_000_000 }));

    expect(tracker.at(9.98)?.videoCodec).toBe('H.264');
    expect(tracker.at(10)).toMatchObject({ videoCodec: 'HEVC', bitrate: 1_600_000, bitrateSampleCount: 1 });
  });

  it('多个档位时间重叠时优先使用 HLS 确认正在播放的片段', () => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment({ key: 'playing', videoCodec: 'H.264', videoSampleCount: 240, videoSampleSeconds: 10 }));
    tracker.add(segment({ key: 'buffered-other-level', start: 0.02, level: 1, bytes: 2_000_000, videoCodec: 'HEVC', videoSampleCount: 300, videoSampleSeconds: 10 }));

    expect(tracker.at(5, 'playing')).toMatchObject({
      videoCodec: 'H.264', bitrate: 800_000, frameRate: 24, bitrateSampleCount: 1,
    });
    expect(tracker.at(5, 'buffered-other-level')).toMatchObject({
      videoCodec: 'HEVC', bitrate: 1_600_000, frameRate: 30, bitrateSampleCount: 1,
    });
  });

  it('拖动后旧播放片段不再包含当前时间时按新时间回退选择', () => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment({ key: 'before-seek', videoCodec: 'H.264' }));
    tracker.add(segment({ key: 'seek-target', start: 30, level: 1, bytes: 2_000_000, videoCodec: 'HEVC' }));

    expect(tracker.at(35, 'before-seek')).toMatchObject({
      videoCodec: 'HEVC', bitrate: 1_600_000, bitrateSampleCount: 1,
    });
    expect(tracker.at(15, 'before-seek')).toBeNull();
  });

  it('乱序下载仍只取当前片段及此前最多四片', () => {
    const tracker = new PlaybackInfoTracker();
    const samples = [0, 1, 2, 3, 4, 5].map((index) => segment({
      key: String(index), start: index * 2, duration: 2,
      bytes: index === 0 ? 99_000_000 : index * 1_000_000,
    }));
    for (const index of [5, 1, 3, 0, 4, 2]) tracker.add(samples[index]);

    expect(tracker.at(10.5)).toMatchObject({
      bitrate: 12_000_000,
      bitrateSampleCount: 5,
      bitrateSampleSeconds: 10,
    });
  });

  it.each([
    { level: 1, continuity: 0 },
    { level: 0, continuity: 1 },
  ])('切换档位或连续性时不沿用前一窗口 %j', (boundary) => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment({ bytes: 90_000_000 }));
    tracker.add(segment({ key: 'after-switch', start: 10, ...boundary }));
    expect(tracker.at(15)).toMatchObject({ bitrate: 800_000, bitrateSampleCount: 1 });
  });

  it.each([
    { gap: 0.3, expectedCount: 2 },
    { gap: 0.4, expectedCount: 1 },
  ])('小时间缝隙保持窗口，明显缺口截断窗口：$gap 秒', ({ gap, expectedCount }) => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment());
    tracker.add(segment({ key: 'after-gap', start: 10 + gap }));
    expect(tracker.at(15)?.bitrateSampleCount).toBe(expectedCount);
  });

  it('窗口有任一片缺少视频时序时帧率未知，清单声明仍独立保留', () => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment());
    tracker.add(segment({ key: 'current', start: 10, videoSampleCount: 240, videoSampleSeconds: 10, declaredFrameRate: 60 }));
    expect(tracker.at(15)).toMatchObject({ frameRate: undefined, declaredFrameRate: 60, bitrateSampleCount: 2 });
  });

  it.each([
    { videoSampleCount: undefined, videoSampleSeconds: 10 },
    { videoSampleCount: 240, videoSampleSeconds: undefined },
    { videoSampleCount: 0, videoSampleSeconds: 10 },
    { videoSampleCount: 240, videoSampleSeconds: 0 },
    { videoSampleCount: NaN, videoSampleSeconds: 10 },
    { videoSampleCount: 240, videoSampleSeconds: Infinity },
  ])('不完整或非法视频时序 %j 不能用 FRAME-RATE 冒充实测', (timing) => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment({ ...timing, declaredFrameRate: 30 }));
    expect(tracker.at(5)?.frameRate).toBeUndefined();
    expect(tracker.at(5)?.declaredFrameRate).toBe(30);
  });

  it('单独的清单帧率不是样本帧率', () => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment({ declaredFrameRate: 60 }));
    expect(tracker.at(5)?.frameRate).toBeUndefined();
  });

  it('保留片段快照，调用者之后修改对象不会重写历史指标', () => {
    const tracker = new PlaybackInfoTracker();
    const sample = segment();
    tracker.add(sample);
    sample.bytes = 99_000_000;
    expect(tracker.at(5)?.bitrate).toBe(800_000);
  });

  it('达到容量时重复缓冲替换同片，不占用其他有效片段的名额', () => {
    const tracker = new PlaybackInfoTracker();
    for (let index = 0; index < PLAYBACK_INFO_MAX_SAMPLES; index += 1) {
      tracker.add(segment({ key: String(index), start: index * 10 }));
    }
    tracker.at(5);
    tracker.add(segment({ key: '0', bytes: 2_000_000 }));
    expect(tracker.at(5)?.bitrate).toBe(1_600_000);
    expect(tracker.at((PLAYBACK_INFO_MAX_SAMPLES - 1) * 10 + 5)).not.toBeNull();
  });

  it('恢复到 46 秒后缓存 400 个未来短分片，仍保留当前完整统计', () => {
    const tracker = new PlaybackInfoTracker();
    tracker.add(segment({
      key: 'playing', start: 46, duration: 2, bytes: 500_000,
      videoCodec: 'H.264', audioCodec: 'AAC', videoSampleCount: 50, videoSampleSeconds: 2,
    }));
    tracker.at(47, 'playing');
    for (let index = 0; index < 400; index += 1) {
      tracker.add(segment({ key: `future-${index}`, start: 48 + index * 2, duration: 2 }));
    }

    expect(tracker.at(47, 'playing')).toMatchObject({
      videoCodec: 'H.264', audioCodec: 'AAC', bitrate: 2_000_000,
      frameRate: 25, bitrateSampleCount: 1, bitrateSampleSeconds: 2,
    });
  });

  it('超过容量保护当前及此前四片，并淘汰最远记录给近处新片留位', () => {
    const tracker = new PlaybackInfoTracker();
    for (let index = 0; index < 5; index += 1) {
      tracker.add(segment({ key: `near-${index}`, start: 38 + index * 2, duration: 2, bytes: 250_000 }));
    }
    tracker.at(47, 'near-4');
    const futureCount = PLAYBACK_INFO_MAX_SAMPLES - 5;
    for (let index = 1; index <= futureCount; index += 1) {
      tracker.add(segment({ key: `future-${index}`, start: 46 + index * 2, duration: 2 }));
    }
    const farthestStart = 46 + futureCount * 2;
    tracker.add(segment({ key: 'new-farthest', start: farthestStart + 2, duration: 2 }));

    expect(tracker.at(farthestStart + 3)).toBeNull();
    expect(tracker.at(47, 'near-4')).toMatchObject({
      bitrate: 1_000_000, bitrateSampleCount: 5, bitrateSampleSeconds: 10,
    });

    tracker.add(segment({ key: 'new-nearby', start: 49, duration: 0.25, bytes: 125_000, videoCodec: 'AV1' }));
    expect(tracker.at(farthestStart + 1)).toBeNull();
    expect(tracker.at(49.1, 'new-nearby')?.videoCodec).toBe('AV1');
    expect(tracker.at(47, 'near-4')?.bitrateSampleCount).toBe(5);
  });
});
