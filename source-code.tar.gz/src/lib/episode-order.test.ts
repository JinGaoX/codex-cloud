import { describe, expect, it, vi } from 'vitest';
import { createEpisodeOrderStore, EPISODE_ORDER_STORAGE_KEY } from './episode-order';

function fixture(saved?: string) {
  const values = new Map<string, string>([
    ['libretv-settings', 'existing source configuration'],
    ['pps-active-account-v1', 'existing account'],
    ...(saved === undefined ? [] : [[EPISODE_ORDER_STORAGE_KEY, saved] as [string, string]]),
  ]);
  const storage = {
    getItem: vi.fn((key: string) => values.get(key) ?? null),
    setItem: vi.fn((key: string, value: string) => { values.set(key, value); }),
  };
  let receive: ((key: string | null, value: string | null) => void) | undefined;
  const stop = vi.fn(() => { receive = undefined; });
  const listen = vi.fn((listener: (key: string | null, value: string | null) => void) => {
    receive = listener;
    return stop;
  });
  const store = createEpisodeOrderStore(() => storage, listen);
  return { store, values, storage, stop, listen, send: (key: string | null, value: string | null) => receive?.(key, value) };
}

describe('device-local episode order', () => {
  it('has a stable SSR snapshot and waits for a subscription to read saved order', () => {
    const { store, storage } = fixture('descending');
    expect(store.getServerSnapshot()).toBe(false);
    expect(store.getSnapshot()).toBe(false);
    expect(storage.getItem).not.toHaveBeenCalled();
    const unsubscribe = store.subscribe(() => {});
    expect(store.getSnapshot()).toBe(true);
    expect(store.getServerSnapshot()).toBe(false);
    expect(storage.setItem).not.toHaveBeenCalled();
    unsubscribe();
  });

  it('persists both directions and restores them on a fresh page without touching existing data', () => {
    const { store, storage, values, listen } = fixture();
    const unsubscribe = store.subscribe(() => {});
    store.setReversed((current) => !current);
    expect(values.get(EPISODE_ORDER_STORAGE_KEY)).toBe('descending');
    const reopened = createEpisodeOrderStore(() => storage, listen);
    const stopReopened = reopened.subscribe(() => {});
    expect(reopened.getSnapshot()).toBe(true);
    reopened.setReversed((current) => !current);
    expect(values.get(EPISODE_ORDER_STORAGE_KEY)).toBe('ascending');
    const nextPage = createEpisodeOrderStore(() => storage, listen);
    const stopNext = nextPage.subscribe(() => {});
    expect(nextPage.getSnapshot()).toBe(false);
    expect(values.get('libretv-settings')).toBe('existing source configuration');
    expect(values.get('pps-active-account-v1')).toBe('existing account');
    expect(storage.setItem.mock.calls.map(([key]) => key)).toEqual([EPISODE_ORDER_STORAGE_KEY, EPISODE_ORDER_STORAGE_KEY]);
    unsubscribe(); stopReopened(); stopNext();
  });

  it.each([undefined, '', 'true', 'invalid', '{broken'])('uses ascending for missing or invalid preference %s without rewriting it', (saved) => {
    const { store, storage } = fixture(saved);
    const unsubscribe = store.subscribe(() => {});
    expect(store.getSnapshot()).toBe(false);
    expect(storage.setItem).not.toHaveBeenCalled();
    unsubscribe();
  });

  it('notifies mounted consumers together and only handles relevant storage changes', () => {
    const { store, send, listen, stop } = fixture();
    const first = vi.fn(), second = vi.fn();
    const unsubscribeFirst = store.subscribe(first), unsubscribeSecond = store.subscribe(second);
    expect(listen).toHaveBeenCalledTimes(1);
    store.setReversed(true);
    expect(first).toHaveBeenCalledTimes(1);
    expect(second).toHaveBeenCalledTimes(1);
    send('libretv-settings', 'ascending');
    expect(store.getSnapshot()).toBe(true);
    send(EPISODE_ORDER_STORAGE_KEY, 'ascending');
    expect(store.getSnapshot()).toBe(false);
    send(EPISODE_ORDER_STORAGE_KEY, 'descending');
    send(null, null);
    expect(store.getSnapshot()).toBe(false);
    expect(first).toHaveBeenCalledTimes(4);
    unsubscribeFirst();
    expect(stop).not.toHaveBeenCalled();
    unsubscribeSecond();
    expect(stop).toHaveBeenCalledTimes(1);
  });

  it('rereads a saved preference when the page is entered again', () => {
    const { store, values } = fixture();
    const unsubscribe = store.subscribe(() => {});
    unsubscribe();
    values.set(EPISODE_ORDER_STORAGE_KEY, 'descending');
    const stop = store.subscribe(() => {});
    expect(store.getSnapshot()).toBe(true);
    stop();
  });

  it.each(['getter', 'read', 'write', 'missing'] as const)('keeps toggling in memory when storage fails at %s', (failure) => {
    const storage = {
      getItem: () => { if (failure === 'read') throw new Error('denied'); return 'ascending'; },
      setItem: () => { throw new Error('quota or access denied'); },
    };
    const store = createEpisodeOrderStore(() => {
      if (failure === 'getter') throw new Error('denied');
      return failure === 'missing' ? undefined : storage;
    }, () => () => {});
    const changed = vi.fn();
    const unsubscribe = store.subscribe(changed);
    expect(() => store.setReversed((current) => !current)).not.toThrow();
    expect(store.getSnapshot()).toBe(true);
    unsubscribe();
    // A stale stored ascending value cannot erase a failed save on a same-tab revisit.
    const stop = store.subscribe(changed);
    expect(store.getSnapshot()).toBe(true);
    store.setReversed((current) => !current);
    expect(store.getSnapshot()).toBe(false);
    expect(changed).toHaveBeenCalledTimes(2);
    stop();
  });
});
