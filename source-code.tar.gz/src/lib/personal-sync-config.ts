/** Only public connection settings belong in browser/PWA bundles. */
export interface SyncConfiguration { url: string; publishableKey: string }

function isLegacyAnonKey(key: string): boolean {
  try {
    const parts = key.split('.');
    if (parts.length !== 3 || !parts.every((part) => /^[A-Za-z0-9_-]+$/.test(part))) return false;
    const payload = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const decoded: unknown = JSON.parse(atob(payload.padEnd(Math.ceil(payload.length / 4) * 4, '=')));
    return !!decoded && typeof decoded === 'object' && 'role' in decoded && decoded.role === 'anon';
  } catch { return false; }
}

/** Validation prevents accidentally embedding a privileged service key in public source. */
export function parseSyncConfiguration(urlValue?: string, keyValue?: string): SyncConfiguration | null {
  const rawUrl = urlValue?.trim() || '';
  const publishableKey = keyValue?.trim() || '';
  if (!rawUrl && !publishableKey) return null;
  if (!rawUrl || !publishableKey) throw new Error('同步服务配置不完整，暂时不能登录。');
  let endpoint: URL;
  try { endpoint = new URL(rawUrl); }
  catch { throw new Error('同步服务地址格式不正确。'); }
  if (endpoint.protocol !== 'https:' || !endpoint.hostname || endpoint.username || endpoint.password
    || endpoint.pathname !== '/' || rawUrl.includes('?') || rawUrl.includes('#') || rawUrl.length > 512) {
    throw new Error('同步服务必须使用不含账号、路径和查询参数的 HTTPS 地址。');
  }
  if (publishableKey.length > 4096 || (!/^sb_publishable_[A-Za-z0-9_-]{8,}$/.test(publishableKey) && !isLegacyAnonKey(publishableKey))) {
    throw new Error('同步服务只允许使用公开连接密钥，不能使用管理员或服务端密钥。');
  }
  return { url: endpoint.origin, publishableKey };
}

export function getSyncConfiguration(): SyncConfiguration | null {
  // Keep explicit property access so Next embeds the selected public values in static builds.
  return parseSyncConfiguration(process.env.NEXT_PUBLIC_SYNC_URL, process.env.NEXT_PUBLIC_SYNC_PUBLISHABLE_KEY);
}

export function syncAuthStorageKey(config: SyncConfiguration): string {
  return `pps-sync-auth-v1:${config.url}`;
}

/** Enable only after the project's verified-email delivery is configured and tested. */
export function isPersonalSignupEnabled(): boolean {
  return process.env.NEXT_PUBLIC_SYNC_ALLOW_SIGNUP === 'true';
}
