import 'fake-indexeddb/auto';
import { IDBFactory } from 'fake-indexeddb';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { AccountScope } from './account-scope';
import type { db as AppDatabase } from './db';

const A: AccountScope = { userId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', endpoint: 'https://first.supabase.co' };
const B: AccountScope = { ...A, userId: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb' };
const values = new Map<string, string>();
const connections: Array<typeof AppDatabase> = [];
const storages: Array<typeof import('./persist-storage')> = [];

beforeEach(() => {
  vi.resetModules();
  values.clear();
  vi.stubGlobal('indexedDB', new IDBFactory());
  vi.stubGlobal('localStorage', {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => values.set(key, value),
    removeItem: (key: string) => values.delete(key),
  });
});

afterEach(() => {
  for (const storage of storages.splice(0)) storage.flushPendingPersist();
  for (const db of connections.splice(0)) db.close();
  vi.unstubAllGlobals();
});

async function load(scope: AccountScope | null) {
  if (scope) values.set('pps-active-account-v1', JSON.stringify(scope));
  else values.delete('pps-active-account-v1');
  vi.resetModules();
  const data = await import('./db');
  const storage = await import('./persist-storage');
  connections.push(data.db);
  storages.push(storage);
  await data.db.open();
  return { ...data, storage, scope: await import('./account-scope') };
}

function film(name: string) {
  return { sourceKey: 'custom_0', sourceUrl: 'https://example.com/api', vodId: '12',
    title: name, episodeIndex: 2, totalEpisodes: 10, playbackPosition: 122, duration: 1200, timestamp: 1234 };
}

describe('账号、本机资料与配置备份隔离', () => {
  it('游客→账号 A→账号 B→游客均各自保存，不自动导入或混合', async () => {
    const guest = await load(null);
    guest.storage.writePersistedSettings('guest-settings');
    await guest.upsertHistory(film('游客影片'));
    const a = await load(A);
    expect(a.storage.readPersistedSettings()).toBeNull();
    expect(await a.db.history.count()).toBe(0);
    expect(a.db.verno).toBe(5);
    a.storage.writePersistedSettings('A-settings');
    await a.upsertHistory(film('A 的影片'));
    await a.saveProgress('custom_0', '12', 2, 800, 1200);
    const b = await load(B);
    expect(b.storage.readPersistedSettings()).toBeNull();
    expect(await b.db.history.count()).toBe(0);
    expect(await b.db.progress.count()).toBe(0);
    b.storage.writePersistedSettings('B-settings');
    await b.upsertHistory(film('B 的影片'));
    const backToA = await load(A);
    expect(backToA.storage.readPersistedSettings()).toBe('A-settings');
    expect((await backToA.db.history.toArray())[0].title).toBe('A 的影片');
    expect((await backToA.db.progress.toArray())[0].position).toBe(800);
    const backToGuest = await load(null);
    expect(backToGuest.db.name).toBe('libretv');
    expect(backToGuest.db.verno).toBe(4);
    expect(backToGuest.storage.readPersistedSettings()).toBe('guest-settings');
    expect((await backToGuest.db.history.toArray())[0].title).toBe('游客影片');
    expect(await backToGuest.db.progress.count()).toBe(0);
  });

  it('同账号连接不同项目时不复用历史或设置', async () => {
    const a = await load(A);
    a.storage.writePersistedSettings('first-project');
    await a.upsertHistory(film('项目一影片'));
    const second = await load({ ...A, endpoint: 'https://second.supabase.co' });
    expect(second.db.name).not.toBe(a.db.name);
    expect(second.storage.readPersistedSettings()).toBeNull();
    expect(await second.db.history.count()).toBe(0);
    expect(values.get(a.scope.settingsKeyForScope(a.storage.PERSIST_KEY, A))).toBe('first-project');
  });

  it('切换标记后卸载前的旧节流写入仍只属于旧空间', async () => {
    const guest = await load(null);
    const oldStorage = guest.storage.createThrottledStorage();
    oldStorage.setItem(guest.storage.PERSIST_KEY, 'guest-pending');
    guest.scope.setActiveAccountScope(A);
    guest.storage.flushPendingPersist();
    expect(values.get('libretv-settings')).toBe('guest-pending');
    expect(values.has(guest.scope.settingsKeyForScope('libretv-settings', A))).toBe(false);
    const a = await load(A);
    a.storage.createThrottledStorage().setItem(a.storage.PERSIST_KEY, 'A-pending');
    a.scope.setActiveAccountScope(B);
    a.storage.flushPendingPersist();
    expect(a.storage.readPersistedSettings()).toBe('A-pending');
    expect(values.has(a.scope.settingsKeyForScope('libretv-settings', B))).toBe(false);
  });

  it('显式移除账号配置后旧缓冲不会让它复活或碰到游客配置', async () => {
    values.set('libretv-settings', 'guest');
    const a = await load(A);
    const storage = a.storage.createThrottledStorage();
    storage.setItem(a.storage.PERSIST_KEY, 'pending');
    a.storage.removePersistedSettings();
    a.storage.flushPendingPersist();
    expect(a.storage.readPersistedSettings()).toBeNull();
    expect(values.get('libretv-settings')).toBe('guest');
    storage.setItem(a.storage.PERSIST_KEY, 'pending-again');
    storage.removeItem(a.storage.PERSIST_KEY);
    a.storage.flushPendingPersist();
    expect(a.storage.readPersistedSettings()).toBeNull();
  });

  it('账号配置完整导出/导入只作用于该账号，备份仍兼容原键名', async () => {
    const guest = await load(null);
    guest.storage.writePersistedSettings('guest');
    await guest.upsertHistory(film('游客影片'));
    const a = await load(A);
    const serialized = JSON.stringify({ state: { customAPIs: [{ key: 'custom_0', name: '私有源', url: 'https://example.com/api' }], selectedKeys: ['custom_0'] }, version: 9 });
    a.storage.writePersistedSettings(serialized);
    await a.upsertHistory(film('账号影片'));
    await a.saveProgress('custom_0', '12', 2, 400, 1200);
    const backup = await a.exportConfig();
    expect(JSON.parse(backup).data['libretv-settings']).toBe(serialized);
    a.storage.writePersistedSettings(JSON.stringify({ state: {} }));
    await a.db.history.clear();
    await a.db.progress.clear();
    await a.importConfig(backup);
    expect(a.storage.readPersistedSettings()).toBe(serialized);
    expect((await a.db.history.toArray())[0].title).toBe('账号影片');
    expect((await a.db.progress.toArray())[0].position).toBe(400);
    expect(guest.storage.readPersistedSettings()).toBe('guest');
    expect((await guest.db.history.toArray())[0].title).toBe('游客影片');
  });

  it('账号导入事务失败时回滚该账号设置，不触碰游客设置或历史', async () => {
    const guest = await load(null);
    guest.storage.writePersistedSettings('guest');
    const a = await load(A);
    a.storage.writePersistedSettings('A-original');
    await a.upsertHistory(film('A-original-film'));
    const failure = vi.spyOn(a.db.favorites, 'bulkPut').mockRejectedValueOnce(new Error('write failure'));
    await expect(a.importConfig(JSON.stringify({ name: 'LibreTV-Settings', data: {
      'libretv-settings': JSON.stringify({ state: {} }), viewingHistory: '[]', favorites: '[]',
    } }))).rejects.toThrow('write failure');
    failure.mockRestore();
    expect(a.storage.readPersistedSettings()).toBe('A-original');
    expect((await a.db.history.toArray())[0].title).toBe('A-original-film');
    expect(guest.storage.readPersistedSettings()).toBe('guest');
  });
});
