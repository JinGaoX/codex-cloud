import { favoriteKeyOf, progressKeyOf, type FavoriteEntry, type HistoryEntry, type ProgressEntry } from './db';
import { canonicalSourceIdentity, canonicalSourceKey, type SyncRecord, type PersonalSyncSnapshot } from './personal-sync-model';
import type { SourceConfig } from './types';
import type { LiveRecentEntry, LiveSubscription } from './store';

export interface LocalSyncSnapshot extends PersonalSyncSnapshot {
  envSources: SourceConfig[];
  customAPIs: SourceConfig[];
}
type MediaEntry = HistoryEntry | ProgressEntry | FavoriteEntry;
export interface MediaMutation {
  kind: 'history' | 'progress' | 'favorites'; key: string; before: MediaEntry | undefined; after: MediaEntry | undefined;
}
export interface ApplyPlan {
  mutations: MediaMutation[];
  projected: LocalSyncSnapshot;
  sourcesChanged: boolean;
  liveChanged: boolean;
}
const object = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);
const text = (value: unknown) => typeof value === 'string' ? value : '';
const nonnegative = (value: unknown) => typeof value === 'number' && Number.isFinite(value) && value >= 0 ? value : 0;

/** Pure projection: no database transaction or WebCrypto awaits belong in this function. */
export function planSyncApply(snapshot: LocalSyncSnapshot, rows: SyncRecord[]): ApplyPlan {
  let sources = [...snapshot.customAPIs];
  let selected = [...snapshot.selectedKeys];
  let liveSubscriptions = [...(snapshot.liveSubscriptions ?? [])];
  let liveSelected = [...(snapshot.liveSelectedUrls ?? [])];
  const liveFavorites = new Map((snapshot.liveFavorites ?? []).map((url) => [canonicalSourceIdentity(url) ?? url, url]));
  const liveRecent = new Map<string, LiveRecentEntry>();
  for (const entry of snapshot.liveRecent ?? []) {
    const identity = canonicalSourceIdentity(entry.url) ?? entry.url;
    if (!liveRecent.has(identity) || liveRecent.get(identity)!.timestamp < entry.timestamp) liveRecent.set(identity, entry);
  }
  for (const row of rows.filter((item) => item.kind === 'liveSources')) {
    liveSelected = liveSelected.filter((url) => canonicalSourceIdentity(url) !== row.key);
    if (row.deleted) {
      liveSubscriptions = liveSubscriptions.filter((source) => canonicalSourceIdentity(source.url) !== row.key);
    } else {
      if (!object(row.payload?.source)) throw new Error('同步直播源数据无效');
      const remote = row.payload.source as unknown as Pick<LiveSubscription, 'url' | 'name' | 'epg'>;
      const existing = liveSubscriptions.find((source) => canonicalSourceIdentity(source.url) === row.key);
      const environment = snapshot.liveEnvSources?.find((source) => canonicalSourceIdentity(source.url) === row.key);
      const url = existing?.url ?? environment?.url ?? remote.url;
      if (!environment) {
        liveSubscriptions = liveSubscriptions.filter((source) => canonicalSourceIdentity(source.url) !== row.key);
        liveSubscriptions.push({ ...existing, url, name: remote.name, epg: remote.epg,
          fromSubscriptions: [...(existing?.fromSubscriptions ?? [])] });
      }
      if (row.payload.selected === true) liveSelected.push(url);
    }
  }
  for (const row of rows.filter((item) => item.kind === 'liveFavorites' || item.kind === 'liveRecent')) {
    if (row.kind === 'liveFavorites') {
      if (row.deleted) liveFavorites.delete(row.key);
      else liveFavorites.set(row.key, liveFavorites.get(row.key) ?? text(row.payload?.url));
    } else if (row.deleted) {
      liveRecent.delete(row.key);
    } else {
      const payload = row.payload ?? {};
      liveRecent.set(row.key, {
        url: liveRecent.get(row.key)?.url ?? text(payload.url), name: text(payload.name),
        logo: text(payload.logo) || undefined, group: text(payload.group) || undefined,
        tvgId: text(payload.tvgId) || undefined, epg: text(payload.epg) || undefined,
        sourceUrl: text(payload.sourceUrl) || undefined, timestamp: nonnegative(payload.timestamp),
      });
    }
  }
  for (const row of rows.filter((item) => item.kind === 'sources')) {
    if (row.deleted) {
      const matches = [...snapshot.envSources, ...sources].filter((source) => canonicalSourceIdentity(source.url) === row.key);
      sources = sources.filter((source) => canonicalSourceIdentity(source.url) !== row.key);
      selected = selected.filter((key) => !matches.some((source) => source.key === key));
    } else {
      if (!object(row.payload?.source)) throw new Error('同步片源数据无效');
      const remote = row.payload.source as unknown as SourceConfig;
      const existing = [...snapshot.envSources, ...sources].find((source) => canonicalSourceIdentity(source.url) === canonicalSourceIdentity(remote.url));
      const localKey = existing?.key ?? remote.key;
      if (!snapshot.envSources.some((source) => source.key === localKey)) {
        sources = sources.filter((source) => source.key !== localKey);
        sources.push({ key: localKey, name: remote.name, url: remote.url, detail: remote.detail, isAdult: remote.isAdult });
      }
      selected = selected.filter((key) => key !== localKey);
      if (row.payload.selected === true) selected.push(localKey);
    }
  }
  // A historical alias is not a current source. custom_N may now belong to another URL.
  const currentSources = [...snapshot.envSources, ...sources];
  const history = new Map(snapshot.history.map((entry) => [entry.id, entry]));
  const progress = new Map(snapshot.progress.map((entry) => [entry.key, entry]));
  const favorites = new Map(snapshot.favorites.map((entry) => [entry.id, entry]));
  const mutations: MediaMutation[] = [];
  for (const row of rows.filter((item) => item.kind === 'history' || item.kind === 'progress' || item.kind === 'favorites')) {
    let parts: unknown;
    try { parts = JSON.parse(row.key); } catch { throw new Error('同步定位信息无效'); }
    if (!Array.isArray(parts) || typeof parts[0] !== 'string' || typeof parts[1] !== 'string') throw new Error('同步定位信息无效');
    const [identity, vodId] = parts as [string, string];
    const payload = row.payload ?? {};
    const existing = currentSources.find((source) => canonicalSourceIdentity(source.url) === identity);
    const canonical = canonicalSourceKey(identity);
    const sourceKey = existing?.key
      ?? (identity.startsWith('builtin:') ? identity.slice('builtin:'.length) : canonical);
    const sourceUrl = text(payload.sourceUrl) || (identity.startsWith('builtin:') ? undefined : identity);
    if (row.kind === 'history') {
      const key = `${sourceKey}_${vodId}`;
      const before = history.get(key);
      const after: HistoryEntry | undefined = row.deleted ? undefined : {
        id: key, sourceKey, sourceUrl, vodId, title: text(payload.title) || '未知视频', pic: text(payload.pic) || undefined,
        episodeIndex: Math.floor(nonnegative(payload.episodeIndex)), totalEpisodes: Math.floor(nonnegative(payload.totalEpisodes)),
        playbackPosition: nonnegative(payload.playbackPosition), duration: nonnegative(payload.duration), timestamp: nonnegative(payload.timestamp),
      };
      if (after) history.set(key, after); else history.delete(key);
      mutations.push({ kind: 'history', key, before, after });
    } else if (row.kind === 'progress') {
      const key = progressKeyOf(sourceKey, vodId, Math.floor(nonnegative(parts[2])));
      const before = progress.get(key);
      const after: ProgressEntry | undefined = row.deleted ? undefined : { key, position: nonnegative(payload.position), duration: nonnegative(payload.duration), updatedAt: nonnegative(payload.updatedAt) };
      if (after) progress.set(key, after); else progress.delete(key);
      mutations.push({ kind: 'progress', key, before, after });
    } else if (row.kind === 'favorites') {
      const key = favoriteKeyOf(sourceKey, vodId);
      const before = favorites.get(key);
      const after: FavoriteEntry | undefined = row.deleted ? undefined : {
        id: key, sourceKey, sourceUrl, vodId, name: text(payload.name) || '未知视频', sourceName: text(payload.sourceName) || sourceKey,
        pic: text(payload.pic) || undefined, year: text(payload.year) || undefined, typeName: text(payload.typeName) || undefined,
        remarks: text(payload.remarks) || undefined, area: text(payload.area) || undefined,
        isAdult: payload.isAdult === true, timestamp: nonnegative(payload.timestamp),
      };
      if (after) favorites.set(key, after); else favorites.delete(key);
      mutations.push({ kind: 'favorites', key, before, after });
    }
  }
  return { mutations, sourcesChanged: rows.some((row) => row.kind === 'sources'),
    liveChanged: rows.some((row) => row.kind === 'liveSources' || row.kind === 'liveFavorites' || row.kind === 'liveRecent'), projected: {
    ...snapshot, customAPIs: sources, selectedKeys: [...new Set(selected)], sources: [...snapshot.envSources, ...sources],
    history: [...history.values()], progress: [...progress.values()], favorites: [...favorites.values()],
    liveSubscriptions, liveSelectedUrls: [...new Set(liveSelected)],
    liveFavorites: [...liveFavorites.values()],
    liveRecent: [...liveRecent.values()].sort((a, b) => b.timestamp - a.timestamp || a.url.localeCompare(b.url)).slice(0, 20),
  } };
}
