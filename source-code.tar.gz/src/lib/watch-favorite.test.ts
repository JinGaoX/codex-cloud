import 'fake-indexeddb/auto';
import { afterAll, beforeEach, describe, expect, it } from 'vitest';
import { addFavorite, db, favoriteKeyOf, removeFavorite } from './db';
import { DIRECT_MEDIA_SOURCE } from './standalone-media';
import { watchFavoriteItem } from './watch-favorite';

const source = { key: 'watch-test', name: '测试源', url: 'https://example.com/api.php/provide/vod' };

beforeEach(async () => {
  await db.open();
  await db.favorites.clear();
});
afterAll(() => db.close());

describe('播放页收藏与详情收藏共用身份', () => {
  it('从详情收藏进入播放后命中同一条记录，更新与取消不产生另一份收藏', async () => {
    await addFavorite({ sourceKey: source.key, sourceName: source.name, sourceUrl: source.url, vodId: 'film-12', name: '测试影片' });
    const item = watchFavoriteItem(source, 'film-12', '测试影片', {
      sourceKey: 'upstream-must-not-replace-identity', sourceName: '源站显示名',
      sourceUrl: 'https://other.example/api', cover: 'https://example.com/poster.webp',
      typeName: '喜剧', year: '2025', area: '中国', remarks: 'HD',
    })!;
    expect(await db.favorites.get(favoriteKeyOf(item.sourceKey, item.vodId))).toBeDefined();
    await addFavorite(item);
    expect(await db.favorites.count()).toBe(1);
    expect(await db.favorites.get(favoriteKeyOf(source.key, 'film-12'))).toMatchObject({
      sourceKey: source.key, sourceName: source.name, sourceUrl: source.url,
      vodId: 'film-12', name: '测试影片', pic: 'https://example.com/poster.webp',
      typeName: '喜剧', year: '2025', area: '中国', remarks: 'HD',
    });
    await removeFavorite(item.sourceKey, item.vodId);
    expect(await db.favorites.count()).toBe(0);
  });

  it('详情尚未取得时仍可用已知影片定位收藏，不把当前集播放链接写入API影片收藏', async () => {
    const item = watchFavoriteItem(source, 'cms-id', '链接里的片名')!;
    await addFavorite(item);
    expect(await db.favorites.get(favoriteKeyOf(source.key, 'cms-id'))).toMatchObject({
      sourceKey: source.key, sourceUrl: source.url, vodId: 'cms-id', name: '链接里的片名',
    });
    expect(Object.keys(item).sort()).toEqual(['name', 'sourceKey', 'sourceName', 'sourceUrl', 'vodId']);
  });

  it('直连视频保持原保留源和URL身份，可以从现有收藏入口重新打开', async () => {
    const url = 'https://example.com/own-video.mp4';
    const item = watchFavoriteItem({ key: DIRECT_MEDIA_SOURCE, name: '视频链接', url: '' }, url, '个人视频')!;
    await addFavorite(item);
    expect(await db.favorites.get(favoriteKeyOf(DIRECT_MEDIA_SOURCE, url))).toMatchObject({
      sourceKey: DIRECT_MEDIA_SOURCE, sourceName: '视频链接', vodId: url, name: '个人视频',
    });
    expect(item).not.toHaveProperty('sourceUrl');
  });

  it('缺少来源或影片ID时不构造可能互相覆盖的空收藏', () => {
    expect(watchFavoriteItem(undefined, '12', '影片')).toBeNull();
    expect(watchFavoriteItem(source, '', '影片')).toBeNull();
    expect(watchFavoriteItem({ ...source, key: '' }, '12', '影片')).toBeNull();
  });
});
