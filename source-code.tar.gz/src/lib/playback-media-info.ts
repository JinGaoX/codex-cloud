/**
 * Read video sample timing from complete ISO BMFF init/fragment box metadata.
 * Field offsets and flags follow the installed hls.js utils/mp4-tools.ts.
 * No manifest frame-rate, bitrate inference, or presentation refresh rate is used.
 */
export interface VideoTrackInfo {
  id: number;
  timescale: number;
  defaultSampleDuration?: number;
}

export interface VideoSampleStats {
  sampleCount: number;
  durationSeconds: number;
  /** Unrounded sample cadence for these fragments, not the screen refresh rate. */
  frameRate: number;
}

interface Box {
  type: string;
  payload: number;
  end: number;
}

function uint32(data: Uint8Array, offset: number): number {
  return data[offset] * 0x1000000 + data[offset + 1] * 0x10000 + data[offset + 2] * 0x100 + data[offset + 3];
}

function fourCC(data: Uint8Array, offset: number): string {
  return String.fromCharCode(data[offset], data[offset + 1], data[offset + 2], data[offset + 3]);
}

/** Every box must fit wholly inside this region, including extended headers. */
function boxes(data: Uint8Array, start = 0, end = data.length): Box[] | undefined {
  const result: Box[] = [];
  for (let offset = start; offset < end;) {
    if (end - offset < 8) return undefined;
    const type = fourCC(data, offset + 4);
    let size = uint32(data, offset);
    let headerSize = 8;
    if (size === 1) {
      if (end - offset < 16) return undefined;
      size = uint32(data, offset + 8) * 0x100000000 + uint32(data, offset + 12);
      headerSize = 16;
    } else if (size === 0) {
      size = end - offset;
    }
    if (type === 'uuid') headerSize += 16;
    if (!Number.isSafeInteger(size) || size < headerSize || size > end - offset) return undefined;
    result.push({ type, payload: offset + headerSize, end: offset + size });
    offset += size;
  }
  return result;
}

function children(data: Uint8Array, box: Box): Box[] | undefined {
  return boxes(data, box.payload, box.end);
}

function one(list: Box[], type: string): Box | undefined {
  const matches = list.filter((box) => box.type === type);
  return matches.length === 1 ? matches[0] : undefined;
}

interface TrackMetadata extends VideoTrackInfo {
  handler: string;
}

function trackMetadata(data: Uint8Array, trak: Box): TrackMetadata | undefined {
  const trackBoxes = children(data, trak);
  if (!trackBoxes) return undefined;
  const tkhd = one(trackBoxes, 'tkhd');
  const mdia = one(trackBoxes, 'mdia');
  if (!tkhd || !mdia || tkhd.end - tkhd.payload < 4) return undefined;
  const tkhdVersion = data[tkhd.payload];
  if (tkhdVersion !== 0 && tkhdVersion !== 1) return undefined;
  if (tkhd.end - tkhd.payload < (tkhdVersion === 0 ? 84 : 96)) return undefined;
  const id = uint32(data, tkhd.payload + (tkhdVersion === 0 ? 12 : 20));
  const mediaBoxes = children(data, mdia);
  if (!mediaBoxes) return undefined;
  const mdhd = one(mediaBoxes, 'mdhd');
  const hdlr = one(mediaBoxes, 'hdlr');
  if (!mdhd || !hdlr || mdhd.end - mdhd.payload < 4 || hdlr.end - hdlr.payload < 24) return undefined;
  const mdhdVersion = data[mdhd.payload];
  if ((mdhdVersion !== 0 && mdhdVersion !== 1) || data[hdlr.payload] !== 0) return undefined;
  if (mdhd.end - mdhd.payload < (mdhdVersion === 0 ? 24 : 36)) return undefined;
  const timescale = uint32(data, mdhd.payload + (mdhdVersion === 0 ? 12 : 20));
  if (id === 0 || timescale === 0) return undefined;
  return { id, timescale, handler: fourCC(data, hdlr.payload + 8) };
}

/** A unique `vide` track is required; multiple video tracks are ambiguous. */
export function parseVideoTrack(init: Uint8Array): VideoTrackInfo | undefined {
  const top = boxes(init);
  if (!top) return undefined;
  const moov = one(top, 'moov');
  if (!moov) return undefined;
  const movieBoxes = children(init, moov);
  if (!movieBoxes) return undefined;
  const trackIds = new Set<number>();
  let video: TrackMetadata | undefined;
  for (const trak of movieBoxes.filter((box) => box.type === 'trak')) {
    const track = trackMetadata(init, trak);
    if (!track || trackIds.has(track.id)) return undefined;
    trackIds.add(track.id);
    if (track.handler !== 'vide') continue;
    if (video) return undefined;
    video = track;
  }
  if (!video) return undefined;

  let defaultSampleDuration: number | undefined;
  const extensions = movieBoxes.filter((box) => box.type === 'mvex');
  if (extensions.length > 1) return undefined;
  if (extensions.length === 1) {
    const extensionBoxes = children(init, extensions[0]);
    if (!extensionBoxes) return undefined;
    let foundDefault = false;
    for (const trex of extensionBoxes.filter((box) => box.type === 'trex')) {
      if (trex.end - trex.payload !== 24 || uint32(init, trex.payload) !== 0) return undefined;
      if (uint32(init, trex.payload + 4) !== video.id) continue;
      if (foundDefault) return undefined;
      foundDefault = true;
      const duration = uint32(init, trex.payload + 12);
      if (duration > 0) defaultSampleDuration = duration;
    }
  }
  return { id: video.id, timescale: video.timescale, ...(defaultSampleDuration === undefined ? {} : { defaultSampleDuration }) };
}

interface FragmentHeader {
  id: number;
  defaultSampleDuration?: number;
  durationIsEmpty: boolean;
}

function fragmentHeader(data: Uint8Array, tfhd: Box, track: VideoTrackInfo): FragmentHeader | undefined {
  if (tfhd.end - tfhd.payload < 8 || data[tfhd.payload] !== 0) return undefined;
  const flags = uint32(data, tfhd.payload) & 0xffffff;
  if (flags & ~0x03003b) return undefined;
  const id = uint32(data, tfhd.payload + 4);
  if (id === 0) return undefined;
  let offset = tfhd.payload + 8;
  if (flags & 0x000001) offset += 8; // base_data_offset
  if (flags & 0x000002) offset += 4; // sample_description_index
  let defaultSampleDuration = track.defaultSampleDuration;
  if (flags & 0x000008) {
    if (offset + 4 > tfhd.end) return undefined;
    defaultSampleDuration = uint32(data, offset); // Explicit zero must not fall back to trex.
    offset += 4;
  }
  if (flags & 0x000010) offset += 4; // default_sample_size
  if (flags & 0x000020) offset += 4; // default_sample_flags
  if (offset !== tfhd.end) return undefined;
  return { id, defaultSampleDuration, durationIsEmpty: Boolean(flags & 0x010000) };
}

interface TickStats {
  sampleCount: number;
  duration: number;
}

function runStats(data: Uint8Array, trun: Box, header: FragmentHeader): TickStats | undefined {
  if (trun.end - trun.payload < 8) return undefined;
  const version = data[trun.payload];
  if (version !== 0 && version !== 1) return undefined;
  const flags = uint32(data, trun.payload) & 0xffffff;
  if (flags & ~0x000f05 || ((flags & 0x000004) && (flags & 0x000400))) return undefined;
  const sampleCount = uint32(data, trun.payload + 4);
  if (header.durationIsEmpty && sampleCount > 0) return undefined;
  let offset = trun.payload + 8;
  if (flags & 0x000001) offset += 4; // signed data_offset (irrelevant to timing)
  if (flags & 0x000004) offset += 4; // first_sample_flags
  const hasDuration = Boolean(flags & 0x000100);
  const stride = 4 * Number(hasDuration) + 4 * Number(Boolean(flags & 0x000200))
    + 4 * Number(Boolean(flags & 0x000400)) + 4 * Number(Boolean(flags & 0x000800));
  if (offset + sampleCount * stride !== trun.end) return undefined;
  if (sampleCount === 0) return { sampleCount: 0, duration: 0 };
  if (!hasDuration) {
    const duration = header.defaultSampleDuration;
    if (!Number.isSafeInteger(duration) || !duration || duration <= 0) return undefined;
    const total = sampleCount * duration;
    return Number.isSafeInteger(total) ? { sampleCount, duration: total } : undefined;
  }
  let duration = 0;
  for (let i = 0; i < sampleCount; i++, offset += stride) {
    const value = uint32(data, offset);
    if (value === 0) return undefined;
    duration += value;
    if (!Number.isSafeInteger(duration)) return undefined;
  }
  return { sampleCount, duration };
}

/**
 * Sum the matching video's sample durations across complete moof/traf/trun boxes.
 * Missing/truncated/ambiguous video timing returns undefined, never a guessed FPS.
 * This reads fragment timing metadata; it neither validates mdat decoding nor counts
 * displayed/dropped frames. Audio samples and composition offsets do not enter FPS.
 */
export function parseVideoSampleStats(data: Uint8Array, track: VideoTrackInfo): VideoSampleStats | undefined {
  if (!Number.isInteger(track.id) || track.id <= 0 || track.id > 0xffffffff
    || !Number.isInteger(track.timescale) || track.timescale <= 0 || track.timescale > 0xffffffff) return undefined;
  if (track.defaultSampleDuration !== undefined && (!Number.isInteger(track.defaultSampleDuration)
    || track.defaultSampleDuration < 0 || track.defaultSampleDuration > 0xffffffff)) return undefined;
  const top = boxes(data);
  if (!top) return undefined;
  const fragments = top.filter((box) => box.type === 'moof');
  if (fragments.length === 0) return undefined;
  let sampleCount = 0;
  let duration = 0;
  for (const moof of fragments) {
    const fragmentBoxes = children(data, moof);
    if (!fragmentBoxes) return undefined;
    for (const traf of fragmentBoxes.filter((box) => box.type === 'traf')) {
      const trackBoxes = children(data, traf);
      if (!trackBoxes) return undefined;
      const tfhd = one(trackBoxes, 'tfhd');
      if (!tfhd) return undefined;
      const header = fragmentHeader(data, tfhd, track);
      if (!header) return undefined;
      if (header.id !== track.id) continue;
      const runs = trackBoxes.filter((box) => box.type === 'trun');
      if (runs.length === 0 && !header.durationIsEmpty) return undefined;
      for (const trun of runs) {
        const stats = runStats(data, trun, header);
        if (!stats) return undefined;
        sampleCount += stats.sampleCount;
        duration += stats.duration;
        if (!Number.isSafeInteger(sampleCount) || !Number.isSafeInteger(duration)) return undefined;
      }
    }
  }
  if (sampleCount === 0 || duration <= 0) return undefined;
  const durationSeconds = duration / track.timescale;
  const frameRate = sampleCount / durationSeconds;
  if (!Number.isFinite(frameRate) || frameRate <= 0) return undefined;
  return { sampleCount, durationSeconds, frameRate };
}
