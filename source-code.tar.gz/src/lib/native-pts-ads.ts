import { analyzeHlsPtsPlaylist, type HlsPtsFilterSession } from './hls-pts-filter';

export interface NativePtsAdRange {
  startSeconds: number;
  endSeconds: number;
}

export interface NativePtsAdsPlan {
  status: 'ready' | 'unchanged' | 'unavailable';
  reason: string;
  /** The original video.src identity, never a rewritten playlist or blob URL. */
  sourceUrl: string;
  durationSeconds: number;
  ranges: NativePtsAdRange[];
}

interface PrepareOptions {
  session: HlsPtsFilterSession;
  signal?: AbortSignal;
  fetcher?: typeof fetch;
}

const MAX_PLAYLIST_BYTES = 2 * 1024 * 1024;
const MAX_PLAYLIST_DEPTH = 3;
const FETCH_TIMEOUT_MS = 8000;
const TOTAL_TIMEOUT_MS = 18000;

function mediaUrl(raw: string, base?: string): string | undefined {
  try {
    const url = new URL(raw, base ?? (typeof document === 'undefined' ? undefined : document.baseURI));
    if (!/^https?:$/.test(url.protocol) || url.username || url.password) return undefined;
    // Native playback is not made less secure by this optional background reader.
    if (url.protocol === 'http:') {
      const origin = typeof location === 'undefined' ? undefined : location.origin;
      if (url.origin !== origin) return undefined;
    }
    return url.href;
  } catch { return undefined; }
}

async function abortable<T>(operation: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) throw signal.reason;
  let onAbort: (() => void) | undefined;
  try {
    return await Promise.race([
      operation,
      new Promise<never>((_resolve, reject) => {
        onAbort = () => reject(signal.reason ?? new DOMException('Aborted', 'AbortError'));
        signal.addEventListener('abort', onAbort, { once: true });
      }),
    ]);
  } finally {
    if (onAbort) signal.removeEventListener('abort', onAbort);
  }
}

async function playlistText(url: string, fetcher: typeof fetch, signal: AbortSignal): Promise<{ text: string; url: string }> {
  const controller = new AbortController();
  const onAbort = () => controller.abort(signal.reason);
  signal.addEventListener('abort', onAbort, { once: true });
  if (signal.aborted) onAbort();
  const timer = setTimeout(() => controller.abort(new DOMException('Playlist timeout', 'TimeoutError')), FETCH_TIMEOUT_MS);
  let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
  try {
    if (controller.signal.aborted) throw controller.signal.reason;
    const pendingResponse = fetcher(url, {
      method: 'GET', mode: 'cors', credentials: 'same-origin', cache: 'no-store',
      headers: { Accept: 'application/vnd.apple.mpegurl, application/x-mpegURL, text/plain;q=0.8, */*;q=0.5' },
      signal: controller.signal,
    }).then((response) => {
      if (controller.signal.aborted) {
        void response.body?.cancel().catch(() => {});
        throw controller.signal.reason;
      }
      return response;
    });
    const response = await abortable(pendingResponse, controller.signal);
    if (!response.ok || response.type === 'opaque') throw new Error('playlist_unavailable');
    const finalUrl = response.url ? mediaUrl(response.url) : url;
    if (!finalUrl) throw new Error('unsafe_redirect');
    const length = Number(response.headers.get('content-length'));
    if (Number.isFinite(length) && length > MAX_PLAYLIST_BYTES) {
      void response.body?.cancel().catch(() => {});
      throw new Error('playlist_size');
    }
    reader = response.body?.getReader();
    if (!reader) throw new Error('playlist_body_unavailable');
    const decoder = new TextDecoder();
    let size = 0;
    let text = '';
    while (true) {
      const part = await abortable(reader.read(), controller.signal);
      if (part.done) break;
      size += part.value.byteLength;
      if (size > MAX_PLAYLIST_BYTES) throw new Error('playlist_size');
      text += decoder.decode(part.value, { stream: true });
    }
    text += decoder.decode();
    if (text.replace(/^\uFEFF/, '').split(/\r?\n/, 1)[0].trim() !== '#EXTM3U') throw new Error('invalid_playlist');
    return { text, url: finalUrl };
  } finally {
    clearTimeout(timer);
    signal.removeEventListener('abort', onAbort);
    void reader?.cancel().catch(() => {});
    controller.abort();
  }
}

/**
 * Native HLS stays on its original URL. JS cannot safely substitute a blob or
 * phone-local Service Worker playlist for an AirPlay receiver. Instead, obtain
 * high-confidence original-timeline ranges in the background, then seek only
 * while the same native video resource is under this page's control.
 *
 * A multi-variant master may carry different timelines; separate audio can also
 * differ. Until all renditions can be checked, preserve such streams unchanged.
 */
export async function prepareNativePtsAds(raw: string, options: PrepareOptions): Promise<NativePtsAdsPlan> {
  const sourceUrl = mediaUrl(raw);
  const base: NativePtsAdsPlan = {
    status: 'unavailable', reason: 'unsupported_url', sourceUrl: sourceUrl ?? raw,
    durationSeconds: 0, ranges: [],
  };
  if (!sourceUrl) return base;
  const controller = new AbortController();
  const onAbort = () => controller.abort(options.signal?.reason);
  options.signal?.addEventListener('abort', onAbort, { once: true });
  if (options.signal?.aborted) onAbort();
  const timer = setTimeout(() => controller.abort(new DOMException('Ad probe timeout', 'TimeoutError')), TOTAL_TIMEOUT_MS);
  try {
    let url = sourceUrl;
    const seen = new Set<string>();
    for (let depth = 0; depth < MAX_PLAYLIST_DEPTH; depth++) {
      if (seen.has(url)) return { ...base, reason: 'playlist_cycle' };
      seen.add(url);
      const loaded = await playlistText(url, options.fetcher ?? fetch, controller.signal);
      const lines = loaded.text.split(/\r?\n/).map((line) => line.trim());
      if (lines.some((line) => /^#EXT-X-(?:MEDIA|SESSION-KEY):/.test(line))) {
        return { ...base, reason: 'separate_renditions_or_encryption' };
      }
      if (lines.some((line) => /^#EXT-X-STREAM-INF:/.test(line))) {
        const variants: string[] = [];
        let pending = false;
        for (const line of lines) {
          if (line.startsWith('#EXT-X-STREAM-INF:')) {
            if (pending) return { ...base, reason: 'invalid_master' };
            pending = true;
          } else if (line && !line.startsWith('#')) {
            if (!pending) return { ...base, reason: 'invalid_master' };
            const child = mediaUrl(line, loaded.url);
            if (!child) return { ...base, reason: 'unsupported_url' };
            variants.push(child);
            pending = false;
          }
        }
        if (pending || variants.length !== 1) return { ...base, reason: 'multiple_variants' };
        url = variants[0];
        continue;
      }
      const analysis = analyzeHlsPtsPlaylist(loaded.text, loaded.url);
      const durationSeconds = analysis.groups.reduce((sum, group) => sum + group.durationMillis / 1000, 0);
      if (analysis.reason) return { ...base, status: 'unchanged', reason: analysis.reason, durationSeconds };
      const result = await abortable(options.session.filter(loaded.text, loaded.url, controller.signal), controller.signal);
      if (result.status === 'aborted' || !result.complete) return { ...base, reason: 'probe_incomplete', durationSeconds };
      if (result.status !== 'filtered' || !result.removedGroups.length) {
        return { ...base, status: 'unchanged', reason: result.reason, durationSeconds };
      }
      const ranges = result.removedGroups.map((group) => ({
        startSeconds: group.startSeconds, endSeconds: group.startSeconds + group.durationSeconds,
      }));
      return { ...base, status: 'ready', reason: 'pts_continuity', durationSeconds, ranges };
    }
    return { ...base, reason: 'playlist_depth' };
  } catch {
    return { ...base, reason: controller.signal.aborted ? 'cancelled_or_timeout' : 'playlist_unavailable' };
  } finally {
    clearTimeout(timer);
    options.signal?.removeEventListener('abort', onAbort);
    controller.abort();
  }
}

interface SkipOptions {
  plan: NativePtsAdsPlan;
  isCurrent: () => boolean;
  isEnabled?: () => boolean;
  onSkip?: (range: NativePtsAdRange) => void;
}

/** A conservative native fallback. It never starts playback, pauses it, or changes the source. */
export function attachNativePtsAdSkips(video: HTMLVideoElement, options: SkipOptions): () => void {
  const plan = options.plan;
  if (plan.status !== 'ready' || !Number.isFinite(plan.durationSeconds) || plan.durationSeconds <= 0) return () => {};
  const ranges: NativePtsAdRange[] = [];
  for (const range of plan.ranges) {
    if (!Number.isFinite(range.startSeconds) || !Number.isFinite(range.endSeconds)
      || range.startSeconds <= 0 || range.endSeconds <= range.startSeconds
      || range.endSeconds > plan.durationSeconds || range.endSeconds - range.startSeconds > 60
      || (ranges.length > 0 && range.startSeconds < ranges[ranges.length - 1].endSeconds)) return () => {};
    ranges.push({ ...range });
  }
  if (!ranges.length) return () => {};
  let disposed = false;
  let failed = false;
  let checking = false;
  let lastAttempt: number | undefined;
  const check = () => {
    if (disposed || failed || checking || !options.isCurrent() || options.isEnabled?.() === false) return;
    if (video.readyState < 1 || video.currentSrc !== plan.sourceUrl || !Number.isFinite(video.currentTime)
      || !Number.isFinite(video.duration) || Math.abs(video.duration - plan.durationSeconds) > 2) return;
    if (typeof document !== 'undefined' && document.visibilityState === 'hidden') return;
    const index = ranges.findIndex((range) => video.currentTime >= range.startSeconds && video.currentTime < range.endSeconds);
    if (index < 0) { lastAttempt = undefined; return; }
    // A device may ignore/reject a seek. Do not trap it in a repeated seek loop.
    if (lastAttempt === index) return;
    const range = ranges[index];
    lastAttempt = index;
    checking = true;
    try {
      video.currentTime = range.endSeconds;
    } catch { failed = true; }
    finally { checking = false; }
    if (!failed) {
      try { options.onSkip?.(range); } catch { /* A presentation callback cannot break media control. */ }
    }
  };
  const events = ['timeupdate', 'playing', 'seeking', 'seeked', 'loadedmetadata', 'durationchange'] as const;
  events.forEach((event) => video.addEventListener(event, check));
  if (typeof document !== 'undefined') document.addEventListener('visibilitychange', check);
  check();
  return () => {
    disposed = true;
    events.forEach((event) => video.removeEventListener(event, check));
    if (typeof document !== 'undefined') document.removeEventListener('visibilitychange', check);
  };
}
