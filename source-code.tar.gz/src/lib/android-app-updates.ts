export const ANDROID_UPDATE_FEED_URL = 'https://jingaox.github.io/codex-cloud/android/latest.json';
export const ANDROID_APP_ID = 'org.libretv.personal';
const MAX_FEED_BYTES = 64 * 1024;
const UPDATE_TIMEOUT_MS = 8000;

export interface AndroidUpdateManifest {
  appId: typeof ANDROID_APP_ID;
  versionCode: number;
  versionName: string;
  sha256: string;
  downloadUrl: string;
}

export interface AndroidInstalledVersion { versionCode: number; versionName: string }
export class AndroidAppUpdateError extends Error {
  constructor(readonly code: 'invalid' | 'offline' | 'unavailable' | 'not-ready' | 'timeout' | 'cancelled' | 'installed-version', message: string) {
    super(message);
    this.name = 'AndroidAppUpdateError';
  }
}

function invalid(): never { throw new AndroidAppUpdateError('invalid', '更新信息格式不正确，请稍后重试。'); }
function positiveVersion(value: unknown): value is number { return typeof value === 'number' && Number.isSafeInteger(value) && value > 0; }
function versionName(value: unknown): value is string {
  return typeof value === 'string' && value.trim().length > 0 && value.length <= 100 && !/[\u0000-\u001f\u007f]/.test(value);
}

/** Restrict user-initiated APK downloads to this project's own distribution paths. */
export function validateAndroidPackageUrl(raw: unknown): string {
  if (typeof raw !== 'string' || raw.length > 2048 || /[\u0000-\u0020\\]/.test(raw)) return invalid();
  let url: URL;
  try { url = new URL(raw); } catch { return invalid(); }
  if (url.protocol !== 'https:' || url.username || url.password || url.port || url.search || url.hash
    || /%(?:2f|5c|25)/i.test(url.pathname) || !/\.apk$/i.test(url.pathname)) return invalid();
  const ownedPath = (url.hostname === 'jingaox.github.io' && url.pathname.startsWith('/codex-cloud/android/'))
    || (url.hostname === 'github.com' && url.pathname.startsWith('/JinGaoX/codex-cloud/releases/download/'));
  if (!ownedPath) return invalid();
  return url.href;
}

export function parseAndroidUpdateManifest(value: unknown): AndroidUpdateManifest {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return invalid();
  const data = value as Record<string, unknown>;
  if (data.appId !== ANDROID_APP_ID || !positiveVersion(data.versionCode) || !versionName(data.versionName)
    || typeof data.sha256 !== 'string' || !/^[a-f0-9]{64}$/i.test(data.sha256)) return invalid();
  return {
    appId: ANDROID_APP_ID, versionCode: data.versionCode, versionName: data.versionName.trim(),
    sha256: data.sha256.toLowerCase(), downloadUrl: validateAndroidPackageUrl(data.downloadUrl),
  };
}

async function abortable<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) throw signal.reason;
  let abort: (() => void) | undefined;
  try {
    return await Promise.race([
      promise,
      new Promise<never>((_resolve, reject) => {
        abort = () => reject(signal.reason ?? new DOMException('Aborted', 'AbortError'));
        signal.addEventListener('abort', abort, { once: true });
      }),
    ]);
  } finally {
    if (abort) signal.removeEventListener('abort', abort);
  }
}

/** Read the installed APK build, never a website version or a guessed preview value. */
export async function readAndroidInstalledVersion(
  getInfo: () => Promise<{ build: string; version: string }>, externalSignal?: AbortSignal,
): Promise<AndroidInstalledVersion> {
  const controller = new AbortController();
  const onAbort = () => controller.abort(externalSignal?.reason);
  externalSignal?.addEventListener('abort', onAbort, { once: true });
  if (externalSignal?.aborted) onAbort();
  const timer = setTimeout(() => controller.abort(new DOMException('Version timeout', 'TimeoutError')), 3000);
  try {
    if (controller.signal.aborted) throw controller.signal.reason;
    const info = await abortable(Promise.resolve().then(getInfo), controller.signal);
    if (!/^\d+$/.test(info.build) || !positiveVersion(Number(info.build)) || !versionName(info.version)) throw new Error('invalid installed version');
    return { versionCode: Number(info.build), versionName: info.version.trim() };
  } catch {
    if (externalSignal?.aborted) throw new AndroidAppUpdateError('cancelled', '已取消检查更新。');
    throw new AndroidAppUpdateError('installed-version', '无法读取当前安装版本，请关闭 App 后重新打开再试。');
  } finally {
    clearTimeout(timer);
    externalSignal?.removeEventListener('abort', onAbort);
    controller.abort();
  }
}

interface CheckOptions { fetcher?: typeof fetch; signal?: AbortSignal; online?: boolean }
export type AndroidAppUpdateResult = { status: 'available' | 'current' | 'preview'; manifest: AndroidUpdateManifest };

/** Metadata only: never downloads JavaScript, installs packages or changes app resources. */
export async function checkAndroidAppUpdate(currentVersionCode: number | null, options: CheckOptions = {}): Promise<AndroidAppUpdateResult> {
  if (currentVersionCode !== null && !positiveVersion(currentVersionCode)) {
    throw new AndroidAppUpdateError('installed-version', '无法读取当前安装版本，请关闭 App 后重新打开再试。');
  }
  const online = options.online ?? (typeof navigator === 'undefined' ? true : navigator.onLine);
  if (!online) throw new AndroidAppUpdateError('offline', '当前没有网络，请联网后重试。');
  const controller = new AbortController();
  const onAbort = () => controller.abort(options.signal?.reason);
  options.signal?.addEventListener('abort', onAbort, { once: true });
  if (options.signal?.aborted) onAbort();
  const timer = setTimeout(() => controller.abort(new DOMException('Update timeout', 'TimeoutError')), UPDATE_TIMEOUT_MS);
  let response: Response | undefined;
  let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
  try {
    if (controller.signal.aborted) throw controller.signal.reason;
    const pending = (options.fetcher ?? fetch)(ANDROID_UPDATE_FEED_URL, {
      method: 'GET', headers: { Accept: 'application/json' }, credentials: 'omit', mode: 'cors',
      cache: 'no-store', redirect: 'error', signal: controller.signal,
    }).then((value) => {
      if (controller.signal.aborted) {
        void value.body?.cancel().catch(() => {});
        throw controller.signal.reason;
      }
      return value;
    });
    response = await abortable(pending, controller.signal);
    if (response.status === 404) throw new AndroidAppUpdateError('not-ready', '更新服务暂未就绪，请稍后重试。');
    if (!response.ok || response.type === 'opaque') throw new AndroidAppUpdateError('unavailable', '更新服务暂时无法访问，请稍后重试。');
    if (Number(response.headers.get('content-length')) > MAX_FEED_BYTES) return invalid();
    reader = response.body?.getReader();
    if (!reader) return invalid();
    const decoder = new TextDecoder('utf-8', { fatal: true });
    let text = '', bytes = 0;
    while (true) {
      const chunk = await abortable(reader.read(), controller.signal);
      if (chunk.done) break;
      bytes += chunk.value.byteLength;
      if (bytes > MAX_FEED_BYTES) return invalid();
      text += decoder.decode(chunk.value, { stream: true });
    }
    text += decoder.decode();
    let value: unknown;
    try { value = JSON.parse(text); } catch { return invalid(); }
    const manifest = parseAndroidUpdateManifest(value);
    return { manifest, status: currentVersionCode === null ? 'preview' : manifest.versionCode > currentVersionCode ? 'available' : 'current' };
  } catch (error) {
    if (options.signal?.aborted) {
      if (options.signal.reason instanceof DOMException && options.signal.reason.name === 'TimeoutError') {
        throw new AndroidAppUpdateError('timeout', '检查更新超时，请联网后重试。');
      }
      throw new AndroidAppUpdateError('cancelled', '已取消检查更新。');
    }
    if (controller.signal.aborted) throw new AndroidAppUpdateError('timeout', '检查更新超时，请联网后重试。');
    if (error instanceof AndroidAppUpdateError) throw error;
    throw new AndroidAppUpdateError('unavailable', '无法连接更新服务，请检查网络后重试。');
  } finally {
    clearTimeout(timer);
    options.signal?.removeEventListener('abort', onAbort);
    if (reader) void reader.cancel().catch(() => {});
    else if (response) void response.body?.cancel().catch(() => {});
    controller.abort();
  }
}
