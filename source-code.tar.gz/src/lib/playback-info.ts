/** 只描述当前装载媒体；不持久化到影片的历史最高尺寸缓存。 */
export interface PlaybackInfo {
  videoCodec?: string;
  audioCodec?: string;
  /** 实际附加视频样本的平均帧率，非显示刷新率。 */
  frameRate?: number;
  /** 当前片段所在变体的 FRAME-RATE 声明，不能充当实测。 */
  declaredFrameRate?: number;
  /** 完整主分片字节数 / 媒体秒数：含封装，可能含音频。 */
  bitrate?: number;
  bitrateSampleCount: number;
  bitrateSampleSeconds: number;
  droppedFrames?: number;
  totalFrames?: number;
}

export interface PlaybackSegmentSample {
  key: string;
  start: number;
  duration: number;
  level: number;
  continuity: number;
  bytes: number;
  videoCodec?: string;
  audioCodec?: string;
  videoSampleCount?: number;
  videoSampleSeconds?: number;
  declaredFrameRate?: number;
}

const positive = (value: number | undefined): value is number => typeof value === 'number' && Number.isFinite(value) && value > 0;
/** 600 秒缓存窗口可包含数百个短分片；元数据远小于媒体，不能用很小的 FIFO 挤掉当前片。 */
export const PLAYBACK_INFO_MAX_SAMPLES = 4096;

/**
 * 以播放时间选当前分片及此前最多四片，而不是展示下载最远处的缓冲数据。
 * 不跨档位、连续性边界或明显时间缺口求平均；重试和重复缓冲替换同一片。
 */
export class PlaybackInfoTracker {
  private readonly samples = new Map<string, PlaybackSegmentSample>();
  private playhead = 0;

  add(sample: PlaybackSegmentSample): void {
    if (!sample.key || !Number.isFinite(sample.start) || !positive(sample.duration) || !positive(sample.bytes)) return;
    this.samples.delete(sample.key);
    this.samples.set(sample.key, { ...sample });
    if (this.samples.size > PLAYBACK_INFO_MAX_SAMPLES) {
      const ordered = [...this.samples.values()].sort((a, b) => a.start - b.start);
      const protectedKeys = new Set(ordered
        .filter((entry) => entry.start <= this.playhead && entry.start + entry.duration > this.playhead)
        .map((entry) => entry.key));
      ordered.filter((entry) => entry.start + entry.duration <= this.playhead).slice(-4)
        .forEach((entry) => protectedKeys.add(entry.key));
      let farthest: PlaybackSegmentSample | undefined;
      for (const entry of ordered) {
        if (protectedKeys.has(entry.key)) continue;
        if (!farthest || Math.abs(entry.start - this.playhead) > Math.abs(farthest.start - this.playhead)) farthest = entry;
      }
      if (farthest) this.samples.delete(farthest.key);
    }
  }

  at(time: number, preferredKey?: string): PlaybackInfo | null {
    if (!Number.isFinite(time) || time < 0) return null;
    this.playhead = time;
    const ordered = [...this.samples.values()].sort((a, b) => a.start - b.start);
    const candidates = ordered.filter((sample) => sample.start <= time && sample.start + sample.duration > time);
    const current = candidates.find((sample) => sample.key === preferredKey) ?? candidates.at(-1);
    if (!current) return null;
    const window = [current];
    let nextStart = current.start;
    for (const previous of ordered.filter((sample) => sample.start < current.start).reverse()) {
      if (previous.level !== current.level || previous.continuity !== current.continuity) break;
      if (Math.abs(previous.start + previous.duration - nextStart) > 0.35) break;
      window.unshift(previous);
      nextStart = previous.start;
      if (window.length === 5) break;
    }
    const seconds = window.reduce((sum, sample) => sum + sample.duration, 0);
    const bytes = window.reduce((sum, sample) => sum + sample.bytes, 0);
    // FPS 只采用每一片都具有完整视频样本时序的窗口，不能忽略未知片后冒充完整窗口。
    const completeTiming = window.every((sample) => positive(sample.videoSampleCount) && positive(sample.videoSampleSeconds));
    const videoSeconds = completeTiming ? window.reduce((sum, sample) => sum + sample.videoSampleSeconds!, 0) : 0;
    const videoFrames = completeTiming ? window.reduce((sum, sample) => sum + sample.videoSampleCount!, 0) : 0;
    return {
      videoCodec: current.videoCodec,
      audioCodec: current.audioCodec,
      frameRate: videoSeconds > 0 ? videoFrames / videoSeconds : undefined,
      declaredFrameRate: positive(current.declaredFrameRate) ? current.declaredFrameRate : undefined,
      bitrate: bytes * 8 / seconds,
      bitrateSampleCount: window.length,
      bitrateSampleSeconds: seconds,
    };
  }
}
