import { copyFileSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { spawnSync } from 'node:child_process';
import { describe, expect, it } from 'vitest';

const validator = pathToFileURL(path.resolve('scripts/validate-public-sync.mjs')).href;
function syntheticEnvironment(extra: Record<string, string> = {}) {
  const environment: NodeJS.ProcessEnv = { ...process.env, NODE_ENV: 'production' };
  for (const key of ['NEXT_PUBLIC_SYNC_URL', 'NEXT_PUBLIC_SYNC_PUBLISHABLE_KEY', 'NEXT_PUBLIC_SYNC_ALLOW_SIGNUP']) delete environment[key];
  return { ...environment, ...extra };
}
function check(url: string, key: string) {
  const temporary = mkdtempSync(path.join(tmpdir(), 'pps-public-sync-'));
  try {
    return spawnSync(process.execPath, ['--input-type=module', '-e',
      `import {assertPublicSyncConfiguration} from ${JSON.stringify(validator)};assertPublicSyncConfiguration(${JSON.stringify(temporary)});`],
    { encoding: 'utf8', env: syntheticEnvironment({ NEXT_PUBLIC_SYNC_URL: url, NEXT_PUBLIC_SYNC_PUBLISHABLE_KEY: key }) });
  } finally { rmSync(temporary, { recursive: true, force: true }); }
}
describe('public synchronization build guard', () => {
  it('keeps the existing no-account build working', () => { expect(check('', '').status).toBe(0); });
  it('accepts only public project credentials', () => {
    expect(check('https://fixture.supabase.co', 'sb_publishable_public_fixture').status).toBe(0);
    const anon = ['header', Buffer.from(JSON.stringify({ role: 'anon' })).toString('base64url'), 'signature'].join('.');
    expect(check('https://fixture.supabase.co', anon).status).toBe(0);
  });
  it('fails before Next bundles an admin key and never prints the key', () => {
    for (const key of ['sb_secret_never_embed_this', ['header', Buffer.from(JSON.stringify({ role: 'service_role' })).toString('base64url'), 'signature'].join('.')]) {
      const result = check('https://fixture.supabase.co', key);
      expect(result.status).not.toBe(0);
      expect(result.stderr + result.stdout).not.toContain(key);
    }
  });
  it.each(['http://fixture.supabase.co', 'https://user:secret@fixture.supabase.co', 'https://fixture.supabase.co/path', 'https://fixture.supabase.co?secret=1'])('rejects unsafe public endpoints: %s', (url) => {
    expect(check(url, 'sb_publishable_public_fixture').status).not.toBe(0);
  });
});

/** Exercise the real standalone launcher, replacing only Next's expensive compiler with an env recorder. */
function standaloneFixture(files: Record<string, string>, shell: Record<string, string> = {}) {
  const temporary = mkdtempSync(path.join(tmpdir(), 'pps-sync-stage-'));
  const project = path.join(temporary, 'project');
  try {
    for (const directory of ['scripts', 'public', 'node_modules/@next', 'node_modules/next/dist/bin']) mkdirSync(path.join(project, directory), { recursive: true });
    for (const name of ['build-standalone.mjs', 'validate-public-sync.mjs']) copyFileSync(path.resolve('scripts', name), path.join(project, 'scripts', name));
    symlinkSync(path.resolve('node_modules/@next/env'), path.join(project, 'node_modules/@next/env'), process.platform === 'win32' ? 'junction' : 'dir');
    for (const name of ['source-distribution.mjs', 'prepare-standalone-pwa.mjs']) writeFileSync(path.join(project, 'scripts', name), '');
    writeFileSync(path.join(project, 'node_modules/next/dist/bin/next'), `
      const fs = require('node:fs');
      fs.mkdirSync('out', { recursive: true });
      fs.writeFileSync('out/synthetic-env.json', JSON.stringify({
        url: process.env.NEXT_PUBLIC_SYNC_URL,
        key: process.env.NEXT_PUBLIC_SYNC_PUBLISHABLE_KEY,
        signup: process.env.NEXT_PUBLIC_SYNC_ALLOW_SIGNUP,
        hasRootPrivate: Object.hasOwn(process.env, 'ROOT_SYNTHETIC_PRIVATE'),
        hasUnrelatedPublic: Object.hasOwn(process.env, 'NEXT_PUBLIC_SYNTHETIC_UNRELATED'),
        hasEnvFile: fs.existsSync('.env.local') || fs.existsSync('.env'),
      }));
    `);
    for (const [name, contents] of Object.entries(files)) writeFileSync(path.join(project, name), contents);
    const result = spawnSync(process.execPath, [path.join(project, 'scripts/build-standalone.mjs')], {
      encoding: 'utf8', env: syntheticEnvironment(shell), windowsHide: true,
    });
    const captured = path.join(project, 'out/synthetic-env.json');
    return { ...result, captured: existsSync(captured) ? JSON.parse(readFileSync(captured, 'utf8')) : null };
  } finally { rmSync(temporary, { recursive: true, force: true }); }
}

describe('standalone public sync environment forwarding', () => {
  it('loads root .env.local with Next expansion and forwards exactly public sync values to staging', () => {
    const result = standaloneFixture({
      '.env': 'NEXT_PUBLIC_SYNC_URL=https://fallback.supabase.co\nNEXT_PUBLIC_SYNC_PUBLISHABLE_KEY=sb_publishable_fallback_fixture\n',
      '.env.local': 'SYNTHETIC_ORIGIN=https://local.supabase.co\nNEXT_PUBLIC_SYNC_URL=$SYNTHETIC_ORIGIN\nNEXT_PUBLIC_SYNC_PUBLISHABLE_KEY=sb_publishable_local_fixture\nROOT_SYNTHETIC_PRIVATE=never_export_this\nNEXT_PUBLIC_SYNTHETIC_UNRELATED=never_export_this_either\n',
    });
    expect(result.status, result.stderr).toBe(0);
    expect(result.captured).toEqual({ url: 'https://local.supabase.co', key: 'sb_publishable_local_fixture', signup: 'false', hasRootPrivate: false, hasUnrelatedPublic: false, hasEnvFile: false });
    expect(result.stdout + result.stderr).not.toContain('never_export_this');
  });

  it('preserves shell overrides, including explicitly disabled registration', () => {
    const result = standaloneFixture({ '.env.local': 'NEXT_PUBLIC_SYNC_URL=https://local.supabase.co\nNEXT_PUBLIC_SYNC_PUBLISHABLE_KEY=sb_publishable_local_fixture\nNEXT_PUBLIC_SYNC_ALLOW_SIGNUP=true\n' }, {
      NEXT_PUBLIC_SYNC_URL: 'https://shell.supabase.co', NEXT_PUBLIC_SYNC_PUBLISHABLE_KEY: 'sb_publishable_shell_fixture', NEXT_PUBLIC_SYNC_ALLOW_SIGNUP: 'false',
    });
    expect(result.status, result.stderr).toBe(0);
    expect(result.captured).toMatchObject({ url: 'https://shell.supabase.co', key: 'sb_publishable_shell_fixture', signup: 'false' });
  });

  it('forwards signup only when explicitly enabled and keeps no-account exports valid', () => {
    const enabled = standaloneFixture({ '.env.local': 'NEXT_PUBLIC_SYNC_URL=https://local.supabase.co\nNEXT_PUBLIC_SYNC_PUBLISHABLE_KEY=sb_publishable_local_fixture\nNEXT_PUBLIC_SYNC_ALLOW_SIGNUP=true\n' });
    expect(enabled.status, enabled.stderr).toBe(0);
    expect(enabled.captured.signup).toBe('true');
    const unconfigured = standaloneFixture({});
    expect(unconfigured.status, unconfigured.stderr).toBe(0);
    expect(unconfigured.captured).toMatchObject({ url: '', key: '', signup: 'false' });
  });

  it('rejects a privileged key from .env.local before running the stage compiler without printing it', () => {
    const key = 'sb_secret_synthetic_do_not_print';
    const result = standaloneFixture({ '.env.local': `NEXT_PUBLIC_SYNC_URL=https://local.supabase.co\nNEXT_PUBLIC_SYNC_PUBLISHABLE_KEY=${key}\n` });
    expect(result.status).not.toBe(0);
    expect(result.captured).toBeNull();
    expect(result.stdout + result.stderr).not.toContain(key);
    expect(result.stderr).toContain('must be publishable/anon');
  });
});
