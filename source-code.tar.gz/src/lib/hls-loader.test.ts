import type Hls from 'hls.js';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { createHlsLoader } from './hls-loader';

const cache = vi.hoisted(() => ({
  key: vi.fn((url: string) => url), read: vi.fn(), touch: vi.fn(),
}));
vi.mock('./video-cache', () => ({
  buildSegmentCacheKey: cache.key, readCachedSegment: cache.read, touchMeta: cache.touch,
}));

interface Request {
  context: Record<string, unknown>;
  callbacks: Record<string, (...args: unknown[]) => void>;
}
class NetworkLoader {
  stats = {};
  requests: Request[] = [];
  load(context: Request['context'], _config: unknown, callbacks: Request['callbacks']) {
    this.requests.push({ context, callbacks });
  }
  abort() {}
  destroy() {}
}
const hls = { DefaultConfig: { loader: NetworkLoader } } as unknown as typeof Hls;
const adPlaylist = '#EXTM3U\n#EXTINF:300,\nmovie1.ts\n#EXT-X-DISCONTINUITY\n#EXTINF:18,\n/video/adjump/ad.ts\n#EXT-X-DISCONTINUITY\n#EXTINF:300,\nmovie2.ts\n#EXT-X-ENDLIST';
const shortPlaylist = adPlaylist.replace('/video/adjump/ad.ts', 'movie-short.ts');

function make(options: Parameters<typeof createHlsLoader>[1] = {}) {
  const Loader = createHlsLoader(hls, options);
  const loader = new Loader({}) as NetworkLoader;
  const callbacks = { onSuccess: vi.fn(), onError: vi.fn(), onTimeout: vi.fn(), onProgress: vi.fn(), onAbort: vi.fn() };
  return { loader, callbacks };
}
function respond(loader: NetworkLoader, content: string) {
  const request = loader.requests.at(-1)!;
  request.callbacks.onSuccess({ data: content }, {}, request.context, undefined);
}

describe('hls.js loader 广告策略与独立版缓存边界', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    cache.read.mockResolvedValue(null);
    cache.touch.mockResolvedValue(undefined);
  });

  it.each(['manifest', 'level'])('explicit 只在%s响应删除明确广告组', (type) => {
    const { loader, callbacks } = make({ blockAd: true, adPolicy: 'explicit', cacheSegments: false });
    loader.load({ type, url: 'https://media.example/film.m3u8' }, {}, callbacks);
    respond(loader, adPlaylist);
    expect(callbacks.onSuccess).toHaveBeenCalledOnce();
    const result = callbacks.onSuccess.mock.calls[0][0].data;
    expect(result).not.toContain('adjump');
    expect(result).toContain('movie1.ts');
    expect(result).toContain('movie2.ts');
    expect(cache.read).not.toHaveBeenCalled();
  });

  it('explicit 保留正常短场景，桌面默认策略保持原行为', () => {
    const standalone = make({ blockAd: true, adPolicy: 'explicit', cacheSegments: false });
    standalone.loader.load({ type: 'level' }, {}, standalone.callbacks);
    respond(standalone.loader, shortPlaylist);
    expect(standalone.callbacks.onSuccess.mock.calls[0][0].data).toBe(shortPlaylist);
    const desktop = make({ blockAd: true });
    desktop.loader.load({ type: 'level' }, {}, desktop.callbacks);
    respond(desktop.loader, shortPlaylist);
    expect(desktop.callbacks.onSuccess.mock.calls[0][0].data).not.toContain('movie-short.ts');
  });

  it('关闭广告过滤时清单原样传递', () => {
    const { loader, callbacks } = make({ blockAd: false, adPolicy: 'explicit', cacheSegments: false });
    loader.load({ type: 'manifest' }, {}, callbacks);
    respond(loader, adPlaylist);
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe(adPlaylist);
  });

  it('独立版分片直接走网络，不读取缓存、不更新缓存元数据', () => {
    const onProbe = vi.fn();
    const { loader, callbacks } = make({ blockAd: true, adPolicy: 'explicit', cacheSegments: false, onProbe });
    loader.load({ type: 'fragment', url: 'https://media.example/a.ts' }, {}, callbacks);
    expect(loader.requests).toHaveLength(1);
    expect(cache.key).not.toHaveBeenCalled();
    expect(cache.read).not.toHaveBeenCalled();
    expect(cache.touch).not.toHaveBeenCalled();
    expect(onProbe).not.toHaveBeenCalled();
    respond(loader, 'media bytes');
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe('media bytes');
  });

  it.each(['abort', 'destroy'] as const)('%s 后忽略迟到的网络回调', (method) => {
    const { loader, callbacks } = make({ blockAd: true, adPolicy: 'explicit', cacheSegments: false });
    loader.load({ type: 'manifest' }, {}, callbacks);
    loader[method]();
    respond(loader, adPlaylist);
    const request = loader.requests[0];
    for (const name of ['onError', 'onTimeout', 'onProgress', 'onAbort']) request.callbacks[name]({});
    for (const callback of Object.values(callbacks)) expect(callback).not.toHaveBeenCalled();
    loader.load({ type: 'fragment', url: 'https://media.example/a.ts' }, {}, callbacks);
    expect(loader.requests).toHaveLength(1);
  });

  it('缓存读取期间销毁，命中后也不能回调或触碰元数据', async () => {
    let finish!: (value: { data: ArrayBuffer; costMs: number }) => void;
    cache.read.mockReturnValue(new Promise((resolve) => { finish = resolve; }));
    const onProbe = vi.fn();
    const { loader, callbacks } = make({ onProbe });
    loader.load({ type: 'fragment', url: 'https://media.example/a.ts' }, {}, callbacks);
    loader.destroy();
    finish({ data: new ArrayBuffer(10), costMs: 50 });
    await Promise.resolve();
    expect(callbacks.onSuccess).not.toHaveBeenCalled();
    expect(loader.requests).toHaveLength(0);
    expect(cache.touch).not.toHaveBeenCalled();
    expect(onProbe).not.toHaveBeenCalled();
  });

  it('桌面缓存命中仍保留真实耗时并避免重复网络请求', async () => {
    const bytes = new ArrayBuffer(20);
    cache.read.mockResolvedValue({ data: bytes, costMs: 75 });
    const { loader, callbacks } = make();
    loader.load({ type: 'fragment', url: 'https://media.example/a.ts' }, {}, callbacks);
    await Promise.resolve();
    expect(loader.requests).toHaveLength(0);
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe(bytes);
    const stats = callbacks.onSuccess.mock.calls[0][1];
    expect(stats.loading.end - stats.loading.start).toBeCloseTo(75);
    expect(cache.touch).toHaveBeenCalledWith('https://media.example/a.ts');
  });

  it('范围从0开始的BYTERANGE也直接走网络', () => {
    const { loader, callbacks } = make();
    loader.load({ type: 'fragment', url: 'https://media.example/a.ts', rangeStart: 0, rangeEnd: 10 }, {}, callbacks);
    expect(loader.requests).toHaveLength(1);
    expect(cache.read).not.toHaveBeenCalled();
  });
});
