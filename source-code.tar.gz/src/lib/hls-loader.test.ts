import type Hls from 'hls.js';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import { createHlsLoader } from './hls-loader';
import type { HlsPtsFilterResult } from './hls-pts-filter';

const cache = vi.hoisted(() => ({
  key: vi.fn((url: string) => url), read: vi.fn(), touch: vi.fn(),
}));
vi.mock('./video-cache', () => ({
  buildSegmentCacheKey: cache.key, readCachedSegment: cache.read, touchMeta: cache.touch,
}));

interface Request {
  context: Record<string, unknown>;
  callbacks: Record<string, (...args: unknown[]) => void>;
}
class NetworkLoader {
  stats = {};
  requests: Request[] = [];
  load(context: Request['context'], _config: unknown, callbacks: Request['callbacks']) {
    this.requests.push({ context, callbacks });
  }
  abort() {}
  destroy() {}
}
const hls = { DefaultConfig: { loader: NetworkLoader } } as unknown as typeof Hls;
const adPlaylist = '#EXTM3U\n#EXTINF:300,\nmovie1.ts\n#EXT-X-DISCONTINUITY\n#EXTINF:18,\n/video/adjump/ad.ts\n#EXT-X-DISCONTINUITY\n#EXTINF:300,\nmovie2.ts\n#EXT-X-ENDLIST';
const shortPlaylist = adPlaylist.replace('/video/adjump/ad.ts', 'movie-short.ts');

function make(options: Parameters<typeof createHlsLoader>[1] = {}) {
  const Loader = createHlsLoader(hls, options);
  const loader = new Loader({}) as NetworkLoader;
  const callbacks = { onSuccess: vi.fn(), onError: vi.fn(), onTimeout: vi.fn(), onProgress: vi.fn(), onAbort: vi.fn() };
  return { loader, callbacks };
}
function respond(loader: NetworkLoader, content: string) {
  const request = loader.requests.at(-1)!;
  request.callbacks.onSuccess({ data: content }, {}, request.context, undefined);
}

function ptsResult(content: string): HlsPtsFilterResult {
  return { content, status: 'unchanged', reason: 'no_ad', removedGroups: [], removedSeconds: 0,
    probedGroups: 3, totalGroups: 3, complete: true };
}

describe('hls.js loader 广告策略与独立版缓存边界', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    cache.read.mockResolvedValue(null);
    cache.touch.mockResolvedValue(undefined);
  });

  it.each(['manifest', 'level'])('explicit 只在%s响应删除明确广告组', (type) => {
    const { loader, callbacks } = make({ blockAd: true, adPolicy: 'explicit', cacheSegments: false });
    loader.load({ type, url: 'https://media.example/film.m3u8' }, {}, callbacks);
    respond(loader, adPlaylist);
    expect(callbacks.onSuccess).toHaveBeenCalledOnce();
    const result = callbacks.onSuccess.mock.calls[0][0].data;
    expect(result).not.toContain('adjump');
    expect(result).toContain('movie1.ts');
    expect(result).toContain('movie2.ts');
    expect(cache.read).not.toHaveBeenCalled();
  });

  it('explicit 保留正常短场景，旧时长策略只在显式指定时使用', () => {
    const standalone = make({ blockAd: true, adPolicy: 'explicit', cacheSegments: false });
    standalone.loader.load({ type: 'level' }, {}, standalone.callbacks);
    respond(standalone.loader, shortPlaylist);
    expect(standalone.callbacks.onSuccess.mock.calls[0][0].data).toBe(shortPlaylist);
    const desktop = make({ blockAd: true, adPolicy: 'legacy' });
    desktop.loader.load({ type: 'level' }, {}, desktop.callbacks);
    respond(desktop.loader, shortPlaylist);
    expect(desktop.callbacks.onSuccess.mock.calls[0][0].data).not.toContain('movie-short.ts');
  });

  it('关闭广告过滤时清单原样传递', () => {
    const { loader, callbacks } = make({ blockAd: false, adPolicy: 'explicit', cacheSegments: false });
    loader.load({ type: 'manifest' }, {}, callbacks);
    respond(loader, adPlaylist);
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe(adPlaylist);
  });

  it('独立版分片直接走网络，不读取缓存、不更新缓存元数据', () => {
    const onProbe = vi.fn();
    const { loader, callbacks } = make({ blockAd: true, adPolicy: 'explicit', cacheSegments: false, onProbe });
    loader.load({ type: 'fragment', url: 'https://media.example/a.ts' }, {}, callbacks);
    expect(loader.requests).toHaveLength(1);
    expect(cache.key).not.toHaveBeenCalled();
    expect(cache.read).not.toHaveBeenCalled();
    expect(cache.touch).not.toHaveBeenCalled();
    expect(onProbe).not.toHaveBeenCalled();
    respond(loader, 'media bytes');
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe('media bytes');
  });

  it.each(['abort', 'destroy'] as const)('%s 后忽略迟到的网络回调', (method) => {
    const { loader, callbacks } = make({ blockAd: true, adPolicy: 'explicit', cacheSegments: false });
    loader.load({ type: 'manifest' }, {}, callbacks);
    loader[method]();
    respond(loader, adPlaylist);
    const request = loader.requests[0];
    for (const name of ['onError', 'onTimeout', 'onProgress', 'onAbort']) request.callbacks[name]({});
    for (const callback of Object.values(callbacks)) expect(callback).not.toHaveBeenCalled();
    loader.load({ type: 'fragment', url: 'https://media.example/a.ts' }, {}, callbacks);
    expect(loader.requests).toHaveLength(1);
  });

  it('缓存读取期间销毁，命中后也不能回调或触碰元数据', async () => {
    let finish!: (value: { data: ArrayBuffer; costMs: number }) => void;
    cache.read.mockReturnValue(new Promise((resolve) => { finish = resolve; }));
    const onProbe = vi.fn();
    const { loader, callbacks } = make({ onProbe });
    loader.load({ type: 'fragment', url: 'https://media.example/a.ts' }, {}, callbacks);
    loader.destroy();
    finish({ data: new ArrayBuffer(10), costMs: 50 });
    await Promise.resolve();
    expect(callbacks.onSuccess).not.toHaveBeenCalled();
    expect(loader.requests).toHaveLength(0);
    expect(cache.touch).not.toHaveBeenCalled();
    expect(onProbe).not.toHaveBeenCalled();
  });

  it('桌面缓存命中仍保留真实耗时并避免重复网络请求', async () => {
    const bytes = new ArrayBuffer(20);
    cache.read.mockResolvedValue({ data: bytes, costMs: 75 });
    const { loader, callbacks } = make();
    loader.load({ type: 'fragment', url: 'https://media.example/a.ts' }, {}, callbacks);
    await Promise.resolve();
    expect(loader.requests).toHaveLength(0);
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe(bytes);
    const stats = callbacks.onSuccess.mock.calls[0][1];
    expect(stats.loading.end - stats.loading.start).toBeCloseTo(75);
    expect(cache.touch).toHaveBeenCalledWith('https://media.example/a.ts');
  });

  it('范围从0开始的BYTERANGE也直接走网络', () => {
    const { loader, callbacks } = make();
    loader.load({ type: 'fragment', url: 'https://media.example/a.ts', rangeStart: 0, rangeEnd: 10 }, {}, callbacks);
    expect(loader.requests).toHaveLength(1);
    expect(cache.read).not.toHaveBeenCalled();
  });

  it('所有点播默认等待PTS判断，不再按短片段时长猜测', async () => {
    let finish!: (result: HlsPtsFilterResult) => void;
    const filter = vi.fn(() => new Promise<HlsPtsFilterResult>((resolve) => { finish = resolve; }));
    const onAdFilterResult = vi.fn();
    const { loader, callbacks } = make({ blockAd: true, cacheSegments: false,
      ptsSession: { filter, destroy: vi.fn() }, onAdFilterResult });
    loader.load({ type: 'level', url: 'https://media.example/film.m3u8' }, {}, callbacks);
    respond(loader, shortPlaylist);
    expect(callbacks.onSuccess).not.toHaveBeenCalled();
    finish(ptsResult(shortPlaylist));
    await Promise.resolve();
    expect(filter).toHaveBeenCalledWith(shortPlaylist, 'https://media.example/film.m3u8', expect.any(AbortSignal));
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe(shortPlaylist);
    expect(onAdFilterResult).toHaveBeenCalledOnce();
    expect(cache.read).not.toHaveBeenCalled();
  });

  it.each(['abort', 'destroy'] as const)('PTS检测中%s取消，迟到结果不能递交旧清单', async (method) => {
    let finish!: (result: HlsPtsFilterResult) => void;
    const filter = vi.fn(() => new Promise<HlsPtsFilterResult>((resolve) => { finish = resolve; }));
    const onAdFilterResult = vi.fn();
    const { loader, callbacks } = make({ blockAd: true,
      ptsSession: { filter, destroy: vi.fn() }, onAdFilterResult });
    loader.load({ type: 'manifest', url: 'https://media.example/a.m3u8' }, {}, callbacks);
    respond(loader, adPlaylist);
    const signal = (filter.mock.calls as unknown as [string, string, AbortSignal][])[0][2];
    loader[method]();
    expect(signal.aborted).toBe(true);
    finish(ptsResult(adPlaylist));
    await Promise.resolve();
    expect(callbacks.onSuccess).not.toHaveBeenCalled();
    expect(onAdFilterResult).not.toHaveBeenCalled();
  });

  it('探测异常原样播放，不把可播放的片源报告为错误', async () => {
    const { loader, callbacks } = make({ blockAd: true,
      ptsSession: { filter: vi.fn().mockRejectedValue(new Error('CORS')), destroy: vi.fn() } });
    loader.load({ type: 'manifest', url: 'https://media.example/a.m3u8' }, {}, callbacks);
    respond(loader, adPlaylist);
    await Promise.resolve(); await Promise.resolve();
    expect(callbacks.onSuccess).toHaveBeenCalledOnce();
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe(adPlaylist);
    expect(callbacks.onError).not.toHaveBeenCalled();
  });

  it('过滤后只递交完成连续性核对的清单，时间轴仍沿用相同广告结果', async () => {
    const filtered = { ...ptsResult('filtered'), status: 'filtered' as const };
    let finish!: (result: HlsPtsFilterResult) => void;
    const smooth = vi.fn(() => new Promise<HlsPtsFilterResult>((resolve) => { finish = resolve; }));
    const onAdFilterResult = vi.fn();
    const { loader, callbacks } = make({ blockAd: true, cacheSegments: false,
      ptsSession: { filter: vi.fn().mockResolvedValue(filtered), destroy: vi.fn() },
      spliceSession: { smooth, destroy: vi.fn() }, onAdFilterResult });
    loader.load({ type: 'level', url: 'https://media.example/film.m3u8' }, {}, callbacks);
    respond(loader, adPlaylist);
    await Promise.resolve();
    expect(smooth).toHaveBeenCalledWith(adPlaylist, filtered, 'https://media.example/film.m3u8', expect.any(AbortSignal));
    expect(callbacks.onSuccess).not.toHaveBeenCalled();
    const joined = { ...filtered, content: 'filtered-and-joined' };
    finish(joined);
    await Promise.resolve();
    expect(callbacks.onSuccess).toHaveBeenCalledOnce();
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe(joined.content);
    expect(onAdFilterResult).toHaveBeenCalledWith(joined, adPlaylist);
    expect(cache.read).not.toHaveBeenCalled();
  });

  it('连续性核对失败仍保留已经去掉的广告，不能回退含广告原片', async () => {
    const filtered = { ...ptsResult('filtered-without-ad'), status: 'filtered' as const };
    const { loader, callbacks } = make({ blockAd: true,
      ptsSession: { filter: vi.fn().mockResolvedValue(filtered), destroy: vi.fn() },
      spliceSession: { smooth: vi.fn().mockRejectedValue(new Error('CORS')), destroy: vi.fn() } });
    loader.load({ type: 'manifest', url: 'https://media.example/a.m3u8' }, {}, callbacks);
    respond(loader, adPlaylist);
    await Promise.resolve(); await Promise.resolve();
    expect(callbacks.onSuccess).toHaveBeenCalledOnce();
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe(filtered.content);
    expect(callbacks.onError).not.toHaveBeenCalled();
  });

  it.each(['abort', 'destroy'] as const)('拼接检查期间%s不能递交迟到结果或旧时间轴', async (method) => {
    let finish!: (result: HlsPtsFilterResult) => void;
    const filtered = { ...ptsResult('filtered'), status: 'filtered' as const };
    const smooth = vi.fn(() => new Promise<HlsPtsFilterResult>((resolve) => { finish = resolve; }));
    const onAdFilterResult = vi.fn();
    const { loader, callbacks } = make({ blockAd: true,
      ptsSession: { filter: vi.fn().mockResolvedValue(filtered), destroy: vi.fn() },
      spliceSession: { smooth, destroy: vi.fn() }, onAdFilterResult });
    loader.load({ type: 'level', url: 'https://media.example/a.m3u8' }, {}, callbacks);
    respond(loader, adPlaylist);
    await Promise.resolve();
    const signal = (smooth.mock.calls as unknown as [string, HlsPtsFilterResult, string, AbortSignal][])[0][3];
    loader[method]();
    expect(signal.aborted).toBe(true);
    finish(filtered);
    await Promise.resolve();
    expect(callbacks.onSuccess).not.toHaveBeenCalled();
    expect(onAdFilterResult).not.toHaveBeenCalled();
  });

  it('没有删除广告时不进行额外整片拼接读取', async () => {
    const unchanged = ptsResult(shortPlaylist);
    const smooth = vi.fn();
    const { loader, callbacks } = make({ blockAd: true,
      ptsSession: { filter: vi.fn().mockResolvedValue(unchanged), destroy: vi.fn() },
      spliceSession: { smooth, destroy: vi.fn() } });
    loader.load({ type: 'level', url: 'https://media.example/a.m3u8' }, {}, callbacks);
    respond(loader, shortPlaylist);
    await Promise.resolve();
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe(shortPlaylist);
    expect(smooth).not.toHaveBeenCalled();
  });

  it('过滤完成后上层观察回调异常，也不应重新送入已删除的广告', async () => {
    const filtered = { ...ptsResult('filtered-without-ad'), status: 'filtered' as const };
    const { loader, callbacks } = make({ blockAd: true,
      ptsSession: { filter: vi.fn().mockResolvedValue(filtered), destroy: vi.fn() },
      spliceSession: { smooth: vi.fn().mockResolvedValue(filtered), destroy: vi.fn() },
      onAdFilterResult: () => { throw new Error('Observer failed'); } });
    loader.load({ type: 'manifest', url: 'https://media.example/a.m3u8' }, {}, callbacks);
    respond(loader, adPlaylist);
    await vi.waitFor(() => expect(callbacks.onSuccess).toHaveBeenCalledOnce());
    expect(callbacks.onSuccess.mock.calls[0][0].data).toBe(filtered.content);
  });

  it('多码率或独立音轨未核对一致时，全会话保持原片避免ABR时轴错位', async () => {
    const filter = vi.fn().mockResolvedValue(ptsResult(shortPlaylist));
    const Loader = createHlsLoader(hls, { blockAd: true, ptsSession: { filter, destroy: vi.fn() } });
    const master = new Loader({}) as NetworkLoader;
    const level = new Loader({}) as NetworkLoader;
    const cb = { onSuccess: vi.fn() };
    const content = '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=100\na.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=200\nb.m3u8';
    master.load({ type: 'manifest', url: 'https://media.example/master.m3u8' }, {}, cb);
    respond(master, content);
    level.load({ type: 'level', url: 'https://media.example/a.m3u8' }, {}, cb);
    respond(level, shortPlaylist);
    await Promise.resolve();
    expect(filter).not.toHaveBeenCalled();
    expect(cb.onSuccess.mock.calls[0][0].data).toBe(content);
    expect(cb.onSuccess.mock.calls[1][0].data).toBe(shortPlaylist);
  });
});
