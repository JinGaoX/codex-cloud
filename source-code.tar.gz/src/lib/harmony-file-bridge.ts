import { IS_HARMONY } from './runtime-mode';
import { validateExportFilename } from './file-export-filename';

const TRUSTED_ORIGIN = 'https://vip.localhost';
const MAX_REQUEST_CHARACTERS = 8 * 1024 * 1024;
const RESPONSE_TIMEOUT_MS = 15 * 60 * 1000;
type ExportResult = 'saved' | 'cancelled';
type HarmonyBridge = {
  saveFile(requestJson: string): void;
  shareSource(requestJson: string): void;
};

declare global {
  interface Window {
    VIPHarmony?: HarmonyBridge;
    __VIP_HARMONY_RESOLVE?: (id: string, resultJson: string) => void;
  }
}

type PendingExport = {
  resolve: (result: ExportResult) => void;
  reject: (error: Error) => void;
};
const pending = new Map<string, PendingExport>();

function requireBridge(): HarmonyBridge {
  if (!IS_HARMONY || typeof window === 'undefined' || window.location.origin !== TRUSTED_ORIGIN) {
    throw new Error('请在已安装的鸿蒙 App 中导出文件');
  }
  const bridge = window.VIPHarmony;
  if (!bridge || typeof bridge.saveFile !== 'function' || typeof bridge.shareSource !== 'function') {
    throw new Error('鸿蒙文件接口尚未就绪，请重新打开 App');
  }
  return bridge;
}

function resolveExport(id: string, resultJson: string): void {
  // The native layer also validates the main frame and fixed virtual origin.
  // Ignore unsolicited/stale replies; never evaluate native callback contents.
  if (window.location.origin !== TRUSTED_ORIGIN || typeof id !== 'string') return;
  const request = pending.get(id);
  if (!request) return;
  try {
    if (typeof resultJson !== 'string' || resultJson.length > 2048) throw new Error();
    const result: unknown = JSON.parse(resultJson);
    if (!result || typeof result !== 'object' || !('status' in result)) throw new Error();
    if (result.status === 'saved' || result.status === 'cancelled') {
      request.resolve(result.status);
    } else if (result.status === 'error') {
      const message = 'message' in result && typeof result.message === 'string'
        ? result.message.slice(0, 300) : '';
      request.reject(new Error(message || '鸿蒙文件导出失败，请重试'));
    } else throw new Error();
  } catch {
    request.reject(new Error('鸿蒙文件接口返回了无效结果，请重试'));
  }
}

function requestExport(method: keyof HarmonyBridge, payload: { filename: string; text: string } | Record<string, never>): Promise<ExportResult> {
  const bridge = requireBridge();
  const id = Array.from(crypto.getRandomValues(new Uint8Array(16)), (byte) => byte.toString(16).padStart(2, '0')).join('');
  const requestJson = JSON.stringify({ id, ...payload });
  if (requestJson.length > MAX_REQUEST_CHARACTERS) throw new Error('导出文件过大，请减少配置内容后重试');
  // Install only on a user-initiated export, never send files during startup.
  window.__VIP_HARMONY_RESOLVE = resolveExport;
  return new Promise((resolve, reject) => {
    const finish = (result?: ExportResult, error?: Error) => {
      clearTimeout(timer);
      window.removeEventListener('pagehide', onPageHide);
      pending.delete(id);
      if (error) reject(error);
      else resolve(result!);
    };
    const onPageHide = () => finish(undefined, new Error('页面已关闭，导出已中止'));
    const timer = setTimeout(() => finish(undefined, new Error('导出等待超时，请检查文件保存窗口后重试')), RESPONSE_TIMEOUT_MS);
    pending.set(id, { resolve: (result) => finish(result), reject: (error) => finish(undefined, error) });
    window.addEventListener('pagehide', onPageHide, { once: true });
    try {
      bridge[method](requestJson);
    } catch {
      finish(undefined, new Error('无法打开鸿蒙文件保存窗口，请重试'));
    }
  });
}

/** Called only by the explicit export action; no upload or remote fallback. */
export function exportHarmonyTextFile(text: string, filename: string): Promise<ExportResult> {
  validateExportFilename(filename);
  return requestExport('saveFile', { filename, text });
}

/** Native code reads the fixed bundled source-code.tar.gz, never a supplied URL. */
export function exportHarmonySourceArchive(): Promise<ExportResult> {
  return requestExport('shareSource', {});
}
