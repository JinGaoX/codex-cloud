import { describe, expect, it } from 'vitest';
import { planSyncApply, type LocalSyncSnapshot } from './personal-sync-apply';
import { canonicalSourceKey, type SyncRecord } from './personal-sync-model';

const oldUrl = 'https://old-fixture.invalid/api.php/provide/vod';
const newUrl = 'https://new-fixture.invalid/api.php/provide/vod';
const oldKey = canonicalSourceKey(oldUrl);
function snapshot(): LocalSyncSnapshot {
  const source = { key: 'custom_7', name: '新来源', url: newUrl };
  return { sources: [source], customAPIs: [source], envSources: [], selectedKeys: [source.key],
    sourceAliases: [{ key: 'custom_7', name: '已删除的旧来源', url: oldUrl }],
    history: [{ id: 'custom_7_12', sourceKey: 'custom_7', sourceUrl: newUrl, vodId: '12', title: '新来源影片',
      episodeIndex: 0, totalEpisodes: 1, playbackPosition: 90, duration: 1200, timestamp: 2000 }],
    progress: [{ key: 'custom_7_12_0', position: 90, duration: 1200, updatedAt: 2000 },
      { key: `${oldKey}_12_0`, position: 10, duration: 1200, updatedAt: 1000 }], favorites: [],
  };
}

describe('跨片源应用计划不信任已过时的本机别名', () => {
  it('旧 URL 的远端历史更新不能借复用 custom_N 覆盖新 URL 的历史', () => {
    const row: SyncRecord = { kind: 'history', key: JSON.stringify([oldUrl, '12']), payload: {
      sourceKey: oldKey, sourceUrl: oldUrl, vodId: '12', title: '旧来源影片', episodeIndex: 0, totalEpisodes: 1,
      playbackPosition: 10, duration: 1200, timestamp: 1000,
    }, revision: 1, deleted: false, updatedAt: 1000 };
    const plan = planSyncApply(snapshot(), [row]);
    expect(plan.mutations[0].key).toBe(`${oldKey}_12`);
    expect(plan.projected.history.find((entry) => entry.id === 'custom_7_12')).toMatchObject({ title: '新来源影片', sourceUrl: newUrl, playbackPosition: 90 });
    expect(plan.projected.history.find((entry) => entry.id === `${oldKey}_12`)).toMatchObject({ title: '旧来源影片', sourceUrl: oldUrl });
  });

  it('旧 URL 的进度删除只删 canonical 记录，不能删除新来源相同数字 ID 的进度', () => {
    const row: SyncRecord = { kind: 'progress', key: JSON.stringify([oldUrl, '12', 0]), payload: null,
      revision: 2, deleted: true, updatedAt: 2000 };
    const plan = planSyncApply(snapshot(), [row]);
    expect(plan.mutations[0].key).toBe(`${oldKey}_12_0`);
    expect(plan.projected.progress.find((entry) => entry.key === 'custom_7_12_0')?.position).toBe(90);
    expect(plan.projected.progress.find((entry) => entry.key === `${oldKey}_12_0`)).toBeUndefined();
    expect(plan.projected.customAPIs[0].url).toBe(newUrl);
  });
});
