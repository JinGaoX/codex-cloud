import { describe, expect, it } from 'vitest';
import { planSyncApply, type LocalSyncSnapshot } from './personal-sync-apply';
import { canonicalSourceKey, snapshotToRecords, type SnapshotRecord, type SyncRecord } from './personal-sync-model';

const oldUrl = 'https://old-fixture.invalid/api.php/provide/vod';
const newUrl = 'https://new-fixture.invalid/api.php/provide/vod';
const oldKey = canonicalSourceKey(oldUrl);
function snapshot(): LocalSyncSnapshot {
  const source = { key: 'custom_7', name: '新来源', url: newUrl };
  return { sources: [source], customAPIs: [source], envSources: [], selectedKeys: [source.key],
    sourceAliases: [{ key: 'custom_7', name: '已删除的旧来源', url: oldUrl }],
    history: [{ id: 'custom_7_12', sourceKey: 'custom_7', sourceUrl: newUrl, vodId: '12', title: '新来源影片',
      episodeIndex: 0, totalEpisodes: 1, playbackPosition: 90, duration: 1200, timestamp: 2000 }],
    progress: [{ key: 'custom_7_12_0', position: 90, duration: 1200, updatedAt: 2000 },
      { key: `${oldKey}_12_0`, position: 10, duration: 1200, updatedAt: 1000 }], favorites: [],
  };
}

describe('跨片源应用计划不信任已过时的本机别名', () => {
  it('旧 URL 的远端历史更新不能借复用 custom_N 覆盖新 URL 的历史', () => {
    const row: SyncRecord = { kind: 'history', key: JSON.stringify([oldUrl, '12']), payload: {
      sourceKey: oldKey, sourceUrl: oldUrl, vodId: '12', title: '旧来源影片', episodeIndex: 0, totalEpisodes: 1,
      playbackPosition: 10, duration: 1200, timestamp: 1000,
    }, revision: 1, deleted: false, updatedAt: 1000 };
    const plan = planSyncApply(snapshot(), [row]);
    expect(plan.mutations[0].key).toBe(`${oldKey}_12`);
    expect(plan.projected.history.find((entry) => entry.id === 'custom_7_12')).toMatchObject({ title: '新来源影片', sourceUrl: newUrl, playbackPosition: 90 });
    expect(plan.projected.history.find((entry) => entry.id === `${oldKey}_12`)).toMatchObject({ title: '旧来源影片', sourceUrl: oldUrl });
  });

  it('旧 URL 的进度删除只删 canonical 记录，不能删除新来源相同数字 ID 的进度', () => {
    const row: SyncRecord = { kind: 'progress', key: JSON.stringify([oldUrl, '12', 0]), payload: null,
      revision: 2, deleted: true, updatedAt: 2000 };
    const plan = planSyncApply(snapshot(), [row]);
    expect(plan.mutations[0].key).toBe(`${oldKey}_12_0`);
    expect(plan.projected.progress.find((entry) => entry.key === 'custom_7_12_0')?.position).toBe(90);
    expect(plan.projected.progress.find((entry) => entry.key === `${oldKey}_12_0`)).toBeUndefined();
    expect(plan.projected.customAPIs[0].url).toBe(newUrl);
  });
});

describe('直播资料跨设备应用计划', () => {
  const playlist = 'https://live-fixture.invalid/channels.m3u';
  const channel = 'https://stream-fixture.invalid/channel.m3u8';
  const epg = 'https://live-fixture.invalid/guide.xml';
  const wire = (row: SnapshotRecord, revision = 1): SyncRecord => ({ ...row, revision, deleted: false, updatedAt: 100 });
  const deleted = (kind: SyncRecord['kind'], key: string): SyncRecord => ({ kind, key, payload: null, revision: 2, deleted: true, updatedAt: 200 });
  const liveSnapshot = (): LocalSyncSnapshot => ({ ...snapshot(), liveSubscriptions: [], liveSelectedUrls: [], liveFavorites: [], liveRecent: [] });

  it('设备甲的直播源与启用状态、收藏、最近观看完整投影到设备乙，保留已有点播资料', async () => {
    const from = liveSnapshot();
    from.liveSubscriptions = [{ url: playlist, name: '家庭直播', epg, lastSync: 500, fromSubscriptions: ['https://owner-fixture.invalid/sub.json'] }];
    from.liveSelectedUrls = [playlist]; from.liveFavorites = [channel];
    from.liveRecent = [{ url: channel, name: '家庭频道', sourceUrl: playlist, epg, timestamp: 300 }];
    const records = [...(await snapshotToRecords(from)).values()].filter((row) => row.kind.startsWith('live')).map((row) => wire(row));
    const receiver = liveSnapshot();
    const original = JSON.stringify(receiver);
    const plan = planSyncApply(receiver, records);
    expect(plan.liveChanged).toBe(true); expect(plan.sourcesChanged).toBe(false); expect(plan.mutations).toEqual([]);
    expect(plan.projected.liveSubscriptions).toEqual([{ url: playlist, name: '家庭直播', epg, fromSubscriptions: [] }]);
    expect(plan.projected.liveSelectedUrls).toEqual([playlist]); expect(plan.projected.liveFavorites).toEqual([channel]);
    expect(plan.projected.liveRecent).toEqual([expect.objectContaining({ url: channel, name: '家庭频道', sourceUrl: playlist, timestamp: 300 })]);
    expect(plan.projected.history).toEqual(receiver.history); expect(plan.projected.progress).toEqual(receiver.progress);
    expect(plan.projected.customAPIs).toEqual(receiver.customAPIs); expect(JSON.stringify(receiver)).toBe(original);
  });

  it('远端编辑保留接收设备统一订阅归属和抓取时间，关闭选中，删除只移除对应配置', () => {
    const receiver = liveSnapshot();
    receiver.liveSubscriptions = [{ url: playlist, name: '旧名', lastSync: 456, fromSubscriptions: ['https://receiver-fixture.invalid/sub.json'] }];
    receiver.liveSelectedUrls = [playlist]; receiver.liveFavorites = [channel];
    receiver.liveRecent = [{ url: channel, name: '频道', sourceUrl: playlist, timestamp: 10 }];
    const edit: SyncRecord = { kind: 'liveSources', key: playlist, payload: { source: { url: playlist, name: '新名', epg }, selected: false },
      revision: 1, deleted: false, updatedAt: 100 };
    const edited = planSyncApply(receiver, [edit]).projected;
    expect(edited.liveSubscriptions).toEqual([{ url: playlist, name: '新名', epg, lastSync: 456, fromSubscriptions: ['https://receiver-fixture.invalid/sub.json'] }]);
    expect(edited.liveSelectedUrls).toEqual([]);
    const removed = planSyncApply(edited, [deleted('liveSources', playlist)]).projected;
    expect(removed.liveSubscriptions).toEqual([]); expect(removed.liveSelectedUrls).toEqual([]);
    expect(removed.liveFavorites).toEqual([channel]); expect(removed.liveRecent).toHaveLength(1);
    const cleared = planSyncApply(removed, [deleted('liveFavorites', channel), deleted('liveRecent', channel)]).projected;
    expect(cleared.liveFavorites).toEqual([]); expect(cleared.liveRecent).toEqual([]);
  });

  it('部署内置源的远端删除只禁用配置，等价URL编辑不制造重复源或选中项', () => {
    const receiver = liveSnapshot();
    receiver.liveEnvSources = [{ key: 'env_live', name: '部署直播', url: playlist }];
    receiver.liveSelectedUrls = [playlist];
    const disabled = planSyncApply(receiver, [deleted('liveSources', playlist)]).projected;
    expect(disabled.liveEnvSources).toEqual(receiver.liveEnvSources); expect(disabled.liveSubscriptions).toEqual([]);
    expect(disabled.liveSelectedUrls).toEqual([]);
    const edit: SyncRecord = { kind: 'liveSources', key: playlist, payload: {
      source: { url: playlist.replace('live-fixture', 'LIVE-FIXTURE') + '#ignored', name: '远端名称' }, selected: true,
    }, revision: 3, deleted: false, updatedAt: 300 };
    const enabled = planSyncApply(disabled, [edit]).projected;
    expect(enabled.liveSelectedUrls).toEqual([playlist]); expect(enabled.liveSubscriptions).toEqual([]);
    expect(enabled.liveEnvSources?.[0].name).toBe('部署直播');
  });

  it('最近观看按真实观看时间合并并限制20条，远端删除可以清除记录且不会清空点播历史', () => {
    const receiver = liveSnapshot();
    receiver.liveRecent = Array.from({ length: 20 }, (_, i) => ({ url: `https://stream-fixture.invalid/${i}.m3u8`, name: `频道${i}`, timestamp: i + 1 }));
    const newest: SyncRecord = { kind: 'liveRecent', key: channel, payload: { url: channel, name: '新频道', timestamp: 21 }, revision: 1, deleted: false, updatedAt: 100 };
    const plan = planSyncApply(receiver, [newest]);
    expect(plan.projected.liveRecent).toHaveLength(20); expect(plan.projected.liveRecent?.[0].url).toBe(channel);
    expect(plan.projected.liveRecent?.some((entry) => entry.url.endsWith('/0.m3u8'))).toBe(false);
    expect(plan.projected.history).toEqual(receiver.history);
    const cleared = planSyncApply(plan.projected, plan.projected.liveRecent!.map((entry) => deleted('liveRecent', entry.url)));
    expect(cleared.projected.liveRecent).toEqual([]); expect(cleared.projected.history).toEqual(receiver.history);
  });
});
