import { afterEach, describe, expect, it, vi } from 'vitest';
import { isSoftwareKeyboardVisible, observeSoftwareKeyboard } from './mobile-keyboard';

const portrait = { layoutWidth: 390, layoutHeight: 844, editableFocused: true };
const viewport = (height: number, width = 390, scale = 1) => ({ width, height, scale });

describe('software keyboard geometry', () => {
  it('requires editable focus as well as a keyboard-sized viewport contraction', () => {
    expect(isSoftwareKeyboardVisible({ ...portrait, viewport: viewport(480) })).toBe(true);
    expect(isSoftwareKeyboardVisible({ ...portrait, editableFocused: false, viewport: viewport(480) })).toBe(false);
  });

  it('restores navigation after keyboard dismissal while the input remains focused', () => {
    expect(isSoftwareKeyboardVisible({ ...portrait, viewport: viewport(480) })).toBe(true);
    expect(isSoftwareKeyboardVisible({ ...portrait, viewport: viewport(844) })).toBe(false);
  });

  it.each([844, 800, 754, 704])('keeps hardware-keyboard and browser-chrome changes visible at height %s', (height) => {
    expect(isSoftwareKeyboardVisible({ ...portrait, viewport: viewport(height) })).toBe(false);
  });

  it('normalizes pinch zoom instead of treating it as a software keyboard', () => {
    expect(isSoftwareKeyboardVisible({ ...portrait, viewport: viewport(422, 195, 2) })).toBe(false);
    expect(isSoftwareKeyboardVisible({ ...portrait, viewport: viewport(240, 195, 2) })).toBe(true);
  });

  it('rejects mixed rotation geometry and evaluates the settled landscape dimensions', () => {
    expect(isSoftwareKeyboardVisible({ ...portrait, viewport: viewport(390, 844) })).toBe(false);
    const landscape = { ...portrait, layoutWidth: 844, layoutHeight: 390 };
    expect(isSoftwareKeyboardVisible({ ...landscape, viewport: viewport(390, 844) })).toBe(false);
    expect(isSoftwareKeyboardVisible({ ...landscape, viewport: viewport(210, 844) })).toBe(true);
  });

  it.each([null, viewport(0), viewport(480, 390, 0), viewport(Number.NaN)])('keeps navigation available without valid viewport geometry: %s', (sample) => {
    expect(isSoftwareKeyboardVisible({ ...portrait, viewport: sample })).toBe(false);
  });
});

class TestElement extends EventTarget {
  inputMode = '';
  isContentEditable = false;
}
class TestInput extends TestElement {
  type = 'search';
  readOnly = false;
  disabled = false;
}
class TestTextArea extends TestInput {}

function browserEnvironment() {
  vi.useFakeTimers();
  vi.stubGlobal('HTMLElement', TestElement);
  vi.stubGlobal('HTMLInputElement', TestInput);
  vi.stubGlobal('HTMLTextAreaElement', TestTextArea);
  const visualViewport = Object.assign(new EventTarget(), viewport(844));
  const doc = Object.assign(new EventTarget(), {
    documentElement: { clientWidth: 390, clientHeight: 844 },
    activeElement: new TestInput() as TestElement,
  });
  const win = Object.assign(new EventTarget(), {
    visualViewport,
    innerWidth: 390,
    innerHeight: 844,
    requestAnimationFrame: (callback: FrameRequestCallback) => setTimeout(() => callback(0), 16) as unknown as number,
    cancelAnimationFrame: (id: number) => clearTimeout(id),
    setTimeout: (callback: () => void, delay: number) => setTimeout(callback, delay) as unknown as number,
    clearTimeout: (id: number | undefined) => clearTimeout(id),
  });
  const observe = (onChange: (visible: boolean) => void) => observeSoftwareKeyboard(onChange, win as unknown as Window, doc as unknown as Document);
  return { visualViewport, doc, win, observe };
}

afterEach(() => {
  vi.unstubAllGlobals();
  vi.useRealTimers();
});

describe('software keyboard lifecycle', () => {
  it('responds to resize dismissal without needing blur, then responds to real blur', () => {
    const { visualViewport, doc, observe } = browserEnvironment();
    const onChange = vi.fn();
    const dispose = observe(onChange);
    expect(onChange).toHaveBeenLastCalledWith(false);

    visualViewport.height = 480;
    visualViewport.dispatchEvent(new Event('resize'));
    vi.runAllTimers();
    expect(onChange).toHaveBeenLastCalledWith(true);

    visualViewport.height = 844;
    visualViewport.dispatchEvent(new Event('resize'));
    vi.runAllTimers();
    expect(doc.activeElement).toBeInstanceOf(TestInput);
    expect(onChange).toHaveBeenLastCalledWith(false);

    visualViewport.height = 480;
    visualViewport.dispatchEvent(new Event('resize'));
    vi.runAllTimers();
    doc.activeElement = new TestElement();
    doc.dispatchEvent(new Event('focusout'));
    vi.runAllTimers();
    expect(onChange).toHaveBeenLastCalledWith(false);
    dispose();
  });

  it('rechecks settled rotation geometry and zoom changes', () => {
    const { visualViewport, doc, win, observe } = browserEnvironment();
    const onChange = vi.fn();
    const dispose = observe(onChange);
    Object.assign(visualViewport, viewport(210, 844));
    win.dispatchEvent(new Event('orientationchange'));
    vi.advanceTimersByTime(16);
    expect(onChange).toHaveBeenLastCalledWith(false);
    Object.assign(doc.documentElement, { clientWidth: 844, clientHeight: 390 });
    Object.assign(win, { innerWidth: 844, innerHeight: 390 });
    vi.runAllTimers();
    expect(onChange).toHaveBeenLastCalledWith(true);

    Object.assign(visualViewport, viewport(195, 422, 2));
    visualViewport.dispatchEvent(new Event('resize'));
    vi.runAllTimers();
    expect(onChange).toHaveBeenLastCalledWith(false);
    dispose();
  });

  it('does not hide for readonly or explicitly keyboard-free inputs', () => {
    const { visualViewport, doc, observe } = browserEnvironment();
    visualViewport.height = 480;
    const input = doc.activeElement as TestInput;
    input.readOnly = true;
    const onChange = vi.fn();
    const dispose = observe(onChange);
    expect(onChange).toHaveBeenLastCalledWith(false);
    input.readOnly = false;
    input.inputMode = 'none';
    doc.dispatchEvent(new Event('focusin'));
    vi.runAllTimers();
    expect(onChange).toHaveBeenLastCalledWith(false);
    dispose();
  });

  it('cancels listeners and delayed callbacks on cleanup', () => {
    const { visualViewport, win, observe } = browserEnvironment();
    const onChange = vi.fn();
    const dispose = observe(onChange);
    win.dispatchEvent(new Event('orientationchange'));
    dispose();
    visualViewport.height = 480;
    visualViewport.dispatchEvent(new Event('resize'));
    win.dispatchEvent(new Event('resize'));
    vi.runAllTimers();
    expect(onChange).toHaveBeenCalledTimes(1);
  });

  it('falls back to available navigation when visualViewport is absent', () => {
    const onChange = vi.fn();
    const dispose = observeSoftwareKeyboard(onChange, { visualViewport: null } as Window, {} as Document);
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenLastCalledWith(false);
    dispose();
  });
});
