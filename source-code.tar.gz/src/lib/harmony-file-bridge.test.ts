import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const capacitor = vi.hoisted(() => ({ core: vi.fn(), writeFile: vi.fn(), share: vi.fn() }));
vi.mock('@capacitor/core', () => ({ Capacitor: { isNativePlatform: capacitor.core } }));
vi.mock('@capacitor/filesystem', () => ({ Filesystem: { writeFile: capacitor.writeFile } }));
vi.mock('@capacitor/share', () => ({ Share: { share: capacitor.share } }));

function mockArkWeb(origin = 'https://vip.localhost') {
  const web = Object.assign(new EventTarget(), {
    location: { origin },
    VIPHarmony: { saveFile: vi.fn(), shareSource: vi.fn() },
    __VIP_HARMONY_RESOLVE: undefined as Window['__VIP_HARMONY_RESOLVE'],
  });
  vi.stubGlobal('window', web);
  return web;
}

beforeEach(() => {
  vi.resetModules();
  vi.clearAllMocks();
  vi.useFakeTimers();
  vi.stubEnv('NEXT_PUBLIC_APP_MODE', 'harmony');
  vi.stubGlobal('fetch', vi.fn());
});

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
  vi.unstubAllEnvs();
});

describe('Harmony local file bridge', () => {
  it('passes exact text only to the local bridge and reports saved after the native callback', async () => {
    const web = mockArkWeb();
    const { exportTextFile, localFileExportMessage } = await import('./local-file-export');
    const text = JSON.stringify({ name: '私人配置', url: 'https://example.invalid/?key=private-fixture' });
    const operation = exportTextFile(text, 'VIP-backup.json');
    const request = JSON.parse(web.VIPHarmony.saveFile.mock.calls[0][0]);
    expect(request).toEqual({ id: expect.stringMatching(/^[a-f0-9]{32}$/), filename: 'VIP-backup.json', text });
    web.__VIP_HARMONY_RESOLVE!(request.id, '{"status":"saved"}');
    expect(await operation).toBe('saved');
    expect(localFileExportMessage('saved')).toBe('已保存到所选位置');
    expect(fetch).not.toHaveBeenCalled();
    expect(capacitor.core).not.toHaveBeenCalled();
    expect(capacitor.writeFile).not.toHaveBeenCalled();
    expect(capacitor.share).not.toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
  });

  it('exports only the fixed bundled source through shareSource, without a URL or JS archive download', async () => {
    const web = mockArkWeb();
    const { exportNativeSourceArchive } = await import('./local-file-export');
    const operation = exportNativeSourceArchive();
    const request = JSON.parse(web.VIPHarmony.shareSource.mock.calls[0][0]);
    expect(Object.keys(request)).toEqual(['id']);
    expect(web.VIPHarmony.saveFile).not.toHaveBeenCalled();
    web.__VIP_HARMONY_RESOLVE!(request.id, '{"status":"saved"}');
    expect(await operation).toBe('saved');
    expect(fetch).not.toHaveBeenCalled();
  });

  it.each(['https://example.invalid', 'http://vip.localhost', 'https://vip.localhost.attacker.invalid', 'https://vip.localhost:8080', 'null'])
    ('refuses a native object on an untrusted origin: %s', async (origin) => {
      const web = mockArkWeb(origin);
      const { exportTextFile } = await import('./local-file-export');
      await expect(exportTextFile('{}', 'backup.json')).rejects.toThrow('已安装的鸿蒙');
      expect(web.VIPHarmony.saveFile).not.toHaveBeenCalled();
      expect(fetch).not.toHaveBeenCalled();
    });

  it('rejects bridge calls outside the Harmony runtime even at the trusted origin', async () => {
    const web = mockArkWeb();
    vi.stubEnv('NEXT_PUBLIC_APP_MODE', 'standalone');
    const { exportHarmonySourceArchive } = await import('./harmony-file-bridge');
    expect(() => exportHarmonySourceArchive()).toThrow('已安装的鸿蒙');
    expect(web.VIPHarmony.shareSource).not.toHaveBeenCalled();
  });

  it('fails clearly in the browser preview without attempting a download fallback', async () => {
    const web = mockArkWeb();
    delete (web as Partial<typeof web>).VIPHarmony;
    const { exportTextFile } = await import('./local-file-export');
    await expect(exportTextFile('{}', 'backup.json')).rejects.toThrow('尚未就绪');
    expect(fetch).not.toHaveBeenCalled();
  });

  it.each(['../backup.json', 'nested/backup.json', 'nested\\backup.json', 'backup..json', '.hidden'])
    ('rejects unsafe filenames before the native call: %s', async (filename) => {
      const web = mockArkWeb();
      const { exportTextFile } = await import('./local-file-export');
      await expect(exportTextFile('{}', filename)).rejects.toThrow('文件名');
      expect(web.VIPHarmony.saveFile).not.toHaveBeenCalled();
    });

  it('bounds the serialized request, including JSON escaping overhead', async () => {
    const web = mockArkWeb();
    const { exportTextFile } = await import('./local-file-export');
    await expect(exportTextFile('"'.repeat(4 * 1024 * 1024), 'backup.json')).rejects.toThrow('文件过大');
    expect(web.VIPHarmony.saveFile).not.toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
  });

  it.each(['{"status":"cancelled"}', '{"status":"error","message":"磁盘空间不足"}'])
    ('distinguishes cancellation from an actual save error: %s', async (reply) => {
      const web = mockArkWeb();
      const { exportTextFile } = await import('./local-file-export');
      const operation = exportTextFile('{}', 'backup.json');
      const request = JSON.parse(web.VIPHarmony.saveFile.mock.calls[0][0]);
      web.__VIP_HARMONY_RESOLVE!(request.id, reply);
      if (reply.includes('cancelled')) expect(await operation).toBe('cancelled');
      else await expect(operation).rejects.toThrow('磁盘空间不足');
      expect(vi.getTimerCount()).toBe(0);
    });

  it.each(['not json', '{"status":"uploaded"}', 'null', '[]', '{"status":"saved"}'.repeat(200)])
    ('does not accept malformed or oversized native results: %s', async (reply) => {
      const web = mockArkWeb();
      const { exportTextFile } = await import('./local-file-export');
      const operation = exportTextFile('{}', 'backup.json');
      const request = JSON.parse(web.VIPHarmony.saveFile.mock.calls[0][0]);
      web.__VIP_HARMONY_RESOLVE!(request.id, reply);
      await expect(operation).rejects.toThrow('无效结果');
      expect(vi.getTimerCount()).toBe(0);
    });

  it('ignores an unrelated id, times out with cleanup and ignores a late callback', async () => {
    const web = mockArkWeb();
    const { exportTextFile } = await import('./local-file-export');
    const operation = exportTextFile('{}', 'backup.json');
    const rejection = expect(operation).rejects.toThrow('等待超时');
    const request = JSON.parse(web.VIPHarmony.saveFile.mock.calls[0][0]);
    web.__VIP_HARMONY_RESOLVE!('unrelated', '{"status":"saved"}');
    expect(vi.getTimerCount()).toBe(1);
    await vi.advanceTimersByTimeAsync(15 * 60 * 1000);
    await rejection;
    web.__VIP_HARMONY_RESOLVE!(request.id, '{"status":"saved"}');
    expect(vi.getTimerCount()).toBe(0);
  });

  it('cleans up on page exit and surfaces a synchronous bridge failure', async () => {
    const web = mockArkWeb();
    const { exportTextFile } = await import('./local-file-export');
    const operation = exportTextFile('{}', 'backup.json');
    web.dispatchEvent(new Event('pagehide'));
    await expect(operation).rejects.toThrow('页面已关闭');
    expect(vi.getTimerCount()).toBe(0);
    web.VIPHarmony.saveFile.mockImplementation(() => { throw new Error('Native bridge failed'); });
    await expect(exportTextFile('{}', 'backup.json')).rejects.toThrow('无法打开');
    expect(vi.getTimerCount()).toBe(0);
  });
});
