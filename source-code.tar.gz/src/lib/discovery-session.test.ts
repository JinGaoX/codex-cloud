import { describe, expect, it } from 'vitest';
import { DEFAULT_DISCOVERY_VIEW, DISCOVERY_SESSION_KEY, readDiscoverySession, writeDiscoverySession, type DiscoverySessionStorage } from './discovery-session';

function storage() {
  const values = new Map<string, string>([['libretv-settings', 'keep-private-settings'], ['libretv-sleep-timer-v1', 'keep-timer']]);
  return { values, getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => { values.set(key, value); } };
}

describe('tab-scoped discovery navigation context', () => {
  it('remembers a TV category and position without changing existing app data', () => {
    const local = storage();
    const view = { ...DEFAULT_DISCOVERY_VIEW, type: 'tv' as const, listId: 'douban_tv_chinese' as const,
      mode: 'browse' as const, tag: '韩剧', scrollY: 1820.7 };
    expect(writeDiscoverySession(view, local)).toBe(true);
    expect(readDiscoverySession(local)).toEqual({ ...view, scrollY: 1821 });
    expect(local.values.get('libretv-settings')).toBe('keep-private-settings');
    expect(local.values.get('libretv-sleep-timer-v1')).toBe('keep-timer');
  });

  it('writes only allowlisted view fields, never source URLs, search terms or records', () => {
    const local = storage();
    const extra = { ...DEFAULT_DISCOVERY_VIEW, scrollY: 0, sourceUrl: 'https://private.example/api',
      search: 'private search fixture', history: [{ title: 'private viewing fixture' }] };
    expect(writeDiscoverySession(extra, local)).toBe(true);
    const saved = local.values.get(DISCOVERY_SESSION_KEY)!;
    expect(saved).not.toMatch(/private|sourceUrl|history|search/);
    expect(Object.keys(JSON.parse(saved))).toHaveLength(7);
  });

  it('ignores corrupted, mismatched or impossible navigation state without clearing storage', () => {
    const local = storage();
    for (const value of ['broken', JSON.stringify({ ...DEFAULT_DISCOVERY_VIEW, scrollY: -1 }),
      JSON.stringify({ ...DEFAULT_DISCOVERY_VIEW, type: 'tv', tag: '科幻', scrollY: 0 }),
      JSON.stringify({ ...DEFAULT_DISCOVERY_VIEW, listId: 'douban_tv_global', scrollY: 0 }),
      JSON.stringify({ ...DEFAULT_DISCOVERY_VIEW, type: 'show', mode: 'catalog', scrollY: 0 })]) {
      local.values.set(DISCOVERY_SESSION_KEY, value);
      expect(readDiscoverySession(local)).toBeUndefined();
      expect(local.values.get(DISCOVERY_SESSION_KEY)).toBe(value);
    }
  });

  it('continues normally when session storage is unavailable', () => {
    const blocked: DiscoverySessionStorage = { getItem: () => { throw new Error('blocked'); }, setItem: () => { throw new Error('blocked'); } };
    expect(readDiscoverySession(blocked)).toBeUndefined();
    expect(writeDiscoverySession({ ...DEFAULT_DISCOVERY_VIEW, scrollY: 0 }, blocked)).toBe(false);
  });
});
