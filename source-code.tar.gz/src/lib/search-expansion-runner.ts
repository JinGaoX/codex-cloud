import { normalizeTitle } from './cms-parser';
import { filterSearchExpansionResults, MAX_SEARCH_EXPANSIONS, type SearchExpansionCandidate } from './search-expansion';
import type { SearchResponse, SearchResultItem } from './types';

export interface SearchExpansionOutcome extends SearchResponse {
  candidate: SearchExpansionCandidate;
}

export interface SearchExpansionOptions {
  candidates: readonly SearchExpansionCandidate[];
  excludedItems?: readonly SearchResultItem[];
  signal?: AbortSignal;
  /** Inject the manual-search client; the runner never changes global API behavior. */
  search: (candidate: SearchExpansionCandidate, signal?: AbortSignal) => Promise<SearchResponse>;
  /** Called as each candidate settles, allowing the first results to appear immediately. */
  onResult?: (outcome: SearchExpansionOutcome) => void;
}

function ensureActive(signal?: AbortSignal): void {
  if (signal?.aborted) throw signal.reason ?? new DOMException('搜索已取消', 'AbortError');
}

async function withAbort<T>(promise: Promise<T>, signal?: AbortSignal): Promise<T> {
  // The injected client may synchronously abort before returning its promise.
  // Consume any eventual rejection even when that cancellation wins immediately.
  if (signal?.aborted) void promise.catch(() => undefined);
  ensureActive(signal);
  if (!signal) return promise;
  let onAbort: (() => void) | undefined;
  try {
    return await Promise.race([promise, new Promise<never>((_, reject) => {
      onAbort = () => reject(signal.reason ?? new DOMException('搜索已取消', 'AbortError'));
      signal.addEventListener('abort', onAbort, { once: true });
      if (signal.aborted) onAbort();
    })]);
  } finally {
    if (onAbort) signal.removeEventListener('abort', onAbort);
  }
}

/** Sequential, bounded supplementation; failures never erase earlier successful results. */
export async function runSearchExpansion(options: SearchExpansionOptions): Promise<SearchExpansionOutcome[]> {
  const { signal, search, onResult } = options;
  ensureActive(signal);
  const excluded = [...(options.excludedItems ?? [])];
  const seenQueries = new Set<string>();
  const candidates = options.candidates.filter((candidate) => {
    const key = normalizeTitle(candidate.query);
    if (!key || seenQueries.has(key)) return false;
    seenQueries.add(key);
    return true;
  }).slice(0, MAX_SEARCH_EXPANSIONS);
  const outcomes: SearchExpansionOutcome[] = [];
  for (const candidate of candidates) {
    ensureActive(signal);
    let response: SearchResponse;
    try {
      response = await withAbort(search(candidate, signal), signal);
      ensureActive(signal);
    } catch (error) {
      ensureActive(signal);
      if (error && typeof error === 'object' && 'name' in error && error.name === 'AbortError') throw error;
      response = { list: [], failures: [], error: error instanceof Error ? error.message : '补充搜索暂时未完成。' };
    }
    const list = filterSearchExpansionResults(response.list, candidate, excluded);
    const outcome: SearchExpansionOutcome = { ...response, candidate, list };
    excluded.push(...list);
    outcomes.push(outcome);
    ensureActive(signal);
    onResult?.(outcome);
  }
  return outcomes;
}
