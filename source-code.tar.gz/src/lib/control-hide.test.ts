import { describe, expect, it } from 'vitest';
import Artplayer from 'artplayer';
import {
  ART_DEFAULT_CONTROL_HIDE_MS,
  DESKTOP_CONTROL_HIDE_MS,
  FULLSCREEN_TOUCH_CONTROL_HIDE_MS,
  TOUCH_CONTROL_HIDE_MS,
} from './control-hide';

describe('控制栏隐藏策略', () => {
  it('恢复基准与 ArtPlayer 库默认一致（升级依赖后若默认值变化会在此暴露）', () => {
    expect(ART_DEFAULT_CONTROL_HIDE_MS).toBe(Artplayer.CONTROL_HIDE_TIME);
  });

  it('桌面收紧到 800ms，快于库默认', () => {
    expect(DESKTOP_CONTROL_HIDE_MS).toBe(800);
    expect(DESKTOP_CONTROL_HIDE_MS).toBeLessThan(ART_DEFAULT_CONTROL_HIDE_MS);
  });

  it('点播触屏全屏使用完整 3 秒空闲时间', () => {
    expect(FULLSCREEN_TOUCH_CONTROL_HIDE_MS).toBe(3000);
    expect(FULLSCREEN_TOUCH_CONTROL_HIDE_MS).toBeGreaterThan(DESKTOP_CONTROL_HIDE_MS);
  });

  it('保留直播旧的触屏常驻阈值，不将其用于点播', () => {
    // ArtPlayer: Date.now() - timer >= CONTROL_HIDE_TIME 时 hide
    const timer = Date.now();
    expect(Date.now() - timer >= TOUCH_CONTROL_HIDE_MS).toBe(false);
    // 即便计时器被异常修改到很久以前，也不会溢出成真
    expect(Date.now() - 0 >= TOUCH_CONTROL_HIDE_MS).toBe(false);
  });
});
