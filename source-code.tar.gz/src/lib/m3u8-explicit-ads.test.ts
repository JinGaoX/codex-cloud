import { describe, expect, it } from 'vitest';
import { stripAdGroups, stripExplicitAdGroups } from './m3u8';

function group(seconds: number, urls: string[]) {
  return urls.flatMap((url) => [`#EXTINF:${seconds / urls.length},`, url]);
}

function playlist(middle: string[]) {
  return [
    '#EXTM3U', '#EXT-X-TARGETDURATION:150',
    ...group(300, ['movie/a.ts', 'movie/b.ts']), '#EXT-X-DISCONTINUITY',
    ...middle, '#EXT-X-DISCONTINUITY',
    ...group(300, ['movie/c.ts', 'movie/d.ts']), '#EXT-X-ENDLIST',
  ].join('\n');
}

describe('独立版明确广告路径过滤', () => {
  it.each(['/video/adjump/time/a.ts', 'https://cdn.example/advert/a.ts', '../ads/a.ts'])(
    '仅删除全部分片带明确广告路径的组：%s', (url) => {
      const input = playlist(group(18, [url]));
      const filtered = stripExplicitAdGroups(input);
      expect(filtered).not.toContain(url);
      for (const movie of ['movie/a.ts', 'movie/b.ts', 'movie/c.ts', 'movie/d.ts']) expect(filtered).toContain(movie);
      expect(filtered.match(/#EXT-X-DISCONTINUITY/g)).toHaveLength(1);
    },
  );

  it('两长夹一短和普通片头都保留，不使用桌面时长启发式', () => {
    const middle = playlist(group(18, ['movie/short-scene.ts']));
    expect(stripExplicitAdGroups(middle)).toBe(middle);
    expect(stripAdGroups(middle)).not.toContain('movie/short-scene.ts');
    const opening = [
      '#EXTM3U', '#EXT-X-DISCONTINUITY', ...group(18, ['movie/opening.ts']),
      '#EXT-X-DISCONTINUITY', ...group(300, ['movie/body.ts']), '#EXT-X-ENDLIST',
    ].join('\n');
    expect(stripExplicitAdGroups(opening)).toBe(opening);
  });

  it('混入一个正常分片则保留整个组', () => {
    const input = playlist(group(18, ['/ads/a.ts', 'movie/scene.ts']));
    expect(stripExplicitAdGroups(input)).toBe(input);
  });

  it('域名和查询参数出现关键词不会把正常正片当广告', () => {
    const input = playlist(group(18, ['https://advert.example/movie/scene.ts?ref=/ads/adjump']));
    expect(stripExplicitAdGroups(input)).toBe(input);
    const namedMovie = playlist(group(18, ['/movie/advert-documentary/scene.ts']));
    expect(stripExplicitAdGroups(namedMovie)).toBe(namedMovie);
  });

  it('保留解密初始化状态与广告后的正片边界', () => {
    const input = playlist([
      '#EXT-X-KEY:METHOD=AES-128,URI="key.bin",IV=0x1', '#EXT-X-MAP:URI="init.mp4"',
      ...group(18, ['/ads/a.ts']),
    ]);
    const filtered = stripExplicitAdGroups(input);
    expect(filtered).toContain('#EXT-X-KEY:METHOD=AES-128,URI="key.bin",IV=0x1');
    expect(filtered).toContain('#EXT-X-MAP:URI="init.mp4"');
    expect(filtered).toContain('#EXT-X-DISCONTINUITY\n#EXTINF:150,\nmovie/c.ts');
  });

  it('没有明确广告组的空清单和主清单不变', () => {
    expect(stripExplicitAdGroups('')).toBe('');
    const master = '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\n/ads-documentary/variant.m3u8';
    expect(stripExplicitAdGroups(master)).toBe(master);
  });
});
