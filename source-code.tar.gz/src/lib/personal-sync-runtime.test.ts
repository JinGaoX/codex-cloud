import 'fake-indexeddb/auto';
import Dexie from 'dexie';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { SupabaseClient } from '@supabase/supabase-js';
import type { HistoryEntry } from './db';
import type { SourceConfig } from './types';
import { canonicalSourceKey, recordId, snapshotToRecords, type SyncRecord } from './personal-sync-model';
import { emptySyncQueue, PersonalSyncQueue, type SyncQueueState } from './personal-sync-queue';

const scope = { userId: '11111111-1111-4111-8111-111111111111', endpoint: 'https://fixture.supabase.co' };
const source = { key: 'custom_7', name: '隔离测试片源', url: 'https://media-fixture.invalid/api.php/provide/vod' };
const history: HistoryEntry = { id: 'custom_7_12', sourceKey: source.key, sourceUrl: source.url, vodId: '12', title: '隔离测试影片',
  episodeIndex: 0, totalEpisodes: 1, playbackPosition: 50, duration: 1200, timestamp: 1000 };
let database: typeof import('./db')['db'];
let Runtime: typeof import('./personal-sync-runtime')['PersonalSyncRuntime'];
let clearCache: typeof import('./personal-sync-runtime')['clearAccountCache'];
let settingsKey: string;
let markerKey: string;
let store: ReturnType<typeof makeStore>;
let values: Map<string, string>;
const running: InstanceType<typeof import('./personal-sync-runtime')['PersonalSyncRuntime']>[] = [];
type Args = { p_cursor: number; p_changes: Array<{ kind: SyncRecord['kind']; key: string; payload: Record<string, unknown> | null; baseRevision: number }> };
const delay = () => new Promise((resolve) => setTimeout(resolve, 10));

function makeStore() {
  let state = { customAPIs: [] as SourceConfig[], envSources: [] as SourceConfig[], selectedKeys: [] as string[] };
  const listeners = new Set<(next: typeof state, previous: typeof state) => void>();
  return {
    getState: () => state,
    setState: (patch: Partial<typeof state>) => {
      const previous = state; state = { ...state, ...patch };
      localStorage.setItem(settingsKey, JSON.stringify({ state, version: 9 }));
      listeners.forEach((listener) => listener(state, previous));
    },
    subscribe: (listener: (next: typeof state, previous: typeof state) => void) => { listeners.add(listener); return () => listeners.delete(listener); },
    persist: { hasHydrated: () => true, onFinishHydration: () => () => {}, rehydrate: async () => {
      const saved = JSON.parse(localStorage.getItem(settingsKey) ?? '{}');
      if (saved.state) { const previous = state; state = { ...state, ...saved.state }; listeners.forEach((listener) => listener(state, previous)); }
    } },
  };
}
function client(handler: (args: Args) => Promise<{ data: unknown; error: { code: string } | null }> | { data: unknown; error: { code: string } | null }) {
  const calls: Args[] = [];
  const signals: AbortSignal[] = [];
  const sdk = { auth: { getSession: async () => ({ data: { session: { user: { id: scope.userId }, access_token: 'isolated-test-token' } } }) },
    rpc: (_name: string, args: Args) => {
      calls.push(structuredClone(args));
      const builder = { setHeader: () => builder, abortSignal: (signal: AbortSignal) => { signals.push(signal); return Promise.resolve(handler(args)); } };
      return builder;
    },
  } as unknown as SupabaseClient;
  return { sdk, calls, signals };
}
function acknowledgements(args: Args, extra: SyncRecord[] = []) {
  let revision = Math.max(args.p_cursor, ...extra.map((row) => row.revision), 0);
  const records: SyncRecord[] = [...extra, ...args.p_changes.map((change) => ({ kind: change.kind, key: change.key, payload: change.payload,
    revision: ++revision, deleted: change.payload === null, updatedAt: 2000 }))];
  return { data: { revision, accepted: true, records, conflicts: [] }, error: null };
}
async function start(sdk: SupabaseClient) {
  const statuses: string[] = [];
  const runtime = new Runtime(sdk, scope, (state) => statuses.push(state.status));
  running.push(runtime); await runtime.start(); await runtime.syncNow();
  return { runtime, statuses };
}
async function main() {
  return (await database.personalSyncState.get('main'))!.value as { queue: SyncQueueState; aliases: SourceConfig[]; lastSyncedAt: number | null; sourceProjection?: { id: string; customAPIs: SourceConfig[]; selectedKeys: string[] } };
}
async function seedBaseline() {
  const records = await snapshotToRecords({ sources: store.getState().customAPIs, selectedKeys: store.getState().selectedKeys,
    history: await database.history.toArray(), progress: await database.progress.toArray(), favorites: await database.favorites.toArray() });
  const queue = new PersonalSyncQueue(); queue.setBaseline(records); queue.state.cursor = 1;
  for (const [id, row] of records) queue.state.records[id] = { ...row, revision: 1, deleted: false, updatedAt: 1000 };
  await database.personalSyncState.put({ key: 'main', value: { queue: queue.state, aliases: [source], lastSyncedAt: 1000 } });
}

beforeEach(async () => {
  vi.resetModules(); values = new Map();
  vi.stubGlobal('localStorage', { getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => values.set(key, String(value)), removeItem: (key: string) => values.delete(key) });
  vi.stubGlobal('window', new EventTarget());
  vi.stubGlobal('document', Object.assign(new EventTarget(), { visibilityState: 'visible' }));
  vi.stubGlobal('navigator', { onLine: false });
  localStorage.setItem('pps-active-account-v1', JSON.stringify(scope));
  const { scopeId, settingsKeyForScope } = await import('./account-scope');
  settingsKey = settingsKeyForScope('libretv-settings', scope);
  markerKey = settingsKeyForScope('pps-sync-projection', scope);
  store = makeStore();
  vi.doMock('./store', () => ({ useAppStore: store }));
  ({ db: database } = await import('./db'));
  await database.delete(); await database.open();
  expect(database.name).toContain(scopeId(scope));
  ({ PersonalSyncRuntime: Runtime, clearAccountCache: clearCache } = await import('./personal-sync-runtime'));
});
afterEach(async () => {
  for (const runtime of running.splice(0)) { runtime.stop(); await runtime.prepareLogout(true); }
  await delay();
  database.close(); await database.delete(); await Dexie.delete('libretv');
  vi.restoreAllMocks(); vi.unstubAllGlobals(); vi.doUnmock('./store');
});

describe('个人同步真实 IndexedDB 运行时', () => {
  it('远端应用的 main-state 写入失败时，影片、cursor 与出站队列一起回滚', async () => {
    store.setState({ customAPIs: [source], selectedKeys: [source.key] });
    const canonical = canonicalSourceKey(source.url);
    const remote: SyncRecord = { kind: 'history', key: JSON.stringify([source.url, '12']), payload: {
      sourceKey: canonical, sourceUrl: source.url, vodId: '12', title: '远端影片', episodeIndex: 0, totalEpisodes: 1,
      playbackPosition: 10, duration: 1200, timestamp: 1000,
    }, revision: 1, deleted: false, updatedAt: 1000 };
    const api = client((args) => acknowledgements(args, [remote]));
    const { runtime } = await start(api.sdk);
    const fail = () => { if (Dexie.currentTransaction?.storeNames.includes('history')) throw new Error('模拟原子日志写入失败'); };
    database.personalSyncState.hook('updating', fail);
    vi.stubGlobal('navigator', { onLine: true });
    await runtime.syncNow();
    expect(await database.history.count()).toBe(0);
    expect((await main()).queue.cursor).toBe(0);
    expect(Object.values((await main()).queue.pending).some((change) => change.kind === 'sources')).toBe(true);
    database.personalSyncState.hook('updating').unsubscribe(fail);
    await runtime.syncNow();
    expect((await database.history.toArray())[0].title).toBe('远端影片');
    expect((await main()).queue.cursor).toBeGreaterThan(0);
    expect(Object.keys((await main()).queue.pending)).toHaveLength(0);
  });

  it('两个运行实例只允许一个发请求，释放后接手者读取最新日志', async () => {
    const a = client(acknowledgements), b = client(acknowledgements);
    const first = await start(a.sdk), second = await start(b.sdk);
    vi.stubGlobal('navigator', { onLine: true });
    await Promise.all([first.runtime.syncNow(), second.runtime.syncNow()]);
    expect(a.calls.length).toBeGreaterThan(0); expect(b.calls).toHaveLength(0);
    first.runtime.stop(); await first.runtime.prepareLogout(true);
    await second.runtime.syncNow();
    expect(b.calls.length).toBeGreaterThan(0);
    expect((await main()).queue.cursor).toBe(0);
  });

  it('source projection 在崩溃重启后恢复，marker 相同则保留后续用户改名', async () => {
    const remote = { ...source, key: canonicalSourceKey(source.url) };
    const snapshot = await snapshotToRecords({ sources: [remote], selectedKeys: [remote.key], history: [], progress: [], favorites: [] });
    const queue = new PersonalSyncQueue(); queue.setBaseline(snapshot);
    await database.personalSyncState.put({ key: 'main', value: { queue: queue.state, aliases: [remote], lastSyncedAt: null,
      sourceProjection: { id: 'committed-projection', customAPIs: [remote], selectedKeys: [remote.key], expected: { customAPIs: [], selectedKeys: [] } } } });
    const api = client(acknowledgements);
    const first = await start(api.sdk);
    expect(store.getState().customAPIs[0].name).toBe(source.name);
    expect(localStorage.getItem(markerKey)).toBe('committed-projection');
    expect(Object.keys((await main()).queue.pending)).toHaveLength(0);
    store.setState({ customAPIs: [{ ...remote, name: '用户后来的改名' }] });
    first.runtime.stop(); await first.runtime.prepareLogout(true);
    await start(api.sdk);
    expect(store.getState().customAPIs[0].name).toBe('用户后来的改名');
    expect(Object.values((await main()).queue.pending)[0].payload?.source).toMatchObject({ name: '用户后来的改名' });
  });

  it('远端删除按来源 URL 定位，不因本机 custom_N 不同而漏删或复活', async () => {
    store.setState({ customAPIs: [source], selectedKeys: [source.key] });
    await database.history.put(history); await seedBaseline();
    const api = client((args) => ({ data: { revision: 2, accepted: true, conflicts: [], records: args.p_cursor < 2
      ? [{ kind: 'sources', key: source.url, payload: null, revision: 2, deleted: true, updatedAt: 2000 }] : [] }, error: null }));
    const { runtime } = await start(api.sdk);
    vi.stubGlobal('navigator', { onLine: true }); await runtime.syncNow();
    expect(store.getState().customAPIs).toHaveLength(0);
    expect(store.getState().selectedKeys).toHaveLength(0);
    expect((await database.history.toArray())[0].sourceUrl).toBe(source.url);
    await runtime.syncNow();
    expect(Object.values((await main()).queue.pending).some((change) => change.kind === 'sources')).toBe(false);
  });

  it('缺少 projection marker 但用户已从原始 A 改为 C 时，不用已提交 B 覆盖 C', async () => {
    const expected = { ...source, name: '原始片源 A' };
    const committed = { ...source, name: '远端已提交 B' };
    const later = { ...source, name: '另一标签页后来的 C' };
    store.setState({ customAPIs: [later], selectedKeys: [source.key] });
    const snapshot = await snapshotToRecords({ sources: [committed], selectedKeys: [source.key], history: [], progress: [], favorites: [] });
    const queue = new PersonalSyncQueue(); queue.setBaseline(snapshot); queue.state.cursor = 1;
    for (const [id, row] of snapshot) queue.state.records[id] = { ...row, revision: 1, deleted: false, updatedAt: 1000 };
    await database.personalSyncState.put({ key: 'main', value: { queue: queue.state, aliases: [source], lastSyncedAt: 1000,
      sourceProjection: { id: 'committed-before-crash', customAPIs: [committed], selectedKeys: [source.key],
        expected: { customAPIs: [expected], selectedKeys: [source.key] } } } });
    expect(localStorage.getItem(markerKey)).toBeNull();
    await start(client(acknowledgements).sdk);
    expect(store.getState().customAPIs[0].name).toBe(later.name);
    expect(localStorage.getItem(markerKey)).toBe('committed-before-crash');
    expect(Object.values((await main()).queue.pending).find((change) => change.kind === 'sources')?.payload?.source).toMatchObject({ name: later.name });
    expect((JSON.parse(localStorage.getItem(settingsKey)!) as { state: { customAPIs: SourceConfig[] } }).state.customAPIs[0].name).toBe(later.name);
  });

  it('无法可靠映射的旧进度保留本机，不误发远端删除', async () => {
    await database.progress.put({ key: 'lost_12_0', position: 120, duration: 1200, updatedAt: 1000 });
    const key = JSON.stringify([source.url, '12', 0]);
    const payload = { sourceKey: canonicalSourceKey(source.url), sourceUrl: source.url, vodId: '12', episodeIndex: 0, position: 120, duration: 1200, updatedAt: 1000 };
    const queue = emptySyncQueue(), id = recordId('progress', key);
    queue.records[id] = { kind: 'progress', key, payload, revision: 1, deleted: false, updatedAt: 1000 };
    queue.baseline[id] = JSON.stringify(payload); queue.cursor = 1;
    await database.personalSyncState.put({ key: 'main', value: { queue, aliases: [], lastSyncedAt: 1000 } });
    await start(client(acknowledgements).sdk);
    expect((await main()).queue.pending).toEqual({});
    expect(await database.progress.get('lost_12_0')).toMatchObject({ position: 120 });
  });

  it('显式合并游客资料产生账号队列，原游客配置与记录完全保留且重复合并不重复', async () => {
    const guest = new Dexie('libretv');
    guest.version(4).stores({ history: 'id,timestamp', progress: 'key,updatedAt', favorites: 'id,timestamp' });
    await guest.open(); await guest.table('history').put(history);
    await guest.table('progress').put({ key: 'custom_7_12_0', position: 50, duration: 1200, updatedAt: 1000 });
    const guestSettings = JSON.stringify({ state: { customAPIs: [source], selectedKeys: [source.key] }, version: 9 });
    localStorage.setItem('libretv-settings', guestSettings);
    const { runtime } = await start(client(acknowledgements).sdk);
    await runtime.importGuest();
    expect(await database.history.count()).toBe(1); expect(await database.progress.count()).toBe(1);
    expect(Object.keys((await main()).queue.pending)).toHaveLength(3);
    await runtime.importGuest();
    expect(Object.keys((await main()).queue.pending)).toHaveLength(3);
    expect(localStorage.getItem('libretv-settings')).toBe(guestSettings);
    expect((await guest.table('history').toArray())[0]).toEqual(history);
    guest.close();
  });

  it('投影期间播放器新增进度触发重试，不覆盖新进度或丢弃其出站修改', async () => {
    store.setState({ customAPIs: [source], selectedKeys: [source.key] });
    await database.history.put(history);
    await database.progress.put({ key: 'custom_7_12_0', position: 50, duration: 1200, updatedAt: 1000 });
    let responseCount = 0;
    const api = client((args) => ++responseCount === 1 ? acknowledgements(args) : { data: null, error: { code: 'test-network-failure' } });
    const { runtime } = await start(api.sdk);
    const transaction = database.transaction.bind(database);
    let inserted = false;
    const replacement = (...args: unknown[]) => {
      if (!inserted && args[0] === 'rw' && Array.isArray(args[1]) && args[1].length === 4) {
        inserted = true;
        return database.progress.put({ key: 'custom_7_12_0', position: 55, duration: 1200, updatedAt: 2000 })
          .then(() => Reflect.apply(transaction, database, args));
      }
      return Reflect.apply(transaction, database, args);
    };
    vi.spyOn(database, 'transaction').mockImplementation(replacement as typeof database.transaction);
    vi.stubGlobal('navigator', { onLine: true }); await runtime.syncNow();
    expect(inserted).toBe(true);
    expect((await database.progress.get('custom_7_12_0'))?.position).toBe(55);
    const pending = Object.values((await main()).queue.pending).find((change) => change.kind === 'progress');
    expect(pending?.payload?.position).toBe(55);
    expect(api.calls.some((request) => request.p_changes.some((change) => change.kind === 'progress' && change.payload?.position === 55))).toBe(true);
  });

  it('capture 后、投影快照前的新进度也在解释旧应答前排队', async () => {
    store.setState({ customAPIs: [source], selectedKeys: [source.key] });
    await database.history.put(history);
    await database.progress.put({ key: 'custom_7_12_0', position: 50, duration: 1200, updatedAt: 1000 });
    let responseCount = 0;
    const api = client((args) => ++responseCount === 1 ? acknowledgements(args) : { data: null, error: { code: 'test-network-failure' } });
    const { runtime } = await start(api.sdk);
    const transaction = database.transaction.bind(database);
    let afterRpcReads = 0;
    let inserted = false;
    const replacement = (...args: unknown[]) => {
      if (responseCount === 1 && args[0] === 'r' && Array.isArray(args[1]) && args[1].length === 3 && ++afterRpcReads === 2) {
        inserted = true;
        return database.progress.put({ key: 'custom_7_12_0', position: 58, duration: 1200, updatedAt: 2000 })
          .then(() => Reflect.apply(transaction, database, args));
      }
      return Reflect.apply(transaction, database, args);
    };
    vi.spyOn(database, 'transaction').mockImplementation(replacement as typeof database.transaction);
    vi.stubGlobal('navigator', { onLine: true }); await runtime.syncNow();
    expect(inserted).toBe(true);
    expect((await database.progress.get('custom_7_12_0'))?.position).toBe(58);
    expect(Object.values((await main()).queue.pending).find((change) => change.kind === 'progress')?.payload?.position).toBe(58);
  });

  it('租约被其他实例接手后，旧请求应答不能写影片或推进 cursor', async () => {
    store.setState({ customAPIs: [source], selectedKeys: [source.key] });
    let release!: (value: ReturnType<typeof acknowledgements>) => void;
    const api = client((args) => new Promise((resolve) => { release = () => resolve(acknowledgements(args)); }));
    const { runtime } = await start(api.sdk);
    vi.stubGlobal('navigator', { onLine: true }); const sync = runtime.syncNow();
    for (let attempt = 0; attempt < 50 && !api.calls.length; attempt++) await delay();
    expect(api.calls.length).toBe(1);
    const { tryAcquireSyncLease } = await import('./personal-sync-lease');
    const { scopeId } = await import('./account-scope');
    const nextOwner = await tryAcquireSyncLease(database, scopeId(scope), 'new-owner-after-suspension', Date.now() + 16_000);
    expect(nextOwner).not.toBeNull();
    release(acknowledgements(api.calls[0])); await sync;
    expect((await main()).queue.cursor).toBe(0);
    expect(Object.keys((await main()).queue.pending)).toHaveLength(1);
  });

  it('另一窗口暂时阻塞删除时等待关闭，只删除已确认退出的账号库', async () => {
    const guest = new Dexie('libretv');
    guest.version(4).stores({ history: 'id' }); await guest.open(); await guest.table('history').put(history);
    localStorage.setItem('libretv-settings', 'guest-remains');
    const { runtime } = await start(client(acknowledgements).sdk);
    await runtime.prepareLogout(true);
    const otherWindow = new Dexie(database.name); await otherWindow.open();
    let versionChange!: () => void;
    const closingRequested = new Promise<void>((resolve) => { versionChange = resolve; });
    otherWindow.on('versionchange', () => { versionChange(); return false; });
    let finished = false;
    const deletion = clearCache(scope).then(() => { finished = true; });
    await closingRequested;
    expect(finished).toBe(false);
    expect(await guest.table('history').count()).toBe(1);
    otherWindow.close(); await deletion;
    expect(await Dexie.exists(database.name)).toBe(false);
    expect(localStorage.getItem('libretv-settings')).toBe('guest-remains');
    expect(await guest.table('history').count()).toBe(1);
    guest.close();
  });

  it('持久化配置恢复超时后，手动同步也不能用空片源创建日志或发请求', async () => {
    store.persist.hasHydrated = () => false;
    const api = client(acknowledgements);
    const runtime = new Runtime(api.sdk, scope, () => {}); running.push(runtime);
    vi.useFakeTimers({ toFake: ['setTimeout'] });
    try {
      const rejection = expect(runtime.start()).rejects.toThrow('配置尚未恢复');
      await vi.advanceTimersByTimeAsync(15_001); await rejection;
    } finally { vi.useRealTimers(); }
    await runtime.syncNow();
    expect(await database.personalSyncState.count()).toBe(0);
    expect(api.calls).toHaveLength(0);
  });

  it('最后一次事务 fence 读取期间停止后，远端影片和 cursor 仍整体回滚', async () => {
    store.setState({ customAPIs: [source], selectedKeys: [source.key] });
    const remote: SyncRecord = { kind: 'history', key: JSON.stringify([source.url, '12']), payload: {
      sourceKey: canonicalSourceKey(source.url), sourceUrl: source.url, vodId: '12', title: '停止后不能落盘的影片',
      episodeIndex: 0, totalEpisodes: 1, playbackPosition: 10, duration: 1200, timestamp: 1000,
    }, revision: 1, deleted: false, updatedAt: 1000 };
    const api = client((args) => acknowledgements(args, [remote]));
    const { runtime } = await start(api.sdk);
    const leaseModule = await import('./personal-sync-lease');
    const owns = leaseModule.ownsSyncLease;
    let fences = 0;
    vi.spyOn(leaseModule, 'ownsSyncLease').mockImplementation(async (...args) => {
      const applyingMedia = Dexie.currentTransaction?.storeNames.includes('history');
      const result = await owns(...args);
      if (applyingMedia && ++fences === 2) runtime.stop();
      return result;
    });
    vi.stubGlobal('navigator', { onLine: true }); await runtime.syncNow();
    expect(fences).toBeGreaterThanOrEqual(2);
    expect(await database.history.count()).toBe(0);
    expect((await main()).queue.cursor).toBe(0);
    expect(Object.keys((await main()).queue.pending)).toHaveLength(1);
  });

  it('旧 heartbeat 迟到的续租失败不会取消同一实例新 epoch 的同步请求', async () => {
    store.setState({ customAPIs: [source], selectedKeys: [source.key] });
    let finishRpc!: () => void;
    const api = client((args) => new Promise((resolve) => { finishRpc = () => resolve(acknowledgements(args)); }));
    vi.useFakeTimers({ toFake: ['setInterval'] });
    try {
      const { runtime } = await start(api.sdk);
      const transaction = database.transaction.bind(database);
      let blockedRenewal = false;
      let finishRenewal!: () => void;
      const replacement = (...args: unknown[]) => {
        if (!blockedRenewal && args[0] === 'rw' && !Array.isArray(args[1]) && (args[1] as { name?: string })?.name === 'personalSyncState') {
          blockedRenewal = true;
          return new Promise((resolve) => { finishRenewal = () => resolve(Reflect.apply(transaction, database, args)); });
        }
        return Reflect.apply(transaction, database, args);
      };
      vi.spyOn(database, 'transaction').mockImplementation(replacement as typeof database.transaction);
      await vi.advanceTimersByTimeAsync(5000);
      expect(blockedRenewal).toBe(true);
      const expired = (await database.personalSyncState.get('lease'))!;
      await database.personalSyncState.put({ key: 'lease', value: { ...expired.value as Record<string, unknown>, expiresAt: 0 } });
      vi.stubGlobal('navigator', { onLine: true });
      const sync = runtime.syncNow();
      for (let attempt = 0; attempt < 50 && !api.calls.length; attempt++) await delay();
      expect(api.calls.length).toBe(1);
      expect((await database.personalSyncState.get('lease'))?.value).toMatchObject({ epoch: 2 });
      finishRenewal(); await delay();
      expect(api.signals[0].aborted).toBe(false);
      finishRpc(); await sync;
      expect((await main()).queue.cursor).toBeGreaterThan(0);
      expect(Object.keys((await main()).queue.pending)).toHaveLength(0);
    } finally { vi.useRealTimers(); }
  });

  it.each(['local', 'cloud'] as const)('离线重看产生较小进度，重连冲突后按 %s 的明确选择处理', async (choice) => {
    store.setState({ customAPIs: [source], selectedKeys: [source.key] });
    await database.history.put(history);
    await database.progress.put({ key: 'custom_7_12_0', position: 50, duration: 1200, updatedAt: 1000 });
    await seedBaseline();
    let server: SyncRecord = { kind: 'progress', key: JSON.stringify([source.url, '12', 0]), payload: {
      sourceKey: canonicalSourceKey(source.url), sourceUrl: source.url, vodId: '12', episodeIndex: 0,
      position: 80, duration: 1200, updatedAt: 3000,
    }, revision: 2, deleted: false, updatedAt: 3000 };
    const api = client((args) => {
      const update = args.p_changes.find((change) => change.kind === 'progress');
      if (update && update.baseRevision !== server.revision) return { data: { revision: server.revision, accepted: false, records: [server], conflicts: [server] }, error: null };
      if (update) server = { ...server, payload: update.payload, deleted: update.payload === null, revision: server.revision + 1 };
      return { data: { revision: server.revision, accepted: true, records: update || args.p_cursor < server.revision ? [server] : [], conflicts: [] }, error: null };
    });
    const { runtime } = await start(api.sdk);
    await database.progress.put({ key: 'custom_7_12_0', position: 20, duration: 1200, updatedAt: 2000 });
    await runtime.syncNow();
    expect(api.calls).toHaveLength(0);
    expect(Object.values((await main()).queue.pending).find((change) => change.kind === 'progress')?.payload?.position).toBe(20);
    vi.stubGlobal('navigator', { onLine: true }); await runtime.syncNow();
    expect((await database.progress.get('custom_7_12_0'))?.position).toBe(20);
    expect(Object.keys((await main()).queue.conflicts)).toHaveLength(1);
    await runtime.resolveConflicts(choice);
    expect((await database.progress.get('custom_7_12_0'))?.position).toBe(choice === 'local' ? 20 : 80);
    expect(Object.keys((await main()).queue.conflicts)).toHaveLength(0);
    expect(Object.keys((await main()).queue.pending)).toHaveLength(0);
    expect(server.payload?.position).toBe(choice === 'local' ? 20 : 80);
  });

  it('离线删除日志重启后仍在，服务端已删除但应答丢失时也不复活旧历史', async () => {
    store.setState({ customAPIs: [source], selectedKeys: [source.key] });
    await database.history.put(history); await seedBaseline();
    const tombstone: SyncRecord = { kind: 'history', key: JSON.stringify([source.url, '12']), payload: null,
      revision: 2, deleted: true, updatedAt: 2000 };
    const api = client((args) => ({ data: {
      revision: 2, accepted: !args.p_changes.length, records: args.p_cursor < 2 ? [tombstone] : [],
      conflicts: args.p_changes.length ? [tombstone] : [],
    }, error: null }));
    const first = await start(api.sdk);
    await database.history.delete(history.id); await first.runtime.syncNow();
    expect(Object.values((await main()).queue.pending).find((change) => change.kind === 'history')?.payload).toBeNull();
    first.runtime.stop(); await first.runtime.prepareLogout(true);
    const second = await start(api.sdk);
    expect(Object.values((await main()).queue.pending).find((change) => change.kind === 'history')?.payload).toBeNull();
    vi.stubGlobal('navigator', { onLine: true }); await second.runtime.syncNow(); await second.runtime.syncNow();
    expect(await database.history.count()).toBe(0);
    expect((await main()).queue.cursor).toBe(2);
    expect(Object.keys((await main()).queue.pending)).toHaveLength(0);
    expect(Object.keys((await main()).queue.conflicts)).toHaveLength(0);
    expect(api.calls.flatMap((request) => request.p_changes).every((change) => change.kind !== 'history' || change.payload === null)).toBe(true);
  });
});
