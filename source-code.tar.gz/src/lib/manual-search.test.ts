import { describe, expect, it, vi } from 'vitest';
import { getManualSearchPolicy, isSupplementarySearchResult, partitionSearchResults } from './manual-search';
import { runSearchExpansion } from './search-expansion-runner';
import type { SearchResultItem } from './types';

const item = (name: string, vodId = name, sourceKey = 'a', typeName = '欧美动漫'): SearchResultItem => ({ name, vodId, sourceKey, typeName, sourceName: sourceKey });

describe('explicit supplementary source labels', () => {
  it.each([
    ['瑞克与莫蒂：秋叶原大战[电影解说]', '少儿动漫'], ['某片【影视解说】', '电影'],
    ['某片（预告片）', '剧情'], ['某片 - 幕后花絮', '剧情'], ['某片：制作特辑', '电影'],
    ['某片', '电影解说'], ['某片', '影视解说'], ['某片[精彩片段]', '动作'],
  ])('recognizes an explicit label on %s', (name, typeName) => {
    expect(isSupplementarySearchResult(item(name, '1', 'a', typeName))).toBe(true);
  });

  it.each(['解说员', '预告犯', '花絮人生', '瑞克与莫蒂第一季', '我和我的祖国', '电影解说员的生活', '某片[国语]', '某片：剧场版', '某片[终极预告之谜]'])('does not guess from ordinary title words in %s', (name) => {
    expect(isSupplementarySearchResult(item(name))).toBe(false);
  });

  it('respects an explicit search for commentary instead of treating the user intent as missing', () => {
    const commentary = item('瑞克与莫蒂：秋叶原大战[电影解说]');
    expect(isSupplementarySearchResult(commentary, '瑞克与莫蒂电影解说')).toBe(false);
    expect(getManualSearchPolicy('瑞克与莫蒂电影解说', [commentary]).automatic).toBe(false);
  });

  it('preserves original records and ordering inside each group', () => {
    const commentary = item('某片[电影解说]', '1');
    const first = item('某片第一季', '2');
    const trailer = item('某片（预告片）', '3');
    const second = item('某片第二季', '4');
    const original = [commentary, first, trailer, second];
    expect(partitionSearchResults(original)).toEqual({ main: [first, second], supplementary: [commentary, trailer] });
    expect(original).toEqual([commentary, first, trailer, second]);
  });
});

describe('manual search supplementation policy', () => {
  it('automatically tries another spelling when one commentary hit would otherwise block it', () => {
    const policy = getManualSearchPolicy('瑞克与莫蒂', [item('瑞克与莫蒂：秋叶原大战[电影解说]')]);
    expect(policy.automatic).toBe(true);
    expect(policy.automaticCandidates).toEqual([{ kind: 'alternative', query: '瑞克和莫蒂' }]);
  });

  it('retains an alternate-spelling button even when a main work already matches', () => {
    const policy = getManualSearchPolicy('瑞克与莫蒂', [item('瑞克与莫蒂第一季')]);
    expect(policy.automatic).toBe(false);
    expect(policy.series).toEqual([]);
    expect(policy.alternatives).toEqual([{ kind: 'alternative', query: '瑞克和莫蒂' }]);
  });

  it('keeps an established series spelling and separate manual alternate lookup', () => {
    const policy = getManualSearchPolicy('猫与鼠2', [item('猫与鼠2')]);
    expect(policy.automatic).toBe(false);
    expect(policy.series).toEqual([{ kind: 'series', query: '猫与鼠' }]);
    expect(policy.alternatives).toEqual([{ kind: 'alternative', query: '猫和鼠' }]);
  });

  it('does not invent alternate queries for ordinary or numeric titles', () => {
    for (const query of ['1917', '十二怒汉', '三体', '电影2025']) {
      expect(getManualSearchPolicy(query, []).automaticCandidates).toEqual([]);
    }
  });

  it('does not let one source commentary suppress real seasons from nine sources', async () => {
    const commentary = item('瑞克与莫蒂：秋叶原大战[电影解说]', 'original-commentary');
    const formal = Array.from({ length: 72 }, (_, index) => item(`瑞克和莫蒂第${index % 8 + 1}季`, String(index % 8 + 1), `source-${Math.floor(index / 8)}`));
    const other = Array.from({ length: 21 }, (_, index) => item('瑞克和莫蒂[影视解说]', `commentary-${index}`, `source-${index % 9}`));
    const sourceResponse = [...formal, ...other, commentary];
    const policy = getManualSearchPolicy('瑞克与莫蒂', [commentary]);
    const search = vi.fn(async () => ({ list: sourceResponse, failures: [] }));
    const outcomes = await runSearchExpansion({ candidates: policy.automaticCandidates, excludedItems: [commentary], search });
    const found = partitionSearchResults(outcomes[0].list);
    expect(search).toHaveBeenCalledTimes(1);
    expect(outcomes[0].candidate.query).toBe('瑞克和莫蒂');
    expect(outcomes[0].list).toHaveLength(93);
    expect(found.main).toHaveLength(72);
    expect(found.supplementary).toHaveLength(21);
    expect(new Set(found.main.map((row) => row.sourceKey)).size).toBe(9);
    expect(new Set(found.main.map((row) => row.name)).size).toBe(8);
    expect(outcomes[0].list).not.toContain(commentary);
  });
});
