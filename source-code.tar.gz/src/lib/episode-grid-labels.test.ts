import { describe, expect, it } from 'vitest';
import { describeEpisode } from './episode-labels';
import { episodeGridLabel } from './episode-grid-labels';

describe('episode grid source labels', () => {
  it('separates valid dated programme labels while retaining the exact version suffix', () => {
    expect(episodeGridLabel(describeEpisode(25, '第20261031期纯享上'))).toEqual({
      primary: '2026-10-31', secondary: '纯享上', dated: true,
    });
    expect(episodeGridLabel(describeEpisode(26, '2026-10-31 纯享 · 下'))).toEqual({
      primary: '2026-10-31', secondary: '纯享 · 下', dated: true,
    });
    expect(episodeGridLabel(describeEpisode(0, '2026年1月9日加更版'))).toEqual({
      primary: '2026-01-09', secondary: '加更版', dated: true,
    });
  });

  it('does not invent a programme version for a date without a suffix', () => {
    expect(episodeGridLabel(describeEpisode(0, '第20261031期'))).toEqual({ primary: '2026-10-31', dated: true });
    expect(episodeGridLabel(describeEpisode(0, '第20261031期2'))).toEqual({ primary: '2026-10-31', secondary: '2', dated: true });
  });

  it.each(['20260229期', '20260431纯享', '20261301', '20260010', '20260100', '00000101', '202610310', '2026-1-01', '2026/10-31'])('retains the entire unrecognized or invalid date %s', (title) => {
    expect(episodeGridLabel(describeEpisode(0, title))).toEqual({ primary: title, dated: false });
  });

  it('uses calendar leap rules, including century years', () => {
    expect(episodeGridLabel(describeEpisode(0, '20240229期')).dated).toBe(true);
    expect(episodeGridLabel(describeEpisode(0, '20000229期')).dated).toBe(true);
    expect(episodeGridLabel(describeEpisode(0, '19000229期'))).toEqual({ primary: '19000229期', dated: false });
    expect(episodeGridLabel(describeEpisode(0, '2026年2月29日'))).toEqual({ primary: '2026年2月29日', dated: false });
  });

  it('keeps the original source and spoken label intact while formatting the date', () => {
    const episode = describeEpisode(24, '第20261031期纯享上');
    const snapshot = { ...episode };
    episodeGridLabel(episode);
    expect(episode).toEqual(snapshot);
    expect(episode.label).toBe('第25集 · 第20261031期纯享上');
  });

  it('preserves specials, offset numbering, punctuation, and long unknown text', () => {
    for (const title of ['第03集', '特别篇：上/下', 'SP01', '上集', '重逢：<b>一家人</b> & A/B'.repeat(8)]) {
      expect(episodeGridLabel(describeEpisode(0, title))).toEqual({ primary: title, dated: false });
    }
  });

  it('uses the real playback number for short or missing labels', () => {
    expect(episodeGridLabel(describeEpisode(2, '第03集'))).toEqual({ primary: '第3集', dated: false });
    expect(episodeGridLabel(describeEpisode(9))).toEqual({ primary: '第10集', dated: false });
  });
});
