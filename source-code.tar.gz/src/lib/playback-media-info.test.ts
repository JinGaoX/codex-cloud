import { describe, expect, it } from 'vitest';
import { parseVideoSampleStats, parseVideoTrack, type VideoTrackInfo } from './playback-media-info';

function concat(...parts: Uint8Array[]): Uint8Array {
  const data = new Uint8Array(parts.reduce((size, part) => size + part.length, 0));
  let offset = 0;
  for (const part of parts) { data.set(part, offset); offset += part.length; }
  return data;
}

function u32(...values: number[]): Uint8Array {
  const data = new Uint8Array(values.length * 4);
  const view = new DataView(data.buffer);
  values.forEach((value, index) => view.setUint32(index * 4, value));
  return data;
}

function text(value: string): Uint8Array {
  return new TextEncoder().encode(value);
}

function box(type: string, ...parts: Uint8Array[]): Uint8Array {
  const payload = concat(...parts);
  return concat(u32(payload.length + 8), text(type), payload);
}

function extendedBox(type: string, payload: Uint8Array): Uint8Array {
  return concat(u32(1), text(type), u32(0, payload.length + 16), payload);
}

function full(type: string, version: number, flags: number, ...parts: Uint8Array[]): Uint8Array {
  return box(type, u32(version * 0x1000000 + flags), ...parts);
}

function track(id: number, timescale: number, handler = 'vide', tkhdVersion = 0, mdhdVersion = 0): Uint8Array {
  const tkhd = new Uint8Array(tkhdVersion === 0 ? 84 : 96);
  const mdhd = new Uint8Array(mdhdVersion === 0 ? 24 : 36);
  const hdlr = new Uint8Array(24);
  tkhd[0] = tkhdVersion;
  mdhd[0] = mdhdVersion;
  tkhd.set(u32(id), tkhdVersion === 0 ? 12 : 20);
  mdhd.set(u32(timescale), mdhdVersion === 0 ? 12 : 20);
  hdlr.set(text(handler), 8);
  return box('trak', box('tkhd', tkhd), box('mdia', box('mdhd', mdhd), box('hdlr', hdlr)));
}

function trex(id: number, duration: number): Uint8Array {
  return full('trex', 0, 0, u32(id, 1, duration, 0, 0));
}

function init(...parts: Uint8Array[]): Uint8Array {
  return concat(box('ftyp', text('iso6'), u32(1)), box('moov', ...parts));
}

interface HeaderOptions {
  duration?: number;
  allOptional?: boolean;
  empty?: boolean;
}

function tfhd(id = 1, options: HeaderOptions = {}): Uint8Array {
  let flags = 0x020000;
  const parts = [u32(id)];
  if (options.allOptional) {
    flags |= 0x000003;
    parts.push(u32(0, 1234), u32(1));
  }
  if (options.duration !== undefined) {
    flags |= 0x000008;
    parts.push(u32(options.duration));
  }
  if (options.allOptional) {
    flags |= 0x000030;
    parts.push(u32(123), u32(0x01010000));
  }
  if (options.empty) flags |= 0x010000;
  return full('tfhd', 0, flags, ...parts);
}

interface RunOptions {
  count?: number;
  durations?: number[];
  dataOffset?: number;
  firstFlags?: number;
  sizes?: number[];
  sampleFlags?: number[];
  compositionOffsets?: number[];
  version?: number;
}

function trun(options: RunOptions): Uint8Array {
  const count = options.count ?? options.durations?.length ?? 0;
  let flags = 0;
  const parts = [u32(count)];
  if (options.dataOffset !== undefined) { flags |= 0x000001; parts.push(u32(options.dataOffset)); }
  if (options.firstFlags !== undefined) { flags |= 0x000004; parts.push(u32(options.firstFlags)); }
  if (options.durations) flags |= 0x000100;
  if (options.sizes) flags |= 0x000200;
  if (options.sampleFlags) flags |= 0x000400;
  if (options.compositionOffsets) flags |= 0x000800;
  if (options.durations || options.sizes || options.sampleFlags || options.compositionOffsets) {
    for (let i = 0; i < count; i++) {
      if (options.durations) parts.push(u32(options.durations[i]));
      if (options.sizes) parts.push(u32(options.sizes[i]));
      if (options.sampleFlags) parts.push(u32(options.sampleFlags[i]));
      if (options.compositionOffsets) parts.push(u32(options.compositionOffsets[i]));
    }
  }
  return full('trun', options.version ?? 0, flags, ...parts);
}

function fragment(...trafs: Uint8Array[]): Uint8Array {
  return concat(box('moof', full('mfhd', 0, 0, u32(1)), ...trafs), box('mdat', new Uint8Array(8)));
}

const VIDEO: VideoTrackInfo = { id: 1, timescale: 1000, defaultSampleDuration: 40 };

describe('parseVideoTrack', () => {
  it.each([[0, 0], [0, 1], [1, 0], [1, 1]])('reads tkhd v%s and mdhd v%s offsets and the matching trex', (tkhdVersion, mdhdVersion) => {
    const data = init(track(2, 48000, 'soun'), track(7, 90000, 'vide', tkhdVersion, mdhdVersion), box('mvex', trex(2, 1024), trex(7, 3003)));
    expect(parseVideoTrack(data)).toEqual({ id: 7, timescale: 90000, defaultSampleDuration: 3003 });
  });

  it('does not invent a default when trex is absent or declares zero', () => {
    expect(parseVideoTrack(init(track(1, 1000)))).toEqual({ id: 1, timescale: 1000 });
    expect(parseVideoTrack(init(track(1, 1000), box('mvex', trex(1, 0))))).toEqual({ id: 1, timescale: 1000 });
  });

  it('supports extended box lengths and Uint8Array views with nonzero byteOffset', () => {
    const data = extendedBox('moov', concat(track(1, 1000), box('mvex', trex(1, 40))));
    const padded = concat(new Uint8Array(13), data, new Uint8Array(7));
    expect(parseVideoTrack(padded.subarray(13, 13 + data.length))).toEqual(VIDEO);
  });

  it('rejects audio-only, multiple video tracks and duplicate track IDs', () => {
    expect(parseVideoTrack(init(track(2, 48000, 'soun')))).toBeUndefined();
    expect(parseVideoTrack(init(track(1, 1000), track(2, 90000)))).toBeUndefined();
    expect(parseVideoTrack(init(track(1, 1000), track(1, 48000, 'soun')))).toBeUndefined();
  });

  it('rejects zero IDs/timescales and unsupported header versions', () => {
    expect(parseVideoTrack(init(track(0, 1000)))).toBeUndefined();
    expect(parseVideoTrack(init(track(1, 0)))).toBeUndefined();
    expect(parseVideoTrack(init(track(1, 1000, 'vide', 2)))).toBeUndefined();
    expect(parseVideoTrack(init(track(1, 1000, 'vide', 0, 2)))).toBeUndefined();
  });

  it('rejects incomplete fixed-size tkhd/mdhd headers even when their outer boxes fit', () => {
    const hdlr = new Uint8Array(24);
    hdlr.set(text('vide'), 8);
    const shortTkhd = box('trak', box('tkhd', new Uint8Array(16)), box('mdia', box('mdhd', new Uint8Array(24)), box('hdlr', hdlr)));
    expect(parseVideoTrack(init(shortTkhd))).toBeUndefined();
    const goodTrack = track(1, 1000);
    const tkhd = goodTrack.subarray(8, 100);
    const shortMdhd = box('trak', tkhd, box('mdia', box('mdhd', new Uint8Array(16)), box('hdlr', hdlr)));
    expect(parseVideoTrack(init(shortMdhd))).toBeUndefined();
  });

  it('rejects truncated boxes, incomplete extended headers and unsafe 64-bit sizes', () => {
    const good = init(track(1, 1000));
    expect(parseVideoTrack(good.subarray(0, good.length - 1))).toBeUndefined();
    expect(parseVideoTrack(concat(u32(1), text('moov'), u32(0)))).toBeUndefined();
    expect(parseVideoTrack(concat(u32(1), text('moov'), u32(0x200000, 0)))).toBeUndefined();
    expect(parseVideoTrack(concat(u32(4), text('moov')))).toBeUndefined();
  });

  it('rejects incomplete/duplicated defaults rather than guessing', () => {
    expect(parseVideoTrack(init(track(1, 1000), box('mvex', full('trex', 0, 0, u32(1, 1, 40)))))).toBeUndefined();
    expect(parseVideoTrack(init(track(1, 1000), box('mvex', trex(1, 40), trex(1, 80))))).toBeUndefined();
  });
});

describe('parseVideoSampleStats', () => {
  it('computes unrounded fractional FPS from explicit sample timing, not nominal tags', () => {
    const data = fragment(box('traf', tfhd(), trun({ durations: [3003, 3003, 3003] })));
    const result = parseVideoSampleStats(data, { id: 1, timescale: 90000 });
    expect(result?.sampleCount).toBe(3);
    expect(result?.durationSeconds).toBeCloseTo(0.1001, 12);
    expect(result?.frameRate).toBeCloseTo(30000 / 1001, 12);
  });

  it('uses tfhd defaults ahead of trex and trun durations ahead of both', () => {
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(), trun({ count: 5 }))), VIDEO)).toEqual({ sampleCount: 5, durationSeconds: 0.2, frameRate: 25 });
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(1, { duration: 50 }), trun({ count: 5 }))), VIDEO)).toEqual({ sampleCount: 5, durationSeconds: 0.25, frameRate: 20 });
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(1, { duration: 80 }), trun({ durations: [40, 40] }))), VIDEO)).toEqual({ sampleCount: 2, durationSeconds: 0.08, frameRate: 25 });
  });

  it('finds tfhd duration after base offset and description index, with trailing defaults', () => {
    const data = fragment(box('traf', tfhd(1, { duration: 50, allOptional: true }), trun({ count: 2, sizes: [500, 100], sampleFlags: [0, 0], compositionOffsets: [100, 50] })));
    expect(parseVideoSampleStats(data, VIDEO)).toEqual({ sampleCount: 2, durationSeconds: 0.1, frameRate: 20 });
  });

  it('sums multiple truns, trafs and moofs while excluding mixed audio tracks', () => {
    const first = fragment(
      box('traf', tfhd(2, { duration: 1024 }), trun({ count: 50 })),
      box('traf', tfhd(), trun({ count: 2 }), trun({ durations: [40, 80, 40] })),
      box('traf', tfhd(1), trun({ count: 1 }))
    );
    const second = fragment(box('traf', tfhd(), trun({ count: 1 })));
    const result = parseVideoSampleStats(concat(first, second), VIDEO);
    expect(result?.sampleCount).toBe(7);
    expect(result?.durationSeconds).toBe(0.32);
    expect(result?.frameRate).toBe(7 / 0.32);
  });

  it.each([0, 1])('skips all tfhd/trun optional offsets and signed v%s composition offsets', (version) => {
    const run = trun({ durations: [40, 40], sizes: [100, 200], dataOffset: -123, firstFlags: 0x02000000, compositionOffsets: version === 1 ? [-40, 40] : [0, 80], version });
    const result = parseVideoSampleStats(fragment(box('traf', tfhd(1, { duration: 99, allOptional: true }), run)), VIDEO);
    expect(result).toEqual({ sampleCount: 2, durationSeconds: 0.08, frameRate: 25 });
  });

  it('skips per-sample flags without confusing them with duration', () => {
    const run = trun({ durations: [20, 60], sizes: [100, 300], sampleFlags: [0x02000000, 0x01010000], compositionOffsets: [0, 20] });
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(), run)), VIDEO)?.frameRate).toBe(25);
  });

  it('does not borrow an audio duration or infer a missing video duration', () => {
    const data = fragment(box('traf', tfhd(2, { duration: 1024 }), trun({ count: 10 })), box('traf', tfhd(), trun({ count: 3 })));
    expect(parseVideoSampleStats(data, { id: 1, timescale: 1000 })).toBeUndefined();
  });

  it('explicit zero default overrides trex; zero explicit sample timing is not guessed', () => {
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(1, { duration: 0 }), trun({ count: 2 }))), VIDEO)).toBeUndefined();
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(), trun({ durations: [40, 0, 40] }))), VIDEO)).toBeUndefined();
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(1, { duration: 0 }), trun({ durations: [40] }))), VIDEO)?.frameRate).toBe(25);
  });

  it('handles empty runs/empty-duration trafs but never invents FPS for zero samples', () => {
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(), trun({ count: 0 }))), VIDEO)).toBeUndefined();
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(1, { empty: true }))), VIDEO)).toBeUndefined();
    const data = fragment(box('traf', tfhd(1, { empty: true })), box('traf', tfhd(), trun({ count: 2 })));
    expect(parseVideoSampleStats(data, VIDEO)?.sampleCount).toBe(2);
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(1, { empty: true }), trun({ count: 2 }))), VIDEO)).toBeUndefined();
  });

  it('rejects truncated optional fields and missing per-sample data even with valid outer sizes', () => {
    const badHeader = full('tfhd', 0, 0x000009, u32(1), u32(0));
    expect(parseVideoSampleStats(fragment(box('traf', badHeader, trun({ count: 2 }))), VIDEO)).toBeUndefined();
    const badRun = full('trun', 0, 0x000301, u32(2), u32(100), u32(40, 5));
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(), badRun)), VIDEO)).toBeUndefined();
    const missingDataOffset = full('trun', 0, 0x000001, u32(2));
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(), missingDataOffset)), VIDEO)).toBeUndefined();
  });

  it('rejects a truncated tail instead of returning stats for an earlier complete moof', () => {
    const good = fragment(box('traf', tfhd(), trun({ count: 2 })));
    expect(parseVideoSampleStats(good.subarray(0, good.length - 1), VIDEO)).toBeUndefined();
    expect(parseVideoSampleStats(concat(good, u32(100)), VIDEO)).toBeUndefined();
  });

  it('never reads a child box across its parent boundary into a later sibling', () => {
    const malformed = concat(box('moof', u32(1000), text('traf')), box('mdat', new Uint8Array(1000)));
    expect(parseVideoSampleStats(malformed, VIDEO)).toBeUndefined();
  });

  it('rejects unsupported flags/versions, missing or duplicate tfhd, and missing trun', () => {
    expect(parseVideoSampleStats(fragment(box('traf', full('tfhd', 1, 0, u32(1)), trun({ count: 1 }))), VIDEO)).toBeUndefined();
    expect(parseVideoSampleStats(fragment(box('traf', full('tfhd', 0, 0x000004, u32(1)), trun({ count: 1 }))), VIDEO)).toBeUndefined();
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(), trun({ count: 1, version: 2 }))), VIDEO)).toBeUndefined();
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(), full('trun', 0, 0x000002, u32(1)))), VIDEO)).toBeUndefined();
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(), tfhd(), trun({ count: 1 }))), VIDEO)).toBeUndefined();
    expect(parseVideoSampleStats(fragment(box('traf', trun({ count: 1 }))), VIDEO)).toBeUndefined();
    expect(parseVideoSampleStats(fragment(box('traf', tfhd())), VIDEO)).toBeUndefined();
  });

  it('rejects conflicting first-sample/per-sample flag fields', () => {
    const run = trun({ count: 1, firstFlags: 0, sampleFlags: [0] });
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(), run)), VIDEO)).toBeUndefined();
  });

  it('accepts extended moof boxes and a correctly bounded size-zero mdat', () => {
    const data = concat(extendedBox('moof', box('traf', tfhd(), trun({ count: 2 }))), u32(0), text('mdat'), new Uint8Array(3));
    expect(parseVideoSampleStats(data, VIDEO)?.frameRate).toBe(25);
  });

  it('rejects unsafe duration arithmetic without iterating billions of default samples', () => {
    const data = fragment(box('traf', tfhd(1, { duration: 0xffffffff }), trun({ count: 0xffffffff })));
    expect(parseVideoSampleStats(data, VIDEO)).toBeUndefined();
  });

  it('returns undefined for no matching video, no moof, or invalid track timing', () => {
    expect(parseVideoSampleStats(fragment(box('traf', tfhd(2), trun({ count: 2 }))), VIDEO)).toBeUndefined();
    expect(parseVideoSampleStats(box('mdat', new Uint8Array(5)), VIDEO)).toBeUndefined();
    const data = fragment(box('traf', tfhd(), trun({ count: 2 })));
    expect(parseVideoSampleStats(data, { ...VIDEO, timescale: 0 })).toBeUndefined();
    expect(parseVideoSampleStats(data, { ...VIDEO, timescale: NaN })).toBeUndefined();
    expect(parseVideoSampleStats(data, { ...VIDEO, id: 1.5 })).toBeUndefined();
    expect(parseVideoSampleStats(data, { ...VIDEO, defaultSampleDuration: 0x100000000 })).toBeUndefined();
  });
});
