import { recordId, type SyncChange, type SyncKind, type SyncRecord, type SyncResponse } from './personal-sync-model';

export type LocalRecord = Pick<SyncRecord, 'kind' | 'key'> & { payload: Record<string, unknown> };
export interface PendingChange extends SyncChange { opId: string }
export interface SyncQueueState {
  version: 1;
  cursor: number;
  records: Record<string, SyncRecord>;
  baseline: Record<string, string>;
  pending: Record<string, PendingChange>;
  conflicts: Record<string, SyncRecord>;
}

// PostgreSQL jsonb sorts object keys. Property insertion order is not a change.
function sortedJson(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sortedJson);
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)
      .map(([key, item]) => [key, sortedJson(item)]));
  }
  return value;
}
const fingerprint = (value: unknown) => JSON.stringify(sortedJson(value));
const serverPayload = (row: SyncRecord) => row.deleted ? null : row.payload;
export const emptySyncQueue = (): SyncQueueState => ({ version: 1, cursor: 0, records: {}, baseline: {}, pending: {}, conflicts: {} });

/** Durable outbox. A stale write is never made newer just because it arrived later. */
export class PersonalSyncQueue {
  constructor(readonly state: SyncQueueState = emptySyncQueue()) {
    // Existing version-1 queues may contain insertion-order JSON fingerprints.
    for (const [id, saved] of Object.entries(state.baseline)) {
      try { state.baseline[id] = fingerprint(JSON.parse(saved)); } catch { /* A corrupt baseline is treated as changed on capture. */ }
    }
  }

  capture(snapshot: Map<string, LocalRecord>, preserveMissing = new Set<SyncKind>(), rejectedSources = new Set<string>()) {
    for (const id of new Set([...Object.keys(this.state.baseline), ...snapshot.keys(), ...rejectedSources])) {
      const current = snapshot.get(id);
      if (!current) {
        if (rejectedSources.has(id)) {
          // A source still present locally never authorizes an inferred deletion.
          if (this.state.pending[id]?.payload === null) {
            delete this.state.pending[id];
            delete this.state.conflicts[id];
            const known = this.state.records[id];
            if (this.state.baseline[id] === undefined && known && !known.deleted) {
              this.state.baseline[id] = fingerprint(known.payload);
            }
          }
          continue;
        }
        const previous = this.state.records[id] ?? this.state.pending[id];
        if (previous && preserveMissing.has(previous.kind)) continue;
      }
      const next = current ? fingerprint(current.payload) : undefined;
      if (next === this.state.baseline[id]) continue;
      const known = this.state.records[id];
      const pending = this.state.pending[id];
      const matchesKnown = next === (known && !known.deleted ? fingerprint(known.payload) : undefined);
      if (matchesKnown && (!pending || this.state.conflicts[id])) {
        delete this.state.pending[id];
        delete this.state.conflicts[id];
      } else {
        const reference = current ?? known ?? pending;
        if (reference) this.state.pending[id] = {
          kind: reference.kind, key: reference.key,
          payload: current?.payload ?? null,
          // Receiving someone else's newer row is not authorization to rebase
          // an offline edit. Only an accepted own write or explicit resolution is.
          baseRevision: pending?.baseRevision ?? known?.revision ?? 0,
          opId: crypto.randomUUID(),
        };
      }
    }
    this.setBaseline(snapshot, preserveMissing, rejectedSources);
  }

  setBaseline(snapshot: Map<string, LocalRecord>, preserveMissing = new Set<SyncKind>(), rejectedSources = new Set<string>()) {
    const preserved = Object.entries(this.state.baseline).filter(([id]) => {
      const previous = this.state.records[id] ?? this.state.pending[id];
      return !snapshot.has(id) && (rejectedSources.has(id) || (previous && preserveMissing.has(previous.kind)));
    });
    this.state.baseline = Object.fromEntries([...preserved, ...[...snapshot].map(([id, row]) => [id, fingerprint(row.payload)])]);
  }

  batch(limit = 100): PendingChange[] { return structuredClone(Object.values(this.state.pending).slice(0, limit)); }

  /** Return only remote records safe to materialize; in-flight new edits remain local. */
  receive(response: SyncResponse, sent: PendingChange[]): SyncRecord[] {
    if (response.revision < this.state.cursor) throw new Error('同步版本倒退，已停止应用');
    const incoming = new Map([...response.records, ...response.conflicts].map((row) => [recordId(row.kind, row.key), row]));
    const acceptedIds = new Set<string>();
    if (response.accepted) {
      for (const row of sent) {
        const id = recordId(row.kind, row.key);
        const server = incoming.get(id);
        // An acknowledgement must include the exact accepted value and its new
        // version; a malformed success must not silently discard the outbox.
        if (!server || server.revision <= row.baseRevision || fingerprint(serverPayload(server)) !== fingerprint(row.payload)) {
          throw new Error('同步应答未确认已发送的修改，已保留本机队列');
        }
        acceptedIds.add(id);
      }
    }
    // Only after validating every acknowledgement may state be changed.
    if (response.accepted) for (const row of sent) {
      const id = recordId(row.kind, row.key);
      if (this.state.pending[id]?.opId === row.opId) delete this.state.pending[id];
    }
    const conflictIds = new Set(response.conflicts.map((row) => recordId(row.kind, row.key)));
    for (const [id, row] of incoming) {
      this.state.records[id] = row;
      const pending = this.state.pending[id];
      if (pending && fingerprint(pending.payload) === fingerprint(serverPayload(row))) {
        // A retry after an interrupted acknowledgement, or matching edits on two
        // devices, already has the desired value. It needs no conflict prompt.
        delete this.state.pending[id];
        delete this.state.conflicts[id];
      } else if (conflictIds.has(id) && pending) {
        this.state.conflicts[id] = row;
      } else if (acceptedIds.has(id) && pending) {
        // A newer local edit follows this instance's accepted in-flight write.
        pending.baseRevision = row.revision;
        delete this.state.conflicts[id];
      } else if (!pending) delete this.state.conflicts[id];
    }
    this.state.cursor = response.revision;
    return [...incoming].filter(([id]) => !this.state.pending[id]).map(([, row]) => row);
  }

  resolve(choice: 'local' | 'cloud'): SyncRecord[] {
    const apply: SyncRecord[] = [];
    for (const [id, server] of Object.entries(this.state.conflicts)) {
      if (choice === 'local' && this.state.pending[id]) this.state.pending[id].baseRevision = server.revision;
      else { delete this.state.pending[id]; apply.push(server); }
    }
    this.state.conflicts = {};
    return apply;
  }
}
