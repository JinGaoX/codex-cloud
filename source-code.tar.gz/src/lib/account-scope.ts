/**
 * 本机资料空间；这不是身份认证，服务端仍须验证登录凭据及每条记录的所有权。
 * 切换标记后必须重新加载页面，当前模块持有的数据库/写入缓冲仍属于原空间。
 */
export interface AccountScope {
  readonly userId: string;
  readonly endpoint: string;
}

export const ACCOUNT_SCOPE_KEY = 'pps-active-account-v1';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function normalizeScope(value: unknown): AccountScope | null {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return null;
  const scope = value as Record<string, unknown>;
  if (typeof scope.userId !== 'string' || !UUID.test(scope.userId)
    || typeof scope.endpoint !== 'string' || scope.endpoint.length > 512) return null;
  try {
    const endpoint = new URL(scope.endpoint);
    if (endpoint.protocol !== 'https:' || !endpoint.hostname || endpoint.username || endpoint.password
      || endpoint.pathname !== '/' || endpoint.search || endpoint.hash) return null;
    return Object.freeze({ userId: scope.userId.toLowerCase(), endpoint: endpoint.origin });
  } catch {
    return null;
  }
}

/** 畸形标记或无法读取存储时按游客处理，不覆盖、迁移或删除原资料。 */
export function readActiveAccountScope(): AccountScope | null {
  try {
    const raw = localStorage.getItem(ACCOUNT_SCOPE_KEY);
    return raw ? normalizeScope(JSON.parse(raw)) : null;
  } catch {
    return null;
  }
}

/** 写入失败会抛错，让调用方停止切换；不能假装已经切换成功。 */
export function setActiveAccountScope(scope: AccountScope | null): void {
  if (scope === null) {
    localStorage.removeItem(ACCOUNT_SCOPE_KEY);
    return;
  }
  const normalized = normalizeScope(scope);
  if (!normalized) throw new Error('账号资料空间格式不正确');
  localStorage.setItem(ACCOUNT_SCOPE_KEY, JSON.stringify(normalized));
}

/** 完整 origin 与 UUID 组成无截断的稳定标识，避免不同项目/账号复用同一空间。 */
export function scopeId(scope: AccountScope | null): string {
  if (!scope) return 'guest';
  const normalized = normalizeScope(scope);
  if (!normalized) throw new Error('账号资料空间格式不正确');
  return `${encodeURIComponent(normalized.endpoint)}:${normalized.userId}`;
}

export function databaseNameForScope(scope: AccountScope | null): string {
  return scope ? `libretv-account:${scopeId(scope)}` : 'libretv';
}

export function settingsKeyForScope(key: string, scope: AccountScope | null): string {
  return scope ? `${key}:account:${scopeId(scope)}` : key;
}

/** 与数据库构造及节流写入共用同一快照，不能在每次写入时重新读取标记。 */
export const ACTIVE_ACCOUNT_SCOPE: AccountScope | null = readActiveAccountScope();
