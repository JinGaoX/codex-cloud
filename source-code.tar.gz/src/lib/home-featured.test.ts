import { describe, expect, it } from 'vitest';
import { selectDynamicHomeFeatures } from '../components/home-featured';
import type { DiscoveryItem } from './discovery';

const film = (id: string, cover = `https://image.example/${id}.jpg`): DiscoveryItem => ({
  id, title: `动态作品${id}`, cover, genres: [], isTv: false,
});

describe('首页只选择真实动态榜单内容', () => {
  it('保留榜单顺序与真实元数据，只展示最多六个可用封面', () => {
    const items = Array.from({ length: 8 }, (_, index) => ({ ...film(String(index)), rating: '8.1' }));
    expect(selectDynamicHomeFeatures(items)).toEqual(items.slice(0, 6));
    expect(selectDynamicHomeFeatures(items)[0]).toBe(items[0]);
  });
  it('跳过缺图与重复作品，不按标题猜测另一个来源或静态内容', () => {
    const items = [film('missing', ''), film('first'), film('first'), film('second')];
    expect(selectDynamicHomeFeatures(items).map((item) => item.id)).toEqual(['first', 'second']);
  });
  it('空数据不回退任何固定片名', () => {
    expect(selectDynamicHomeFeatures([])).toEqual([]);
    expect(selectDynamicHomeFeatures([film('missing', '')])).toEqual([]);
  });
});
