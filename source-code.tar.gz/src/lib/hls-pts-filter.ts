/**
 * HLS interstitial detection by MPEG-TS presentation timestamp continuity.
 *
 * Algorithm adapted from OpenAni / Animeko (AGPL-3.0), HlsPtsContinuity and
 * HlsManifestFilter, introduced by c173844ab5fab4a04fea2e31289f4be3fad56453.
 * https://github.com/open-ani/animeko/pull/3471
 * Copyright (C) 2024-2026 OpenAni and contributors.
 * Adapted portions are distributed under GNU AGPL version 3, as upstream.
 * See LICENSE and UPSTREAM.md for the complete attribution and source offer.
 *
 * A discontinuity is only a probe boundary, never evidence of an advertisement.
 * Unknown, encrypted, live, byte-range and non-TS media are left untouched.
 */

const PROBE_BYTES = 2048;
const MAX_PLAYLIST_BYTES = 4 * 1024 * 1024;
const MAX_GROUPS = 1024;
const MAX_SEGMENTS = 30000;
const MAX_AD_BREAK_MS = 60000;
const TOLERANCE_MS = 2000;
const FRESH_TIMELINE_MS = 10000;
const PTS_WRAP_MS = 2 ** 33 / 90;
const CACHE_LIMIT = 512;
const CACHE_TTL_MS = 8 * 60 * 1000;

export interface HlsPtsGroup {
  index: number;
  uri: string;
  durationMillis: number;
  startSeconds: number;
  startSegmentIndex: number;
  endSegmentIndex: number;
  segmentCount: number;
  /** Inclusive source-line range. Original line endings are kept. */
  lineStart: number;
  lineEnd: number;
}

export interface HlsPtsAnalysis {
  content: string;
  groups: HlsPtsGroup[];
  reason?: string;
}

export interface HlsPtsRemovedGroup {
  index: number;
  startSegmentIndex: number;
  endSegmentIndex: number;
  startSeconds: number;
  durationSeconds: number;
  segmentCount: number;
}

export interface HlsPtsFilterResult {
  content: string;
  status: 'filtered' | 'unchanged' | 'unsupported' | 'aborted';
  reason: string;
  removedGroups: HlsPtsRemovedGroup[];
  removedSeconds: number;
  probedGroups: number;
  totalGroups: number;
  complete: boolean;
}

export interface HlsPtsFilterOptions {
  fetcher?: typeof fetch;
  /** Map resolved upstream segment URLs to the app's authenticated proxy, if needed. */
  resolveProbeUrl?: (absoluteUri: string) => string;
  timeoutMs?: number;
  concurrency?: number;
}

export interface HlsPtsFilterSession {
  filter(content: string, playlistUrl: string, signal?: AbortSignal): Promise<HlsPtsFilterResult>;
  destroy(): void;
}

function sourceLines(content: string): string[] {
  return content.match(/[^\n]*(?:\n|$)/g)?.filter((line) => line !== '') ?? [];
}

function safeMediaUrl(uri: string, playlistUrl: string): string | null {
  try {
    const base = typeof document === 'undefined' ? undefined : document.baseURI;
    const resolved = new URL(uri, new URL(playlistUrl, base));
    if (!/^https?:$/.test(resolved.protocol) || resolved.username || resolved.password) return null;
    return resolved.href;
  } catch {
    return null;
  }
}

/** Parse only complete, unencrypted MPEG-TS VOD playlists. No duration-based guesses. */
export function analyzeHlsPtsPlaylist(content: string, playlistUrl: string): HlsPtsAnalysis {
  const unsupported = (reason: string): HlsPtsAnalysis => ({ content, groups: [], reason });
  if (!content || content.length > MAX_PLAYLIST_BYTES) return unsupported('playlist_size');
  const lines = sourceLines(content);
  if (lines[0]?.trim().replace(/^\uFEFF/, '') !== '#EXTM3U') return unsupported('invalid_playlist');
  const tags = lines.map((line) => line.trim());
  if (tags.some((line) => /^#EXT-X-(?:I-FRAME-)?STREAM-INF:/.test(line))) return unsupported('master_playlist');
  if (!tags.includes('#EXT-X-ENDLIST')) return unsupported('live_or_incomplete_playlist');
  if (tags.some((line) => /^#EXT-X-BYTERANGE(?::|$)/.test(line))) return unsupported('byterange');
  if (tags.some((line) => /^#EXT-X-(?:MAP|PART|SKIP|GAP|PRELOAD-HINT)(?::|$)/.test(line))) return unsupported('non_ts_or_partial');
  for (const line of tags) {
    if (!/^#EXT-X-(?:SESSION-)?KEY:/.test(line)) continue;
    const method = /(?:^|,)\s*METHOD\s*=\s*([^,\s]+)/i.exec(line.slice(line.indexOf(':') + 1))?.[1];
    if (method?.toUpperCase() !== 'NONE') return unsupported('encrypted');
  }
  if (!tags.includes('#EXT-X-DISCONTINUITY')) return unsupported('no_discontinuity');

  const groups: HlsPtsGroup[] = [];
  let current: HlsPtsGroup | null = null;
  let boundary = -1;
  let pending: { line: number; seconds: number } | null = null;
  let segmentIndex = 0;
  let cursor = 0;
  const close = () => {
    if (current) groups.push(current);
    current = null;
  };
  for (let i = 1; i < lines.length; i++) {
    const line = tags[i];
    if (line === '#EXT-X-DISCONTINUITY') {
      if (pending) return unsupported('invalid_playlist');
      close();
      boundary = i;
      continue;
    }
    if (line.startsWith('#EXTINF:')) {
      if (pending) return unsupported('invalid_playlist');
      const match = /^#EXTINF:([\d.]+)(?:,|$)/.exec(line);
      const seconds = match ? Number(match[1]) : NaN;
      if (!Number.isFinite(seconds) || seconds <= 0 || seconds > 86400) return unsupported('invalid_duration');
      pending = { line: i, seconds };
      continue;
    }
    if (!line || line.startsWith('#')) continue;
    if (!pending || segmentIndex >= MAX_SEGMENTS) return unsupported('invalid_playlist');
    const uri = safeMediaUrl(line, playlistUrl);
    if (!uri) return unsupported('unsupported_uri');
    if (!current) {
      current = {
        index: groups.length, uri, durationMillis: 0, startSeconds: cursor,
        startSegmentIndex: segmentIndex, endSegmentIndex: segmentIndex, segmentCount: 0,
        lineStart: boundary >= 0 ? boundary : pending.line, lineEnd: i,
      };
    }
    current.durationMillis += Math.round(pending.seconds * 1000);
    current.endSegmentIndex = segmentIndex;
    current.segmentCount++;
    current.lineEnd = i;
    cursor += pending.seconds;
    segmentIndex++;
    pending = null;
  }
  if (pending) return unsupported('invalid_playlist');
  close();
  if (groups.length < 2) return unsupported('single_group');
  if (groups.length > MAX_GROUPS) return unsupported('too_many_groups');
  return { content, groups };
}

/** First video PTS in a bounded MPEG-TS prefix. Audio PTS never substitutes for video. */
export function readTsVideoPts(bytes: Uint8Array): number | null {
  const packetSize = 188;
  let sync = -1;
  for (let i = 0; i + packetSize * 2 < bytes.length; i++) {
    if (bytes[i] === 0x47 && bytes[i + packetSize] === 0x47 && bytes[i + packetSize * 2] === 0x47) {
      sync = i;
      break;
    }
  }
  if (sync < 0) return null;
  const pmtPids = new Set<number>();
  const videoPids = new Set<number>();
  for (let pos = sync; pos + packetSize <= bytes.length; pos += packetSize) {
    if (bytes[pos] !== 0x47 || (bytes[pos + 1] & 0x80) !== 0) continue;
    const starts = (bytes[pos + 1] & 0x40) !== 0;
    if (!starts) continue;
    const pid = ((bytes[pos + 1] & 0x1f) << 8) | bytes[pos + 2];
    const control = (bytes[pos + 3] >> 4) & 3;
    if (control === 0 || control === 2 || (bytes[pos + 3] & 0xc0) !== 0) continue;
    const payload = pos + 4 + (control === 3 ? 1 + bytes[pos + 4] : 0);
    const end = pos + packetSize;
    if (payload >= end) continue;
    if (pid === 0 || pmtPids.has(pid)) {
      const section = payload + 1 + bytes[payload];
      if (section + 3 >= end) continue;
      const sectionLength = ((bytes[section + 1] & 0x0f) << 8) | bytes[section + 2];
      const sectionEnd = section + 3 + sectionLength - 4; // CRC is not a table entry.
      if (sectionEnd > end || sectionEnd <= section) continue;
      if (pid === 0 && bytes[section] === 0x00) {
        for (let i = section + 8; i + 4 <= sectionEnd; i += 4) {
          const program = (bytes[i] << 8) | bytes[i + 1];
          if (program !== 0) pmtPids.add(((bytes[i + 2] & 0x1f) << 8) | bytes[i + 3]);
        }
      } else if (bytes[section] === 0x02 && section + 12 <= sectionEnd) {
        const infoLength = ((bytes[section + 10] & 0x0f) << 8) | bytes[section + 11];
        for (let i = section + 12 + infoLength; i + 5 <= sectionEnd;) {
          const streamType = bytes[i];
          if ([0x01, 0x02, 0x10, 0x1b, 0x24, 0x42].includes(streamType)) {
            videoPids.add(((bytes[i + 1] & 0x1f) << 8) | bytes[i + 2]);
          }
          i += 5 + (((bytes[i + 3] & 0x0f) << 8) | bytes[i + 4]);
        }
      }
      continue;
    }
    if (payload + 14 > end || bytes[payload] !== 0 || bytes[payload + 1] !== 0 || bytes[payload + 2] !== 1) continue;
    const streamId = bytes[payload + 3];
    if (!(videoPids.has(pid) || (streamId >= 0xe0 && streamId <= 0xef))) continue;
    const flags = (bytes[payload + 7] >> 6) & 3;
    if ((bytes[payload + 6] & 0xc0) !== 0x80 || (flags !== 2 && flags !== 3) || bytes[payload + 8] < 5) continue;
    const at = payload + 9;
    if ((bytes[at] >> 4) !== (flags === 3 ? 3 : 2) || !(bytes[at] & 1) || !(bytes[at + 2] & 1) || !(bytes[at + 4] & 1)) continue;
    const ticks = ((bytes[at] >> 1) & 7) * 2 ** 30 + bytes[at + 1] * 2 ** 22 +
      ((bytes[at + 2] >> 1) & 0x7f) * 2 ** 15 + bytes[at + 3] * 2 ** 7 + ((bytes[at + 4] >> 1) & 0x7f);
    return Math.round(ticks / 90);
  }
  return null;
}

function near(pts: number, cursor: number): number {
  return pts + Math.round((cursor - pts) / PTS_WRAP_MS) * PTS_WRAP_MS;
}

/** Unknown groups are retained and widen the possible continuation interval. */
export function classifyPtsGroups(groups: readonly HlsPtsGroup[], firstPts: readonly (number | null)[]): Set<number> {
  if (groups.length < 2 || groups.length !== firstPts.length || firstPts.filter((pts) => pts !== null).length < 2) return new Set();
  let best = { members: new Set<number>(), covered: 0 };
  for (let start = 0; start < groups.length; start++) {
    const anchor = firstPts[start];
    if (anchor === null || !Number.isFinite(anchor)) continue;
    const members = new Set([start]);
    let covered = groups[start].durationMillis;
    let cursor = anchor + groups[start].durationMillis;
    let unknown = 0;
    for (let i = start + 1; i < groups.length; i++) {
      const raw = firstPts[i];
      if (raw === null) { members.add(i); covered += groups[i].durationMillis; unknown += groups[i].durationMillis; continue; }
      const pts = near(raw, cursor);
      if (pts >= cursor - TOLERANCE_MS && pts <= cursor + unknown + TOLERANCE_MS) {
        members.add(i); covered += groups[i].durationMillis; cursor = pts + groups[i].durationMillis; unknown = 0;
      }
    }
    let back = anchor;
    let backUnknown = 0;
    for (let i = start - 1; i >= 0; i--) {
      const raw = firstPts[i];
      if (raw === null) { members.add(i); covered += groups[i].durationMillis; backUnknown += groups[i].durationMillis; continue; }
      const end = near(raw + groups[i].durationMillis, back);
      if (end >= back - backUnknown - TOLERANCE_MS && end <= back + TOLERANCE_MS) {
        members.add(i); covered += groups[i].durationMillis; back = end - groups[i].durationMillis; backUnknown = 0;
      }
    }
    if (covered > best.covered) best = { members, covered };
  }
  // A playlist made of independently encoded chapters has no reliable main chain.
  if ([...best.members].filter((i) => firstPts[i] !== null).length < 2 ||
    best.covered < groups.reduce((sum, group) => sum + group.durationMillis, 0) * 0.5) return new Set();
  const candidates = new Set<number>();
  for (let i = 1; i < groups.length; i++) {
    const pts = firstPts[i];
    if (pts === null || !Number.isFinite(pts) || best.members.has(i)) continue;
    const previousPts = firstPts[i - 1];
    if (pts <= FRESH_TIMELINE_MS || (candidates.has(i - 1) && previousPts !== null &&
      Math.abs(near(pts, previousPts + groups[i - 1].durationMillis) - (previousPts + groups[i - 1].durationMillis)) <= TOLERANCE_MS)) {
      candidates.add(i);
    }
  }
  const removed = new Set<number>();
  let run: number[] = [];
  const finish = () => {
    if (run.reduce((sum, i) => sum + groups[i].durationMillis, 0) <= MAX_AD_BREAK_MS) {
      for (const i of run) removed.add(groups[i].index);
    }
    run = [];
  };
  for (let i = 0; i < groups.length; i++) {
    if (candidates.has(i)) run.push(i);
    else finish();
  }
  finish();
  return removed;
}

function aborted(): DOMException {
  return new DOMException('PTS probe cancelled', 'AbortError');
}

function awaitAbortable<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) return Promise.reject(aborted());
  return new Promise((resolve, reject) => {
    const onAbort = () => { cleanup(); reject(aborted()); };
    const cleanup = () => signal.removeEventListener('abort', onAbort);
    signal.addEventListener('abort', onAbort, { once: true });
    promise.then((value) => { cleanup(); resolve(value); }, (error) => { cleanup(); reject(error); });
  });
}

async function readPrefix(response: Response, signal: AbortSignal): Promise<Uint8Array | null> {
  if (!response.ok || !response.body) {
    void response.body?.cancel().catch(() => undefined);
    return null;
  }
  const reader = response.body.getReader();
  const prefix = new Uint8Array(PROBE_BYTES);
  let size = 0;
  try {
    while (size < PROBE_BYTES) {
      const { done, value } = await awaitAbortable(reader.read(), signal);
      if (done) break;
      const count = Math.min(value.length, PROBE_BYTES - size);
      prefix.set(value.subarray(0, count), size);
      size += count;
    }
    return prefix.subarray(0, size);
  } finally {
    void reader.cancel().catch(() => undefined);
  }
}

/** Per-player cache: bounded, memory-only, and discarded on episode/player teardown. */
export function createHlsPtsFilterSession(options: HlsPtsFilterOptions = {}): HlsPtsFilterSession {
  const fetcher = options.fetcher ?? ((...args: Parameters<typeof fetch>) => fetch(...args));
  const concurrency = Math.max(1, Math.min(16, Math.floor(options.concurrency ?? 8)));
  const timeoutMs = Math.max(1, Math.min(15000, options.timeoutMs ?? 15000));
  const lifetime = new AbortController();
  const cache = new Map<string, { pts: number; at: number }>();
  const pending = new Set<AbortController>();
  let activeProbes = 0;
  const probeQueue: (() => void)[] = [];
  const acquireProbe = async (signal: AbortSignal) => {
    if (signal.aborted) throw aborted();
    await new Promise<void>((resolve, reject) => {
      let waiting = true;
      const cancel = () => {
        if (!waiting) return;
        waiting = false;
        const index = probeQueue.indexOf(grant);
        if (index >= 0) probeQueue.splice(index, 1);
        reject(aborted());
      };
      const grant = () => {
        if (!waiting) return;
        waiting = false;
        signal.removeEventListener('abort', cancel);
        activeProbes++;
        resolve();
      };
      if (activeProbes < concurrency) grant();
      else {
        probeQueue.push(grant);
        signal.addEventListener('abort', cancel, { once: true });
      }
    });
    let released = false;
    return () => {
      if (released) return;
      released = true;
      activeProbes--;
      while (activeProbes < concurrency && probeQueue.length) probeQueue.shift()!();
    };
  };
  const decisions: { url: string; source: string; result: HlsPtsFilterResult; at: number }[] = [];
  const copy = (result: HlsPtsFilterResult): HlsPtsFilterResult => ({
    ...result, removedGroups: result.removedGroups.map((group) => ({ ...group })),
  });
  const recalled = (url: string, content: string) => decisions.find((entry) =>
    entry.url === url && entry.source === content);
  const remember = (url: string, content: string, result: HlsPtsFilterResult) => {
    // First completed decision wins, including partial probes: reparsing the same
    // playlist must not change its timeline while this player is using it.
    const existing = recalled(url, content);
    if (existing) return copy(existing.result);
    decisions.push({ url, source: content, result: copy(result), at: Date.now() });
    let size = decisions.reduce((sum, entry) => sum + entry.source.length + entry.result.content.length, 0);
    while (decisions.length > 4 || (decisions.length > 1 && size > 6 * 1024 * 1024)) {
      const old = decisions.shift()!;
      size -= old.source.length + old.result.content.length;
    }
    return result;
  };
  return {
    destroy() {
      lifetime.abort();
      for (const controller of pending) controller.abort();
      cache.clear();
      decisions.length = 0;
    },
    async filter(content, playlistUrl, signal) {
      const analysis = analyzeHlsPtsPlaylist(content, playlistUrl);
      const base: HlsPtsFilterResult = {
        content, status: 'unchanged', reason: analysis.reason ?? 'no_ad', removedGroups: [], removedSeconds: 0,
        probedGroups: 0, totalGroups: analysis.groups.length, complete: false,
      };
      if (lifetime.signal.aborted || signal?.aborted) return { ...base, status: 'aborted', reason: 'aborted' };
      if (analysis.reason) return { ...base, status: 'unsupported', reason: analysis.reason };
      const known = recalled(playlistUrl, content);
      if (known) return copy(known.result);
      const controller = new AbortController();
      pending.add(controller);
      const cancel = () => controller.abort();
      signal?.addEventListener('abort', cancel, { once: true });
      lifetime.signal.addEventListener('abort', cancel, { once: true });
      const timer = setTimeout(cancel, timeoutMs);
      const points: (number | null)[] = analysis.groups.map(() => null);
      const unique = new Map<string, Promise<number | null>>();
      let next = 0;
      const probe = async (uri: string): Promise<number | null> => {
        const hit = cache.get(uri);
        if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.pts;
        cache.delete(uri);
        let release: (() => void) | undefined;
        try {
          release = await acquireProbe(controller.signal);
          if (controller.signal.aborted) return null;
          const url = options.resolveProbeUrl ? options.resolveProbeUrl(uri) : uri;
          const request = fetcher(url, {
            signal: controller.signal, headers: { Range: `bytes=0-${PROBE_BYTES - 1}` }, cache: 'no-store',
          });
          // A custom fetcher may ignore AbortSignal. Close a late body as well.
          void request.then((response) => {
            if (controller.signal.aborted) void response.body?.cancel().catch(() => undefined);
          }, () => undefined);
          const response = await awaitAbortable(request, controller.signal);
          if (response.status === 206) {
            const range = response.headers.get('content-range');
            if (range && !/^bytes\s+0-/i.test(range)) { void response.body?.cancel().catch(() => undefined); return null; }
          }
          const bytes = await readPrefix(response, controller.signal);
          const pts = bytes ? readTsVideoPts(bytes) : null;
          if (pts !== null && !controller.signal.aborted && !lifetime.signal.aborted) {
            cache.set(uri, { pts, at: Date.now() });
            while (cache.size > CACHE_LIMIT) cache.delete(cache.keys().next().value!);
          }
          return pts;
        } catch {
          return null;
        } finally {
          release?.();
        }
      };
      const worker = async () => {
        while (next < analysis.groups.length && !controller.signal.aborted) {
          const i = next++;
          const uri = analysis.groups[i].uri;
          let request = unique.get(uri);
          if (!request) { request = probe(uri); unique.set(uri, request); }
          points[i] = await request;
        }
      };
      try {
        await Promise.all(Array.from({ length: Math.min(concurrency, analysis.groups.length) }, worker));
      } finally {
        clearTimeout(timer);
        signal?.removeEventListener('abort', cancel);
        lifetime.signal.removeEventListener('abort', cancel);
        pending.delete(controller);
      }
      if (lifetime.signal.aborted || signal?.aborted) return { ...base, status: 'aborted', reason: 'aborted' };
      base.probedGroups = points.filter((pts) => pts !== null).length;
      base.complete = base.probedGroups === analysis.groups.length;
      const removed = classifyPtsGroups(analysis.groups, points);
      if (!removed.size) return remember(playlistUrl, content, {
        ...base, reason: controller.signal.aborted ? 'probe_timeout' : base.complete ? 'no_ad' : 'probe_incomplete',
      });
      const lines = sourceLines(content);
      const dropped = new Set<number>();
      for (const group of analysis.groups) {
        if (!removed.has(group.index)) continue;
        base.removedGroups.push({
          index: group.index, startSegmentIndex: group.startSegmentIndex, endSegmentIndex: group.endSegmentIndex,
          startSeconds: group.startSeconds, durationSeconds: group.durationMillis / 1000, segmentCount: group.segmentCount,
        });
        base.removedSeconds += group.durationMillis / 1000;
        for (let i = group.lineStart; i <= group.lineEnd; i++) {
          // State declarations can apply to later retained media. Never discard them.
          if (!/^#EXT-X-(?:KEY|MAP|VERSION|TARGETDURATION|MEDIA-SEQUENCE|DISCONTINUITY-SEQUENCE|PLAYLIST-TYPE|INDEPENDENT-SEGMENTS|START|DEFINE|ENDLIST|SESSION-DATA|SESSION-KEY|DATERANGE)(?::|$)/.test(lines[i].trim())) dropped.add(i);
        }
      }
      return remember(playlistUrl, content, {
        ...base, content: lines.filter((_, i) => !dropped.has(i)).join(''), status: 'filtered', reason: 'pts_continuity',
      });
    },
  };
}
