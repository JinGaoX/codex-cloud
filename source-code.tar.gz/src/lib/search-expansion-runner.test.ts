import { describe, expect, it, vi } from 'vitest';
import { runSearchExpansion } from './search-expansion-runner';
import type { SearchExpansionCandidate } from './search-expansion';
import type { SearchResponse, SearchResultItem } from './types';

const candidates: SearchExpansionCandidate[] = [
  { kind: 'alternative', query: '瑞克和莫蒂第二季' },
  { kind: 'series', query: '瑞克和莫蒂' },
];
const item = (name: string, vodId: string): SearchResultItem => ({ name, vodId, sourceKey: 'a', sourceName: '测试源' });
const response = (list: SearchResultItem[] = []): SearchResponse => ({ list, failures: [] });

describe('runSearchExpansion', () => {
  it('starts candidates sequentially and publishes the first before requesting the second', async () => {
    const trace: string[] = [];
    const search = vi.fn(async (candidate: SearchExpansionCandidate) => {
      trace.push(candidate.query);
      return response([item(candidate.query, candidate.query)]);
    });
    const results = await runSearchExpansion({ candidates, search, onResult: (outcome) => trace.push(`shown:${outcome.candidate.query}`) });
    expect(trace).toEqual([candidates[0].query, `shown:${candidates[0].query}`, candidates[1].query, `shown:${candidates[1].query}`]);
    expect(results).toHaveLength(2);
  });

  it('excludes original and earlier supplemental IDs without merging distinct source entries', async () => {
    const exact = item('瑞克和莫蒂第二季', '2');
    const other = item('瑞克和莫蒂第一季', '1');
    const results = await runSearchExpansion({
      candidates, excludedItems: [exact],
      search: async () => response([exact, other, { ...other, sourceKey: 'b' }]),
    });
    expect(results[0].list).toEqual([]);
    expect(results[1].list).toEqual([other, { ...other, sourceKey: 'b' }]);
  });

  it('preserves partial failure metadata and keeps earlier results after a later error', async () => {
    const partial: SearchResponse = { list: [item(candidates[0].query, '2')], failures: [{ sourceKey: 'b', error: '超时', timedOut: true }], partial: true, error: '部分源失败' };
    const search = vi.fn().mockResolvedValueOnce(partial).mockRejectedValueOnce(new Error('传输中断'));
    const results = await runSearchExpansion({ candidates, search });
    expect(results[0]).toMatchObject(partial);
    expect(results[1]).toMatchObject({ list: [], failures: [], error: '传输中断' });
  });

  it('can continue after one failed hypothesis', async () => {
    const search = vi.fn().mockRejectedValueOnce(new Error('不支持')).mockResolvedValueOnce(response([item('瑞克和莫蒂第一季', '1')]));
    const results = await runSearchExpansion({ candidates, search });
    expect(results[0].error).toBe('不支持');
    expect(results[1].list).toHaveLength(1);
  });

  it('deduplicates equivalent candidate queries and hard bounds requests', async () => {
    const search = vi.fn<(candidate: SearchExpansionCandidate) => Promise<SearchResponse>>().mockResolvedValue(response());
    await runSearchExpansion({ candidates: [candidates[0], { ...candidates[0], query: '瑞克 和 莫蒂 第二季！' }, candidates[1], { kind: 'series', query: '第三种' }], search });
    expect(search).toHaveBeenCalledTimes(2);
    expect(search.mock.calls[1][0]).toEqual(candidates[1]);
  });

  it('does not start or publish when already cancelled', async () => {
    const controller = new AbortController();
    controller.abort();
    const search = vi.fn();
    const onResult = vi.fn();
    await expect(runSearchExpansion({ candidates, search, onResult, signal: controller.signal })).rejects.toMatchObject({ name: 'AbortError' });
    expect(search).not.toHaveBeenCalled();
    expect(onResult).not.toHaveBeenCalled();
  });

  it('immediately cancels even if the injected client ignores its signal', async () => {
    const controller = new AbortController();
    let settle!: (value: SearchResponse) => void;
    const search = vi.fn(() => new Promise<SearchResponse>((resolve) => { settle = resolve; }));
    const onResult = vi.fn();
    const running = runSearchExpansion({ candidates, search, onResult, signal: controller.signal });
    controller.abort();
    await expect(running).rejects.toMatchObject({ name: 'AbortError' });
    settle(response([item(candidates[0].query, '2')]));
    await Promise.resolve();
    expect(search).toHaveBeenCalledTimes(1);
    expect(onResult).not.toHaveBeenCalled();
  });

  it('never converts a client AbortError into a normal empty result', async () => {
    const search = vi.fn().mockRejectedValue(new DOMException('取消', 'AbortError'));
    await expect(runSearchExpansion({ candidates, search })).rejects.toMatchObject({ name: 'AbortError' });
    expect(search).toHaveBeenCalledTimes(1);
  });

  it('handles a client that synchronously cancels before returning a rejecting promise', async () => {
    const controller = new AbortController();
    const search = vi.fn(() => {
      controller.abort();
      return Promise.reject(new DOMException('取消', 'AbortError'));
    });
    await expect(runSearchExpansion({ candidates, search, signal: controller.signal })).rejects.toMatchObject({ name: 'AbortError' });
    expect(search).toHaveBeenCalledTimes(1);
  });
});
