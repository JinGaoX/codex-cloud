import { describe, expect, it, vi } from 'vitest';
import { NativeHlsRecovery } from './native-hls-recovery';
import type { NativeHlsFallbackOptions } from './native-hls-fallback';

const original = 'https://media.example/master.m3u8';
const child = 'https://media.example/child.m3u8';
const callbacks = () => ({ isCurrent: () => true, onResolved: vi.fn(), onUnavailable: vi.fn() });
const settle = async () => { for (let i = 0; i < 6; i++) await Promise.resolve(); };

describe('native HLS per-episode recovery lifecycle', () => {
  it('deduplicates play rejection and video:error while a retry is pending', async () => {
    let finish!: (url: string) => void;
    const resolve = vi.fn(() => new Promise<string>((yes) => { finish = yes; }));
    const recovery = new NativeHlsRecovery(resolve);
    const notices = callbacks();
    expect(recovery.tryRecover(original, notices)).toBe(true);
    expect(recovery.tryRecover(original, notices)).toBe(true);
    await settle();
    expect(resolve).toHaveBeenCalledOnce();
    finish(child);
    await settle();
    expect(notices.onResolved).toHaveBeenCalledWith(child);
    expect(notices.onUnavailable).not.toHaveBeenCalled();
    expect(recovery.tryRecover(child, notices)).toBe(false);
  });

  it('does not change a new episode after an old fetch completes', async () => {
    let finish!: (url: string) => void;
    let signal: AbortSignal | undefined;
    const resolve = vi.fn((_url: string, options?: NativeHlsFallbackOptions) => {
      signal = options?.signal;
      return new Promise<string>((yes) => { finish = yes; });
    });
    const recovery = new NativeHlsRecovery(resolve);
    const old = callbacks();
    recovery.tryRecover(original, old);
    await settle();
    recovery.reset();
    expect(signal?.aborted).toBe(true);
    finish(child);
    await settle();
    expect(old.onResolved).not.toHaveBeenCalled();
    expect(old.onUnavailable).not.toHaveBeenCalled();
    expect(recovery.tryRecover(original, callbacks())).toBe(true);
    recovery.cancel();
  });

  it('rechecks the logical episode identity before notifying', async () => {
    let current = true;
    const resolve = vi.fn(async () => { current = false; return child; });
    const recovery = new NativeHlsRecovery(resolve);
    const notices = { ...callbacks(), isCurrent: () => current };
    recovery.tryRecover(original, notices);
    await settle();
    expect(notices.onResolved).not.toHaveBeenCalled();
    expect(notices.onUnavailable).not.toHaveBeenCalled();
  });

  it('reports an exhausted attempt once and resets only for a new episode', async () => {
    const resolve = vi.fn(async () => undefined);
    const recovery = new NativeHlsRecovery(resolve);
    const notices = callbacks();
    recovery.tryRecover(original, notices);
    await settle();
    expect(notices.onUnavailable).toHaveBeenCalledOnce();
    recovery.cancel();
    expect(recovery.tryRecover(original, notices)).toBe(false);
    recovery.reset();
    expect(recovery.tryRecover(original, notices)).toBe(true);
    await settle();
    expect(resolve).toHaveBeenCalledTimes(2);
  });

  it('can restart an interrupted settings reload without accepting its stale result', async () => {
    const pending: ((url: string) => void)[] = [];
    const resolve = vi.fn(() => new Promise<string>((yes) => { pending.push(yes); }));
    const recovery = new NativeHlsRecovery(resolve);
    const old = callbacks(), current = callbacks();
    recovery.tryRecover(original, old);
    await settle();
    recovery.cancel();
    recovery.tryRecover(original, current);
    await settle();
    pending[0](child);
    pending[1](child);
    await settle();
    expect(old.onResolved).not.toHaveBeenCalled();
    expect(current.onResolved).toHaveBeenCalledOnce();
  });
});
