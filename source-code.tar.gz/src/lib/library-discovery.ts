import { fetchPublicMetadata, normalizeDoubanSubjects, type DiscoveryItem, type DiscoveryResponse } from './discovery';

/** Same public metadata mirrors as existing discovery; never receives playback sources or account data. */
export const LIBRARY_METADATA_ORIGIN = 'https://movie.douban.cmliussss.net';
const LIBRARY_METADATA_FALLBACK = 'https://movie.douban.cmliussss.com';
export const LIBRARY_PAGE_SIZE = 20;
export const LIBRARY_MAX_PAGES = 250;
export const TOP250_PAGE_SIZE = 25;

export const LIBRARY_TYPES = [
  { value: 'movie', label: '电影' }, { value: 'tv', label: '电视剧' },
  { value: 'animation', label: '动漫' }, { value: 'show', label: '综艺' },
] as const;
export const LIBRARY_SORTS = [
  { value: 'U', label: '近期热门' }, { value: 'T', label: '标记最多' },
  { value: 'S', label: '评分优先' }, { value: 'R', label: '最新上映' },
] as const;
export const LIBRARY_GENRES = [
  { value: '', label: '全部类型' },
  ...['剧情', '喜剧', '动作', '爱情', '科幻', '悬疑', '惊悚', '恐怖', '犯罪', '动画', '纪录片', '家庭', '历史', '战争', '奇幻', '冒险', '音乐', '武侠', '古装'].map((value) => ({ value, label: value })),
] as const;
export const LIBRARY_COUNTRIES = [
  { value: '', label: '全部地区' },
  ...['中国大陆', '中国香港', '中国台湾', '美国', '英国', '韩国', '日本', '法国', '德国', '意大利', '西班牙', '印度', '泰国'].map((value) => ({ value, label: value })),
] as const;
const currentYear = new Date().getFullYear();
export const LIBRARY_YEARS = [
  { value: '', label: '全部年代' },
  ...Array.from({ length: 6 }, (_, index) => ({ value: String(currentYear - index), label: `${currentYear - index}年` })),
  { value: '2020s', label: '2020年代' }, { value: '2010s', label: '2010年代' },
  { value: '2000s', label: '2000年代' }, { value: '1990s', label: '1990年代' },
  { value: 'older', label: '1990年以前' },
] as const;
export const LIBRARY_MIN_RATINGS = [
  { value: 0, label: '全部评分' }, { value: 6, label: '6分以上' },
  { value: 7, label: '7分以上' }, { value: 8, label: '8分以上' }, { value: 9, label: '9分以上' },
] as const;

export type LibraryType = (typeof LIBRARY_TYPES)[number]['value'];
export type LibrarySort = (typeof LIBRARY_SORTS)[number]['value'];
export interface LibraryFilters {
  type: LibraryType;
  sort: LibrarySort;
  genre: string;
  country: string;
  year: string;
  minRating: number;
}
export interface LibraryItem extends DiscoveryItem {
  year?: string;
  regions?: string[];
  votes?: number;
  casts?: string[];
  directors?: string[];
}
export interface LibraryPage extends DiscoveryResponse {
  items: LibraryItem[];
  start: number;
}
export const DEFAULT_LIBRARY_FILTERS: LibraryFilters = {
  type: 'movie', sort: 'U', genre: '', country: '', year: '', minRating: 0,
};
const object = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);

/** Rebuild only public, allowlisted filters. Arbitrary URL parameters cannot become fetch destinations. */
export function cleanLibraryFilters(value: unknown): LibraryFilters {
  const row = object(value) ? value : {};
  const allowed = <T extends string | number>(options: readonly { value: T }[], input: unknown, fallback: T): T =>
    options.some((option) => option.value === input) ? input as T : fallback;
  return {
    type: allowed(LIBRARY_TYPES, row.type, DEFAULT_LIBRARY_FILTERS.type),
    sort: allowed(LIBRARY_SORTS, row.sort, DEFAULT_LIBRARY_FILTERS.sort),
    genre: allowed(LIBRARY_GENRES, row.genre, ''),
    country: allowed(LIBRARY_COUNTRIES, row.country, ''),
    year: allowed(LIBRARY_YEARS, row.year, ''),
    minRating: allowed(LIBRARY_MIN_RATINGS, row.minRating, 0),
  };
}

export function libraryRequestKey(filters: LibraryFilters): string {
  const clean = cleanLibraryFilters(filters);
  return `library:${JSON.stringify([clean.type, clean.sort, clean.genre, clean.country, clean.year, clean.minRating])}`;
}

function validStart(start: number, size = LIBRARY_PAGE_SIZE, maxPages = LIBRARY_MAX_PAGES): void {
  if (!Number.isInteger(start) || start < 0 || start % size !== 0 || start >= size * maxPages) throw new Error('不支持的影视库页码');
}

export function libraryDiscoveryUrl(filters: LibraryFilters, start = 0): string {
  validStart(start);
  const clean = cleanLibraryFilters(filters);
  const tags: Record<LibraryType, string> = { movie: '电影', tv: '电视剧', animation: '动画', show: '综艺' };
  const url = new URL('/j/new_search_subjects', LIBRARY_METADATA_ORIGIN);
  url.search = new URLSearchParams({ sort: clean.sort, range: `${clean.minRating},10`, tags: tags[clean.type], start: String(start) }).toString();
  if (clean.genre) url.searchParams.set('genres', clean.genre);
  if (clean.country) url.searchParams.set('countries', clean.country);
  if (clean.year) {
    const range = clean.year === 'older' ? '1888,1989' : clean.year.endsWith('s')
      ? `${clean.year.slice(0, 4)},${Math.min(Number(clean.year.slice(0, 4)) + 9, currentYear)}`
      : `${clean.year},${clean.year}`;
    url.searchParams.set('year_range', range);
  }
  return url.href;
}

function names(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((entry): entry is string => typeof entry === 'string')
    .map((entry) => entry.trim().slice(0, 80)).filter(Boolean).slice(0, 5) : [];
}

/** A missing year/region is intentionally missing; filter criteria are not invented per-film metadata. */
export function normalizeLibraryItems(raw: unknown, type: LibraryType): LibraryItem[] {
  if (!Array.isArray(raw) || raw.length > LIBRARY_PAGE_SIZE) throw new Error('影视库数据格式不正确');
  const byId = new Map(raw.filter(object).map((row) => [String(row.id), row]));
  return normalizeDoubanSubjects(raw, type === 'movie' || type === 'animation' ? 'movie' : 'tv').map((item) => {
    const row = byId.get(item.id.split(':').at(-1)!) ?? {};
    const casts = names(row.casts);
    const directors = names(row.directors);
    return { ...item, ...(casts.length ? { casts } : {}), ...(directors.length ? { directors } : {}) };
  });
}

/** Network fallback uses an existing mirror only. Requests never carry cookies or source configuration. */
async function publicJson(url: string, signal?: AbortSignal): Promise<unknown> {
  try { return await fetchPublicMetadata(url, signal); }
  catch (error) {
    signal?.throwIfAborted();
    if (new URL(url).origin !== LIBRARY_METADATA_ORIGIN) throw error;
    const alternate = new URL(url);
    alternate.host = new URL(LIBRARY_METADATA_FALLBACK).host;
    return await fetchPublicMetadata(alternate.href, signal);
  }
}

export async function fetchLibraryPage(filters: LibraryFilters, start = 0, signal?: AbortSignal): Promise<LibraryPage> {
  const clean = cleanLibraryFilters(filters);
  const raw = await publicJson(libraryDiscoveryUrl(clean, start), signal);
  if (!object(raw) || !Array.isArray(raw.data)) throw new Error('影视库暂时没有可读取的数据');
  const items = normalizeLibraryItems(raw.data, clean.type);
  if (raw.data.length > 0 && items.length === 0) throw new Error('影视库返回的影片资料不完整');
  return { items, start, retrievedAt: Date.now(),
    ...(raw.data.length === LIBRARY_PAGE_SIZE && start + LIBRARY_PAGE_SIZE < LIBRARY_PAGE_SIZE * LIBRARY_MAX_PAGES
      ? { nextPageStart: start + LIBRARY_PAGE_SIZE } : {}),
  };
}

/** Repeated/overlapping pages must not create an endless loop. A bounded UI may also use page-by-page navigation. */
export function nextLibraryPage(pages: readonly LibraryPage[]): number | undefined {
  const last = pages.at(-1);
  if (!last || last.nextPageStart === undefined || pages.length >= LIBRARY_MAX_PAGES) return undefined;
  const previous = new Set(pages.slice(0, -1).flatMap((page) => page.items.map((item) => item.id)));
  return last.items.some((item) => !previous.has(item.id)) ? last.nextPageStart : undefined;
}

function plainHtmlText(value: string): string {
  const entities: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
  return value.replace(/<[^>]*>/g, '').replace(/&(#x[0-9a-f]+|#\d+|amp|lt|gt|quot|apos|nbsp);/gi, (full, entity: string) => {
    if (entity.startsWith('#')) {
      const point = entity[1]?.toLowerCase() === 'x' ? Number.parseInt(entity.slice(2), 16) : Number(entity.slice(1));
      return point >= 32 && point <= 0x10ffff && !(point >= 0xd800 && point <= 0xdfff) ? String.fromCodePoint(point) : '';
    }
    return entities[entity.toLowerCase()] ?? full;
  }).replace(/\s+/g, ' ').trim();
}

/** Extract text only from bounded public HTML. The document is never inserted into the page or executed. */
export function parseTop250Html(html: string, start = 0): LibraryItem[] {
  validStart(start, TOP250_PAGE_SIZE, 10);
  if (new TextEncoder().encode(html).byteLength > 256 * 1024) throw new Error('榜单响应过大');
  const blocks = [...html.matchAll(/<div\s+class=["']item["'][^>]*>([\s\S]*?)<\/li>/g)];
  if (blocks.length !== TOP250_PAGE_SIZE) throw new Error('豆瓣Top250页面暂时无法识别');
  const seen = new Set<string>();
  return blocks.map((match, index) => {
    const block = match[1];
    const rank = Number(block.match(/<em[^>]*>\s*(\d+)\s*<\/em>/)?.[1]);
    const id = block.match(/href=["']https:\/\/movie\.douban\.com\/subject\/(\d+)\/["']/)?.[1];
    const title = plainHtmlText(block.match(/<span\s+class=["']title["'][^>]*>([\s\S]*?)<\/span>/)?.[1] ?? '').slice(0, 150);
    const cover = block.match(/<img\b[^>]*\bsrc=["'](https:\/\/[^"']+)["']/)?.[1] ?? '';
    const rating = Number(block.match(/<span\s+class=["']rating_num["'][^>]*>([\d.]+)<\/span>/)?.[1]);
    if (!id || !title || seen.has(id) || rank !== start + index + 1 || !Number.isFinite(rating) || rating <= 0 || rating > 10) throw new Error('豆瓣Top250资料校验未通过');
    seen.add(id);
    const body = block.match(/<div\s+class=["']bd["'][^>]*>[\s\S]*?<p>([\s\S]*?)<\/p>/)?.[1] ?? '';
    const metadata = plainHtmlText(body.split(/<br\s*\/?\s*>/i).at(-1) ?? '').split('/').map((part) => part.trim());
    const year = metadata[0]?.match(/^(\d{4})(?:\D|$)/)?.[1];
    const regions = metadata[1]?.split(/\s+/).filter(Boolean).slice(0, 8);
    const genres = metadata[2]?.split(/\s+/).filter(Boolean).slice(0, 10) ?? [];
    const votes = Number(block.match(/<span[^>]*>(\d+)人评价<\/span>/)?.[1]);
    const item = normalizeDoubanSubjects([{ id, title, cover, rate: rating }], 'movie')[0];
    if (!item) throw new Error('豆瓣Top250影片资料不完整');
    return { ...item, rank, genres,
      ...(year ? { year } : {}), ...(regions?.length ? { regions } : {}),
      ...(Number.isSafeInteger(votes) && votes > 0 ? { votes } : {}),
    };
  });
}

async function publicHtml(url: string, signal?: AbortSignal): Promise<string> {
  signal?.throwIfAborted();
  const controller = new AbortController();
  const abort = () => controller.abort(signal?.reason);
  signal?.addEventListener('abort', abort, { once: true });
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const response = await fetch(url, { method: 'GET', mode: 'cors', credentials: 'omit', referrerPolicy: 'no-referrer',
      headers: { Accept: 'text/html' }, signal: controller.signal });
    if (!response.ok) throw new Error('豆瓣Top250暂时无法加载');
    if (Number(response.headers.get('content-length')) > 256 * 1024) { await response.body?.cancel(); throw new Error('榜单响应过大'); }
    const reader = response.body?.getReader();
    if (!reader) throw new Error('榜单数据为空');
    const decoder = new TextDecoder();
    let bytes = 0;
    let html = '';
    try {
      while (true) {
        const chunk = await reader.read();
        if (chunk.done) break;
        bytes += chunk.value.byteLength;
        if (bytes > 256 * 1024) { await reader.cancel(); throw new Error('榜单响应过大'); }
        html += decoder.decode(chunk.value, { stream: true });
      }
      return html + decoder.decode();
    } finally { reader.releaseLock(); }
  } catch (error) {
    signal?.throwIfAborted();
    if (controller.signal.aborted) throw new Error('豆瓣Top250请求超时');
    throw error;
  } finally { clearTimeout(timer); signal?.removeEventListener('abort', abort); }
}

export async function fetchTop250Page(start = 0, signal?: AbortSignal): Promise<LibraryPage> {
  validStart(start, TOP250_PAGE_SIZE, 10);
  const path = `/top250?start=${start}`;
  let html: string;
  try { html = await publicHtml(`${LIBRARY_METADATA_ORIGIN}${path}`, signal); }
  catch { signal?.throwIfAborted(); html = await publicHtml(`${LIBRARY_METADATA_FALLBACK}${path}`, signal); }
  const items = parseTop250Html(html, start);
  return { items, start, retrievedAt: Date.now(), ...(start < 225 ? { nextPageStart: start + TOP250_PAGE_SIZE } : {}) };
}
