import { afterEach, describe, expect, it, vi } from 'vitest';
import { resolveNativeHlsFallback } from './native-hls-fallback';

const original = 'https://pic1.mgzywpic.com/20260718/jxRvwqLp/index.m3u8';
const child = 'https://pic1.mgzywpic.com/20260718/jxRvwqLp/hls/index.m3u8';
// The actual failed master shape: one variant and no CODECS attribute.
const master = '#EXTM3U\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=2580000,RESOLUTION=2580x1080\n/20260718/jxRvwqLp/hls/index.m3u8\n';
const media = '#EXTM3U\n#EXT-X-TARGETDURATION:4\n#EXTINF:3.2,\nuGuUEZCh.ts\n#EXT-X-ENDLIST\n';
const response = (body: string, url?: string) => {
  const result = new Response(body);
  if (url) Object.defineProperty(result, 'url', { value: url });
  return result;
};
afterEach(() => vi.useRealTimers());

describe('native HLS compatibility fallback', () => {
  it('unwraps the Mango master and returns a verified real child URL', async () => {
    const fetcher = vi.fn().mockResolvedValueOnce(response(master)).mockResolvedValueOnce(response(media));
    expect(await resolveNativeHlsFallback(original, { fetcher })).toBe(child);
    expect(fetcher.mock.calls.map(([url]) => url)).toEqual([original, child]);
    expect(fetcher.mock.calls[0][1]).toMatchObject({ credentials: 'omit', mode: 'cors' });
  });

  it('resolves relative variants against the redirected master and returns final child URL', async () => {
    const finalChild = 'https://cdn.example/media/actual.m3u8?token=example';
    const fetcher = vi.fn().mockResolvedValueOnce(response(master.replace('/20260718/jxRvwqLp/hls/index.m3u8', 'hls/index.m3u8'), 'https://cdn.example/film/master.m3u8'))
      .mockResolvedValueOnce(response(media, finalChild));
    expect(await resolveNativeHlsFallback(original, { fetcher })).toBe(finalChild);
    expect(fetcher.mock.calls[1][0]).toBe('https://cdn.example/film/hls/index.m3u8');
  });

  it.each([
    ['multiple variants', master + '#EXT-X-STREAM-INF:BANDWIDTH=1200000\nother.m3u8'],
    ['external audio', master.replace('RESOLUTION=2580x1080', 'AUDIO="stereo"')],
    ['external subtitles', master.replace('RESOLUTION=2580x1080', 'SUBTITLES="subs"')],
    ['rendition metadata', '#EXT-X-MEDIA:TYPE=AUDIO,URI="a.m3u8"\n' + master],
    ['inherited key', master.replace('#EXTM3U', '#EXTM3U\n#EXT-X-SESSION-KEY:METHOD=AES-128,URI="key"')],
    ['missing URI', master.split('\n').slice(0, 2).join('\n')],
    ['unknown attribute', master.replace('PROGRAM-ID=1', 'UNRECOGNIZED=1')],
    ['HTML response', '<html>not a playlist</html>'],
    ['plain media playlist', media],
    ['HTTP downgrade', master.replace('/20260718/jxRvwqLp/hls/index.m3u8', 'http://cdn.example/media.m3u8')],
    ['private literal', master.replace('/20260718/jxRvwqLp/hls/index.m3u8', 'https://127.0.0.1/media.m3u8')],
  ])('preserves the original for %s', async (_name, body) => {
    const fetcher = vi.fn().mockResolvedValue(response(body));
    expect(await resolveNativeHlsFallback(original, { fetcher })).toBeUndefined();
    expect(fetcher).toHaveBeenCalledOnce();
  });

  it.each([
    '#EXTM3U\n#EXT-X-TARGETDURATION:4\n#EXTINF:3.2,\n',
    media.replace('uGuUEZCh.ts', 'http://cdn.example/segment.ts'),
    media.replace('#EXT-X-ENDLIST', '#EXT-X-KEY:METHOD=AES-128,URI="http://cdn.example/key"'),
  ])('rejects an incomplete or downgraded child', async (body) => {
    const fetcher = vi.fn().mockResolvedValueOnce(response(master)).mockResolvedValueOnce(response(body));
    expect(await resolveNativeHlsFallback(original, { fetcher })).toBeUndefined();
  });

  it('does not revisit cyclic playlists or follow unlimited nested masters', async () => {
    const cycle = vi.fn().mockResolvedValue(response(master.replace('/20260718/jxRvwqLp/hls/index.m3u8', original + '#loop')));
    expect(await resolveNativeHlsFallback(original, { fetcher: cycle })).toBeUndefined();
    expect(cycle).toHaveBeenCalledOnce();
    let count = 0;
    const nested = vi.fn().mockImplementation(() => Promise.resolve(response(master.replace('/20260718/jxRvwqLp/hls/index.m3u8', `https://cdn.example/${++count}.m3u8`))));
    expect(await resolveNativeHlsFallback(original, { fetcher: nested })).toBeUndefined();
    expect(nested).toHaveBeenCalledTimes(3);
  });

  it('rejects oversized bodies without fetching children', async () => {
    const fetcher = vi.fn().mockResolvedValue(response(master + '#'.repeat(512 * 1024)));
    expect(await resolveNativeHlsFallback(original, { fetcher })).toBeUndefined();
    expect(fetcher).toHaveBeenCalledOnce();
  });

  it('settles when fetch ignores cancellation, and clears every timer', async () => {
    vi.useFakeTimers();
    const fetcher = vi.fn().mockImplementation(() => new Promise<Response>(() => {}));
    const task = resolveNativeHlsFallback(original, { fetcher });
    await vi.advanceTimersByTimeAsync(8001);
    expect(await task).toBeUndefined();
    expect(vi.getTimerCount()).toBe(0);
  });

  it('cancels a reader that never delivers its next chunk', async () => {
    vi.useFakeTimers();
    const cancel = vi.fn();
    const body = new ReadableStream({ cancel });
    const fetcher = vi.fn().mockResolvedValue(new Response(body));
    const task = resolveNativeHlsFallback(original, { fetcher });
    await vi.advanceTimersByTimeAsync(8001);
    expect(await task).toBeUndefined();
    expect(cancel).toHaveBeenCalledOnce();
    expect(vi.getTimerCount()).toBe(0);
  });

  it('honors episode cancellation immediately', async () => {
    const controller = new AbortController();
    const fetcher = vi.fn().mockImplementation(() => new Promise<Response>(() => {}));
    const task = resolveNativeHlsFallback(original, { signal: controller.signal, fetcher });
    controller.abort();
    expect(await task).toBeUndefined();
    expect(fetcher).toHaveBeenCalledOnce();
  });
});
