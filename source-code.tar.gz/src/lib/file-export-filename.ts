/** Keep native and browser export names flat and independent of filesystem paths. */
export function validateExportFilename(filename: string): void {
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$/.test(filename) || filename.includes('..')) {
    throw new Error('导出文件名无效');
  }
}
