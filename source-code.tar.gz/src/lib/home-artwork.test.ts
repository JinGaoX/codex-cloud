import { describe, expect, it } from 'vitest';
import { HOME_WIDE_ARTWORK } from '../components/home-featured';
import { homeArtworkCandidates, homeArtworkShape } from './home-artwork';

const wides = [{ title: '真实电影', image: 'feature-film.webp' }];
const catalog = [{ title: '真实电影', posterFile: 'poster-film.webp' }];

describe('首页现有图片候选', () => {
  it('已核对横图、现有历史图片、本地竖海报按顺序回退', () => {
    expect(homeArtworkCandidates('真实电影', 'https://image.example/actual.webp', wides, catalog)).toEqual([
      { kind: 'bundled', source: 'reviewed-wide', url: '/posters/platform/feature-film.webp' },
      { kind: 'remote', source: 'history', url: 'https://image.example/actual.webp' },
      { kind: 'bundled', source: 'catalog-poster', url: '/posters/platform/poster-film.webp' },
    ]);
  });
  it('没有已核对横图时，历史提供的横图不会被目录竖海报挡住', () => {
    expect(homeArtworkCandidates('真实电影', 'https://image.example/wide.webp', [], catalog).map((item) => item.source))
      .toEqual(['history', 'catalog-poster']);
  });
  it('《浪浪山小妖怪》的既有已核对宽图保持优先', () => {
    expect(homeArtworkCandidates('浪浪山小妖怪', 'https://image.example/poster.jpg', HOME_WIDE_ARTWORK, [])[0])
      .toMatchObject({ source: 'reviewed-wide', url: '/posters/platform/feature-nobody.webp' });
  });
  it.each(['真实电影2025', '真实电影[电影解说]', '真实电影 第二季'])('不把%s模糊匹配成另一作品', (title) => {
    expect(homeArtworkCandidates(title, 'https://image.example/source.jpg', wides, catalog))
      .toEqual([{ kind: 'remote', source: 'history', url: 'https://image.example/source.jpg' }]);
  });
  it('没有历史封面时直接使用真实目录海报，无图则为空', () => {
    expect(homeArtworkCandidates('真实电影', '   ', [], catalog)).toEqual([
      { kind: 'bundled', source: 'catalog-poster', url: '/posters/platform/poster-film.webp' },
    ]);
    expect(homeArtworkCandidates('未知电影', undefined, wides, catalog)).toEqual([]);
  });
  it('相同候选URL不重复加载且保持原先优先级', () => {
    const same = '/posters/platform/feature-film.webp';
    expect(homeArtworkCandidates('真实电影', same, wides, [{ title: '真实电影', posterFile: 'feature-film.webp' }]))
      .toEqual([{ kind: 'bundled', source: 'reviewed-wide', url: same }]);
    expect(homeArtworkCandidates('真实电影', '/posters/platform/poster-film.webp', [], catalog))
      .toEqual([{ kind: 'bundled', source: 'history', url: '/posters/platform/poster-film.webp' }]);
  });
});

describe('首页图片按实际尺寸选择布局', () => {
  it.each([[1920, 1080], [1366, 768], [130, 100]])('%s×%s是横图，不改变原比例', (width, height) => {
    expect(homeArtworkShape(width, height)).toBe('wide');
  });
  it.each([[500, 750], [100, 100], [129, 100]])('%s×%s使用完整主体加氛围背景', (width, height) => {
    expect(homeArtworkShape(width, height)).toBe('poster');
  });
  it.each([[0, 100], [100, 0], [-1, 100], [Infinity, 100], [100, NaN]])('无效尺寸%s×%s不判断为已加载', (width, height) => {
    expect(homeArtworkShape(width, height)).toBeNull();
  });
});
