export interface HomeArtworkCandidate {
  kind: 'bundled' | 'remote';
  source: 'reviewed-wide' | 'history' | 'catalog-poster';
  url: string;
}

export type HomeArtworkShape = 'wide' | 'poster';

/** Aspect ratio describes layout only, never a claim about HD/4K quality. */
export function homeArtworkShape(width: number, height: number): HomeArtworkShape | null {
  if (!Number.isFinite(width) || !Number.isFinite(height) || width <= 0 || height <= 0) return null;
  return width / height >= 1.3 ? 'wide' : 'poster';
}

/**
 * Only exact reviewed-title matches provide a known backdrop. Existing history
 * artwork precedes a local portrait, so a source's real wide is not hidden by it.
 * No year/season stripping, metadata API, storage mutation or guessed URL.
 */
export function homeArtworkCandidates(
  title: string,
  pic: string | undefined,
  wides: readonly { title: string; image: string }[],
  catalog: readonly { title: string; posterFile: string }[],
): HomeArtworkCandidate[] {
  const wide = wides.find((entry) => entry.title === title);
  const poster = catalog.find((entry) => entry.title === title);
  const local = (file: string) => `/posters/platform/${file}`;
  const bundled = new Set([wide?.image && local(wide.image), poster?.posterFile && local(poster.posterFile)].filter(Boolean));
  const candidates: HomeArtworkCandidate[] = [];
  if (wide?.image) candidates.push({ kind: 'bundled', source: 'reviewed-wide', url: local(wide.image) });
  const historyUrl = pic?.trim();
  if (historyUrl) candidates.push({ kind: bundled.has(historyUrl) ? 'bundled' : 'remote', source: 'history', url: historyUrl });
  if (poster?.posterFile) candidates.push({ kind: 'bundled', source: 'catalog-poster', url: local(poster.posterFile) });
  const seen = new Set<string>();
  return candidates.filter((candidate) => {
    if (seen.has(candidate.url)) return false;
    seen.add(candidate.url);
    return true;
  });
}
