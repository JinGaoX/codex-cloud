import Hls, { type Fragment, type HlsListeners } from 'hls.js';
import { PLAYBACK_INFO_MAX_SAMPLES, PlaybackInfoTracker, type PlaybackInfo } from './playback-info';
import { parseVideoSampleStats, parseVideoTrack, type VideoTrackInfo } from './playback-media-info';

export interface PlaybackResolution {
  width: number;
  height: number;
}

interface TelemetryOptions {
  /** Only native media uses this URL check; MSE is confirmed by FRAG_BUFFERED. */
  nativeSourceUrl?: string;
  isCurrent: () => boolean;
  onResolution: (resolution: PlaybackResolution | null) => void;
  onInfo: (info: PlaybackInfo | null) => void;
}

/**
 * Observe the current playback only. Never fetch media, change transport, seek,
 * or derive FPS/bitrate from network speed or the browser's display counters.
 * Native HLS/MP4 exposes decoded size and, where supported, frame counters;
 * unavailable codec/fragment statistics remain unknown.
 */
export function createPlaybackTelemetry(video: HTMLVideoElement, options: TelemetryOptions) {
  const tracker = new PlaybackInfoTracker();
  const cleanup: Array<() => void> = [];
  let disposed = false;
  let resolutionReady = false;
  let attachedHls: Hls | undefined;
  let videoTrack: VideoTrackInfo | undefined;
  let videoCodec: string | undefined;
  let audioCodec: string | undefined;
  let activeFragmentKey: string | undefined;
  let lastInfo = '';
  let lastInfoUpdate = -Infinity;
  const readQuality = () => {
    try {
      return typeof video.getVideoPlaybackQuality === 'function' ? video.getVideoPlaybackQuality() : undefined;
    } catch { return undefined; }
  };
  const baseline = readQuality();
  let totalBaseline = baseline?.totalVideoFrames ?? 0;
  let droppedBaseline = baseline?.droppedVideoFrames ?? 0;
  const isCurrent = () => !disposed && options.isCurrent();
  const validCounter = (value: unknown): value is number => typeof value === 'number' && Number.isInteger(value) && value >= 0;

  const reportInfo = (force = false) => {
    if (!isCurrent()) return;
    const now = performance.now();
    if (!force && now - lastInfoUpdate < 1000) return;
    lastInfoUpdate = now;
    let info: PlaybackInfo | null = null;
    if (resolutionReady) {
      info = tracker.at(video.currentTime, activeFragmentKey);
      const quality = readQuality();
      if (quality && validCounter(quality.totalVideoFrames) && validCounter(quality.droppedVideoFrames)) {
        if (quality.totalVideoFrames < totalBaseline) totalBaseline = 0;
        if (quality.droppedVideoFrames < droppedBaseline) droppedBaseline = 0;
        info = {
          ...(info ?? { bitrateSampleCount: 0, bitrateSampleSeconds: 0 }),
          totalFrames: quality.totalVideoFrames - totalBaseline,
          droppedFrames: quality.droppedVideoFrames - droppedBaseline,
        };
      }
    }
    const serialized = JSON.stringify(info);
    if (serialized === lastInfo) return;
    lastInfo = serialized;
    options.onInfo(info);
  };
  const clear = () => {
    resolutionReady = false;
    if (!isCurrent()) return;
    options.onResolution(null);
    lastInfo = 'null';
    options.onInfo(null);
  };
  const onEmptied = () => {
    // Counters reset with a new media resource. Before that event, preserve the
    // baseline so a retry cannot include frames from the previous playback.
    totalBaseline = 0;
    droppedBaseline = 0;
    clear();
  };
  const reportResolution = () => {
    if (!isCurrent() || video.readyState < 1) return;
    if (!attachedHls && options.nativeSourceUrl && video.currentSrc === options.nativeSourceUrl) resolutionReady = true;
    if (!resolutionReady) return;
    const { videoWidth: width, videoHeight: height } = video;
    if (Number.isInteger(width) && width > 0 && Number.isInteger(height) && height > 0) {
      options.onResolution({ width, height });
    }
    reportInfo(true);
  };
  const onTime = () => reportInfo();
  const onSeek = () => reportInfo(true);
  for (const [event, listener] of [
    ['loadedmetadata', reportResolution], ['canplay', reportResolution],
    ['playing', reportResolution], ['resize', reportResolution], ['emptied', onEmptied],
    ['timeupdate', onTime], ['seeking', onSeek], ['seeked', onSeek],
  ] as const) {
    video.addEventListener(event, listener);
    cleanup.push(() => video.removeEventListener(event, listener));
  }
  clear();

  interface PendingInfo {
    bytes?: number;
    frames: number;
    seconds: number;
    invalidTiming: boolean;
    hasVideo: boolean;
    chunks: Set<string>;
    videoCodec?: string;
    audioCodec?: string;
  }
  const pending = new Map<string, PendingInfo>();
  const videoAppends = new Set<string>();
  const fragmentKey = (frag: Fragment) => `${frag.level}|${frag.cc}|${frag.sn}|${frag.url}`;
  const videoAppendKey = (frag: Fragment, part: { index?: number } | null | undefined) => `${fragmentKey(frag)}|${part ? part.index : 'full'}`;
  const isMainMedia = (frag: Fragment) => frag.type === 'main' && typeof frag.sn === 'number' && !frag.gap && !frag.bitrateTest;
  const isFullMain = (frag: Fragment, part: unknown) => isMainMedia(frag) && !part;
  const rowFor = (frag: Fragment) => {
    const key = fragmentKey(frag);
    let row = pending.get(key);
    if (!row) {
      row = { frames: 0, seconds: 0, invalidTiming: false, hasVideo: false, chunks: new Set() };
      pending.set(key, row);
      if (pending.size > PLAYBACK_INFO_MAX_SAMPLES) pending.delete(pending.keys().next().value!);
    }
    return row;
  };

  return {
    attachHls(hls: Hls) {
      if (disposed || attachedHls) return;
      attachedHls = hls;
      const on = <E extends keyof HlsListeners>(event: E, listener: HlsListeners[E]) => {
        hls.on(event, listener);
        cleanup.push(() => hls.off(event, listener));
      };
      on(Hls.Events.BUFFER_CODECS, (_event, data) => {
        if (!isCurrent()) return;
        if (data.video?.codec) videoCodec = data.video.codec;
        if (data.audio?.codec) audioCodec = data.audio.codec;
        const combined = data.audiovideo?.codec?.split(',').map((codec) => codec.trim());
        if (combined) {
          videoCodec = combined.find((codec) => /^(avc|hvc|hev|av01|vp0)/i.test(codec));
          audioCodec = combined.find((codec) => /^(mp4a|ac-3|ec-3|opus|flac|mp3)/i.test(codec));
        }
        const init = data.video?.initSegment ?? data.audiovideo?.initSegment;
        if (init) videoTrack = parseVideoTrack(init);
      });
      on(Hls.Events.FRAG_LOADING, (_event, data) => {
        if (!isCurrent() || !isMainMedia(data.frag)) return;
        videoAppends.delete(videoAppendKey(data.frag, data.part));
        if (isFullMain(data.frag, data.part)) pending.delete(fragmentKey(data.frag));
      });
      on(Hls.Events.FRAG_LOADED, (_event, data) => {
        if (!isCurrent() || !isFullMain(data.frag, data.part)) return;
        // A worker may have transferred payload. Loader stats also carry the
        // actual cached/network bytes; download duration is deliberately unused.
        const bytes = data.payload.byteLength || data.frag.stats.loaded;
        rowFor(data.frag).bytes = Number.isFinite(bytes) && bytes > 0 ? bytes : undefined;
      });
      on(Hls.Events.BUFFER_APPENDING, (_event, data) => {
        if (!isCurrent() || !isMainMedia(data.frag) || !data.data.byteLength
          || (data.type !== 'video' && data.type !== 'audiovideo')) return;
        const init = parseVideoTrack(data.data);
        if (init) videoTrack = init;
        const stats = videoTrack ? parseVideoSampleStats(data.data, videoTrack) : undefined;
        if (init && !stats) return;
        // Video parts can establish decoded dimensions, but cannot be counted
        // as complete main-fragment bitrate/FPS samples.
        videoAppends.add(videoAppendKey(data.frag, data.part));
        if (videoAppends.size > PLAYBACK_INFO_MAX_SAMPLES) videoAppends.delete(videoAppends.values().next().value!);
        if (!isFullMain(data.frag, data.part)) return;
        const row = rowFor(data.frag);
        const chunk = `${data.type}|${data.chunkMeta.id}`;
        if (row.chunks.has(chunk)) return;
        row.chunks.add(chunk);
        row.hasVideo = true;
        row.videoCodec = videoCodec;
        row.audioCodec = audioCodec;
        if (stats) {
          row.frames += stats.sampleCount;
          row.seconds += stats.durationSeconds;
        } else row.invalidTiming = true;
      });
      on(Hls.Events.FRAG_CHANGED, (_event, data) => {
        if (!isCurrent()) return;
        activeFragmentKey = fragmentKey(data.frag);
        reportInfo(true);
      });
      on(Hls.Events.FRAG_BUFFERED, (_event, data) => {
        if (!isCurrent()) return;
        if (isFullMain(data.frag, data.part)) {
          const row = pending.get(fragmentKey(data.frag));
          if (row?.hasVideo && row.bytes) {
            tracker.add({
              key: fragmentKey(data.frag), start: data.frag.start, duration: data.frag.duration,
              level: data.frag.level, continuity: data.frag.cc, bytes: row.bytes,
              videoCodec: row.videoCodec, audioCodec: row.audioCodec,
              videoSampleCount: !row.invalidTiming && row.frames > 0 ? row.frames : undefined,
              videoSampleSeconds: !row.invalidTiming && row.seconds > 0 ? row.seconds : undefined,
              declaredFrameRate: hls.levels[data.frag.level]?.frameRate,
            });
          }
        }
        const appendKey = videoAppendKey(data.frag, data.part);
        if (videoAppends.has(appendKey)) resolutionReady = true;
        videoAppends.delete(appendKey);
        reportResolution();
      });
    },
    dispose() {
      disposed = true;
      cleanup.forEach((remove) => remove());
      pending.clear();
      videoAppends.clear();
    },
  };
}
