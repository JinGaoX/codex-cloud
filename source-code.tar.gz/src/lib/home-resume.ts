import type { HistoryEntry, ProgressEntry } from './db';
import { DIRECT_MEDIA_SOURCE } from './standalone-media';

/** No persisted ended flag exists: use a conservative near-end heuristic. */
export const HOME_RESUME_COMPLETION_RATIO = 0.95;
/** Even at 95%, a long film can have minutes left. Require the final two minutes as well. */
export const HOME_RESUME_COMPLETION_MAX_REMAINING_SECONDS = 120;
export const HOME_RESUME_OTHER_LIMIT = 4;

/** A read-only presentation of existing records, never a new stored record. */
export interface HomeResumeItem extends HistoryEntry {
  /** Per-episode progress time when available, otherwise the legacy history time. */
  watchedAt: number;
  /** Unknown total duration is represented by null, never a fabricated percentage. */
  percent: number | null;
  /** Multiple entries do not prove that an API item is a TV series. */
  hasEpisodeContext: boolean;
}

export interface HomeResumeSelection {
  hero: HomeResumeItem | null;
  others: HomeResumeItem[];
  /** All unique, unfinished items, including the hero. */
  total: number;
}

const positive = (value: number) => Number.isFinite(value) && value > 0 ? value : 0;
const episodeNumber = (value: number) => Number.isSafeInteger(value) && value >= 0 ? value : null;
const historyStem = (entry: Pick<HistoryEntry, 'sourceKey' | 'vodId'>) => `${entry.sourceKey}_${entry.vodId}`;

export function isHomeResumeComplete(position: number, duration: number): boolean {
  const total = positive(duration), watched = positive(position);
  return total > 0 && (watched >= total || watched / total >= HOME_RESUME_COMPLETION_RATIO
    && total - watched <= HOME_RESUME_COMPLETION_MAX_REMAINING_SECONDS);
}

/** Direct-link titles can be just a hostname; their complete URL is the actual identity. */
function workKey(item: HomeResumeItem): string {
  if (item.sourceKey === DIRECT_MEDIA_SOURCE) return JSON.stringify([DIRECT_MEDIA_SOURCE, item.vodId]);
  // No fuzzy matching or stripping season/year/version suffixes for ordinary films.
  return JSON.stringify(['title', item.title.normalize('NFKC').trim().replace(/\s+/g, ' ').toLocaleLowerCase('en')]);
}

interface SavedEpisode {
  index: number;
  position: number;
  duration: number;
  at: number;
}

/**
 * Pick actual saved playback before considering History.timestamp: entering a
 * watch page refreshes that timestamp even when the user never starts it.
 * Source and VOD identifiers may contain underscores, so only split the final
 * numeric episode suffix, and match the entire remaining stem to a known item.
 */
export function selectHomeResume(
  history: readonly HistoryEntry[],
  progress: readonly ProgressEntry[],
  otherLimit = HOME_RESUME_OTHER_LIMIT,
): HomeResumeSelection {
  const histories = history.filter((entry) => entry && typeof entry.sourceKey === 'string' && entry.sourceKey.trim()
    && typeof entry.vodId === 'string' && entry.vodId.trim() && typeof entry.title === 'string' && entry.title.trim());
  const knownStems = new Set(histories.map(historyStem));
  const latestByStem = new Map<string, SavedEpisode>();
  for (const saved of progress) {
    if (!saved || typeof saved.key !== 'string' || !positive(saved.updatedAt) || positive(saved.position) < 1) continue;
    const suffix = /_(0|[1-9]\d*)$/.exec(saved.key);
    if (!suffix) continue;
    const stem = saved.key.slice(0, suffix.index), index = episodeNumber(Number(suffix[1]));
    if (!knownStems.has(stem) || index === null) continue;
    const previous = latestByStem.get(stem);
    if (!previous || saved.updatedAt > previous.at) latestByStem.set(stem, {
      index, position: positive(saved.position), duration: positive(saved.duration), at: saved.updatedAt,
    });
  }

  const observations: { item: HomeResumeItem; complete: boolean }[] = [];
  for (const entry of histories) {
    const saved = latestByStem.get(historyStem(entry));
    const historyIndex = episodeNumber(entry.episodeIndex);
    const historyPosition = positive(entry.playbackPosition), historyDuration = positive(entry.duration);
    const historyAt = positive(entry.timestamp);
    const historyFinished = historyIndex !== null && historyPosition >= 1 && isHomeResumeComplete(historyPosition, historyDuration);

    // handleEnded clears the current progress row. A newer near-end history
    // observation prevents an older half-watched episode from resurfacing.
    const finishedAfterSaved = historyFinished && (!saved || historyAt >= saved.at);
    const useSaved = saved && !finishedAfterSaved;
    const index = useSaved ? saved.index : historyIndex;
    const position = useSaved ? saved.position : historyPosition;
    const duration = useSaved ? saved.duration : historyDuration;
    const watchedAt = useSaved ? saved.at : historyAt;
    if (index === null || position < 1) continue;
    const totalEpisodes = Number.isSafeInteger(entry.totalEpisodes) && entry.totalEpisodes > 0 ? entry.totalEpisodes : 0;
    const item: HomeResumeItem = {
      ...entry,
      title: entry.title.trim(),
      episodeIndex: index,
      totalEpisodes,
      playbackPosition: position,
      duration,
      watchedAt,
      percent: duration > 0 ? Math.min(100, Math.round(position / duration * 100)) : null,
      hasEpisodeContext: totalEpisodes > 1 || index > 0,
    };
    observations.push({ item, complete: finishedAfterSaved || isHomeResumeComplete(position, duration) });
  }
  observations.sort((a, b) => b.item.watchedAt - a.item.watchedAt
    || historyStem(a.item).localeCompare(historyStem(b.item)));

  const seen = new Set<string>(), unfinished: HomeResumeItem[] = [];
  for (const observation of observations) {
    const key = workKey(observation.item);
    if (seen.has(key)) continue;
    // A completed latest source also hides an older partial copy of the same
    // exact-titled work. Zero-progress visits never reach this set.
    seen.add(key);
    if (!observation.complete) unfinished.push(observation.item);
  }
  const limit = Number.isFinite(otherLimit) ? Math.max(0, Math.min(8, Math.floor(otherLimit))) : HOME_RESUME_OTHER_LIMIT;
  return { hero: unfinished[0] ?? null, others: unfinished.slice(1, limit + 1), total: unfinished.length };
}
