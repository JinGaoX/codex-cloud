import { describe, expect, it } from 'vitest';
import {
  QUALITY_FAIL_TTL_MS,
  QUALITY_TTL_MS,
  describeQualityBadge,
  failureReasonLabel,
  isQualityEntryFresh,
  isRetryableTimeout,
  mergeQualityEntries,
  qualityLabel,
  resolutionLabel,
  summarizeQuality,
} from './quality';
import { parseBestResolution, parseMediaPlaylist } from './quality-probe';
import type { QualityEntry } from './types';

/** master playlist 样例：三档，其中一个只有 BANDWIDTH 没有 RESOLUTION */
const MASTER = `#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=1280000,RESOLUTION=1280x720
720/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=2560000,RESOLUTION=1920x1080
1080/index.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=800000
480/index.m3u8
`;

describe('qualityLabel', () => {
  it('按常见档位命名', () => {
    expect(qualityLabel(2160)).toBe('4K');
    expect(qualityLabel(1440)).toBe('2K');
    expect(qualityLabel(1080)).toBe('1080P');
    expect(qualityLabel(720)).toBe('720P');
    expect(qualityLabel(540)).toBe('540P');
    expect(qualityLabel(480)).toBe('480P');
    expect(qualityLabel(360)).toBe('360P');
  });

  it('轻微裁切仍归原档：1080P 裁掉上下边还是 1080P', () => {
    expect(qualityLabel(1040)).toBe('1080P'); // 1924×1040
    expect(qualityLabel(1030)).toBe('1080P');
    expect(qualityLabel(1110)).toBe('1080P');
  });

  it('1920×960 这类 2.0:1 裁切仍算 1080P（960 不是独立档位）', () => {
    expect(qualityLabel(960)).toBe('1080P');
    expect(qualityLabel(920)).toBe('1080P');
    expect(qualityLabel(1000)).toBe('1080P');
    expect(qualityLabel(700)).toBe('720P');
    expect(qualityLabel(680)).toBe('720P');
  });

  it('偏差过大时不抬档：低分辨率不会被算成 360P', () => {
    expect(qualityLabel(144)).toBe('144P');
    expect(qualityLabel(240)).toBe('240P');
    expect(qualityLabel(800)).toBe('720P');
  });

  it('缺失或非法高度返回 undefined（前端据此显示「未知」）', () => {
    expect(qualityLabel(undefined)).toBeUndefined();
    expect(qualityLabel(0)).toBeUndefined();
  });
});

describe('parseBestResolution', () => {
  it('从 master 中选择完整尺寸，忽略只有高码率但没有尺寸的档位', () => {
    expect(parseBestResolution(MASTER)).toEqual({ width: 1920, height: 1080 });
  });

  it('仅 BANDWIDTH 时保持未知，不推断像素尺寸', () => {
    const text = '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=50000000\nvideo.m3u8\n';
    expect(parseBestResolution(text)).toBeUndefined();
  });

  it('媒体列表、空文本及注释没有可用分辨率', () => {
    expect(parseBestResolution('#EXTM3U\n#EXTINF:10.0,\nseg0.ts\n')).toBeUndefined();
    expect(parseBestResolution('')).toBeUndefined();
    expect(parseBestResolution('#EXTM3U\n')).toBeUndefined();
  });

  it('缺少变体 URI 的声明不参与最大值选择', () => {
    const text = `#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=5000000,RESOLUTION=3840x2160
#EXT-X-STREAM-INF:BANDWIDTH=2500000,RESOLUTION=1920x1080
valid/index.m3u8
`;
    expect(parseBestResolution(text)).toEqual({ width: 1920, height: 1080 });
  });

  it('RESOLUTION 原样保留方向，不把 720x1280 变成 1280x720', () => {
    const text = '#EXTM3U\n#EXT-X-STREAM-INF:RESOLUTION=720x1280\nportrait.m3u8\n';
    expect(parseBestResolution(text)).toEqual({ width: 720, height: 1280 });
  });

  it('按像素面积而非高度或码率选取同一个档位的整对宽高', () => {
    const text = `#EXTM3U
#EXT-X-STREAM-INF:BANDWIDTH=1000000,RESOLUTION=1920x800
wide.m3u8
#EXT-X-STREAM-INF:BANDWIDTH=20000000,RESOLUTION=1280x1080
taller.m3u8
`;
    expect(parseBestResolution(text)).toEqual({ width: 1920, height: 800 });
  });

  it('更宽但面积较小的档位不会被当成最大分辨率', () => {
    const text = '#EXTM3U\n#EXT-X-STREAM-INF:RESOLUTION=2560x720\nwide.m3u8\n#EXT-X-STREAM-INF:RESOLUTION=1920x1080\nfull.m3u8\n';
    expect(parseBestResolution(text)).toEqual({ width: 1920, height: 1080 });
  });

  it('不接受包含零尺寸的声明', () => {
    expect(parseBestResolution('#EXTM3U\n#EXT-X-STREAM-INF:RESOLUTION=0x1080\ninvalid.m3u8\n')).toBeUndefined();
    expect(parseBestResolution('#EXTM3U\n#EXT-X-STREAM-INF:RESOLUTION=1920x0\ninvalid.m3u8\n')).toBeUndefined();
  });
});

describe('parseMediaPlaylist', () => {
  const MEDIA = `#EXTM3U
#EXT-X-TARGETDURATION:10
#EXT-X-MEDIA-SEQUENCE:17
#EXT-X-MAP:URI="init.mp4"
#EXTINF:10.0,
seg0.m4s
#EXTINF:10.0,
seg1.m4s
`;

  it('取到 init segment 与第一个分片（分片解析靠这两个）', () => {
    const info = parseMediaPlaylist(MEDIA);
    expect(info.initUri).toBe('init.mp4');
    expect(info.firstSegment).toBe('seg0.m4s'); // 只取第一个，第二个不关心
  });

  it('解析媒体序列号：未显式给 IV 时它就是 IV', () => {
    expect(parseMediaPlaylist(MEDIA).mediaSequence).toBe(17);
    expect(parseMediaPlaylist('#EXTM3U\nseg.ts\n').mediaSequence).toBe(0);
  });

  it('解析 AES-128 的方法、密钥地址与十六进制 IV', () => {
    const info = parseMediaPlaylist(`#EXTM3U
#EXT-X-KEY:METHOD=AES-128,URI="https://cdn.example/key.bin",IV=0x1a2b3c4d5e6f708192a3b4c5d6e7f809
seg0.ts
`);
    expect(info.keyMethod).toBe('AES-128');
    expect(info.keyUri).toBe('https://cdn.example/key.bin');
    expect(info.keyIv).toHaveLength(16);
    expect(info.keyIv![0]).toBe(0x1a);
    expect(info.keyIv![15]).toBe(0x09);
  });

  it('SAMPLE-AES 单独识别：服务端解不开，调用方据此放弃而不是解密出错', () => {
    const info = parseMediaPlaylist('#EXT-X-KEY:METHOD=SAMPLE-AES,URI="skd://x"\nseg.ts\n');
    expect(info.keyMethod).toBe('SAMPLE-AES');
    expect(info.keyUri).toBe('skd://x');
  });

  it('相对路径原样保留（拼接由调用方用 new URL 完成）', () => {
    expect(parseMediaPlaylist('#EXTM3U\n/2024/01/abc/index.ts\n').firstSegment).toBe('/2024/01/abc/index.ts');
  });

  it('m3u8 里没有分片时返回空，调用方据此判定测不出', () => {
    expect(parseMediaPlaylist('#EXTM3U\n#EXT-X-ENDLIST\n').firstSegment).toBeUndefined();
  });
});

describe('isQualityEntryFresh', () => {
  const T = 1_700_000_000_000;

  it('成功与「测不出」按长 TTL 判定', () => {
    const ok: QualityEntry = { width: 1920, height: 1080, from: 'probe', timestamp: T };
    const unknown: QualityEntry = { from: 'probe', timestamp: T };
    expect(isQualityEntryFresh(ok, T + QUALITY_TTL_MS - 1)).toBe(true);
    expect(isQualityEntryFresh(unknown, T + QUALITY_TTL_MS - 1)).toBe(true);
    expect(isQualityEntryFresh(ok, T + QUALITY_TTL_MS + 1)).toBe(false);
  });

  it('失败按短 TTL 判定：过期后允许重试', () => {
    const failed: QualityEntry = { from: 'probe', error: 'HTTP 403', timestamp: T };
    expect(isQualityEntryFresh(failed, T + QUALITY_FAIL_TTL_MS - 1)).toBe(true);
    expect(isQualityEntryFresh(failed, T + QUALITY_FAIL_TTL_MS + 1)).toBe(false);
  });

  it('读取路径靠它挡住持久化回来的过期条目', () => {
    // 刷新页面后旧条目直接从 localStorage 回到内存，写入时的清理没机会跑
    const stale: QualityEntry = { width: 1280, height: 720, from: 'play', timestamp: T };
    expect(isQualityEntryFresh(stale, T + QUALITY_TTL_MS * 2)).toBe(false);
  });

  it('height-only / width-only 旧缓存和非法尺寸都须重读，不能作为新鲜终态', () => {
    const incomplete: Array<Partial<QualityEntry>> = [
      { height: 1080 }, { width: 1920 }, { width: 0, height: 1080 },
      { width: 1920, height: -1 }, { width: 1920.5, height: 1080 },
      { width: NaN, height: 1080 }, { width: 1920, height: Infinity },
    ];
    for (const dimensions of incomplete) {
      for (const from of ['probe', 'play'] as const) {
        expect(isQualityEntryFresh({ ...dimensions, from, timestamp: T }, T + 1)).toBe(false);
      }
    }
  });

  it('损坏或明显未来的时间戳不无限保留缓存', () => {
    for (const timestamp of [NaN, Infinity, 0, -1, T + 60_001]) {
      expect(isQualityEntryFresh({ from: 'probe', timestamp }, T)).toBe(false);
    }
  });
});

describe('mergeQualityEntries', () => {
  const T = 1_700_000_000_000;
  const fixtureWidths: Record<number, number> = { 540: 960, 720: 1280, 1080: 1920 };
  const probe = (height?: number, error?: string): QualityEntry => ({
    width: height === undefined ? undefined : fixtureWidths[height], height, from: 'probe', error, timestamp: T,
  });
  const play = (height: number): QualityEntry => ({ width: fixtureWidths[height], height, from: 'play', timestamp: T });
  const KEY = 'huang:123';

  it('播放实测覆盖此前的「测不出」——单码率源的画质只能这样补上', () => {
    // 先探测：单码率 m3u8，没有画质信息（无 error、无 height）
    const afterProbe = mergeQualityEntries({}, { [KEY]: probe() }, T);
    expect(afterProbe[KEY].height).toBeUndefined();

    // 播放后拿到真实解码高度
    const afterPlay = mergeQualityEntries(afterProbe, { [KEY]: play(1080) }, T + 1000);
    expect(afterPlay[KEY]).toMatchObject({ height: 1080, from: 'play' });
  });

  it('实测值不被后续探测覆盖（m3u8 里写的是声明值，不如解码值可信）', () => {
    const current = { [KEY]: play(1080) };
    const next = mergeQualityEntries(current, { [KEY]: probe(720) }, T + 1000);
    expect(next[KEY]).toMatchObject({ height: 1080, from: 'play' });
  });

  it('多次实测取较大值：ABR 起播先选低档再升档，不能被起播档位低估', () => {
    const current = { [KEY]: play(720) };
    const next = mergeQualityEntries(current, { [KEY]: play(1080) }, T + 1000);
    expect(next[KEY].height).toBe(1080);

    // 反向：后来的低档位不该把已知的高档位拉低
    const back = mergeQualityEntries(next, { [KEY]: play(540) }, T + 2000);
    expect(back[KEY].height).toBe(1080);
  });

  it('已有明确档位时，不被「测不出」的探测抹掉', () => {
    const current = { [KEY]: probe(1080) };
    const next = mergeQualityEntries(current, { [KEY]: probe() }, T + 1000);
    expect(next[KEY].height).toBe(1080);
  });

  it('探测失败按短 TTL 淘汰，成功与「测不出」按长 TTL 保留', () => {
    const now = T + QUALITY_FAIL_TTL_MS + 1000;
    const merged = mergeQualityEntries(
      {
        failed: probe(undefined, 'HTTP 403'),
        unknown: probe(),
        ok: probe(1080),
      },
      {},
      now
    );
    // 失败记录已过期 → 允许重试；另外两条是有效结论，不能反复重探
    expect(merged.failed).toBeUndefined();
    expect(merged.unknown).toBeDefined();
    expect(merged.ok).toBeDefined();
    // 长 TTL 到期后同样清掉
    expect(mergeQualityEntries({ ok: probe(1080) }, {}, T + QUALITY_TTL_MS + 1000).ok).toBeUndefined();
  });

  it('保留未过期条目，避免每次写入都把已有缓存丢掉', () => {
    const current = { other: probe(720) };
    const next = mergeQualityEntries(current, { [KEY]: play(1080) }, T + 1000);
    expect(next.other).toMatchObject({ height: 720 });
    expect(next[KEY]).toMatchObject({ height: 1080 });
  });

  it('超过上限时淘汰最旧条目', () => {
    const current: Record<string, QualityEntry> = {};
    for (let i = 0; i < 400; i++) {
      current[`k${i}`] = { width: 1280, height: 720, from: 'probe', timestamp: T + i };
    }
    const next = mergeQualityEntries(current, { fresh: { width: 1920, height: 1080, from: 'probe', timestamp: T + 9999 } }, T + 9999);
    expect(Object.keys(next)).toHaveLength(400);
    expect(next.k0).toBeUndefined(); // 最旧的一条被淘汰
    expect(next.fresh).toBeDefined();
  });
});

describe('describeQualityBadge', () => {
  const entry = (patch: Partial<QualityEntry> = {}): QualityEntry => ({
    from: 'probe',
    timestamp: 1_700_000_000_000,
    ...patch,
  });

  it('探测中优先于已有结果：重试时不该还挂着旧结论', () => {
    expect(describeQualityBadge(entry({ width: 1280, height: 720 }), true)).toMatchObject({ kind: 'loading', retryable: false });
  });

  it('尚未探测时返回 undefined：不渲染，避免与「未知」混淆', () => {
    expect(describeQualityBadge(undefined, false)).toBeUndefined();
  });

  it('有档位：探测值与实测值的 tooltip 区分数据来源', () => {
    expect(describeQualityBadge(entry({ width: 1920, height: 1080 }))).toMatchObject({ kind: 'value', label: '1920×1080' });
    expect(describeQualityBadge(entry({ width: 1920, height: 1080, from: 'play' }))?.title).toContain('解码尺寸');
    expect(describeQualityBadge(entry({ width: 1920, height: 1080, from: 'probe' }))?.title).toContain('预览抽样');
  });

  it('无高度无错误 = 未知，且不可重试（源站本就不给信息）', () => {
    const view = describeQualityBadge(entry());
    expect(view).toMatchObject({ kind: 'unknown', retryable: false });
    expect(view?.title).toContain('完整宽高');
  });

  it('有错误 = 未探到，可重试，且原因写进 tooltip', () => {
    const view = describeQualityBadge(entry({ error: 'HTTP 403' }));
    expect(view).toMatchObject({ kind: 'failed', retryable: true });
    expect(view?.title).toContain('HTTP 403');
  });

  it('失败但带有高度时按有档位展示（部分源先失败后回填）', () => {
    expect(describeQualityBadge(entry({ width: 1280, height: 720, error: 'HTTP 500' }))).toMatchObject({ kind: 'value', label: '1280×720' });
  });
});

describe('summarizeQuality', () => {
  const T = 1_700_000_000_000;
  const probe = (height?: number, error?: string): QualityEntry => ({ width: height === undefined ? undefined : height === 720 ? 1280 : 1920, height, from: 'probe', error, timestamp: T });

  it('空输入：没有结论也不虚报总数', () => {
    expect(summarizeQuality([])).toEqual({ best: undefined, known: 0, failed: 0, total: 0 });
  });

  it('取最高档并统计命中/失败/总数', () => {
    const summary = summarizeQuality([probe(720), probe(1080), probe(), probe(undefined, 'HTTP 403')]);
    expect(summary).toEqual({ best: '1920×1080', known: 2, failed: 1, total: 4 });
  });

  it('未探测条目（undefined）不计入分母，进度不会显得永远差几条', () => {
    expect(summarizeQuality([probe(720), undefined, undefined])).toEqual({
      best: '1280×720',
      known: 1,
      failed: 0,
      total: 1,
    });
  });

  it('全部测不出时没有 best，但仍是有效结论（total 计入）', () => {
    expect(summarizeQuality([probe(), probe()])).toEqual({ best: undefined, known: 0, failed: 0, total: 2 });
  });

  it('实测与探测混合时取较大值（实测可把单码率源补上）', () => {
    const play: QualityEntry = { width: 3840, height: 2160, from: 'play', timestamp: T };
    expect(summarizeQuality([probe(720), play]).best).toBe('3840×2160');
  });
});

describe('失败原因标签', () => {
  it('源站拒绝与超时各有短标签', () => {
    expect(failureReasonLabel('HTTP 403')).toBe('防盗链');
    expect(failureReasonLabel('画质探测超时')).toBe('超时');
    expect(failureReasonLabel('未找到播放资源')).toBe('无资源');
  });

  it('传输层失败也要有标签：否则线上只剩裸「未测到」，无从判断哪一环挂了', () => {
    expect(failureReasonLabel('探测请求被网关拦截（未收到任何响应）')).toBe('连接中断');
    expect(failureReasonLabel('探测连接中途被断开（已收到部分结果，多为网关超时）')).toBe('连接中断');
    expect(failureReasonLabel('探测请求没能送达服务器（网络或反向代理中断）')).toBe('连接中断');
    expect(failureReasonLabel('请求失败 (502)')).toBe('网关异常');
  });

  it('无法归类的错误不硬造标签', () => {
    expect(failureReasonLabel('fetch failed')).toBeUndefined();
    expect(failureReasonLabel(undefined)).toBeUndefined();
  });
});

describe('isRetryableTimeout', () => {
  it('只把超时视作值得自动补探的失败', () => {
    expect(isRetryableTimeout('画质探测超时')).toBe(true);
    expect(isRetryableTimeout('HTTP 403')).toBe(false);
    expect(isRetryableTimeout(undefined)).toBe(false);
  });
});


describe('exact resolution data', () => {
  const timestamp = 1700000000000;
  it('shows exact full dimensions without guessing a width for legacy height-only entries', () => {
    expect(resolutionLabel(1920, 1080)).toBe('1920×1080');
    expect(resolutionLabel(720, 1280)).toBe('720×1280');
    expect(resolutionLabel(undefined, 1080)).toBeUndefined();
    expect(resolutionLabel(0, 1080)).toBeUndefined();
    expect(resolutionLabel(1920.5, 1080)).toBeUndefined();
    expect(describeQualityBadge({ width: 1920, height: 1080, from: 'play', timestamp })?.label).toBe('1920×1080');
    expect(describeQualityBadge({ height: 1080, from: 'play', timestamp })?.kind).toBe('unknown');
  });
  it('keeps width-height pairs together when a later ABR level has lower dimensions', () => {
    const previous: QualityEntry = { width: 1920, height: 1080, from: 'play', timestamp };
    const lower: QualityEntry = { width: 1280, height: 720, from: 'play', timestamp };
    const best = mergeQualityEntries({ a: previous }, { a: lower }, timestamp + 1).a;
    expect(best).toMatchObject({ width: 1920, height: 1080 });
    const higher: QualityEntry = { width: 2560, height: 1440, from: 'play', timestamp };
    expect(mergeQualityEntries({ a: previous }, { a: higher }, timestamp + 1).a).toMatchObject({ width: 2560, height: 1440 });
  });
  it('upgrades legacy measured entries only when the exact dimensions are actually read', () => {
    const previous: QualityEntry = { height: 1080, from: 'play', timestamp };
    const measured: QualityEntry = { width: 1920, height: 1080, from: 'play', timestamp };
    expect(mergeQualityEntries({ a: previous }, { a: measured }, timestamp + 1).a.width).toBe(1920);
    expect(mergeQualityEntries({ a: measured }, { a: previous }, timestamp + 1).a.width).toBe(1920);
  });
  it('replaces height-only or width-only played history with a complete preview pair', () => {
    const preview: QualityEntry = { width: 1920, height: 800, from: 'probe', timestamp };
    for (const legacy of [{ height: 2160 }, { width: 3840 }]) {
      const previous: QualityEntry = { ...legacy, from: 'play', timestamp };
      expect(mergeQualityEntries({ a: previous }, { a: preview }, timestamp + 1).a).toEqual(preview);
    }
    const unknownPlay: QualityEntry = { from: 'play', timestamp };
    expect(mergeQualityEntries({ a: unknownPlay }, { a: preview }, timestamp + 1).a).toEqual(preview);
  });
  it('compares played pixel area using the complete measured pair, never height alone', () => {
    const wide: QualityEntry = { width: 1920, height: 800, from: 'play', timestamp };
    const taller: QualityEntry = { width: 1280, height: 1080, from: 'play', timestamp };
    expect(mergeQualityEntries({ a: taller }, { a: wide }, timestamp + 1).a).toMatchObject({ width: 1920, height: 800 });
    expect(mergeQualityEntries({ a: wide }, { a: taller }, timestamp + 1).a).toMatchObject({ width: 1920, height: 800 });
  });
  it('does not erase known dimensions with unknown or malformed incoming measurements', () => {
    const known: QualityEntry = { width: 1920, height: 800, from: 'probe', timestamp };
    for (const patch of [{}, { width: 2560 }, { height: 1440 }, { width: -1, height: 1440 }]) {
      expect(mergeQualityEntries({ a: known }, { a: { ...patch, from: 'play', timestamp } }, timestamp + 1).a).toEqual(known);
    }
  });
});
