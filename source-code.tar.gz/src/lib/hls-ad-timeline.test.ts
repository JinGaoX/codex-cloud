import { describe, expect, it } from 'vitest';
import { createHlsAdTimeline, filteredToSourceTime, sourceToFilteredTime } from './hls-ad-timeline';

const manifest = '#EXTM3U\n#EXTINF:100,\na.ts\n#EXTINF:20,\nb.ts\n#EXTINF:80,\nc.ts\n#EXTINF:10,\nd.ts\n#EXTINF:90,\ne.ts\n#EXT-X-ENDLIST';
const timeline = createHlsAdTimeline(manifest, [
  { startSeconds: 100, durationSeconds: 20 }, { startSeconds: 200, durationSeconds: 10 },
])!;
describe('ad filtering preserves source positions across playback modes', () => {
  it('restores old source progress after either inserted break', () => {
    expect(timeline.originalDuration).toBe(300);
    expect(timeline.filteredDuration).toBe(270);
    expect(sourceToFilteredTime(50, timeline)).toBe(50);
    expect(sourceToFilteredTime(150, timeline)).toBe(130);
    expect(sourceToFilteredTime(250, timeline)).toBe(220);
    expect(filteredToSourceTime(220, timeline)).toBe(250);
  });
  it('restoring inside a removed break resumes at the next main segment', () => {
    expect(sourceToFilteredTime(110, timeline)).toBe(100);
    expect(filteredToSourceTime(100, timeline)).toBe(120);
    expect(filteredToSourceTime(180, timeline)).toBe(210);
  });
  it('maps every surviving source point back to itself', () => {
    for (const point of [0, 30, 99.9, 120, 165.3, 199.9, 210, 299, 300]) {
      expect(filteredToSourceTime(sourceToFilteredTime(point, timeline), timeline)).toBeCloseTo(point, 5);
    }
  });
  it('leaves native/unfiltered time unchanged', () => {
    expect(sourceToFilteredTime(120, null)).toBe(120);
    expect(filteredToSourceTime(120, null)).toBe(120);
    expect(createHlsAdTimeline(manifest, [])).toBeNull();
  });
  it('rejects invalid overlapping or out-of-bounds deletion maps', () => {
    expect(createHlsAdTimeline(manifest, [{ startSeconds: -1, durationSeconds: 20 }])).toBeNull();
    expect(createHlsAdTimeline(manifest, [{ startSeconds: 299, durationSeconds: 20 }])).toBeNull();
    expect(createHlsAdTimeline(manifest, [
      { startSeconds: 20, durationSeconds: 20 }, { startSeconds: 30, durationSeconds: 5 },
    ])).toBeNull();
  });
});
