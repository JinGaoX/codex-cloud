import { EventEmitter } from 'node:events';
import Hls, { type Fragment } from 'hls.js';
import { describe, expect, it, vi } from 'vitest';
import { createPlaybackTelemetry } from './playback-telemetry';

class FakeVideo extends EventTarget {
  currentTime = 1;
  currentSrc = 'https://media.example/film.m3u8';
  readyState = 1;
  videoWidth = 1920;
  videoHeight = 800;
  totalFrames = 100;
  droppedFrames = 2;
  getVideoPlaybackQuality: (() => VideoPlaybackQuality) | undefined = () => ({
    totalVideoFrames: this.totalFrames, droppedVideoFrames: this.droppedFrames,
  } as VideoPlaybackQuality);
  fire(event: string) { this.dispatchEvent(new Event(event)); }
}

class FakeHls extends EventEmitter {
  levels = [{ frameRate: 60 }];
  trigger(event: string, data: unknown) { this.emit(event, event, data); }
}

function fixture(native = false) {
  const video = new FakeVideo();
  const onResolution = vi.fn();
  const onInfo = vi.fn();
  let current = true;
  const telemetry = createPlaybackTelemetry(video as unknown as HTMLVideoElement, {
    nativeSourceUrl: native ? video.currentSrc : undefined,
    isCurrent: () => current,
    onResolution, onInfo,
  });
  const hls = new FakeHls();
  if (!native) telemetry.attachHls(hls as unknown as Hls);
  return { video, hls, telemetry, onResolution, onInfo, supersede: () => { current = false; } };
}

function fragment(overrides: Partial<Fragment> = {}): Fragment {
  return {
    type: 'main', sn: 1, level: 0, cc: 0, start: 0, duration: 2,
    url: 'https://media.example/1.ts', gap: false, bitrateTest: false,
    stats: { loaded: 250_000 }, ...overrides,
  } as Fragment;
}

function append(hls: FakeHls, frag: Fragment, options: { part?: object; audioOnly?: boolean; payloadBytes?: number } = {}) {
  const part = options.part ?? null;
  hls.trigger(Hls.Events.FRAG_LOADING, { frag, part });
  hls.trigger(Hls.Events.FRAG_LOADED, { frag, part, payload: new ArrayBuffer(options.payloadBytes ?? 250_000) });
  hls.trigger(Hls.Events.BUFFER_APPENDING, {
    frag, part, type: options.audioOnly ? 'audio' : 'video', chunkMeta: { id: 1 }, data: new Uint8Array([1]),
  });
}

// Minimal complete ISO-BMFF timing fixtures: video timescale 1000, default
// sample duration 40 ticks. These exercise the actual MP4 parser/event chain.
function u32(...values: number[]) {
  const bytes = new Uint8Array(values.length * 4);
  values.forEach((value, index) => new DataView(bytes.buffer).setUint32(index * 4, value));
  return bytes;
}
function box(type: string, ...parts: Uint8Array[]) {
  const bytes = new Uint8Array(8 + parts.reduce((sum, part) => sum + part.length, 0));
  bytes.set(u32(bytes.length));
  bytes.set(new TextEncoder().encode(type), 4);
  let offset = 8;
  for (const part of parts) { bytes.set(part, offset); offset += part.length; }
  return bytes;
}
function videoInit() {
  const tkhd = new Uint8Array(84);
  tkhd.set(u32(1), 12);
  const mdhd = new Uint8Array(24);
  mdhd.set(u32(1000), 12);
  const hdlr = new Uint8Array(24);
  hdlr.set(new TextEncoder().encode('vide'), 8);
  return box('moov', box('trak', box('tkhd', tkhd), box('mdia', box('mdhd', mdhd), box('hdlr', hdlr))));
}
function videoChunk(frames = 25) {
  return box('moof', box('traf', box('tfhd', u32(0x020008, 1, 40)), box('trun', u32(0, frames))));
}

describe('playback telemetry uses the active media without extra requests', () => {
  it('native HLS/MP4 reports decoded dimensions and supported counters, leaving fragment data unknown', () => {
    const { video, onResolution, onInfo, telemetry } = fixture(true);
    video.fire('emptied');
    video.fire('loadedmetadata');
    expect(onResolution).toHaveBeenLastCalledWith({ width: 1920, height: 800 });
    expect(onInfo).toHaveBeenLastCalledWith({ bitrateSampleCount: 0, bitrateSampleSeconds: 0, totalFrames: 100, droppedFrames: 2 });
    const info = onInfo.mock.lastCall![0];
    expect(info.videoCodec).toBeUndefined();
    expect(info.audioCodec).toBeUndefined();
    expect(info.bitrate).toBeUndefined();
    expect(info.frameRate).toBeUndefined();
    telemetry.dispose();
  });

  it('native media never borrows the old resource dimensions or invents missing browser counters', () => {
    const { video, onResolution, onInfo, telemetry } = fixture(true);
    video.currentSrc = 'https://media.example/previous.mp4';
    video.fire('loadedmetadata');
    expect(onResolution).toHaveBeenLastCalledWith(null);
    video.currentSrc = 'https://media.example/film.m3u8';
    video.getVideoPlaybackQuality = undefined;
    video.fire('canplay');
    expect(onResolution).toHaveBeenLastCalledWith({ width: 1920, height: 800 });
    expect(onInfo).toHaveBeenLastCalledWith(null);
    telemetry.dispose();
  });

  it('counts frames for this media load, resets on emptied, and does not infer FPS from decoded counters', () => {
    const { video, onInfo, telemetry } = fixture(true);
    video.totalFrames = 160;
    video.droppedFrames = 3;
    video.fire('playing');
    expect(onInfo.mock.lastCall![0]).toMatchObject({ totalFrames: 60, droppedFrames: 1 });
    expect(onInfo.mock.lastCall![0].frameRate).toBeUndefined();
    video.fire('emptied');
    video.totalFrames = 24;
    video.droppedFrames = 0;
    video.fire('loadedmetadata');
    expect(onInfo.mock.lastCall![0]).toMatchObject({ totalFrames: 24, droppedFrames: 0 });
    telemetry.dispose();
  });

  it('does not report zero or incomplete dimensions and accepts a later resize', () => {
    const { video, onResolution, telemetry } = fixture(true);
    video.videoWidth = 0;
    video.fire('loadedmetadata');
    expect(onResolution).toHaveBeenLastCalledWith(null);
    video.videoWidth = 1280;
    video.videoHeight = 536;
    video.fire('resize');
    expect(onResolution).toHaveBeenLastCalledWith({ width: 1280, height: 536 });
    telemetry.dispose();
  });

  it('commits a full main fragment only after it has entered the buffer', () => {
    const { video, hls, onResolution, onInfo, telemetry } = fixture();
    const frag = fragment();
    hls.trigger(Hls.Events.BUFFER_CODECS, { video: { codec: 'avc1.640028' }, audio: { codec: 'mp4a.40.2' } });
    video.fire('loadedmetadata');
    append(hls, frag);
    expect(onResolution).toHaveBeenLastCalledWith(null);
    expect(onInfo).toHaveBeenLastCalledWith(null);
    hls.trigger(Hls.Events.FRAG_BUFFERED, { frag, part: null });
    expect(onResolution).toHaveBeenLastCalledWith({ width: 1920, height: 800 });
    expect(onInfo).toHaveBeenLastCalledWith(expect.objectContaining({
      videoCodec: 'avc1.640028', audioCodec: 'mp4a.40.2', bitrate: 1_000_000,
      bitrateSampleCount: 1, bitrateSampleSeconds: 2, declaredFrameRate: 60,
    }));
    expect(onInfo.mock.lastCall![0].frameRate).toBeUndefined();
    telemetry.dispose();
  });

  it('uses the loader byte count when worker transfer detached the payload', () => {
    const { hls, onInfo, telemetry } = fixture();
    const frag = fragment();
    append(hls, frag, { payloadBytes: 0 });
    hls.trigger(Hls.Events.FRAG_BUFFERED, { frag, part: null });
    expect(onInfo.mock.lastCall![0]).toMatchObject({ bitrate: 1_000_000 });
    telemetry.dispose();
  });

  it('computes FPS from actual appended video samples, ignoring duplicate chunks and manifest FPS', () => {
    const { hls, onInfo, telemetry } = fixture();
    const frag = fragment();
    hls.trigger(Hls.Events.BUFFER_CODECS, { video: { codec: 'avc1.640028', initSegment: videoInit() } });
    hls.trigger(Hls.Events.FRAG_LOADING, { frag, part: null });
    hls.trigger(Hls.Events.FRAG_LOADED, { frag, part: null, payload: new ArrayBuffer(250_000) });
    for (const id of [1, 1, 2]) {
      hls.trigger(Hls.Events.BUFFER_APPENDING, { frag, part: null, type: 'video', chunkMeta: { id }, data: videoChunk() });
    }
    hls.trigger(Hls.Events.FRAG_BUFFERED, { frag, part: null });
    expect(onInfo.mock.lastCall![0]).toMatchObject({ frameRate: 25, declaredFrameRate: 60, bitrateSampleSeconds: 2 });
    telemetry.dispose();
  });

  it('leaves measured FPS unknown when any media chunk lacks complete video timing', () => {
    const { hls, onInfo, telemetry } = fixture();
    const frag = fragment();
    hls.trigger(Hls.Events.BUFFER_CODECS, { video: { codec: 'avc1.640028', initSegment: videoInit() } });
    append(hls, frag); // First media chunk has no readable timing metadata.
    hls.trigger(Hls.Events.BUFFER_APPENDING, { frag, part: null, type: 'video', chunkMeta: { id: 2 }, data: videoChunk() });
    hls.trigger(Hls.Events.FRAG_BUFFERED, { frag, part: null });
    expect(onInfo.mock.lastCall![0].frameRate).toBeUndefined();
    expect(onInfo.mock.lastCall![0].declaredFrameRate).toBe(60);
    telemetry.dispose();
  });

  it.each(['audio-only', 'LL part', 'gap', 'bandwidth test'] as const)('does not call %s a full main video sample', (kind) => {
    const { hls, onInfo, onResolution, telemetry } = fixture();
    const frag = fragment({ gap: kind === 'gap', bitrateTest: kind === 'bandwidth test' });
    const part = kind === 'LL part' ? { index: 0 } : undefined;
    append(hls, frag, { part, audioOnly: kind === 'audio-only' });
    hls.trigger(Hls.Events.FRAG_BUFFERED, { frag, part: part ?? null });
    expect(onInfo.mock.lastCall![0]?.bitrate).toBeUndefined();
    expect(onInfo.mock.lastCall![0]?.frameRate).toBeUndefined();
    if (kind === 'LL part') expect(onResolution).toHaveBeenLastCalledWith({ width: 1920, height: 800 });
    else expect(onResolution).toHaveBeenLastCalledWith(null);
    telemetry.dispose();
  });

  it('future buffered fragments do not overwrite current fragment bitrate or codec', () => {
    const { hls, onInfo, telemetry } = fixture();
    const current = fragment();
    hls.trigger(Hls.Events.BUFFER_CODECS, { video: { codec: 'avc1.640028' } });
    append(hls, current);
    hls.trigger(Hls.Events.FRAG_BUFFERED, { frag: current, part: null });
    const future = fragment({ sn: 2, start: 20, url: 'https://media.example/future.ts' });
    hls.trigger(Hls.Events.BUFFER_CODECS, { video: { codec: 'hvc1.1.6.L93.B0' } });
    append(hls, future, { payloadBytes: 1_000_000 });
    hls.trigger(Hls.Events.FRAG_BUFFERED, { frag: future, part: null });
    expect(onInfo.mock.lastCall![0]).toMatchObject({ bitrate: 1_000_000, videoCodec: 'avc1.640028' });
    telemetry.dispose();
  });

  it('ignores superseded callbacks even when a new episode reuses the same URL', () => {
    const { video, hls, supersede, onResolution, onInfo, telemetry } = fixture();
    const frag = fragment();
    append(hls, frag);
    supersede();
    const resolutionsBefore = onResolution.mock.calls.length;
    const infosBefore = onInfo.mock.calls.length;
    hls.trigger(Hls.Events.FRAG_BUFFERED, { frag, part: null });
    video.fire('resize');
    video.fire('timeupdate');
    expect(onResolution).toHaveBeenCalledTimes(resolutionsBefore);
    expect(onInfo).toHaveBeenCalledTimes(infosBefore);
    telemetry.dispose();
  });

  it('dispose removes native listeners and HLS event subscriptions before a retry', () => {
    const { video, hls, telemetry, onResolution, onInfo } = fixture();
    expect(hls.listenerCount(Hls.Events.FRAG_BUFFERED)).toBe(1);
    telemetry.dispose();
    expect(hls.listenerCount(Hls.Events.FRAG_BUFFERED)).toBe(0);
    onResolution.mockClear();
    onInfo.mockClear();
    video.fire('resize');
    video.fire('emptied');
    expect(onResolution).not.toHaveBeenCalled();
    expect(onInfo).not.toHaveBeenCalled();
  });
});
