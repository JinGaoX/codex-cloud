/**
 * zustand persist 用的节流 localStorage 包装（独立成模块的原因：
 * db.ts 的 importConfig 需要 flush 节流缓冲，而运行时依赖方向是 store → db，
 * db.ts 不能反向 import store，故把两者共用的存储逻辑放在这个无依赖的底层模块）。
 */

import type { StateStorage } from 'zustand/middleware';
import { ACTIVE_ACCOUNT_SCOPE, settingsKeyForScope } from './account-scope';

/** store 持久化在 localStorage 中的键（store.ts 的 persist name 与 importConfig 共用） */
export const PERSIST_KEY = 'libretv-settings';

// 在模块初始化时固定资料空间；账号标记变化后的旧缓冲不能写进新账号。
const storageKey = (name: string) => settingsKeyForScope(name, ACTIVE_ACCOUNT_SCOPE);

/** 节流窗口：搜索/测活等高频 set 合并为 800ms 一次落盘 */
const THROTTLE_MS = 800;

let timer: ReturnType<typeof setTimeout> | null = null;
let pending: [string, string] | null = null;

function flush(): void {
  if (timer) {
    clearTimeout(timer);
    timer = null;
  }
  if (!pending) return;
  const [key, value] = pending;
  pending = null;
  try {
    localStorage.setItem(key, value);
  } catch {
    // 配额不足 / 隐私模式下静默放弃持久化，内存态仍可用
  }
}

if (typeof window !== 'undefined') {
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') flush();
  });
  window.addEventListener('beforeunload', flush);
  // iOS 切后台或进入往返缓存时通常不发 beforeunload。
  window.addEventListener('pagehide', flush);
}

/**
 * 立即落盘缓冲中的待写状态。
 * importConfig 直接写 localStorage 前必须先调用，否则缓冲中的旧状态
 * 会在导入后 flush 覆盖刚写入的配置（竞态见 db.ts importConfig）。
 */
export function flushPendingPersist(): void {
  flush();
}

/** 配置导入导出与 Zustand 使用同一空间，备份文件内仍保留原兼容键名。 */
export function readPersistedSettings(): string | null {
  try {
    return localStorage.getItem(storageKey(PERSIST_KEY));
  } catch {
    return null;
  }
}

export function writePersistedSettings(value: string): void {
  flush();
  localStorage.setItem(storageKey(PERSIST_KEY), value);
}

export function removePersistedSettings(): void {
  removeStorageItem(storageKey(PERSIST_KEY));
}

function removeStorageItem(key: string): void {
  // 显式移除之后，旧缓冲不得把这个键重新写回来。
  if (pending?.[0] === key) {
    pending = null;
    if (timer) clearTimeout(timer);
    timer = null;
  }
  localStorage.removeItem(key);
}

/**
 * 节流写入的 localStorage 包装。
 * 搜索会逐源写健康度、测活每 200ms 合并写回，这些都会触发 persist 的整份序列化 + 写盘；
 * 这里把写入合并为 800ms 一次，并在页面隐藏/卸载时立即 flush，确保不丢最后一次修改。
 */
export function createThrottledStorage(): StateStorage {
  return {
    getItem: (name) => {
      try {
        return localStorage.getItem(storageKey(name));
      } catch {
        return null;
      }
    },
    setItem: (name, value) => {
      pending = [storageKey(name), value];
      if (!timer) timer = setTimeout(flush, THROTTLE_MS);
    },
    removeItem: (name) => {
      try {
        removeStorageItem(storageKey(name));
      } catch {
        // 忽略
      }
    },
  };
}
