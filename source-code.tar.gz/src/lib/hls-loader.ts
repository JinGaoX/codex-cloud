import type HlsType from 'hls.js';
import { stripAdGroups, stripExplicitAdGroups } from './m3u8';
import { buildSegmentCacheKey, readCachedSegment, touchMeta } from './video-cache';

/**
 * hls.js loader 工厂：在同一个 loader 里组合「广告过滤」与「片段缓存命中」。
 *
 * - manifest / level：走基类网络加载；blockAd 开启时在 onSuccess 里剔除
 *   广告段（整段移除，保留正片 DISCONTINUITY 时间轴标记）；
 *   独立版使用 explicit 策略，不启用时长/片头启发式。
 * - fragment：cache-first——本地缓存命中直接合成响应（不回源），未命中走基类。
 *   BYTERANGE 分片（原文件切片）不缓存、直接回源。
 *
 * 关键细节：缓存命中时用预取阶段记录的**真实耗时**（costMs）合成 hls.js 的
 * loader stats——如果让加载时长为 0，ABR 会把它当成无限带宽，错误地拉高码率。
 *
 * hls.js 对每次请求都会 new 一个 loader 实例，因此实例上的 destroyed 标记
 * 生命周期安全（abort/destroy 后不再回调，防孤儿 onSuccess）。
 */
interface LoaderOptions {
  blockAd?: boolean;
  /** 默认保留桌面原有策略；explicit 只过滤明确广告路径分组。 */
  adPolicy?: 'legacy' | 'explicit';
  /** 独立版关闭影片缓存读取，避免过滤广告时顺带打开缓存存储。 */
  cacheSegments?: boolean;
  /** 缓存命中探针（设置面板展示命中率用），可缺省 */
  onProbe?: (hit: boolean) => void;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type HlsLoaderCtor = new (config: any) => any;

export function createHlsLoader(
  HlsCtor: typeof HlsType,
  options: LoaderOptions = {}
): HlsLoaderCtor {
  const { blockAd = false, adPolicy = 'legacy', cacheSegments = true, onProbe } = options;

  return class CacheFirstHlsLoader extends (HlsCtor.DefaultConfig.loader as HlsLoaderCtor) {
    private destroyed = false;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    constructor(config: any) {
      super(config);
      const load = this.load.bind(this);

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      this.load = (context: any, config: any, callbacks: any) => {
        if (this.destroyed) return;
        const isPlaylist = context.type === 'manifest' || context.type === 'level';
        const guardedCallbacks = {
          ...callbacks,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          onSuccess: (response: any, stats: any, ctx: any, networkDetails: any) => {
            if (this.destroyed) return;
            if (isPlaylist && blockAd && typeof response.data === 'string') {
              response.data = adPolicy === 'explicit' ? stripExplicitAdGroups(response.data) : stripAdGroups(response.data);
            }
            callbacks.onSuccess(response, stats, ctx, networkDetails);
          },
        };
        for (const name of ['onError', 'onTimeout', 'onProgress', 'onAbort']) {
          if (typeof callbacks[name] === 'function') {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            guardedCallbacks[name] = (...args: any[]) => {
              if (!this.destroyed) callbacks[name](...args);
            };
          }
        }

        // —— 播放列表：网络加载 + 可选广告过滤 ——
        if (isPlaylist) {
          load(context, config, guardedCallbacks);
          return;
        }

        // 独立版和 BYTERANGE 都直接回源，不打开本地影片 Cache Storage。
        if (!cacheSegments || context.rangeStart != null || context.rangeEnd != null) {
          load(context, config, guardedCallbacks);
          return;
        }

        // —— 片段：cache-first ——
        const key = buildSegmentCacheKey(context.url);
        readCachedSegment(key).then((hit) => {
          if (this.destroyed) return;
          if (hit) {
            void touchMeta(key);
            onProbe?.(true);
            const now = performance.now();
            Object.assign(this.stats, {
              loading: { start: now - hit.costMs, first: now - hit.costMs + 1, end: now },
              total: hit.data.byteLength,
              loaded: hit.data.byteLength,
            });
            guardedCallbacks.onSuccess({ url: context.url, data: hit.data }, this.stats, context, undefined);
            return;
          }
          onProbe?.(false);
          load(context, config, guardedCallbacks);
        });
      };
    }

    abort(): void {
      this.destroyed = true;
      super.abort();
    }

    destroy(): void {
      this.destroyed = true;
      super.destroy?.();
    }
  };
}
