import type HlsType from 'hls.js';
import { stripAdGroups, stripExplicitAdGroups } from './m3u8';
import { buildSegmentCacheKey, readCachedSegment, touchMeta } from './video-cache';
import { createHlsPtsFilterSession, type HlsPtsFilterSession, type HlsPtsFilterResult } from './hls-pts-filter';
import { createHlsSpliceContinuitySession, type HlsSpliceContinuitySession } from './hls-splice-continuity';

/**
 * hls.js loader 工厂：在同一个 loader 里组合「广告过滤」与「片段缓存命中」。
 *
 * - manifest / level：走基类网络加载；blockAd 开启时在 onSuccess 里剔除
 *   广告段（整段移除，仅在严格核对连续后平滑广告接缝，其他断点保留）；
 *   默认以 PTS 连续性识别，不启用时长/片头启发式。
 * - fragment：cache-first——本地缓存命中直接合成响应（不回源），未命中走基类。
 *   BYTERANGE 分片（原文件切片）不缓存、直接回源。
 *
 * 关键细节：缓存命中时用预取阶段记录的**真实耗时**（costMs）合成 hls.js 的
 * loader stats——如果让加载时长为 0，ABR 会把它当成无限带宽，错误地拉高码率。
 *
 * hls.js 对每次请求都会 new 一个 loader 实例，因此实例上的 destroyed 标记
 * 生命周期安全（abort/destroy 后不再回调，防孤儿 onSuccess）。
 */
interface LoaderOptions {
  blockAd?: boolean;
  /** 老调用可显式保留旧策略；所有点播默认使用 PTS，不叠加时长猜测。 */
  adPolicy?: 'pts' | 'legacy' | 'explicit';
  ptsSession?: HlsPtsFilterSession;
  spliceSession?: HlsSpliceContinuitySession;
  onAdScan?: () => void;
  onAdFilterResult?: (result: HlsPtsFilterResult, originalContent: string) => void;
  /** 独立版关闭影片缓存读取，避免过滤广告时顺带打开缓存存储。 */
  cacheSegments?: boolean;
  /** 缓存命中探针（设置面板展示命中率用），可缺省 */
  onProbe?: (hit: boolean) => void;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type HlsLoaderCtor = new (config: any) => any;

export function createHlsLoader(
  HlsCtor: typeof HlsType,
  options: LoaderOptions = {}
): HlsLoaderCtor {
  const { blockAd = false, adPolicy = 'pts', cacheSegments = true, onProbe,
    onAdScan, onAdFilterResult } = options;
  // One bounded in-memory decision per playlist for this player. Never put probe
  // bytes in the whole-fragment cache or feed them to playback telemetry / ABR.
  const ptsSession = options.ptsSession ?? createHlsPtsFilterSession({ concurrency: 16, timeoutMs: 15_000 });
  const spliceSession = options.spliceSession ?? createHlsSpliceContinuitySession();
  // Native and MSE share the same conservative boundary until all rendition
  // timelines can be compared. A partially filtered ABR switch is unsafe.
  let compatibleRenditions = true;

  return class CacheFirstHlsLoader extends (HlsCtor.DefaultConfig.loader as HlsLoaderCtor) {
    private destroyed = false;
    private filterAbort = new AbortController();

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    constructor(config: any) {
      super(config);
      const load = this.load.bind(this);

      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      this.load = (context: any, config: any, callbacks: any) => {
        if (this.destroyed) return;
        const isPlaylist = context.type === 'manifest' || context.type === 'level';
        let delivered = false;
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const deliver = (response: any, stats: any, ctx: any, networkDetails: any) => {
          if (this.destroyed || delivered) return;
          delivered = true;
          callbacks.onSuccess(response, stats, ctx, networkDetails);
        };
        const guardedCallbacks = {
          ...callbacks,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          onSuccess: (response: any, stats: any, ctx: any, networkDetails: any) => {
            if (this.destroyed) return;
            if (isPlaylist && blockAd && typeof response.data === 'string') {
              if (adPolicy === 'pts') {
                const originalContent = response.data as string;
                if ((originalContent.match(/^\s*#EXT-X-STREAM-INF:/gm)?.length ?? 0) > 1
                  || /^\s*#EXT-X-MEDIA:/m.test(originalContent)) compatibleRenditions = false;
                if (!compatibleRenditions) {
                  onAdFilterResult?.({ content: originalContent, status: 'unsupported', reason: 'multiple_renditions',
                    removedGroups: [], removedSeconds: 0, probedGroups: 0, totalGroups: 0, complete: false }, originalContent);
                  deliver(response, stats, ctx, networkDetails);
                  return;
                }
                onAdScan?.();
                let inspectedResponse = response;
                void ptsSession.filter(originalContent, response.url || context.url, this.filterAbort.signal)
                  .then(async (result) => {
                    if (this.destroyed || this.filterAbort.signal.aborted) return;
                    inspectedResponse = { ...response, data: result.content };
                    // This optional stage may only join verified continuous main
                    // media. Its failure must never restore an ad-containing raw
                    // playlist through the outer inspection fallback.
                    let playbackResult = result;
                    if (result.status === 'filtered') {
                      try {
                        playbackResult = await spliceSession.smooth(originalContent, result,
                          response.url || context.url, this.filterAbort.signal);
                      } catch { /* Keep the already filtered playlist. */ }
                    }
                    if (this.destroyed || this.filterAbort.signal.aborted) return;
                    inspectedResponse = { ...response, data: playbackResult.content };
                    onAdFilterResult?.(playbackResult, originalContent);
                    deliver(inspectedResponse, stats, ctx, networkDetails);
                  }).catch(() => {
                    // Inspection failure keeps the origin. Once filtering has
                    // succeeded, subsequent failure must keep that ad decision.
                    if (!this.destroyed && !this.filterAbort.signal.aborted) {
                      deliver(inspectedResponse, stats, ctx, networkDetails);
                    }
                  });
                return;
              }
              response.data = adPolicy === 'explicit' ? stripExplicitAdGroups(response.data) : stripAdGroups(response.data);
            }
            deliver(response, stats, ctx, networkDetails);
          },
        };
        for (const name of ['onError', 'onTimeout', 'onProgress', 'onAbort']) {
          if (typeof callbacks[name] === 'function') {
            // eslint-disable-next-line @typescript-eslint/no-explicit-any
            guardedCallbacks[name] = (...args: any[]) => {
              if (!this.destroyed) callbacks[name](...args);
            };
          }
        }

        // —— 播放列表：网络加载 + 可选广告过滤 ——
        if (isPlaylist) {
          load(context, config, guardedCallbacks);
          return;
        }

        // 独立版和 BYTERANGE 都直接回源，不打开本地影片 Cache Storage。
        if (!cacheSegments || context.rangeStart != null || context.rangeEnd != null) {
          load(context, config, guardedCallbacks);
          return;
        }

        // —— 片段：cache-first ——
        const key = buildSegmentCacheKey(context.url);
        readCachedSegment(key).then((hit) => {
          if (this.destroyed) return;
          if (hit) {
            void touchMeta(key);
            onProbe?.(true);
            const now = performance.now();
            Object.assign(this.stats, {
              loading: { start: now - hit.costMs, first: now - hit.costMs + 1, end: now },
              total: hit.data.byteLength,
              loaded: hit.data.byteLength,
            });
            guardedCallbacks.onSuccess({ url: context.url, data: hit.data }, this.stats, context, undefined);
            return;
          }
          onProbe?.(false);
          load(context, config, guardedCallbacks);
        });
      };
    }

    abort(): void {
      this.destroyed = true;
      this.filterAbort.abort();
      super.abort();
    }

    destroy(): void {
      this.destroyed = true;
      this.filterAbort.abort();
      super.destroy?.();
    }
  };
}
