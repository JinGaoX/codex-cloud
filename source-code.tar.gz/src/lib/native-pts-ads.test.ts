import { afterEach, describe, expect, it, vi } from 'vitest';
import type { HlsPtsFilterResult, HlsPtsFilterSession } from './hls-pts-filter';
import { attachNativePtsAdSkips, prepareNativePtsAds, type NativePtsAdsPlan } from './native-pts-ads';

const sourceUrl = 'https://media.example/film/index.m3u8';
const media = [
  '#EXTM3U', '#EXT-X-TARGETDURATION:100', '#EXTINF:100,', 'main-a.ts',
  '#EXT-X-DISCONTINUITY', '#EXTINF:20,', 'clip.ts',
  '#EXT-X-DISCONTINUITY', '#EXTINF:100,', 'main-b.ts', '#EXT-X-ENDLIST', '',
].join('\n');

function filterResult(overrides: Partial<HlsPtsFilterResult> = {}): HlsPtsFilterResult {
  return {
    status: 'filtered', reason: 'pts_continuity', content: 'rewritten playlist is intentionally unused',
    removedGroups: [{ index: 1, startSegmentIndex: 1, endSegmentIndex: 1,
      startSeconds: 100, durationSeconds: 20, segmentCount: 1 }],
    removedSeconds: 20, probedGroups: 3, totalGroups: 3, complete: true, ...overrides,
  };
}

function session(result = filterResult()) {
  return { filter: vi.fn().mockResolvedValue(result), destroy: vi.fn() } satisfies HlsPtsFilterSession;
}

function readyPlan(overrides: Partial<NativePtsAdsPlan> = {}): NativePtsAdsPlan {
  return { status: 'ready', reason: 'pts_continuity', sourceUrl, durationSeconds: 220,
    ranges: [{ startSeconds: 100, endSeconds: 120 }], ...overrides };
}

afterEach(() => {
  vi.useRealTimers();
  vi.unstubAllGlobals();
});

describe('native HLS PTS preparation keeps the original media source', () => {
  it('uses the shared detector and returns only original-timeline intervals', async () => {
    const detector = session();
    const fetcher = vi.fn().mockResolvedValue(new Response(media));
    const plan = await prepareNativePtsAds(sourceUrl, { session: detector, fetcher });
    expect(plan).toEqual(readyPlan());
    expect(detector.filter).toHaveBeenCalledWith(media, sourceUrl, expect.any(AbortSignal));
    expect(fetcher).toHaveBeenCalledWith(sourceUrl, expect.objectContaining({ cache: 'no-store', mode: 'cors' }));
    expect(detector.destroy).not.toHaveBeenCalled();
  });

  it('resolves a single rendition relative to the final response URL', async () => {
    const detector = session();
    const master = new Response('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\nvideo/list.m3u8\n');
    Object.defineProperty(master, 'url', { value: 'https://cdn.example/redirect/master.m3u8' });
    const fetcher = vi.fn().mockResolvedValueOnce(master).mockResolvedValueOnce(new Response(media));
    const plan = await prepareNativePtsAds(sourceUrl, { session: detector, fetcher });
    expect(plan.sourceUrl).toBe(sourceUrl);
    expect(plan.ranges).toEqual(readyPlan().ranges);
    expect(fetcher.mock.calls[1][0]).toBe('https://cdn.example/redirect/video/list.m3u8');
    expect(detector.filter.mock.calls[0][1]).toBe('https://cdn.example/redirect/video/list.m3u8');
  });

  it.each([
    ['multiple variants', '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\na.m3u8\n#EXT-X-STREAM-INF:BANDWIDTH=2000\nb.m3u8'],
    ['separate audio', '#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,URI="audio.m3u8"\n#EXT-X-STREAM-INF:BANDWIDTH=1000\na.m3u8'],
    ['session encryption', '#EXTM3U\n#EXT-X-SESSION-KEY:METHOD=AES-128,URI="key"\n#EXT-X-STREAM-INF:BANDWIDTH=1000\na.m3u8'],
  ])('preserves %s without guessing which timeline native HLS selected', async (_name, content) => {
    const detector = session();
    const fetcher = vi.fn().mockResolvedValue(new Response(content));
    const plan = await prepareNativePtsAds(sourceUrl, { session: detector, fetcher });
    expect(plan.status).toBe('unavailable');
    expect(plan.ranges).toEqual([]);
    expect(fetcher).toHaveBeenCalledTimes(1);
    expect(detector.filter).not.toHaveBeenCalled();
  });

  it('keeps live or incomplete playlists outside the native seek path', async () => {
    const detector = session();
    const plan = await prepareNativePtsAds(sourceUrl, {
      session: detector, fetcher: vi.fn().mockResolvedValue(new Response(media.replace('#EXT-X-ENDLIST', ''))),
    });
    expect(plan).toMatchObject({ status: 'unchanged', reason: 'live_or_incomplete_playlist', ranges: [] });
    expect(detector.filter).not.toHaveBeenCalled();
  });

  it('does not trust partial probe results for a native seek plan', async () => {
    const detector = session(filterResult({ complete: false, probedGroups: 2 }));
    const plan = await prepareNativePtsAds(sourceUrl, {
      session: detector, fetcher: vi.fn().mockResolvedValue(new Response(media)),
    });
    expect(plan).toMatchObject({ status: 'unavailable', reason: 'probe_incomplete', ranges: [] });
  });

  it('makes no fetch after an already cancelled load', async () => {
    const controller = new AbortController();
    controller.abort();
    const fetcher = vi.fn();
    const detector = session();
    const plan = await prepareNativePtsAds(sourceUrl, { session: detector, fetcher, signal: controller.signal });
    expect(plan.status).toBe('unavailable');
    expect(fetcher).not.toHaveBeenCalled();
    expect(detector.filter).not.toHaveBeenCalled();
  });

  it('bounds a fetch adapter which ignores AbortSignal', async () => {
    vi.useFakeTimers();
    const fetcher = vi.fn().mockImplementation(() => new Promise(() => {}));
    const promise = prepareNativePtsAds(sourceUrl, { session: session(), fetcher });
    await vi.advanceTimersByTimeAsync(8001);
    expect(await promise).toMatchObject({ status: 'unavailable', ranges: [] });
  });

  it('cancels an oversized streaming playlist instead of reading the entire body', async () => {
    const cancel = vi.fn();
    const body = new ReadableStream<Uint8Array>({
      start(controller) { controller.enqueue(new Uint8Array(2 * 1024 * 1024 + 1)); },
      cancel,
    });
    const detector = session();
    const plan = await prepareNativePtsAds(sourceUrl, {
      session: detector, fetcher: vi.fn().mockResolvedValue(new Response(body)),
    });
    expect(plan).toMatchObject({ status: 'unavailable', ranges: [] });
    expect(cancel).toHaveBeenCalled();
    expect(detector.filter).not.toHaveBeenCalled();
  });

  it('rejects cyclic and unsafe nested playlists', async () => {
    const detector = session();
    const cyclic = '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\nindex.m3u8\n';
    const fetcher = vi.fn().mockResolvedValue(new Response(cyclic));
    expect(await prepareNativePtsAds(sourceUrl, { session: detector, fetcher })).toMatchObject({ reason: 'playlist_cycle', ranges: [] });
    expect(fetcher).toHaveBeenCalledTimes(1);
    const unsafe = '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\nhttp://cdn.example/media.m3u8\n';
    expect(await prepareNativePtsAds(sourceUrl, { session: detector,
      fetcher: vi.fn().mockResolvedValue(new Response(unsafe)) })).toMatchObject({ reason: 'unsupported_url', ranges: [] });
  });
});

class FakeVideo extends EventTarget {
  currentSrc = sourceUrl;
  duration = 220;
  readyState = 1;
  paused = true;
  position = 0;
  throwOnSeek = false;
  ignoreSeek = false;
  seeks: number[] = [];
  play = vi.fn();
  pause = vi.fn();
  get currentTime() { return this.position; }
  set currentTime(value: number) {
    this.seeks.push(value);
    if (this.throwOnSeek) throw new Error('native seek rejected');
    if (!this.ignoreSeek) this.position = value;
  }
  fire(event: string) { this.dispatchEvent(new Event(event)); }
}

function nativeGuard(plan = readyPlan()) {
  const video = new FakeVideo();
  const onSkip = vi.fn();
  let current = true;
  let enabled = true;
  const dispose = attachNativePtsAdSkips(video as unknown as HTMLVideoElement, {
    plan, isCurrent: () => current, isEnabled: () => enabled, onSkip,
  });
  return { video, onSkip, dispose, supersede: () => { current = false; }, disable: () => { enabled = false; } };
}

describe('native HLS seek guard', () => {
  it('skips only inside a detected interval and preserves paused/timer state and media URL', () => {
    const { video, onSkip } = nativeGuard();
    video.position = 99.9;
    video.fire('timeupdate');
    expect(video.seeks).toEqual([]);
    video.position = 100;
    video.fire('timeupdate');
    video.fire('seeking');
    video.fire('seeked');
    expect(video.seeks).toEqual([120]);
    expect(onSkip).toHaveBeenCalledTimes(1);
    expect(video.currentSrc).toBe(sourceUrl);
    expect(video.play).not.toHaveBeenCalled();
    expect(video.pause).not.toHaveBeenCalled();
    expect(video.paused).toBe(true);
  });

  it('checks a restored position and leaves an exact end boundary unchanged', () => {
    const { video } = nativeGuard();
    video.position = 110;
    video.fire('seeked');
    expect(video.currentTime).toBe(120);
    video.fire('timeupdate');
    expect(video.seeks).toEqual([120]);
  });

  it('does not apply the playlist timeline to a differently mapped native duration', () => {
    const { video } = nativeGuard();
    video.duration = 200;
    video.position = 110;
    video.fire('timeupdate');
    expect(video.seeks).toEqual([]);
    video.duration = 220;
    video.fire('durationchange');
    expect(video.seeks).toEqual([120]);
  });

  it('does nothing for stale resources, disabled filtering, or after disposal', () => {
    for (const mode of ['source', 'identity', 'disabled', 'dispose']) {
      const g = nativeGuard();
      if (mode === 'source') g.video.currentSrc = 'https://media.example/another.m3u8';
      if (mode === 'identity') g.supersede();
      if (mode === 'disabled') g.disable();
      if (mode === 'dispose') g.dispose();
      g.video.position = 110;
      g.video.fire('timeupdate');
      expect(g.video.seeks).toEqual([]);
      expect(g.onSkip).not.toHaveBeenCalled();
    }
  });

  it('does not loop when a device rejects or ignores a seek', () => {
    for (const failure of ['reject', 'ignore']) {
      const { video, onSkip } = nativeGuard();
      video.position = 110;
      video.throwOnSeek = failure === 'reject';
      video.ignoreSeek = failure === 'ignore';
      for (let i = 0; i < 4; i++) video.fire('timeupdate');
      expect(video.seeks).toEqual([120]);
      expect(onSkip).toHaveBeenCalledTimes(failure === 'reject' ? 0 : 1);
    }
  });

  it('waits while hidden and rechecks when the page becomes visible', () => {
    const page = Object.assign(new EventTarget(), { visibilityState: 'hidden' });
    vi.stubGlobal('document', page);
    const { video, dispose } = nativeGuard();
    video.position = 110;
    video.fire('timeupdate');
    expect(video.seeks).toEqual([]);
    page.visibilityState = 'visible';
    page.dispatchEvent(new Event('visibilitychange'));
    expect(video.seeks).toEqual([120]);
    dispose();
    video.position = 110;
    page.dispatchEvent(new Event('visibilitychange'));
    expect(video.seeks).toEqual([120]);
  });

  it.each([
    [{ startSeconds: -1, endSeconds: 10 }],
    [{ startSeconds: 0, endSeconds: 10 }],
    [{ startSeconds: 100, endSeconds: 170 }],
    [{ startSeconds: 100, endSeconds: 230 }],
    [{ startSeconds: 100, endSeconds: 120 }, { startSeconds: 110, endSeconds: 130 }],
    [{ startSeconds: 100, endSeconds: NaN }],
  ])('rejects an invalid or ambiguous interval plan: %j', (...ranges) => {
    const { video } = nativeGuard(readyPlan({ ranges }));
    video.position = 110;
    video.fire('timeupdate');
    expect(video.seeks).toEqual([]);
  });
});
