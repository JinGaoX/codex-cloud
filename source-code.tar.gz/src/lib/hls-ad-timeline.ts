/** Keep saved progress and user skip marks on the original source timeline,
 * including when native HLS skips ads while MSE removes them from its playlist. */
export interface HlsAdRange { startSeconds: number; durationSeconds: number }
export interface HlsAdTimeline {
  ranges: HlsAdRange[];
  originalDuration: number;
  filteredDuration: number;
}

export function createHlsAdTimeline(content: string, ranges: HlsAdRange[]): HlsAdTimeline | null {
  const originalDuration = [...content.matchAll(/^\s*#EXTINF:([\d.]+)\s*,/gm)]
    .reduce((sum, match) => sum + Number(match[1]), 0);
  if (!Number.isFinite(originalDuration) || originalDuration <= 0 || !ranges.length) return null;
  const sorted = ranges.map((r) => ({ startSeconds: r.startSeconds, durationSeconds: r.durationSeconds }))
    .sort((a, b) => a.startSeconds - b.startSeconds);
  let end = 0;
  for (const r of sorted) {
    if (!Number.isFinite(r.startSeconds) || !Number.isFinite(r.durationSeconds)
      || r.startSeconds < end || r.durationSeconds <= 0
      || r.startSeconds + r.durationSeconds > originalDuration + 0.001) return null;
    end = r.startSeconds + r.durationSeconds;
  }
  const filteredDuration = originalDuration - sorted.reduce((sum, r) => sum + r.durationSeconds, 0);
  return filteredDuration > 0 ? { ranges: sorted, originalDuration, filteredDuration } : null;
}

export function sourceToFilteredTime(time: number, timeline: HlsAdTimeline | null): number {
  if (!timeline || !Number.isFinite(time)) return time;
  let removed = 0;
  for (const r of timeline.ranges) {
    if (time < r.startSeconds) break;
    if (time < r.startSeconds + r.durationSeconds) return Math.max(0, r.startSeconds - removed);
    removed += r.durationSeconds;
  }
  return Math.max(0, time - removed);
}

export function filteredToSourceTime(time: number, timeline: HlsAdTimeline | null): number {
  if (!timeline || !Number.isFinite(time)) return time;
  let removed = 0;
  for (const r of timeline.ranges) {
    if (time < r.startSeconds - removed - 0.000001) break;
    removed += r.durationSeconds;
  }
  return time + removed;
}
