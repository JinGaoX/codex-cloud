import { afterEach, describe, expect, it, vi } from 'vitest';
import type { SaveTarget } from './download-saver';
import { validateFragmentTiming } from './mp4-transmuxer';
import { downloadWebVideo, inspectWebVideoDownload } from './web-video-download';

const base = 'https://video.invalid/';
const master = '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=8000000,RESOLUTION=1920x1080\nlow.m3u8\n'
  + '#EXT-X-STREAM-INF:BANDWIDTH=4000000,RESOLUTION=3840x2160\nhigh.m3u8\n'
  + '#EXT-X-STREAM-INF:BANDWIDTH=1000000,RESOLUTION=1280x720\nhttp://blocked.invalid/low.m3u8\n'
  + '#EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1280x720\nlow.m3u8\n';
const media = (first = 'first.ts', second = 'second.ts') => `#EXTM3U\n#EXTINF:2,\n${first}\n#EXTINF:2,\n${second}\n#EXT-X-ENDLIST\n`;
const signal = () => new AbortController().signal;

function target(kind: SaveTarget['kind'] = 'fs') {
  return {
    kind, write: vi.fn<(bytes: Uint8Array) => Promise<void>>(async () => {}),
    close: vi.fn(async () => {}), abort: vi.fn(async () => {}),
  };
}

afterEach(() => vi.unstubAllGlobals());

describe('PPS 网页视频下载', () => {
  it('默认以实际标明的最高分辨率排序，同地址保留最高标记，失败时不会静默请求低档', async () => {
    const fetcher = vi.fn(async (url: string) => url.endsWith('master.m3u8')
      ? new Response(master) : new Response(null, { status: 403 }));
    vi.stubGlobal('fetch', fetcher);
    const { kind, variants } = await inspectWebVideoDownload(base + 'master.m3u8', signal());
    expect(variants.map((variant) => variant.height)).toEqual([2160, 1080, 720]);
    expect(variants[2].unsupported).toContain('HTTPS');
    const output = target();
    await expect(downloadWebVideo({ kind, variant: variants[0], title: 'test', signal: signal(), target: output })).rejects.toThrow('403');
    expect(fetcher.mock.calls.map(([url]) => url)).toEqual([base + 'master.m3u8', base + 'high.m3u8']);
    expect(output.abort).toHaveBeenCalledOnce();
    expect(output.close).not.toHaveBeenCalled();
  });

  it('保留确认为更高清但有独立音轨的档位，让用户明确选其他档', async () => {
    const text = master.replace('#EXTM3U', '#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="separate",URI="audio.m3u8"')
      .replace('RESOLUTION=3840x2160', 'RESOLUTION=3840x2160,AUDIO="separate"');
    const fetcher = vi.fn(async () => new Response(text));
    vi.stubGlobal('fetch', fetcher);
    const { kind, variants } = await inspectWebVideoDownload(base + 'master.m3u8', signal());
    expect(variants[0]).toMatchObject({ height: 2160, unsupported: expect.stringContaining('独立音轨') });
    await expect(downloadWebVideo({ kind, variant: variants[0], title: 'test', signal: signal(), target: target() })).rejects.toThrow('独立音轨');
    expect(fetcher).toHaveBeenCalledOnce();
  });

  it.each([
    [media().replace('#EXT-X-ENDLIST', ''), '尚未结束'],
    [media().replace('#EXTINF:2,\nsecond', '#EXT-X-DISCONTINUITY\n#EXTINF:2,\nsecond'), '时间轴'],
    [media('http://blocked.invalid/first.ts'), 'HTTPS'],
  ])('拒绝不完整和无法安全转封装的 HLS %s', async (playlist, message) => {
    const fetcher = vi.fn(async () => new Response(playlist));
    vi.stubGlobal('fetch', fetcher);
    const output = target();
    await expect(downloadWebVideo({ kind: 'hls', variant: { url: base + 'media.m3u8' }, title: 'test',
      signal: signal(), target: output })).rejects.toThrow(message);
    expect(fetcher).toHaveBeenCalledOnce();
    expect(output.write).not.toHaveBeenCalled();
    expect(output.abort).toHaveBeenCalledOnce();
  });

  it('只返回分片局部内容时不会保存', async () => {
    vi.stubGlobal('fetch', vi.fn(async (url: string) => url.endsWith('.m3u8')
      ? new Response(media()) : new Response(new Uint8Array([0x47]), { status: 206 })));
    const output = target();
    await expect(downloadWebVideo({ kind: 'hls', variant: { url: base + 'media.m3u8' }, title: 'test',
      signal: signal(), target: output })).rejects.toThrow('206');
    expect(output.abort).toHaveBeenCalledOnce();
    expect(output.close).not.toHaveBeenCalled();
  });

  it('超出浏览器内存限制时不开始 MP4 传输，文件保存模式仍可接收', async () => {
    const data = new Uint8Array([0, 0, 0, 16, 102, 116, 121, 112, 109, 112, 52, 50, 0, 0, 0, 0]);
    const fetcher = vi.fn(async () => new Response(data, { headers: { 'Content-Length': String(data.length) } }));
    vi.stubGlobal('fetch', fetcher);
    const variant = { url: base + 'test.mp4', estimatedBytes: 200 * 1024 * 1024 };
    const memory = target('memory');
    await expect(downloadWebVideo({ kind: 'mp4', variant, title: 'test', signal: signal(), target: memory })).rejects.toThrow('大小');
    expect(fetcher).not.toHaveBeenCalled();
    const output = target();
    await expect(downloadWebVideo({ kind: 'mp4', variant, title: 'test', signal: signal(), target: output })).resolves.toBe('saved');
    expect(output.write.mock.calls.flatMap(([bytes]) => [...bytes])).toEqual([...data]);
    expect(output.close).toHaveBeenCalledOnce();
  });

  it('下载取消时中止目标，禁止返回保存成功', async () => {
    const controller = new AbortController();
    const abort = new DOMException('cancelled', 'AbortError');
    const output = target();
    const data = new Uint8Array([0, 0, 0, 8, 102, 116, 121, 112]);
    vi.stubGlobal('fetch', vi.fn(async () => new Response(data)));
    output.write.mockImplementationOnce(async () => controller.abort(abort));
    await expect(downloadWebVideo({ kind: 'mp4', variant: { url: base + 'test.mp4' }, title: 'test',
      signal: controller.signal, target: output })).rejects.toBe(abort);
    expect(output.close).not.toHaveBeenCalled();
    expect(output.abort).toHaveBeenCalledOnce();
  });

  it('验证每条输出轨道的时间戳，包括拒绝重复时间和缺失轨道信息', () => {
    const box = (name: string, ...children: number[][]): number[] => {
      const flat = children.flat();
      return [0, 0, 0, flat.length + 8, ...Array.from(name, (letter) => letter.charCodeAt(0)), ...flat];
    };
    const fragment = (time: number) => Uint8Array.from(box('moof', box('traf',
      box('tfhd', [0, 0, 0, 0, 0, 0, 0, 1]), box('tfdt', [0, 0, 0, 0, 0, 0, 0, time]))));
    const trackTimes = new Map<number, number>();
    expect(validateFragmentTiming(fragment(7), trackTimes)).toBe(true);
    expect(validateFragmentTiming(fragment(8), trackTimes)).toBe(true);
    expect(validateFragmentTiming(fragment(8), trackTimes)).toBe(false);
    expect(validateFragmentTiming(Uint8Array.from(box('moof', box('traf', []))), trackTimes)).toBe(false);
  });
});
