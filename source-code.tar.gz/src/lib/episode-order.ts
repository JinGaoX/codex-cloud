/** A device preference, separate from accounts, playback records, and source settings. */
export const EPISODE_ORDER_STORAGE_KEY = 'pps-watch-episode-order-v1';

type OrderStorage = Pick<Storage, 'getItem' | 'setItem'>;
type OrderUpdate = boolean | ((reversed: boolean) => boolean);
type StorageListener = (key: string | null, value: string | null) => void;

function browserStorage(): OrderStorage | undefined {
  return typeof window === 'undefined' ? undefined : window.localStorage;
}

function listenToBrowserStorage(listener: StorageListener): () => void {
  if (typeof window === 'undefined') return () => {};
  const onStorage = (event: StorageEvent) => {
    // Ignore sessionStorage events even if another feature uses the same key.
    try { if (event.storageArea && event.storageArea !== window.localStorage) return; } catch { return; }
    listener(event.key, event.newValue);
  };
  window.addEventListener('storage', onStorage);
  return () => window.removeEventListener('storage', onStorage);
}

/** The small store also keeps sorting usable when a browser denies storage. */
export function createEpisodeOrderStore(
  getStorage: () => OrderStorage | undefined = browserStorage,
  listenToStorage: (listener: StorageListener) => () => void = listenToBrowserStorage,
) {
  let reversed = false;
  let initialized = false;
  let memoryOnly = false;
  let stopListening: (() => void) | undefined;
  const listeners = new Set<() => void>();

  const update = (value: boolean) => {
    if (value === reversed) return;
    reversed = value;
    listeners.forEach((listener) => listener());
  };
  const restore = () => {
    initialized = true;
    // A failed save must not let a stale persisted value erase this session's choice.
    if (memoryOnly) return;
    try {
      const storage = getStorage();
      if (storage) update(storage.getItem(EPISODE_ORDER_STORAGE_KEY) === 'descending');
    } catch { /* Keep the current in-memory order when storage is unavailable. */ }
  };

  return {
    getSnapshot: () => reversed,
    // SSR and the first hydration render always agree, without reading browser state.
    getServerSnapshot: () => false,
    subscribe(listener: () => void) {
      if (listeners.size === 0) {
        restore();
        stopListening = listenToStorage((key, value) => {
          if (key !== EPISODE_ORDER_STORAGE_KEY && key !== null) return;
          memoryOnly = false;
          update(value === 'descending');
        });
      }
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
        if (listeners.size === 0) { stopListening?.(); stopListening = undefined; }
      };
    },
    setReversed(value: OrderUpdate) {
      if (!initialized) restore();
      const next = typeof value === 'function' ? value(reversed) : value;
      try {
        const storage = getStorage();
        if (storage) storage.setItem(EPISODE_ORDER_STORAGE_KEY, next ? 'descending' : 'ascending');
        memoryOnly = !storage;
      } catch { memoryOnly = true; }
      update(next);
    },
  };
}
