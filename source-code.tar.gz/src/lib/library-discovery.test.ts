import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  DEFAULT_LIBRARY_FILTERS, LIBRARY_MAX_PAGES, LIBRARY_PAGE_SIZE, cleanLibraryFilters,
  fetchLibraryPage, fetchTop250Page, libraryDiscoveryUrl, libraryRequestKey,
  nextLibraryPage, normalizeLibraryItems, parseTop250Html,
} from './library-discovery';

afterEach(() => vi.unstubAllGlobals());
const film = (id: number, extra: Record<string, unknown> = {}) => ({ id: String(id), title: `影片${id}`, rate: '8.5', cover: 'https://img9.doubanio.com/a.jpg', ...extra });
const rows = (offset = 0) => Array.from({ length: LIBRARY_PAGE_SIZE }, (_, i) => film(offset + i + 1));
const htmlPage = (start = 0) => `<ol>${Array.from({ length: 25 }, (_, index) => {
  const rank = start + index + 1;
  return `<li><div class="item"><div class="pic"><em>${rank}</em><a href="https://movie.douban.com/subject/${rank}/"><img alt="封面" src="https://img3.doubanio.com/p${rank}.jpg"></a></div><div class="info"><div class="hd"><span class="title">片名 &amp; ${rank}</span></div><div class="bd"><p>导演: 某人<br>1994&nbsp;/&nbsp;美国&nbsp;/&nbsp;犯罪 剧情</p><span class="rating_num" property="v:average">9.2</span><span>123456人评价</span></div></div></div></li>`;
}).join('')}</ol>`;

describe('dynamic library query contract', () => {
  it('rebuilds an allowlisted filter set and never carries private or arbitrary fields', () => {
    expect(cleanLibraryFilters({ type: 'tv', sort: 'S', genre: '悬疑', country: '韩国', year: '2010s', minRating: 8, url: 'https://attacker.example', token: 'private' }))
      .toEqual({ type: 'tv', sort: 'S', genre: '悬疑', country: '韩国', year: '2010s', minRating: 8 });
    expect(cleanLibraryFilters({ type: 'bad', sort: 'script', genre: 'not-allowed', country: 'arbitrary', year: 'javascript:', minRating: '8' })).toEqual(DEFAULT_LIBRARY_FILTERS);
    expect(cleanLibraryFilters(null)).toEqual(DEFAULT_LIBRARY_FILTERS);
  });

  it('applies compound filters to the source query rather than filtering the currently loaded page', () => {
    const query = new URL(libraryDiscoveryUrl({ ...DEFAULT_LIBRARY_FILTERS, sort: 'S', genre: '悬疑', country: '韩国', year: '2010s', minRating: 8 }, 20));
    expect(query.origin).toBe('https://movie.douban.cmliussss.net');
    expect(Object.fromEntries(query.searchParams)).toEqual({ sort: 'S', range: '8,10', tags: '电影', start: '20', genres: '悬疑', countries: '韩国', year_range: '2010,2019' });
  });

  it('uses the correct public tags and safe year intervals', () => {
    expect(new URL(libraryDiscoveryUrl({ ...DEFAULT_LIBRARY_FILTERS, type: 'animation' })).searchParams.get('tags')).toBe('动画');
    expect(new URL(libraryDiscoveryUrl({ ...DEFAULT_LIBRARY_FILTERS, type: 'tv' })).searchParams.get('tags')).toBe('电视剧');
    expect(new URL(libraryDiscoveryUrl({ ...DEFAULT_LIBRARY_FILTERS, year: 'older' })).searchParams.get('year_range')).toBe('1888,1989');
    const year = String(new Date().getFullYear());
    expect(new URL(libraryDiscoveryUrl({ ...DEFAULT_LIBRARY_FILTERS, year })).searchParams.get('year_range')).toBe(`${year},${year}`);
  });

  it('allows genuine deep pagination without accepting unbounded or malformed offsets', () => {
    expect(new URL(libraryDiscoveryUrl(DEFAULT_LIBRARY_FILTERS, 4980)).searchParams.get('start')).toBe('4980');
    for (const start of [-20, 1, 5000, 1.5, NaN, Infinity]) expect(() => libraryDiscoveryUrl(DEFAULT_LIBRARY_FILTERS, start)).toThrow('页码');
    expect(LIBRARY_MAX_PAGES * LIBRARY_PAGE_SIZE).toBe(5000);
  });

  it('keys queries by the exact public filter set, including rating, not property order', () => {
    const a = cleanLibraryFilters({ minRating: 8, type: 'movie', sort: 'S' });
    const b = { ...DEFAULT_LIBRARY_FILTERS, sort: 'S' as const, minRating: 8 };
    expect(libraryRequestKey(a)).toBe(libraryRequestKey(b));
    expect(libraryRequestKey(a)).not.toBe(libraryRequestKey(DEFAULT_LIBRARY_FILTERS));
    expect(libraryRequestKey(a)).not.toContain('token');
  });

  it('keeps actual actor/director data without inventing year, country, votes or genre', () => {
    const result = normalizeLibraryItems([film(1, { casts: ['河正宇', '', 22], directors: ['金秉祐'], year: '2030', votes: 999, regions: ['韩国'] })], 'movie')[0];
    expect(result.casts).toEqual(['河正宇']);
    expect(result.directors).toEqual(['金秉祐']);
    expect(result.genres).toEqual([]);
    expect(result).not.toHaveProperty('year');
    expect(result).not.toHaveProperty('regions');
    expect(result).not.toHaveProperty('votes');
  });

  it('rejects malformed or unexpectedly oversized response pages and deduplicates by actual ID', () => {
    expect(() => normalizeLibraryItems({}, 'movie')).toThrow('格式');
    expect(() => normalizeLibraryItems([...rows(), film(21)], 'movie')).toThrow('格式');
    expect(normalizeLibraryItems([film(1), film(1)], 'movie')).toHaveLength(1);
    expect(normalizeLibraryItems([film(1, { rate: '', cover: 'javascript:alert(1)' })], 'tv')[0]).toMatchObject({ isTv: true, cover: '' });
  });
});

describe('public library transport and end detection', () => {
  it('requests only public metadata and marks a full page as pageable', async () => {
    const fetcher = vi.fn().mockResolvedValue(new Response(JSON.stringify({ data: rows() })));
    vi.stubGlobal('fetch', fetcher);
    const page = await fetchLibraryPage(DEFAULT_LIBRARY_FILTERS, 1000);
    expect(page.start).toBe(1000);
    expect(page.nextPageStart).toBe(1020);
    expect(fetcher.mock.calls[0][1]).toMatchObject({ method: 'GET', mode: 'cors', credentials: 'omit', referrerPolicy: 'no-referrer' });
    expect(fetcher.mock.calls[0][1].headers).toEqual({ Accept: 'application/json' });
  });

  it('ends on a short page, empty page, safety cap or entirely repeated page', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({ data: rows().slice(0, 3) }))));
    expect((await fetchLibraryPage(DEFAULT_LIBRARY_FILTERS)).nextPageStart).toBeUndefined();
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({ data: [] }))));
    expect((await fetchLibraryPage(DEFAULT_LIBRARY_FILTERS)).items).toEqual([]);
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({ data: rows() }))));
    const last = await fetchLibraryPage(DEFAULT_LIBRARY_FILTERS, 4980);
    expect(last.nextPageStart).toBeUndefined();
    const first = { ...last, start: 0, nextPageStart: 20 };
    expect(nextLibraryPage([first, { ...first, start: 20, nextPageStart: 40 }])).toBeUndefined();
    expect(nextLibraryPage([first, { ...first, items: normalizeLibraryItems(rows(20), 'movie'), start: 20, nextPageStart: 40 }])).toBe(40);
  });

  it('uses only the existing alternate metadata mirror on transport failure', async () => {
    const fetcher = vi.fn().mockRejectedValueOnce(new Error('network')).mockResolvedValueOnce(new Response(JSON.stringify({ data: rows() })));
    vi.stubGlobal('fetch', fetcher);
    await fetchLibraryPage(DEFAULT_LIBRARY_FILTERS);
    expect(new URL(fetcher.mock.calls[1][0]).origin).toBe('https://movie.douban.cmliussss.com');
  });

  it('does not retry a cancelled request or silently return a login/error JSON as an empty library', async () => {
    const controller = new AbortController();
    controller.abort();
    const fetcher = vi.fn();
    vi.stubGlobal('fetch', fetcher);
    await expect(fetchLibraryPage(DEFAULT_LIBRARY_FILTERS, 0, controller.signal)).rejects.toThrow();
    expect(fetcher).not.toHaveBeenCalled();
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(new Response(JSON.stringify({ error: 'login required' }))));
    await expect(fetchLibraryPage(DEFAULT_LIBRARY_FILTERS)).rejects.toThrow('暂时没有');
  });
});

describe('live Top250 HTML extraction', () => {
  it('extracts actual title, ranking, year, votes and genres without rendering remote HTML', () => {
    const result = parseTop250Html(htmlPage());
    expect(result).toHaveLength(25);
    expect(result[0]).toMatchObject({ title: '片名 & 1', rank: 1, year: '1994', votes: 123456, genres: ['犯罪', '剧情'], regions: ['美国'], rating: '9.2' });
    expect(result[24].rank).toBe(25);
    expect(parseTop250Html(htmlPage(25), 25)[0].rank).toBe(26);
  });

  it('fails closed for challenge pages, wrong page rank, duplicate IDs, missing rows and huge bodies', () => {
    expect(() => parseTop250Html('<title>登录</title>')).toThrow('无法识别');
    expect(() => parseTop250Html(htmlPage(25), 0)).toThrow('校验');
    expect(() => parseTop250Html(htmlPage().replace('/subject/2/', '/subject/1/'))).toThrow('校验');
    expect(() => parseTop250Html('a'.repeat(256 * 1024 + 1))).toThrow('过大');
    expect(() => parseTop250Html(htmlPage(), 1)).toThrow('页码');
  });

  it('treats entity-encoded markup as plain text and rejects unsafe covers', () => {
    const html = htmlPage().replace('片名 &amp; 1', '&#x7535;&#24433; &lt;img&gt;').replace('https://img3.doubanio.com/p1.jpg', 'javascript:alert(1)');
    expect(parseTop250Html(html)[0]).toMatchObject({ title: '电影 <img>', cover: '' });
  });

  it('fetches one public page at a time and stops after the actual Top250 boundary', async () => {
    const fetcher = vi.fn().mockResolvedValueOnce(new Response(htmlPage(25))).mockResolvedValueOnce(new Response(htmlPage(225)));
    vi.stubGlobal('fetch', fetcher);
    const first = await fetchTop250Page(25);
    expect(first.start).toBe(25);
    expect(first.nextPageStart).toBe(50);
    expect(fetcher.mock.calls[0][1]).toMatchObject({ mode: 'cors', credentials: 'omit', referrerPolicy: 'no-referrer' });
    expect((await fetchTop250Page(225)).nextPageStart).toBeUndefined();
    await expect(fetchTop250Page(250)).rejects.toThrow('页码');
  });
});
