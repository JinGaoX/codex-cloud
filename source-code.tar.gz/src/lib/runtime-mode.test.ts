import { afterEach, describe, expect, it, vi } from 'vitest';
import nativeConfig from '../../capacitor.config';

afterEach(() => { vi.unstubAllEnvs(); vi.resetModules(); });

describe('local application build boundaries', () => {
  it.each([
    ['android', true, true, false, true, true],
    ['native', false, true, false, true, false],
    ['harmony', false, false, true, true, false],
    ['standalone', false, false, false, true, true],
    ['', false, false, false, false, true],
  ])('selects %s capabilities without enabling server APIs in local builds', async (mode, android, native, harmony, standalone, live) => {
    vi.stubEnv('NEXT_PUBLIC_APP_MODE', mode);
    vi.resetModules();
    const flags = await import('./runtime-mode');
    expect(flags.IS_ANDROID_NATIVE).toBe(android);
    expect(flags.IS_NATIVE).toBe(native);
    expect(flags.IS_HARMONY).toBe(harmony);
    expect(flags.IS_STANDALONE).toBe(standalone);
    expect(flags.SUPPORTS_LIVE_TV).toBe(live);
  });

  it('ships application files with a stable local identity and no remote server or navigation allowlist', () => {
    expect(nativeConfig.webDir).toBe('native-dist');
    expect(nativeConfig.appId).toBe('org.libretv.personal');
    expect(nativeConfig.server?.hostname).toBe('localhost');
    expect(nativeConfig.server?.iosScheme).toBe('capacitor');
    expect(nativeConfig.server?.url).toBeUndefined();
    expect(nativeConfig.server?.allowNavigation).toBeUndefined();
    expect(nativeConfig.server?.cleartext).not.toBe(true);
    expect(nativeConfig.plugins?.CapacitorHttp?.enabled).toBe(false);
  });
});
