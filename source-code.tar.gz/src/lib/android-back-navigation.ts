export interface AndroidBackSurface {
  id: string;
  /** Ancestor stacking contexts, outermost first; DOM order breaks equal ties. */
  stackingPath: readonly number[];
  order: number;
}

export interface AndroidBackState {
  documentFullscreen: boolean;
  webFullscreen: boolean;
  surfaces: readonly AndroidBackSurface[];
  canGoBack: boolean;
  canReturnHome: boolean;
}

export type AndroidBackAction =
  | { type: 'exit-document-fullscreen' }
  | { type: 'exit-web-fullscreen' }
  | { type: 'dismiss-surface'; id: string }
  | { type: 'history-back' }
  | { type: 'navigate-home' }
  | { type: 'minimize' };

/** Use the actual current entry, not history.length (which includes forward entries). */
export function hasAndroidBackHistory(nativeCanGoBack: boolean, historyIndex: number): boolean {
  return nativeCanGoBack || (Number.isSafeInteger(historyIndex) && historyIndex > 0);
}

function compareSurfaces(left: AndroidBackSurface, right: AndroidBackSurface): number {
  const depth = Math.max(left.stackingPath.length, right.stackingPath.length);
  for (let index = 0; index < depth; index++) {
    const difference = (left.stackingPath[index] ?? 0) - (right.stackingPath[index] ?? 0);
    if (difference) return difference;
  }
  return left.order - right.order;
}

/** One back press consumes one visible layer; it never confirms a destructive dialog. */
export function chooseAndroidBackAction(state: AndroidBackState): AndroidBackAction {
  if (state.documentFullscreen) return { type: 'exit-document-fullscreen' };
  if (state.webFullscreen) return { type: 'exit-web-fullscreen' };
  const top = state.surfaces.reduce<AndroidBackSurface | undefined>((current, surface) => (
    !current || compareSurfaces(surface, current) > 0 ? surface : current
  ), undefined);
  if (top) return { type: 'dismiss-surface', id: top.id };
  if (state.canGoBack) return { type: 'history-back' };
  return { type: state.canReturnHome ? 'navigate-home' : 'minimize' };
}

export interface AndroidBackPorts {
  readState: (canGoBack: boolean) => AndroidBackState;
  exitDocumentFullscreen: () => void | Promise<void>;
  exitWebFullscreen: () => void | Promise<void>;
  dismissSurface: (id: string) => void | Promise<void>;
  historyBack: () => void | Promise<void>;
  navigateHome: () => void | Promise<void>;
  minimize: () => void | Promise<void>;
}

/** Avoid duplicate native callbacks and closing the next layer during a 200ms exit animation. */
export function createAndroidBackDispatcher(ports: AndroidBackPorts, clock = Date.now) {
  let busy = false;
  let disposed = false;
  let lastBack = -Infinity;
  return {
    dispose() { disposed = true; },
    async handle(canGoBack: boolean): Promise<AndroidBackAction | undefined> {
      const now = clock();
      if (disposed || busy || now - lastBack < 250) return undefined;
      busy = true;
      lastBack = now;
      try {
        const action = chooseAndroidBackAction(ports.readState(canGoBack));
        switch (action.type) {
          case 'exit-document-fullscreen': await ports.exitDocumentFullscreen(); break;
          case 'exit-web-fullscreen': await ports.exitWebFullscreen(); break;
          case 'dismiss-surface': await ports.dismissSurface(action.id); break;
          case 'history-back': await ports.historyBack(); break;
          case 'navigate-home': await ports.navigateHome(); break;
          case 'minimize': await ports.minimize(); break;
        }
        return action;
      } catch {
        // A failed close or fullscreen exit must not fall through and navigate
        // away from the still-visible dialog or terminate current playback.
        return undefined;
      } finally {
        busy = false;
      }
    },
  };
}
