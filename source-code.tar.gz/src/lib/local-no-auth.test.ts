import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { GET as getAuth, POST as postAuth } from '@/app/api/auth/route';
import { GET as getStatus } from '@/app/api/status/route';
import { guardRequest } from './api-guard';
import { SESSION_COOKIE, clearRateLimit, isLocalNoAuthEnabled, signSession } from './auth';

const TEST_PASSWORD = 'local-mode-regression-password';
const TEST_IP = '192.0.2.75';

function request(path = '/api/search', cookie?: string): Request {
  return new Request(`http://localhost:8080${path}`, {
    headers: cookie ? { cookie } : undefined,
  });
}

beforeEach(() => {
  vi.stubEnv('LOCAL_NO_AUTH', undefined);
  vi.stubEnv('PASSWORD', TEST_PASSWORD);
  vi.stubEnv('PROXY_SECRET', undefined);
  clearRateLimit(TEST_IP);
});

afterEach(() => {
  clearRateLimit(TEST_IP);
  vi.unstubAllEnvs();
});

describe('local password bypass requires explicit opt-in', () => {
  it.each([undefined, '', 'false', 'TRUE', '1'])('does not enable for %s', (value) => {
    vi.stubEnv('LOCAL_NO_AUTH', value);

    expect(isLocalNoAuthEnabled()).toBe(false);
    expect(guardRequest(request())?.status).toBe(401);
  });

  it('enables only for the literal true value', () => {
    vi.stubEnv('LOCAL_NO_AUTH', 'true');

    expect(isLocalNoAuthEnabled()).toBe(true);
  });
});

describe('ordinary password protection remains unchanged', () => {
  it('rejects a cookie-less request when a password is configured', async () => {
    const response = guardRequest(request());

    expect(response?.status).toBe(401);
    expect(await response?.json()).toMatchObject({ error: '未登录' });
    expect(await (await getStatus(request('/api/status'))).json()).toMatchObject({
      passwordRequired: true,
      verified: false,
    });
  });

  it('still accepts a valid signed session', async () => {
    const cookie = `${SESSION_COOKIE}=${signSession().token}`;

    expect(guardRequest(request('/api/search', cookie))).toBeNull();
    expect(await (await getStatus(request('/api/status', cookie))).json()).toMatchObject({
      passwordRequired: true,
      verified: true,
    });
  });

  it('keeps an unconfigured server unavailable instead of silently bypassing auth', async () => {
    vi.stubEnv('PASSWORD', undefined);

    expect(guardRequest(request())?.status).toBe(503);
    expect(await (await getStatus(request('/api/status'))).json()).toMatchObject({
      passwordRequired: false,
      verified: false,
    });
    const login = await postAuth(new Request('http://localhost:8080/api/auth', { method: 'POST' }));
    expect(login.status).toBe(503);
    expect(login.headers.get('set-cookie')).toBeNull();
  });

  it('does not accept an incorrect password when local mode is disabled', async () => {
    const response = await postAuth(new Request('http://localhost:8080/api/auth', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-real-ip': TEST_IP },
      body: JSON.stringify({ password: 'incorrect' }),
    }));

    expect(response.status).toBe(401);
    expect(response.headers.get('set-cookie')).toBeNull();
    expect(await response.json()).toMatchObject({ success: false });
  });
});

describe('explicit local mode needs no password or session cookie', () => {
  beforeEach(() => {
    vi.stubEnv('LOCAL_NO_AUTH', 'true');
    vi.stubEnv('PASSWORD', undefined);
  });

  it('allows a protected request without a cookie', () => {
    expect(guardRequest(request())).toBeNull();
  });

  it.each([undefined, TEST_PASSWORD])('reports usable, password-free status with PASSWORD=%s', async (password) => {
    vi.stubEnv('PASSWORD', password);
    const response = await getStatus(request('/api/status'));

    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({ passwordRequired: false, verified: true });
  });

  it('reports an authenticated session without a cookie', async () => {
    const response = await getAuth(request('/api/auth'));

    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({ success: true, verified: true });
    expect(response.headers.get('set-cookie')).toBeNull();
  });

  it('accepts login without a body and does not mint a session cookie', async () => {
    const response = await postAuth(new Request('http://localhost:8080/api/auth', { method: 'POST' }));

    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({ success: true, verified: true });
    expect(response.headers.get('set-cookie')).toBeNull();
  });
});
