import { describe, expect, it } from 'vitest';
import { personalAccountLabel, personalLoginEmail } from './personal-login';

describe('家庭账号登录别名', () => {
  it.each(['001', '0001', '0', '12345678901', '9'.repeat(64)])('数字账号 %s 对应已有内部邮箱并保留前导零', (id) => {
    expect(personalLoginEmail(id)).toBe(`${id}@pps.invalid`);
  });

  it('只清理账号首尾空白', () => {
    expect(personalLoginEmail(' \t001\n')).toBe('001@pps.invalid');
  });

  it.each(['001@pps.invalid', 'User+family@Example.com', 'a@localhost', 'user.name@example.co.uk'])('保留完整邮箱 %s', (email) => {
    expect(personalLoginEmail(` ${email} `)).toBe(email);
  });

  it.each(['', ' ', 'family', '００１', '001 2', '001\n2', '9'.repeat(65), '001@', '@pps.invalid', '001@@pps.invalid', 'a b@example.com', 'a@-example.com', 'a@exam_ple.com', 'a'.repeat(243) + '@example.com'])('拒绝无效输入而不猜测其他账号 %j', (value) => {
    expect(() => personalLoginEmail(value)).toThrow('数字家庭账号');
  });

  it('短号与完整内部邮箱解析为同一个登录身份', () => {
    expect(personalLoginEmail('001')).toBe(personalLoginEmail('001@pps.invalid'));
    expect(personalLoginEmail('001')).not.toBe(personalLoginEmail('1'));
  });

  it('仅缩短数字家庭账号的展示', () => {
    expect(personalAccountLabel('001@pps.invalid')).toBe('001');
    expect(personalAccountLabel('0001@PPS.INVALID')).toBe('0001');
    expect(personalAccountLabel('user@example.com')).toBe('user@example.com');
    expect(personalAccountLabel('family@pps.invalid')).toBe('family@pps.invalid');
    expect(personalAccountLabel('001@pps.invalid.example.com')).toBe('001@pps.invalid.example.com');
  });
});
