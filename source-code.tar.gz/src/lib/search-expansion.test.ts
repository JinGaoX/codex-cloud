import { describe, expect, it } from 'vitest';
import { isRelevant } from './cms-parser';
import { filterSearchExpansionResults, getSearchExpansionPlan, searchResultIdentity } from './search-expansion';
import type { SearchResultItem } from './types';

const result = (name: string, vodId: string, sourceKey = 'a'): SearchResultItem => ({
  name, vodId, sourceKey, sourceName: '测试片源', year: '2025',
});

describe('manual search expansion planning', () => {
  it('supplements the series instead of replacing a missing numbered installment', () => {
    expect(getSearchExpansionPlan('人生七年10')).toEqual({
      originalQuery: '人生七年10', seriesQuery: '人生七年', candidates: [{ kind: 'series', query: '人生七年' }],
    });
  });

  it.each([
    ['庆余年第二季', '庆余年'], ['庆余年第 2 季', '庆余年'], ['人生七年第十部', '人生七年'],
    ['电影2025第二季', '电影2025'], ['1984第二季', '1984'],
    ['Breaking Bad Season 2', 'Breaking Bad'], ['Friends S12', 'Friends'], ['Friends 2', 'Friends'],
  ])('retains the complete series name of %s', (query, base) => {
    expect(getSearchExpansionPlan(query).seriesQuery).toBe(base);
  });

  it.each(['1917', '1984', '007', '十二怒汉', '三体', 'F1', 'A24', 'Apollo13', '唐探1900', '电影2025', '影片100', '庆余年第百季', '庆余年第十一十季'])('does not broadly strip numbers from %s', (query) => {
    expect(getSearchExpansionPlan(query).candidates).toEqual([]);
  });

  it.each([
    ['瑞克与莫蒂', '瑞克和莫蒂'], ['瑞克和莫蒂', '瑞克与莫蒂'],
  ])('tries one alternative for %s', (query, alternative) => {
    expect(getSearchExpansionPlan(query).candidates).toEqual([{ kind: 'alternative', query: alternative }]);
  });

  it('keeps connector hypotheses separate from series hypotheses and bounded', () => {
    const plan = getSearchExpansionPlan('瑞克与莫蒂第二季');
    expect(plan.candidates).toEqual([
      { kind: 'series', query: '瑞克与莫蒂' },
      { kind: 'alternative', query: '瑞克和莫蒂' },
    ]);
    expect(plan.seriesQuery).toBe('瑞克与莫蒂');
    expect(plan.candidates).toHaveLength(2);
  });

  it('covers an attached season and connector correction in two requests', () => {
    expect(getSearchExpansionPlan('瑞克与莫蒂2').candidates).toEqual([
      { kind: 'series', query: '瑞克与莫蒂' },
      { kind: 'alternative', query: '瑞克和莫蒂' },
    ]);
    expect(getSearchExpansionPlan('瑞克和莫蒂2').seriesQuery).toBe('瑞克和莫蒂');
  });

  it('keeps the established spelling when exact results already exist', () => {
    expect(getSearchExpansionPlan('猫与鼠2', 'matched')).toEqual({
      originalQuery: '猫与鼠2', seriesQuery: '猫与鼠', candidates: [{ kind: 'series', query: '猫与鼠' }],
    });
    expect(getSearchExpansionPlan('猫与鼠2', 'empty').candidates).toEqual([
      { kind: 'series', query: '猫与鼠' },
      { kind: 'alternative', query: '猫和鼠' },
    ]);
  });

  it('can retain other installments under either spelling when one installment is missing', () => {
    const plan = getSearchExpansionPlan('猫与鼠2', 'empty');
    const originalSeries = result('猫与鼠第一季', '1');
    const alternateSeries = result('猫和鼠第三季', '3');
    expect(filterSearchExpansionResults([originalSeries, alternateSeries], plan.candidates[0])).toEqual([originalSeries]);
    expect(filterSearchExpansionResults([originalSeries, alternateSeries], plan.candidates[1])).toEqual([alternateSeries]);
    expect(plan.seriesQuery).toBe('猫与鼠');
  });

  it('does not correct connectors for a matched title without a series suffix', () => {
    expect(getSearchExpansionPlan('瑞克与莫蒂', 'matched').candidates).toEqual([]);
  });

  it('retains internal digits and established connectors for matched seasons', () => {
    expect(getSearchExpansionPlan('电影2025与我们第二季', 'matched')).toEqual({
      originalQuery: '电影2025与我们第二季', seriesQuery: '电影2025与我们',
      candidates: [{ kind: 'series', query: '电影2025与我们' }],
    });
  });

  it.each(['', '  ', '！', '与你', '你和', '你与我和她'])('does not issue broad connector searches for %s', (query) => {
    expect(getSearchExpansionPlan(query).candidates).toEqual([]);
  });

  it('trims and bounds the submitted original query', () => {
    const plan = getSearchExpansionPlan('  ' + '电影'.repeat(80) + '  ');
    expect(plan.originalQuery).toHaveLength(100);
  });

  it('does not weaken strict season matching used outside manual discovery', () => {
    expect(isRelevant('庆余年第一季', '庆余年2')).toBe(false);
    expect(isRelevant('庆余年第十二季', '庆余年2')).toBe(false);
    expect(isRelevant('庆余年第二季', '庆余年2')).toBe(true);
  });
});

describe('supplemental result selection', () => {
  it('uses the supplemental query while preserving original titles, years and source identities', () => {
    const item = result('瑞克和莫蒂第二季', '2');
    expect(filterSearchExpansionResults([item, result('莫蒂传', '3')], { kind: 'alternative', query: '瑞克和莫蒂第二季' })).toEqual([item]);
    expect(item.name).toBe('瑞克和莫蒂第二季');
  });

  it('can show different installments only in the explicit series section', () => {
    const items = [result('人生七年1', '1'), result('人生七年9', '9'), result('人生七年10', '10')];
    expect(filterSearchExpansionResults(items, { kind: 'series', query: '人生七年' }, [items[2]])).toEqual(items.slice(0, 2));
  });

  it('deduplicates by source and ID, not title/year or delimiter concatenation', () => {
    const a = result('人生七年9', '9');
    const otherSource = result('人生七年9', '9', 'b');
    const excluded = result('人生七年10', '10');
    expect(filterSearchExpansionResults([a, a, otherSource, excluded], { kind: 'series', query: '人生七年' }, [excluded])).toEqual([a, otherSource]);
    expect(searchResultIdentity(result('片名', 'b_c', 'a'))).not.toBe(searchResultIdentity(result('片名', 'c', 'a_b')));
  });

  it('discards unidentifiable or unrelated source results', () => {
    expect(filterSearchExpansionResults([result('人生七年1', ''), result('人生七年1', '1', ''), result('任意电影', '2')], { kind: 'series', query: '人生七年' })).toEqual([]);
  });

  it('never exposes an unfiltered directory for an empty supplemental query', () => {
    expect(filterSearchExpansionResults([result('任意电影', '1')], { kind: 'series', query: '！' })).toEqual([]);
  });
});
