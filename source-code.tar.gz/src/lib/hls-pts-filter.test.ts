import { describe, expect, it, vi } from 'vitest';
import {
  analyzeHlsPtsPlaylist, classifyPtsGroups, createHlsPtsFilterSession, readTsVideoPts,
} from './hls-pts-filter';

const URL_BASE = 'https://media.example/library/index.m3u8';
const WRAP_MS = 2 ** 33 / 90;

function packet(pid: number, payload: number[]): Uint8Array<ArrayBuffer> {
  const result = new Uint8Array(188).fill(0xff);
  result.set([0x47, 0x40 | ((pid >> 8) & 0x1f), pid & 0xff, 0x10]);
  result.set(payload, 4);
  return result;
}

function pes(ptsMs: number, streamId = 0xe0): number[] {
  const ticks = Math.round(ptsMs * 90) % 2 ** 33;
  return [
    0, 0, 1, streamId, 0, 0, 0x80, 0x80, 5,
    0x20 | ((Math.floor(ticks / 2 ** 30) & 7) << 1) | 1,
    Math.floor(ticks / 2 ** 22) & 0xff,
    ((Math.floor(ticks / 2 ** 15) & 0x7f) << 1) | 1,
    Math.floor(ticks / 2 ** 7) & 0xff,
    ((ticks & 0x7f) << 1) | 1,
  ];
}

function bytesOfPackets(packets: Uint8Array[], prefix: number[] = []): Uint8Array<ArrayBuffer> {
  const result = new Uint8Array(prefix.length + packets.length * 188);
  result.set(prefix);
  packets.forEach((value, i) => result.set(value, prefix.length + i * 188));
  return result;
}

function ts(ptsMs: number): Uint8Array<ArrayBuffer> {
  return bytesOfPackets([packet(256, pes(ptsMs)), packet(8191, []), packet(8191, [])]);
}

function playlist(durations = [300, 20, 300], options: { crlf?: boolean; extras?: string[]; urls?: string[] } = {}): string {
  const lines = ['#EXTM3U', '#EXT-X-VERSION:3', '#EXT-X-TARGETDURATION:300', '#EXT-X-MEDIA-SEQUENCE:100', ...(options.extras ?? [])];
  durations.forEach((duration, index) => {
    if (index > 0) lines.push('#EXT-X-DISCONTINUITY');
    lines.push(`#EXTINF:${duration},`, options.urls?.[index] ?? `random-${index}.ts`);
  });
  lines.push('#EXT-X-ENDLIST', '');
  return lines.join(options.crlf ? '\r\n' : '\n');
}

function fetching(points: (number | null)[]) {
  return vi.fn<typeof fetch>(async (input) => {
    const i = Number(/random-(\d+)/.exec(String(input))?.[1] ?? 0);
    const bytes = points[i] === null ? new Uint8Array(600) : ts(points[i]);
    return new Response(bytes, { status: 206, headers: { 'Content-Range': `bytes 0-${bytes.length - 1}/${bytes.length}` } });
  });
}

describe('bounded MPEG-TS video timestamp reader', () => {
  it('reads full 33-bit video PTS and ignores earlier audio timestamps', () => {
    const input = bytesOfPackets([packet(257, pes(18, 0xc0)), packet(256, pes(9876543)), packet(8191, [])]);
    expect(readTsVideoPts(input)).toBe(9876543);
    expect(readTsVideoPts(ts(WRAP_MS - 1000))).toBe(Math.round(WRAP_MS - 1000));
  });

  it('requires repeated TS sync bytes, including after a PNG-like disguise prefix', () => {
    const input = bytesOfPackets([packet(256, pes(1480)), packet(8191, []), packet(8191, [])], [0x89, 0x50, 0x4e, 0x47, 13, 10, 26, 10]);
    expect(readTsVideoPts(input)).toBe(1480);
    expect(readTsVideoPts(new Uint8Array([0x47, ...pes(1480), 0x47]))).toBeNull();
    expect(readTsVideoPts(bytesOfPackets([packet(256, pes(1480, 0xc0)), packet(8191, []), packet(8191, [])]))).toBeNull();
  });

  it('finds a video PID from PAT/PMT even with a private PES stream ID', () => {
    const pat = packet(0, [0, 0, 0xb0, 13, 0, 1, 0xc1, 0, 0, 0, 1, 0xe0, 100, 0, 0, 0, 0]);
    const pmt = packet(100, [0, 2, 0xb0, 18, 0, 1, 0xc1, 0, 0, 0xe1, 0, 0xf0, 0, 0x1b, 0xe1, 0, 0xf0, 0, 0, 0, 0, 0]);
    expect(readTsVideoPts(bytesOfPackets([pat, pmt, packet(256, pes(2222, 0xbd))]))).toBe(2222);
  });

  it('rejects corrupt PTS marker bits, scrambled packets and incomplete headers', () => {
    const broken = ts(1480);
    broken[13] &= 0xfe;
    expect(readTsVideoPts(broken)).toBeNull();
    const scrambled = ts(1480);
    scrambled[3] |= 0x80;
    expect(readTsVideoPts(scrambled)).toBeNull();
    const adapt = ts(1480);
    adapt[3] = 0x30;
    adapt[4] = 250;
    expect(readTsVideoPts(adapt)).toBeNull();
  });
});

describe('PTS playlist analysis and continuity protections', () => {
  it.each([
    ['encrypted', ['#EXT-X-KEY:METHOD=AES-128,URI="key",IV=0x1']],
    ['encrypted', ['#EXT-X-KEY:METHOD=SAMPLE-AES,URI="key"']],
    ['encrypted', ['#EXT-X-KEY:URI="key"']],
    ['byterange', ['#EXT-X-BYTERANGE:1024@0']],
    ['non_ts_or_partial', ['#EXT-X-MAP:URI="init.mp4"']],
    ['non_ts_or_partial', ['#EXT-X-GAP']],
  ])('preserves %s playlists without probing', (reason, extras) => {
    expect(analyzeHlsPtsPlaylist(playlist(undefined, { extras }), URL_BASE).reason).toBe(reason);
  });

  it('does not treat a master, live or malformed playlist as removable media', () => {
    expect(analyzeHlsPtsPlaylist('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=1000\na.m3u8\n', URL_BASE).reason).toBe('master_playlist');
    expect(analyzeHlsPtsPlaylist(playlist().replace('#EXT-X-ENDLIST', ''), URL_BASE).reason).toBe('live_or_incomplete_playlist');
    expect(analyzeHlsPtsPlaylist(playlist().replace('#EXTINF:20,', '#EXTINF:NaN,'), URL_BASE).reason).toBe('invalid_duration');
    expect(analyzeHlsPtsPlaylist(playlist(undefined, { urls: ['a.ts', 'data:text/plain,bad', 'c.ts'] }), URL_BASE).reason).toBe('unsupported_uri');
  });

  it('finds a reset-timestamp insert between continuous main parts without URL clues', () => {
    const { groups } = analyzeHlsPtsPlaylist(playlist(), URL_BASE);
    expect([...classifyPtsGroups(groups, [1480, 1480, 301480])]).toEqual([1]);
    expect([...classifyPtsGroups(groups, [1480, 301480, 321480])]).toEqual([]);
  });

  it('keeps leading, unknown and off-chain mid-timeline normal groups', () => {
    const groups = analyzeHlsPtsPlaylist(playlist([20, 300, 300]), URL_BASE).groups;
    expect([...classifyPtsGroups(groups, [1480, 1480, 301480])]).toEqual([]);
    expect([...classifyPtsGroups(analyzeHlsPtsPlaylist(playlist(), URL_BASE).groups, [1480, null, 301480])]).toEqual([]);
    expect([...classifyPtsGroups(analyzeHlsPtsPlaylist(playlist(), URL_BASE).groups, [1480, 123000, 301480])]).toEqual([]);
  });

  it('preserves an adjacent independently encoded run over 60 seconds', () => {
    const groups = analyzeHlsPtsPlaylist(playlist([300, 40, 30, 300]), URL_BASE).groups;
    expect([...classifyPtsGroups(groups, [1480, 1480, 41480, 301480])]).toEqual([]);
  });

  it('requires a substantial main chain, rather than deleting independent chapters', () => {
    const groups = analyzeHlsPtsPlaylist(playlist([30, 30, 30, 30]), URL_BASE).groups;
    expect([...classifyPtsGroups(groups, [1480, 1480, 1480, 1480])]).toEqual([]);
  });

  it('connects main content over the 33-bit timestamp wrap', () => {
    const groups = analyzeHlsPtsPlaylist(playlist([20, 8, 20]), URL_BASE).groups;
    expect([...classifyPtsGroups(groups, [Math.round(WRAP_MS - 10000), 1480, 10000])]).toEqual([1]);
  });

  it('retains unknown media while connecting both sides of the main timeline', () => {
    const groups = analyzeHlsPtsPlaylist(playlist([300, 20, 300, 300, 300]), URL_BASE).groups;
    expect([...classifyPtsGroups(groups, [1480, 1480, 301480, null, 901480])]).toEqual([1]);
  });
});

describe('bounded, cancellable per-player PTS filter session', () => {
  it('removes only the identified group, preserving media sequence, CRLF and the following discontinuity', async () => {
    const fetcher = fetching([1480, 1480, 301480]);
    const session = createHlsPtsFilterSession({ fetcher });
    const input = playlist(undefined, { crlf: true, extras: ['#EXT-X-KEY:METHOD=NONE'] });
    const result = await session.filter(input, URL_BASE);
    expect(result.status).toBe('filtered');
    expect(result.removedSeconds).toBe(20);
    expect(result.removedGroups[0]).toMatchObject({ index: 1, startSegmentIndex: 1, endSegmentIndex: 1, segmentCount: 1 });
    expect(result.content).not.toContain('random-1.ts');
    expect(result.content).toContain('random-0.ts\r\n#EXT-X-DISCONTINUITY\r\n#EXTINF:300,\r\nrandom-2.ts');
    expect(result.content).toContain('#EXT-X-MEDIA-SEQUENCE:100\r\n');
    expect(result.content).toContain('#EXT-X-KEY:METHOD=NONE');
    expect(result.content.endsWith('#EXT-X-ENDLIST\r\n')).toBe(true);
    expect(result.complete).toBe(true);
    for (const call of fetcher.mock.calls) expect(call[1]).toMatchObject({ headers: { Range: 'bytes=0-2047' }, cache: 'no-store' });
    session.destroy();
  });

  it('preserves all ordinary short groups in a dense random-name playlist', async () => {
    const durations = Array.from({ length: 80 }, (_, i) => 2 * ((i % 8) + 1));
    let cursor = 1480;
    const pts = durations.map((duration) => { const start = cursor; cursor += duration * 1000; return start; });
    const input = playlist(durations);
    const session = createHlsPtsFilterSession({ fetcher: fetching(pts) });
    const result = await session.filter(input, URL_BASE);
    expect(result.content).toBe(input);
    expect(result.removedGroups).toEqual([]);
    expect(result.probedGroups).toBe(80);
    session.destroy();
  });

  it('retains playlist-wide state even when it is declared inside the removed range', async () => {
    const input = playlist().replace('#EXT-X-MEDIA-SEQUENCE:100\n', '')
      .replace('#EXTINF:20,', '#EXT-X-MEDIA-SEQUENCE:100\n#EXTINF:20,');
    const session = createHlsPtsFilterSession({ fetcher: fetching([1480, 1480, 301480]) });
    const result = await session.filter(input, URL_BASE);
    expect(result.status).toBe('filtered');
    expect(result.content).toContain('#EXT-X-MEDIA-SEQUENCE:100');
    expect(result.content).not.toContain('random-1.ts');
    session.destroy();
  });

  it('bounds reads when a server ignores Range, cancelling after the prefix', async () => {
    const cancel = vi.fn();
    const fetcher = vi.fn<typeof fetch>(async () => new Response(new ReadableStream({
      start(controller) { const data = new Uint8Array(16384); data.set(ts(1480)); controller.enqueue(data); }, cancel,
    }), { status: 200 }));
    const session = createHlsPtsFilterSession({ fetcher });
    await session.filter(playlist(), URL_BASE);
    expect(cancel).toHaveBeenCalledTimes(3);
    session.destroy();
  });

  it('has a hard deadline even if an injected fetch ignores AbortSignal', async () => {
    const session = createHlsPtsFilterSession({ fetcher: vi.fn(() => new Promise<Response>(() => undefined)), timeoutMs: 15 });
    const input = playlist();
    const result = await session.filter(input, URL_BASE);
    expect(result.content).toBe(input);
    expect(result.reason).toBe('probe_timeout');
    expect(result.complete).toBe(false);
    session.destroy();
  });

  it('caller cancellation returns the original and does not freeze a decision or cancel later calls', async () => {
    let hang = true;
    const ready = fetching([1480, 1480, 301480]);
    const session = createHlsPtsFilterSession({ fetcher: vi.fn<typeof fetch>((input, init) => hang ? new Promise<Response>(() => undefined) : ready(input, init)) });
    const controller = new AbortController();
    const input = playlist();
    const request = session.filter(input, URL_BASE, controller.signal);
    controller.abort();
    expect(await request).toMatchObject({ status: 'aborted', content: input, removedSeconds: 0 });
    hang = false;
    expect((await session.filter(input, URL_BASE)).status).toBe('filtered');
    session.destroy();
  });

  it('freezes a partial decision so a re-request cannot alter the active timeline', async () => {
    const fetcher = fetching([1480, null, 301480]);
    const session = createHlsPtsFilterSession({ fetcher });
    const input = playlist();
    const first = await session.filter(input, URL_BASE);
    expect(first.complete).toBe(false);
    expect(first.content).toBe(input);
    fetcher.mockImplementation(fetching([1480, 1480, 301480]));
    expect(await session.filter(input, URL_BASE)).toEqual(first);
    expect(fetcher).toHaveBeenCalledTimes(3);
    session.destroy();
  });

  it('deduplicates a repeated segment URL and permits an authenticated URL mapper', async () => {
    const fetcher = vi.fn<typeof fetch>(async (input) => {
      const original = new URL(String(input)).searchParams.get('url')!;
      return new Response(ts(original.includes('later') ? 301480 : 1480));
    });
    const session = createHlsPtsFilterSession({ fetcher, resolveProbeUrl: (uri) => `https://app.example/api/proxy?url=${encodeURIComponent(uri)}` });
    await session.filter(playlist(undefined, { urls: ['same.ts', 'same.ts', 'later.ts'] }), URL_BASE);
    expect(fetcher).toHaveBeenCalledTimes(2);
    expect(fetcher.mock.calls.every(([input]) => String(input).startsWith('https://app.example/api/proxy?url='))).toBe(true);
    session.destroy();
  });

  it('keeps the concurrency budget across simultaneous requests in one player session', async () => {
    let active = 0;
    let peak = 0;
    const inner = fetching([1480, 1480, 301480]);
    const fetcher = vi.fn<typeof fetch>(async (input, init) => {
      active++;
      peak = Math.max(peak, active);
      await new Promise((resolve) => setTimeout(resolve, 1));
      active--;
      return inner(input, init);
    });
    const session = createHlsPtsFilterSession({ fetcher, concurrency: 2 });
    const [first, second] = await Promise.all([session.filter(playlist(), URL_BASE), session.filter(playlist(), URL_BASE)]);
    expect(peak).toBe(2);
    expect(first).toEqual(second);
    expect(first.status).toBe('filtered');
    session.destroy();
  });

  it('destroy prevents a stale result or further network requests', async () => {
    const fetcher = vi.fn<typeof fetch>(() => new Promise<Response>(() => undefined));
    const session = createHlsPtsFilterSession({ fetcher });
    const input = playlist();
    const pending = session.filter(input, URL_BASE);
    session.destroy();
    expect(await pending).toMatchObject({ status: 'aborted', content: input });
    const count = fetcher.mock.calls.length;
    expect((await session.filter(input, URL_BASE)).status).toBe('aborted');
    expect(fetcher).toHaveBeenCalledTimes(count);
  });
});
