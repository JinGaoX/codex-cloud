import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { runInNewContext } from 'node:vm';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { updateRepairHtml } from '../../scripts/prepare-standalone-pwa.mjs';

const appVersion = JSON.parse(readFileSync(resolve(process.cwd(), 'package.json'), 'utf8')).version as string;
const template = readFileSync(resolve(process.cwd(), 'public/update-repair.html'), 'utf8');
const source = updateRepairHtml(template, appVersion).match(/<script>([\s\S]*?)<\/script>/)![1];
function setup() {
  const elements = new Map<string, { disabled: boolean; hidden: boolean; textContent: string; href: string; click?: () => Promise<void>; addEventListener: (event: string, callback: () => Promise<void>) => void }>();
  for (const name of ['check', 'apply', 'status', 'home']) {
    const entry = { disabled: false, hidden: name === 'apply', textContent: '', href: '',
      addEventListener: (_event: string, callback: () => Promise<void>) => { entry.click = callback; }, click: undefined as undefined | (() => Promise<void>) };
    elements.set(name, entry);
  }
  class Channel {
    port1 = { onmessage: null as null | ((event: { data: unknown }) => void), close: vi.fn() };
    port2 = { reply: (data: unknown) => this.port1.onmessage?.({ data }) };
  }
  const worker = { state: 'installed', postMessage: vi.fn((data: { type: string }, ports?: { reply: (data: unknown) => void }[]) => {
    if (data.type === 'GET_APP_VERSION') ports?.[0].reply({ type: 'APP_VERSION', version: appVersion });
  }) };
  const registration = { waiting: worker as typeof worker | null, installing: null as typeof worker | null, update: vi.fn(async () => {}) };
  const serviceWorker = Object.assign(new EventTarget(), { register: vi.fn(async () => registration) });
  const assign = vi.fn();
  runInNewContext(source, { URL, Date, MessageChannel: Channel, setTimeout, clearTimeout, setInterval, clearInterval,
    document: { getElementById: (name: string) => elements.get(name) },
    location: { href: 'https://app.example.test/codex-cloud/update-repair.html?repair=fixture', assign },
    isSecureContext: true, navigator: { serviceWorker },
  });
  return { elements, worker, registration, serviceWorker, assign };
}
afterEach(() => vi.useRealTimers());

describe('independent update repair bootstrap', () => {
  it('injects the package target into visible text and verification code without pinning an old release', () => {
    const rendered = updateRepairHtml(template, '9.99.0-fixture');
    expect(rendered).toContain('<strong id="target-version">9.99.0-fixture</strong>');
    expect(rendered).toContain('const targetVersion = "9.99.0-fixture";');
    expect(updateRepairHtml(rendered, appVersion)).toContain(`const targetVersion = "${appVersion}";`);
  });

  it('uses the stable project worker, activates only on explicit action and never accesses user storage', async () => {
    const w = setup();
    expect(w.serviceWorker.register).not.toHaveBeenCalled();
    await w.elements.get('check')!.click!();
    expect(w.serviceWorker.register).toHaveBeenCalledWith('https://app.example.test/codex-cloud/sw-standalone.js', { scope: '/codex-cloud/', updateViaCache: 'none' });
    expect(w.elements.get('apply')!.hidden).toBe(false);
    expect(w.worker.postMessage.mock.calls[0][0]).toEqual({ type: 'GET_APP_VERSION' });
    expect(Array.isArray(w.worker.postMessage.mock.calls[0][1])).toBe(true);
    expect(w.worker.postMessage.mock.calls.some(([data]) => data.type === 'ACTIVATE_UPDATE')).toBe(false); expect(w.assign).not.toHaveBeenCalled();
    const applying = w.elements.get('apply')!.click!();
    expect(w.worker.postMessage).toHaveBeenCalledWith({ type: 'ACTIVATE_UPDATE' });
    w.serviceWorker.dispatchEvent(new Event('controllerchange')); await applying;
    expect(w.assign).toHaveBeenCalledWith('https://app.example.test/codex-cloud/');
  });

  it('makes a hung network registration retryable without unregistering or clearing data', async () => {
    vi.useFakeTimers(); const w = setup();
    w.serviceWorker.register.mockImplementationOnce(() => new Promise(() => {}));
    const checking = w.elements.get('check')!.click!();
    await vi.advanceTimersByTimeAsync(15000); await checking;
    expect(w.elements.get('check')!.disabled).toBe(false);
    expect(w.elements.get('status')!.textContent).toContain('本机资料仍保留');
    await w.elements.get('check')!.click!();
    expect(w.elements.get('apply')!.hidden).toBe(false); expect(w.assign).not.toHaveBeenCalled();
  });

  it('bounds an indefinitely installing old app update and never activates it automatically', async () => {
    vi.useFakeTimers(); const w = setup();
    w.worker.state = 'installing'; w.registration.waiting = null; w.registration.installing = w.worker;
    const checking = w.elements.get('check')!.click!();
    await vi.advanceTimersByTimeAsync(70250); await checking;
    expect(w.elements.get('check')!.disabled).toBe(false);
    expect(w.elements.get('status')!.textContent).toContain('更新未完成');
    expect(w.worker.postMessage).not.toHaveBeenCalled(); expect(w.assign).not.toHaveBeenCalled();
  });

  it('does not activate an old waiting worker while the latest one is installing', async () => {
    vi.useFakeTimers(); const w = setup();
    const latest = { state: 'installing', postMessage: w.worker.postMessage };
    const oldPost = vi.fn(); w.worker.postMessage = oldPost;
    w.registration.installing = latest;
    const checking = w.elements.get('check')!.click!();
    await vi.advanceTimersByTimeAsync(250);
    expect(w.registration.update).toHaveBeenCalledOnce(); expect(w.elements.get('apply')!.hidden).toBe(true); expect(oldPost).not.toHaveBeenCalled();
    latest.state = 'installed'; w.registration.installing = null;
    await vi.advanceTimersByTimeAsync(250); await checking;
    expect(w.elements.get('apply')!.hidden).toBe(false); expect(oldPost).not.toHaveBeenCalled();
  });

  it('refuses an older waiting worker that cannot confirm the target version', async () => {
    vi.useFakeTimers(); const w = setup();
    w.worker.postMessage.mockImplementation(() => {});
    const checking = w.elements.get('check')!.click!();
    await vi.advanceTimersByTimeAsync(3000); await checking;
    expect(w.elements.get('apply')!.hidden).toBe(true); expect(w.elements.get('status')!.textContent).toContain('更新未完成');
    expect(w.assign).not.toHaveBeenCalled();
  });
});
