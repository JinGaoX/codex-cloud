import { ACTIVE_ACCOUNT_SCOPE, readActiveAccountScope, scopeId } from './account-scope';
import { getSyncConfiguration, type SyncConfiguration } from './personal-sync-config';
import { getPersonalSyncClient } from './personal-sync-client';

const TIMEOUT_MS = 15_000;
const SESSION_TIMEOUT_MS = 3_000;
// JSON escaping can double the upstream text size; still bound the wire envelope.
const MAX_RESPONSE_BYTES = 6 * 1024 * 1024 + 8192;
const MAX_TEXT_BYTES = 3 * 1024 * 1024;
const AUTH_MESSAGE = '账号连接已失效，请重新登录后再搜索。';
const ERROR_MESSAGES: Record<string, string> = {
  SOURCE_NOT_SYNCED: '请先保存片源，并在「账号与同步」中完成同步后再测试或搜索。',
  AUTH_REQUIRED: AUTH_MESSAGE,
  SOURCE_BLOCKED: '该 API 地址或请求参数不受账号服务支持，请检查片源配置。',
  UPSTREAM_FAILED: '片源暂时无法访问，请重试或更换片源。',
  UPSTREAM_INVALID: '片源没有返回有效的 Apple CMS JSON API 数据。',
  UPSTREAM_TOO_LARGE: '片源返回内容过大，请更换片源。',
  RELAY_TIMEOUT: '片源请求超时，请重试或更换片源。',
  RATE_LIMITED: '搜索请求较多，请稍候重试。',
  RELAY_UNAVAILABLE: '账号片源服务暂时不可用，请稍后重试。',
};

export class AccountSourceRelayError extends Error {
  constructor(message: string, readonly healthIgnored = true) { super(message); this.name = 'AccountSourceRelayError'; }
}

export function sourceHealthIgnored(error: unknown): boolean {
  return error instanceof AccountSourceRelayError && error.healthIgnored;
}

function configuration(): SyncConfiguration | null {
  if (!ACTIVE_ACCOUNT_SCOPE) return null;
  const config = getSyncConfiguration();
  if (!config || config.url !== ACTIVE_ACCOUNT_SCOPE.endpoint
    || scopeId(readActiveAccountScope()) !== scopeId(ACTIVE_ACCOUNT_SCOPE)) throw new AccountSourceRelayError(AUTH_MESSAGE);
  return config;
}

/** Guests retain direct HTTPS transport. An active account never falls back to another origin. */
export function accountSourceRelayEnabled(): boolean {
  return configuration() !== null;
}

/** HTTP API metadata may use the owned HTTPS relay; media URLs still require HTTPS. */
export function accountApiUrl(raw: string): URL {
  let url: URL;
  try { url = new URL(raw.trim()); } catch { throw new Error('地址格式不正确，请填写完整的 HTTP 或 HTTPS API 地址'); }
  if (!['http:', 'https:'].includes(url.protocol) || !url.hostname || url.username || url.password) {
    throw new Error('API 地址必须为不含账号密码的 HTTP 或 HTTPS 地址');
  }
  url.hash = '';
  return url;
}

function abortReason(signal: AbortSignal): unknown {
  return signal.reason ?? new DOMException('请求已取消', 'AbortError');
}

async function boundedBody(response: Response, signal: AbortSignal): Promise<string> {
  if (Number(response.headers.get('content-length')) > MAX_RESPONSE_BYTES) {
    void response.body?.cancel().catch(() => {});
    throw new AccountSourceRelayError('账号片源服务返回内容过大，请更换片源。');
  }
  const reader = response.body?.getReader();
  if (!reader) return '';
  const chunks: Uint8Array[] = [];
  let size = 0;
  const onAbort = () => { void reader.cancel().catch(() => {}); };
  signal.addEventListener('abort', onAbort, { once: true });
  try {
    for (;;) {
      if (signal.aborted) throw abortReason(signal);
      const part = await reader.read();
      if (part.done) break;
      size += part.value.byteLength;
      if (size > MAX_RESPONSE_BYTES) {
        void reader.cancel().catch(() => {});
        throw new AccountSourceRelayError('账号片源服务返回内容过大，请更换片源。');
      }
      chunks.push(part.value);
    }
  } finally { signal.removeEventListener('abort', onAbort); reader.releaseLock(); }
  const joined = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { joined.set(chunk, offset); offset += chunk.byteLength; }
  return new TextDecoder().decode(joined);
}

/** Bearer credentials are sent only to this account's configured Supabase function. */
export async function accountSourceRelayText(raw: string, signal?: AbortSignal): Promise<{ text: string; url: string }> {
  const config = configuration();
  const scope = ACTIVE_ACCOUNT_SCOPE;
  if (!config || !scope) throw new AccountSourceRelayError(AUTH_MESSAGE);
  const url = accountApiUrl(raw).href;
  if (signal?.aborted) throw signal.reason ?? new DOMException('请求已取消', 'AbortError');
  const controller = new AbortController();
  const onParentAbort = () => controller.abort(signal?.reason ?? new DOMException('请求已取消', 'AbortError'));
  signal?.addEventListener('abort', onParentAbort, { once: true });
  const timer = setTimeout(() => {
    const error = new AccountSourceRelayError('账号片源服务请求超时，请稍后重试。'); error.name = 'TimeoutError'; controller.abort(error);
  }, TIMEOUT_MS);
  let sessionTimer: ReturnType<typeof setTimeout> | undefined;
  let onAbort: (() => void) | undefined;
  const aborted = new Promise<never>((_resolve, reject) => {
    onAbort = () => reject(abortReason(controller.signal));
    controller.signal.addEventListener('abort', onAbort, { once: true });
  });
  try {
    const operation = async () => {
      const sessionResult = await Promise.race([
        getPersonalSyncClient(config).auth.getSession(),
        new Promise<never>((_resolve, reject) => { sessionTimer = setTimeout(() => reject(new AccountSourceRelayError(AUTH_MESSAGE)), SESSION_TIMEOUT_MS); }),
      ]);
      if (sessionTimer) clearTimeout(sessionTimer);
      if (controller.signal.aborted) throw abortReason(controller.signal);
      const session = sessionResult.data.session;
      if (sessionResult.error || !session?.access_token || session.user.id !== scope.userId
        || configuration()?.url !== config.url) throw new AccountSourceRelayError(AUTH_MESSAGE);
      let response: Response;
      try {
        response = await fetch(`${config.url}/functions/v1/pps-source-relay`, {
          method: 'POST', mode: 'cors', credentials: 'omit', cache: 'no-store', redirect: 'error',
          headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}`, apikey: config.publishableKey },
          body: JSON.stringify({ url }), signal: controller.signal,
        });
      } catch {
        if (controller.signal.aborted) throw abortReason(controller.signal);
        throw new AccountSourceRelayError('账号片源服务暂时无法连接，请检查网络后重试。');
      }
      const body = await boundedBody(response, controller.signal);
      let payload: unknown;
      try { payload = JSON.parse(body); } catch { throw new AccountSourceRelayError('账号片源服务响应异常，请稍后重试。'); }
      if (!response.ok) {
        const code = payload && typeof payload === 'object' && 'code' in payload ? String(payload.code) : '';
        throw new AccountSourceRelayError(ERROR_MESSAGES[code] || (response.status === 401 ? AUTH_MESSAGE : '账号片源服务请求失败，请稍后重试。'),
          !['SOURCE_BLOCKED', 'UPSTREAM_FAILED', 'UPSTREAM_INVALID', 'UPSTREAM_TOO_LARGE'].includes(code));
      }
      if (!payload || typeof payload !== 'object' || !('text' in payload) || typeof payload.text !== 'string'
        || !('url' in payload) || typeof payload.url !== 'string' || new TextEncoder().encode(payload.text).byteLength > MAX_TEXT_BYTES) {
        throw new AccountSourceRelayError('账号片源服务响应异常，请稍后重试。');
      }
      if (configuration()?.url !== config.url) throw new AccountSourceRelayError(AUTH_MESSAGE);
      return { text: payload.text, url: accountApiUrl(payload.url).href };
    };
    return await Promise.race([operation(), aborted]);
  } catch (error) {
    if (signal?.aborted) throw signal.reason ?? new DOMException('请求已取消', 'AbortError');
    if (controller.signal.aborted) throw abortReason(controller.signal);
    if (error instanceof AccountSourceRelayError) throw error;
    throw new AccountSourceRelayError('账号片源服务响应异常，请稍后重试。');
  } finally {
    clearTimeout(timer);
    if (sessionTimer) clearTimeout(sessionTimer);
    signal?.removeEventListener('abort', onParentAbort);
    if (onAbort) controller.signal.removeEventListener('abort', onAbort);
  }
}
