import { afterEach, describe, expect, it, vi } from 'vitest';
import { createTemporaryWebFile, supportsTemporaryWebFile } from './web-download-file-target';

function fileSystem() {
  const write = vi.fn(async () => {});
  const close = vi.fn(async () => {});
  const abort = vi.fn(async () => {});
  const getFile = vi.fn(async () => new File([new Uint8Array([1, 2, 3])], 'temporary.mp4'));
  const createWritable = vi.fn(async () => ({ getWriter: () => ({ write, close, abort }) }));
  const removeEntry = vi.fn(async () => {});
  const folder = { getFileHandle: vi.fn(async (name: string) => ({ name, createWritable, getFile })), removeEntry };
  const getDirectoryHandle = vi.fn(async () => folder);
  vi.stubGlobal('navigator', { storage: { getDirectory: async () => ({ getDirectoryHandle }) } });
  vi.stubGlobal('FileSystemFileHandle', class { createWritable() {} });
  return { write, close, abort, getFile, createWritable, removeEntry, folder, getDirectoryHandle };
}

afterEach(() => {
  vi.restoreAllMocks();
  vi.unstubAllGlobals();
  vi.useRealTimers();
});

describe('网页版下载临时文件', () => {
  it('完成写入后才提供可交给浏览器保存的文件，保存时延迟释放', async () => {
    vi.useFakeTimers();
    const fixture = fileSystem();
    const createUrl = vi.spyOn(URL, 'createObjectURL').mockReturnValue('blob:test-output');
    const revoke = vi.spyOn(URL, 'revokeObjectURL').mockImplementation(() => {});
    expect(supportsTemporaryWebFile()).toBe(true);
    const staged = await createTemporaryWebFile('测试.mp4');
    await expect(staged.prepare()).rejects.toThrow('尚未保存完整');
    const bytes = new Uint8Array([1, 2, 3]);
    await staged.target.write(bytes);
    await staged.target.close();
    expect(fixture.write).toHaveBeenCalledWith(bytes);
    expect(fixture.close).toHaveBeenCalledOnce();
    const file = await staged.prepare();
    expect(file).toMatchObject({ kind: 'prepared', url: 'blob:test-output', filename: '测试.mp4' });
    expect(createUrl).toHaveBeenCalledOnce();
    file.dispose(true);
    expect(revoke).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(120_000);
    expect(revoke).toHaveBeenCalledWith('blob:test-output');
    expect(fixture.removeEntry).toHaveBeenCalledOnce();
  });

  it('中止时关闭写入并仅删除该次下载的临时文件', async () => {
    const fixture = fileSystem();
    const staged = await createTemporaryWebFile('测试.mp4');
    await staged.target.abort();
    expect(fixture.abort).toHaveBeenCalledOnce();
    expect(fixture.removeEntry).toHaveBeenCalledWith(fixture.folder.getFileHandle.mock.calls[0][0]);
    expect(fixture.getFile).not.toHaveBeenCalled();
  });
});
