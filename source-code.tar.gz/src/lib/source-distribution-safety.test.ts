import { describe, expect, it } from 'vitest';
import { assertUnsignedHarmonyProfile } from '../../scripts/source-distribution-safety.mjs';

describe('public Harmony source archive safety', () => {
  it('accepts unsigned root and entry templates without changing them', () => {
    expect(() => assertUnsignedHarmonyProfile('{"app":{"signingConfigs":[],"products":[{"runtimeOS":"HarmonyOS"}]}}')).not.toThrow();
    expect(() => assertUnsignedHarmonyProfile('{"apiType":"stageMode","buildOption":{}}')).not.toThrow();
  });

  it.each([
    '{"app":{"signingConfigs":[{"name":"default","material":{"storePassword":"private-fixture"}}]}}',
    '{"app":{"products":[{"signingConfig":"default"}]}}',
    '{"app":{"signingConfigs":null}}',
    '{"app":{"signingConfigs":[],"nested":{"keyPassword":"private-fixture"}}}',
    '{"app":{"signingConfigs":[],"nested":{"profile":"/private/fixture.p7b"}}}',
    '{"app":{"signingConfigs":[],"nested":{"keyAlias":"private-fixture"}}}',
    '{"app":{"signingConfigs":[],"nested":{"value":"-----BEGIN PRIVATE KEY-----"}}}',
  ])('refuses signing configuration without echoing secret values', (source) => {
    expect(() => assertUnsignedHarmonyProfile(source)).toThrow(/拒绝归档/);
    try {
      assertUnsignedHarmonyProfile(source);
    } catch (error) {
      expect((error as Error).message).not.toContain('private-fixture');
      expect((error as Error).message).not.toContain('/private/');
    }
  });

  it.each(['not json', '{app:{signingConfigs:[]}}', 'null', '[]'])
    ('fails closed for unparseable or non-object profiles: %s', (source) => {
      expect(() => assertUnsignedHarmonyProfile(source)).toThrow('无签名');
    });
});
