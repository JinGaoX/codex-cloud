import { ACTIVE_ACCOUNT_SCOPE, readActiveAccountScope, scopeId, settingsKeyForScope } from './account-scope';
import { flushPendingPersist, readPersistedSettings } from './persist-storage';
import { useAppStore, type SourceHealthEntry } from './store';

const MARKER = 'pps-account-source-relay-health-v2';

/** Browser CORS and the .36 cloud TLS compatibility failures are obsolete. */
export function obsoleteDirectHealthKeys(health: Record<string, SourceHealthEntry>): string[] {
  return Object.entries(health).filter(([, entry]) => !entry.ok && typeof entry.error === 'string'
    && (/CORS|跨域限制|Failed to fetch|NetworkError|Load failed|无法直接访问该源：可能是网络、证书/.test(entry.error)
      || entry.error === '片源暂时无法访问，请重试或更换片源。'))
    .map(([key]) => key);
}

/** Account-scoped, once only. Unchecked sources are never reselected. */
export function repairAccountSourceTransportHealth(): void {
  if (!ACTIVE_ACCOUNT_SCOPE || scopeId(readActiveAccountScope()) !== scopeId(ACTIVE_ACCOUNT_SCOPE)) return;
  const marker = settingsKeyForScope(MARKER, ACTIVE_ACCOUNT_SCOPE);
  try {
    if (localStorage.getItem(marker) === 'done') return;
    const state = useAppStore.getState();
    const obsolete = obsoleteDirectHealthKeys(state.sourceHealth);
    if (obsolete.length) {
      const health = { ...state.sourceHealth };
      for (const key of obsolete) delete health[key];
      useAppStore.setState({ sourceHealth: health });
      flushPendingPersist();
      // A storage failure must leave the migration eligible on the next launch.
      const persisted = readPersistedSettings();
      if (!persisted) return;
      const saved = JSON.parse(persisted) as { state?: { sourceHealth?: Record<string, unknown> } };
      if (!saved.state?.sourceHealth || obsolete.some((key) => key in saved.state!.sourceHealth!)) return;
    }
    localStorage.setItem(marker, 'done');
  } catch { /* Offline/private storage failures do not block account access. */ }
}
