import { supportsFileSystemAccess, UserCancelledError, type SaveTarget } from './download-saver';
import { decryptSegment } from './m3u8-downloader';
import { standaloneMediaUrl } from './standalone-media';
import { StreamingTransmuxer, validateFragmentTiming } from './mp4-transmuxer';
import { createTemporaryWebFile, supportsTemporaryWebFile, type PreparedWebDownload, type StagedWebDownload } from './web-download-file-target';
import { readTsStreamTypes } from './codec-parse-browser';

export interface WebVideoDownloadVariant {
  url: string;
  width?: number;
  height?: number;
  bandwidth?: number;
  estimatedBytes?: number;
  directAttachment?: boolean;
  unsupported?: string;
}

export interface WebVideoDownloadOptions {
  kind: 'mp4' | 'hls';
  variants: WebVideoDownloadVariant[];
}

export interface WebVideoDownloadProgress {
  current: number;
  total: number;
  percentage?: number;
}

interface DownloadOptions {
  kind: WebVideoDownloadOptions['kind'];
  variant: WebVideoDownloadVariant;
  title: string;
  signal: AbortSignal;
  onProgress?: (state: WebVideoDownloadProgress) => void;
  target?: SaveTarget;
  background?: boolean;
  memoryBudget?: number;
}

export const WEB_DOWNLOAD_MEMORY_LIMIT = 64 * 1024 * 1024;
const SEGMENT_LIMIT = 48 * 1024 * 1024;
const PLAYLIST_LIMIT = 1024 * 1024;
const WAIT_MS = 30_000;
const MEMORY_LIMIT_MESSAGE = '这个视频超过当前浏览器可安全暂存的大小。可换支持磁盘保存的浏览器，或手动选择其他画质。';

class WebDownloadError extends Error {}

function safeUrl(value: string, base?: string) {
  try { return standaloneMediaUrl(base ? new URL(value, base).href : value); }
  catch { throw new WebDownloadError('下载需要不含账号密码的 HTTPS 视频和分片地址。'); }
}

function contentLength(response: Response): number | undefined {
  const length = Number(response.headers.get('content-length'));
  return Number.isSafeInteger(length) && length > 0 ? length : undefined;
}

function stopReading(response: Response) {
  void response.body?.cancel().catch(() => {});
}

async function requestResource(url: string, signal: AbortSignal, name: string, method = 'GET'): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), WAIT_MS);
  let response: Response;
  try {
    response = await fetch(safeUrl(url), {
      method, credentials: 'omit', referrerPolicy: 'no-referrer',
      cache: 'no-store', signal: AbortSignal.any([signal, controller.signal]),
    });
  } catch (error) {
    signal.throwIfAborted();
    if (error instanceof WebDownloadError) throw error;
    throw new WebDownloadError(controller.signal.aborted
      ? `读取${name}超时，请重试。`
      : `浏览器无法读取${name}。片源可能限制跨域下载，或连接暂时不可用。`);
  } finally { clearTimeout(timer); }
  if (!response.ok) {
    stopReading(response);
    throw new WebDownloadError(`读取${name}失败（HTTP ${response.status}）。`);
  }
  if (response.status !== 200) {
    stopReading(response);
    throw new WebDownloadError(`片源没有返回完整的${name}（HTTP ${response.status}）。`);
  }
  try { if (response.url) safeUrl(response.url); }
  catch (error) { stopReading(response); throw error; }
  return response;
}

async function transferResponse(
  response: Response,
  signal: AbortSignal,
  limit: number,
  consume: (bytes: Uint8Array<ArrayBuffer>, current: number) => Promise<void>,
  limitMessage: string,
): Promise<number> {
  if ((contentLength(response) ?? 0) > limit) {
    stopReading(response);
    throw new WebDownloadError(limitMessage);
  }
  const reader = response.body?.getReader();
  if (!reader) throw new WebDownloadError('片源没有返回可读取的视频数据。');
  let total = 0;
  const onAbort = () => { void reader.cancel().catch(() => {}); };
  signal.addEventListener('abort', onAbort, { once: true });
  try {
    for (;;) {
      signal.throwIfAborted();
      let timedOut = false;
      const timer = setTimeout(() => { timedOut = true; onAbort(); }, WAIT_MS);
      const chunk = await reader.read().finally(() => clearTimeout(timer));
      signal.throwIfAborted();
      if (timedOut) throw new WebDownloadError('片源长时间没有返回视频数据，请重试。');
      if (chunk.done) break;
      const bytes = chunk.value;
      total += bytes.byteLength;
      if (total > limit) throw new WebDownloadError(limitMessage);
      await consume(bytes, total);
    }
  } finally {
    signal.removeEventListener('abort', onAbort);
    void reader.cancel().catch(() => {});
    reader.releaseLock();
  }
  return total;
}

async function limitedBytes(response: Response, signal: AbortSignal, limit: number, message: string): Promise<Uint8Array<ArrayBuffer>> {
  const chunks: Uint8Array<ArrayBuffer>[] = [];
  const size = await transferResponse(response, signal, limit, async (bytes) => { chunks.push(bytes); }, message);
  const result = new Uint8Array(size);
  let offset = 0;
  for (const chunk of chunks) { result.set(chunk, offset); offset += chunk.byteLength; }
  return result;
}

function attributes(line: string): Map<string, string> {
  return new Map([...line.slice(line.indexOf(':') + 1).matchAll(/(?:^|,)\s*([A-Z0-9-]+)=("(?:[^"]*)"|[^,]*)/g)]
    .map(([, key, value]) => [key, value.replace(/^"|"$/g, '').trim()]));
}

function validNumber(value?: string): number | undefined {
  const number = Number(value);
  return Number.isSafeInteger(number) && number > 0 ? number : undefined;
}

function playlistLines(text: string): string[] {
  const lines = text.trim().split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  if (lines[0]?.replace(/^\uFEFF/, '') !== '#EXTM3U') throw new WebDownloadError('片源没有返回有效的 HLS 播放列表。');
  return lines;
}

async function fetchPlaylist(url: string, signal: AbortSignal) {
  const response = await requestResource(url, signal, '播放列表');
  const bytes = await limitedBytes(response, signal, PLAYLIST_LIMIT, '播放列表过大，无法在网页内安全读取。');
  return { base: response.url || url, lines: playlistLines(new TextDecoder().decode(bytes)) };
}

function compareVariants(a: WebVideoDownloadVariant, b: WebVideoDownloadVariant): number {
  const pixels = (variant: WebVideoDownloadVariant) => (variant.width ?? 0) * (variant.height ?? 0);
  return pixels(b) - pixels(a) || (b.bandwidth ?? 0) - (a.bandwidth ?? 0);
}

function masterVariants(lines: string[], base: string): WebVideoDownloadVariant[] {
  const alternateAudio = new Set(lines.filter((line) => line.startsWith('#EXT-X-MEDIA:'))
    .map(attributes).filter((entry) => entry.get('TYPE') === 'AUDIO' && entry.has('URI')).map((entry) => entry.get('GROUP-ID')));
  const variants: WebVideoDownloadVariant[] = [];
  let pending: Map<string, string> | undefined;
  for (const line of lines) {
    if (line.startsWith('#EXT-X-STREAM-INF:')) {
      pending = attributes(line);
    } else if (pending && !line.startsWith('#')) {
      const resolution = /^([1-9]\d{0,4})x([1-9]\d{0,4})$/i.exec(pending.get('RESOLUTION') ?? '');
      const codecs = pending.get('CODECS');
      const separateAudio = alternateAudio.has(pending.get('AUDIO'));
      let url = '';
      try { url = safeUrl(line, base); } catch { /* Keep the unavailable quality in its original rank. */ }
      variants.push({
        url,
        width: validNumber(resolution?.[1]), height: validNumber(resolution?.[2]),
        bandwidth: validNumber(pending.get('BANDWIDTH')),
        unsupported: !url ? '这一档没有可用的 HTTPS 下载地址。'
          : separateAudio ? '这一档使用独立音轨，网页暂时不能完整合并。'
          : codecs && !/(?:^|,)\s*avc[13](?:\.|,|$)/i.test(codecs)
            ? '这一档的视频编码暂不支持在网页内转封装。' : undefined,
      });
      pending = undefined;
    }
  }
  if (!variants.length) throw new WebDownloadError('播放列表没有提供可识别的清晰度档位。');
  const seen = new Set<string>();
  return variants.sort(compareVariants).filter((variant) => {
    if (!variant.url) return true;
    if (seen.has(variant.url)) return false;
    seen.add(variant.url);
    return true;
  });
}

/** Read only the top-level playlist so failed or lower variants are never fetched implicitly. */
export async function inspectWebVideoDownload(input: string, signal: AbortSignal): Promise<WebVideoDownloadOptions> {
  const url = safeUrl(input);
  if (/\.mp4$/i.test(new URL(url).pathname)) {
    const response = await requestResource(url, signal, 'MP4 文件信息', 'HEAD').catch((error: unknown) => {
      signal.throwIfAborted();
      // Some sources reject HEAD but allow the browser to read a normal GET.
      if (error instanceof WebDownloadError) return undefined;
      throw error;
    });
    return {
      kind: 'mp4',
      variants: [{
        url: response?.url || url,
        directAttachment: Boolean(response && /^(?:video\/mp4|application\/octet-stream)(?:\s*;|$)/i.test(response.headers.get('content-type') ?? '')
          && /^attachment(?:\s*;|$)/i.test(response.headers.get('content-disposition') ?? '')),
        estimatedBytes: response && contentLength(response),
      }],
    };
  }
  const { lines, base } = await fetchPlaylist(url, signal);
  return { kind: 'hls', variants: lines.some((line) => line.startsWith('#EXT-X-STREAM-INF:'))
    ? masterVariants(lines, base) : [{ url: base }] };
}

interface MediaPlaylist {
  urls: string[];
  duration: number;
  sequence: number;
  key?: { url: string; iv?: string };
}

function mediaPlaylist(lines: string[], base: string): MediaPlaylist {
  if (!lines.includes('#EXT-X-ENDLIST')) throw new WebDownloadError('直播或尚未结束的视频不能下载为完整文件。');
  if (lines.some((line) => /^#EXT-X-DISCONTINUITY(?:$|:)/.test(line))) {
    throw new WebDownloadError('这一档在分片之间切换播放时间轴，网页暂时无法安全合并。');
  }
  if (lines.some((line) => /^#EXT-X-(?:MAP:|BYTERANGE:|GAP(?:$|:)|SKIP:|STREAM-INF:|PART:)/.test(line))) {
    throw new WebDownloadError('这一档使用的 HLS 分片格式目前无法在网页内完整保存。');
  }
  const sequence = Number(lines.find((line) => line.startsWith('#EXT-X-MEDIA-SEQUENCE:'))?.split(':')[1] ?? 0);
  if (!Number.isSafeInteger(sequence) || sequence < 0) throw new WebDownloadError('HLS 分片序号无效。');
  const urls: string[] = [];
  let duration = 0, nextDuration = 0;
  let key: MediaPlaylist['key'];
  for (const line of lines) {
    if (line.startsWith('#EXT-X-KEY:')) {
      const entry = attributes(line);
      const method = entry.get('METHOD');
      if (method === 'NONE' && !key) continue;
      const uri = entry.get('URI');
      const rawIv = entry.get('IV');
      const format = entry.get('KEYFORMAT');
      if (method !== 'AES-128' || !uri || (format !== undefined && format !== 'identity')
        || (rawIv !== undefined && !/^0x[0-9a-f]{1,32}$/i.test(rawIv))) {
        throw new WebDownloadError('这一档的加密方式暂不支持网页下载。');
      }
      const nextKey = { url: safeUrl(uri, base), iv: rawIv?.slice(2) };
      if ((urls.length && !key) || (key && (key.url !== nextKey.url || key.iv !== nextKey.iv))) {
        throw new WebDownloadError('这一档在播放中更换解密密钥，网页暂时无法完整保存。');
      }
      key = nextKey;
    } else if (line.startsWith('#EXTINF:')) {
      if (nextDuration) throw new WebDownloadError('HLS 播放列表缺少对应的视频分片。');
      nextDuration = Number(line.slice('#EXTINF:'.length).split(',', 1)[0]);
      if (!Number.isFinite(nextDuration) || nextDuration <= 0) throw new WebDownloadError('HLS 分片时长无效。');
    } else if (!line.startsWith('#')) {
      if (!nextDuration || urls.length >= 20_000) throw new WebDownloadError('HLS 视频分片无效或数量过多。');
      urls.push(safeUrl(line, base));
      duration += nextDuration;
      nextDuration = 0;
    }
  }
  if (!urls.length || nextDuration || sequence > Number.MAX_SAFE_INTEGER - urls.length) {
    throw new WebDownloadError('HLS 播放列表没有提供完整的视频分片。');
  }
  return { urls, duration, key, sequence };
}

export function webDownloadFilename(title: string) {
  return (title.replace(/[<>:"/\\|?*\u0000-\u001f]+/g, '_').trim().replace(/[ .]+$/, '').slice(0, 120) || 'PPS 视频') + '.mp4';
}

function preparedMemoryFile(filename: string, memoryBudget: number): StagedWebDownload {
  const chunks: Uint8Array<ArrayBuffer>[] = [];
  let bytes = 0;
  let closed = false;
  return {
    target: {
      kind: 'memory',
      async write(chunk) {
        bytes += chunk.byteLength;
        if (bytes > memoryBudget) throw new WebDownloadError(memoryLimitMessage(memoryBudget));
        chunks.push(chunk.slice());
      },
      async close() { closed = true; },
      async abort() { chunks.length = 0; },
    },
    async prepare() {
      if (!closed || !bytes || !chunks.length) throw new WebDownloadError('下载没有得到可保存的视频。');
      const url = URL.createObjectURL(new Blob(chunks, { type: 'video/mp4' }));
      chunks.length = 0;
      let disposed = false;
      return {
        kind: 'prepared', url, filename, bytes, storage: 'memory',
        dispose(saveRequested) {
          if (disposed) return;
          disposed = true;
          const release = () => URL.revokeObjectURL(url);
          if (saveRequested) setTimeout(release, 120_000);
          else release();
        },
      };
    },
  };
}

export function supportsWebDownloadStreaming(): boolean {
  return supportsFileSystemAccess() || supportsTemporaryWebFile();
}

async function openFileTarget(filename: string, background: boolean, memoryBudget: number): Promise<Pick<StagedWebDownload, 'target'> & Partial<StagedWebDownload>> {
  const picker = background || typeof window === 'undefined' ? undefined : (window as unknown as {
    showSaveFilePicker?: (options: { suggestedName: string }) => Promise<FileSystemFileHandle>;
  }).showSaveFilePicker;
  if (typeof picker === 'function') {
    try {
      const file = await picker.call(window, { suggestedName: filename });
      const writer = (await file.createWritable()).getWriter();
      return { target: {
        kind: 'fs',
        async write(bytes) { await writer.write(bytes); },
        async close() { await writer.close(); },
        async abort() { await writer.abort().catch(() => {}); },
      } };
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') throw new UserCancelledError();
      if (!(error instanceof DOMException) || !['SecurityError', 'NotSupportedError'].includes(error.name)) throw error;
    }
  }
  if (supportsTemporaryWebFile()) {
    try { return await createTemporaryWebFile(filename); }
    catch { /* Before writing video, bounded memory is still safe. */ }
  }
  return preparedMemoryFile(filename, memoryBudget);
}

function memoryLimitMessage(budget: number) {
  return budget < WEB_DOWNLOAD_MEMORY_LIMIT
    ? '浏览器的暂存空间已被其他待保存视频占用。请先保存并移除它们，再重试。'
    : MEMORY_LIMIT_MESSAGE;
}

function progress(opts: DownloadOptions, current: number, total: number) {
  opts.onProgress?.({ current, total, percentage: total > 0 ? Math.min(100, Math.round(current / total * 100)) : undefined });
}

function isMp4Header(bytes: Uint8Array): boolean {
  return bytes.length >= 8 && String.fromCharCode(...bytes.subarray(4, 8)) === 'ftyp';
}

async function saveMp4(opts: DownloadOptions, target: SaveTarget) {
  const response = await requestResource(opts.variant.url, opts.signal, 'MP4 视频');
  const total = contentLength(response) ?? 0;
  const budget = opts.memoryBudget ?? WEB_DOWNLOAD_MEMORY_LIMIT;
  const limit = target.kind === 'memory' ? budget : Infinity;
  const header = new Uint8Array(8);
  let headerLength = 0;
  const received = await transferResponse(response, opts.signal, limit, async (bytes, current) => {
    if (headerLength < header.length) {
      const consumed = Math.min(header.length - headerLength, bytes.length);
      header.set(bytes.subarray(0, consumed), headerLength);
      headerLength += consumed;
      if (headerLength < header.length) return;
      if (!isMp4Header(header)) throw new WebDownloadError('片源返回的数据不是完整的 MP4 文件。');
      await target.write(header);
      bytes = bytes.subarray(consumed);
    }
    if (bytes.length) await target.write(bytes);
    progress(opts, current, total);
  }, memoryLimitMessage(budget));
  if (headerLength < header.length || (total > 0 && received !== total)) {
    throw new WebDownloadError('片源没有返回完整的 MP4 文件。');
  }
  await target.close();
}

async function saveHls(opts: DownloadOptions, target: SaveTarget) {
  const { lines, base } = await fetchPlaylist(opts.variant.url, opts.signal);
  const playlist = mediaPlaylist(lines, base);
  const estimatedBytes = (opts.variant.bandwidth ?? 0) * playlist.duration / 8;
  const budget = opts.memoryBudget ?? WEB_DOWNLOAD_MEMORY_LIMIT;
  if (target.kind === 'memory' && estimatedBytes > budget) throw new WebDownloadError(memoryLimitMessage(budget));
  const key = playlist.key && await limitedBytes(await requestResource(playlist.key.url, opts.signal, '解密密钥'),
    opts.signal, 16, 'HLS 解密密钥格式无效。');
  if (key && key.byteLength !== 16) throw new WebDownloadError('HLS 解密密钥格式无效。');

  const decodeTimes = new Map<number, number>();
  const remuxer = new StreamingTransmuxer({ async write(bytes) {
    opts.signal.throwIfAborted();
    if (!validateFragmentTiming(bytes, decodeTimes)) {
      throw new WebDownloadError('视频分片的时间戳不连续，未保存不完整的视频。');
    }
    await target.write(bytes);
  } }, { durationSeconds: playlist.duration });
  let expectedAudio: boolean | undefined;
  progress(opts, 0, playlist.urls.length);
  for (const [index, url] of playlist.urls.entries()) {
    const bytes = await limitedBytes(await requestResource(url, opts.signal, `第 ${index + 1} 个视频分片`),
      opts.signal, SEGMENT_LIMIT, '单个视频分片过大，无法在网页内安全读取。');
    const decoded = key ? new Uint8Array(await decryptSegment(bytes.buffer, key, playlist.key?.iv, playlist.sequence, index)) : bytes;
    opts.signal.throwIfAborted();
    if (!decoded.length || decoded[0] !== 0x47 || decoded.length % 188 !== 0) {
      throw new WebDownloadError('这一档的 HLS 分片不是网页可转封装的 MPEG-TS 视频。');
    }
    const streams = readTsStreamTypes(decoded);
    const audioTracks = streams.filter((type) => type === 0x0f).length;
    if (streams.filter((type) => type === 0x1b).length !== 1 || audioTracks > 1
      || streams.some((type) => ![0x1b, 0x0f, 0x15].includes(type))) {
      throw new WebDownloadError('这一档的音视频轨道无法在网页内完整转封装。');
    }
    const containsAudio = audioTracks === 1;
    if (expectedAudio !== undefined && expectedAudio !== containsAudio) {
      throw new WebDownloadError('这一档在分片之间切换音轨，未保存不完整的视频。');
    }
    expectedAudio = containsAudio;
    const videoCount = remuxer.getVideoSegmentCount();
    const audioCount = remuxer.getAudioSegmentCount();
    await remuxer.pushAndTransmux(decoded);
    // The transmuxer may emit audio-only data for unsupported video codecs.
    if (remuxer.getVideoSegmentCount() === videoCount) {
      throw new WebDownloadError(`第 ${index + 1} 个分片的视频无法转封装，未保存不完整的视频。`);
    }
    if (containsAudio && remuxer.getAudioSegmentCount() === audioCount) {
      throw new WebDownloadError(`第 ${index + 1} 个分片的声音无法转封装，未保存不完整的视频。`);
    }
    progress(opts, index + 1, playlist.urls.length);
  }
  await remuxer.finish();
  opts.signal.throwIfAborted();
  await target.close();
}

/** Save exactly the selected variant. The caller may explicitly choose another after failure. */
export async function downloadWebVideo(opts: DownloadOptions): Promise<'saved' | 'browser' | PreparedWebDownload> {
  const { variant, signal } = opts;
  signal.throwIfAborted();
  if (variant.unsupported) throw new WebDownloadError(variant.unsupported);
  const url = safeUrl(variant.url);
  const filename = webDownloadFilename(opts.title);
  if (opts.kind === 'mp4' && variant.directAttachment && !opts.target && !opts.background) {
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.append(link);
    try { link.click(); } finally { link.remove(); }
    return 'browser';
  }
  let staged: Awaited<ReturnType<typeof openFileTarget>> | undefined;
  try {
    const budget = opts.memoryBudget ?? WEB_DOWNLOAD_MEMORY_LIMIT;
    staged = opts.target ? { target: opts.target } : await openFileTarget(filename, opts.background ?? false, budget);
    signal.throwIfAborted();
    if (staged.target.kind === 'memory' && (budget <= 0 || (variant.estimatedBytes ?? 0) > budget)) {
      throw new WebDownloadError(memoryLimitMessage(budget));
    }
    if (opts.kind === 'mp4') await saveMp4(opts, staged.target);
    else await saveHls(opts, staged.target);
    signal.throwIfAborted();
    if (!staged.prepare) return 'saved';
    const prepared = await staged.prepare();
    if (signal.aborted) { prepared.dispose(); signal.throwIfAborted(); }
    return prepared;
  } catch (error) {
    await staged?.target.abort().catch(() => {});
    signal.throwIfAborted();
    if (error instanceof WebDownloadError || error instanceof UserCancelledError) throw error;
    if (error instanceof DOMException && ['QuotaExceededError', 'NotReadableError'].includes(error.name)) {
      throw new WebDownloadError('设备暂存空间不足或文件无法写入，请检查存储空间后重试。');
    }
    throw new WebDownloadError('下载没有完成。可以重试当前画质，或手动选择其他画质。');
  }
}
