import { DISCOVERY_LISTS, DOUBAN_BROWSE_TAGS, type DiscoveryFilter, type DiscoveryListId } from './discovery';
// Retain the old public navigation field without importing the retired fixed catalog.
type PlatformId = 'iqiyi' | 'youku' | 'tencent';

export type DiscoveryType = 'movie' | 'tv' | 'show';
export type DiscoveryMode = 'ranking' | 'browse';
export interface DiscoveryView {
  type: DiscoveryType;
  listId: DiscoveryListId;
  mode: DiscoveryMode;
  platform: PlatformId;
  tag: string;
  filter: DiscoveryFilter;
}
export interface DiscoverySession extends DiscoveryView { scrollY: number }
export interface DiscoverySessionStorage { getItem(key: string): string | null; setItem(key: string, value: string): void }
/** Navigation state only. No source addresses, search terms, viewing records or media. */
export const DISCOVERY_SESSION_KEY = 'libretv-discovery-session-v1';
export const DEFAULT_DISCOVERY_VIEW: DiscoveryView = {
  type: 'movie', listId: 'douban_movie_weekly', mode: 'browse', platform: 'iqiyi', tag: '热门', filter: 'all',
};

function browserStorage(): DiscoverySessionStorage | undefined {
  try { return typeof window === 'undefined' ? undefined : window.sessionStorage; } catch { return undefined; }
}

function cleanSession(value: unknown): DiscoverySession | undefined {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return undefined;
  const input = value as Record<string, unknown>;
  const type = input.type;
  if (type !== 'movie' && type !== 'tv' && type !== 'show') return undefined;
  if (type === 'show' && input.mode !== 'ranking') return undefined;
  const mode = input.mode === 'catalog' ? 'browse' : input.mode;
  if (mode !== 'ranking' && mode !== 'browse') return undefined;
  const allowedLists = DISCOVERY_LISTS.filter((entry) => type === 'movie' ? !entry.isTv
    : type === 'show' ? entry.id.startsWith('douban_show_') : entry.isTv && !entry.id.startsWith('douban_show_')).map((entry) => entry.id);
  const list = DISCOVERY_LISTS.find((entry) => entry.id === input.listId && allowedLists.includes(entry.id));
  const platform = ['iqiyi', 'youku', 'tencent'].includes(String(input.platform)) ? input.platform as PlatformId : undefined;
  const tags = DOUBAN_BROWSE_TAGS[type === 'movie' ? 'movie' : 'tv'] as readonly string[];
  if (!list || !platform || typeof input.tag !== 'string' || !tags.includes(input.tag) ||
    !['all', 'high-rated', 'comedy'].includes(String(input.filter)) ||
    typeof input.scrollY !== 'number' || !Number.isFinite(input.scrollY) || input.scrollY < 0 || input.scrollY > 1_000_000) return undefined;
  return { type, mode, listId: list.id, platform, tag: input.tag,
    filter: input.filter as DiscoveryFilter, scrollY: Math.round(input.scrollY) };
}

export function readDiscoverySession(storage = browserStorage()): DiscoverySession | undefined {
  if (!storage) return undefined;
  try {
    const raw = storage.getItem(DISCOVERY_SESSION_KEY);
    return raw && raw.length <= 2048 ? cleanSession(JSON.parse(raw)) : undefined;
  } catch { return undefined; }
}

export function writeDiscoverySession(value: DiscoverySession, storage = browserStorage()): boolean {
  if (!storage) return false;
  const cleaned = cleanSession(value);
  if (!cleaned) return false;
  try { storage.setItem(DISCOVERY_SESSION_KEY, JSON.stringify(cleaned)); return true; } catch { return false; }
}
