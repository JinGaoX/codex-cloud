import { DISCOVERY_LISTS, DOUBAN_BROWSE_TAGS, type DiscoveryFilter, type DiscoveryListId } from './discovery';
import { PLATFORM_CHOICES, type PlatformId } from './platform-catalog';

export type DiscoveryType = 'movie' | 'tv' | 'show';
export type DiscoveryMode = 'ranking' | 'browse' | 'catalog';
export interface DiscoveryView {
  type: DiscoveryType;
  listId: DiscoveryListId;
  mode: DiscoveryMode;
  platform: PlatformId;
  tag: string;
  filter: DiscoveryFilter;
}
export interface DiscoverySession extends DiscoveryView { scrollY: number }
export interface DiscoverySessionStorage { getItem(key: string): string | null; setItem(key: string, value: string): void }
/** Navigation state only. No source addresses, search terms, viewing records or media. */
export const DISCOVERY_SESSION_KEY = 'libretv-discovery-session-v1';
export const DEFAULT_DISCOVERY_VIEW: DiscoveryView = {
  type: 'movie', listId: 'douban_movie_weekly', mode: 'ranking', platform: 'iqiyi', tag: '热门', filter: 'all',
};

function browserStorage(): DiscoverySessionStorage | undefined {
  try { return typeof window === 'undefined' ? undefined : window.sessionStorage; } catch { return undefined; }
}

function cleanSession(value: unknown): DiscoverySession | undefined {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return undefined;
  const input = value as Record<string, unknown>;
  const type = input.type;
  if (type !== 'movie' && type !== 'tv' && type !== 'show') return undefined;
  const mode = input.mode;
  if (mode !== 'ranking' && mode !== 'browse' && mode !== 'catalog' || type === 'show' && mode !== 'ranking') return undefined;
  const allowedLists = type === 'movie' ? ['douban_movie_weekly'] : type === 'tv'
    ? ['douban_tv_chinese', 'douban_tv_global', 'baidu_teleplay'] : ['douban_show_chinese', 'douban_show_global'];
  const list = DISCOVERY_LISTS.find((entry) => entry.id === input.listId && allowedLists.includes(entry.id));
  const platform = PLATFORM_CHOICES.find((entry) => entry.id === input.platform);
  const tags = DOUBAN_BROWSE_TAGS[type === 'movie' ? 'movie' : 'tv'] as readonly string[];
  if (!list || !platform || typeof input.tag !== 'string' || !tags.includes(input.tag) ||
    !['all', 'high-rated', 'comedy'].includes(String(input.filter)) ||
    typeof input.scrollY !== 'number' || !Number.isFinite(input.scrollY) || input.scrollY < 0 || input.scrollY > 1_000_000) return undefined;
  return { type, mode, listId: list.id, platform: platform.id, tag: input.tag,
    filter: input.filter as DiscoveryFilter, scrollY: Math.round(input.scrollY) };
}

export function readDiscoverySession(storage = browserStorage()): DiscoverySession | undefined {
  if (!storage) return undefined;
  try {
    const raw = storage.getItem(DISCOVERY_SESSION_KEY);
    return raw && raw.length <= 2048 ? cleanSession(JSON.parse(raw)) : undefined;
  } catch { return undefined; }
}

export function writeDiscoverySession(value: DiscoverySession, storage = browserStorage()): boolean {
  if (!storage) return false;
  const cleaned = cleanSession(value);
  if (!cleaned) return false;
  try { storage.setItem(DISCOVERY_SESSION_KEY, JSON.stringify(cleaned)); return true; } catch { return false; }
}
