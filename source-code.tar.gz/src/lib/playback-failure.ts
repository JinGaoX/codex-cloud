export interface PlaybackFailure {
  stage: string;
  reason: string;
  status?: number;
}

const httpErrorStatus = (status: number | undefined) =>
  typeof status === 'number' && Number.isInteger(status) && status >= 400 && status <= 599 ? status : undefined;

export const INVALID_PLAYBACK_ADDRESS: PlaybackFailure = {
  stage: '检查播放地址',
  reason: '当前版本无法使用这条视频地址。可以尝试有效的 HTTPS 播放链接。',
};

export const UNKNOWN_PLAYBACK_FAILURE: PlaybackFailure = {
  stage: '开始或恢复播放',
  reason: '播放器未能确认失败原因。可以重试，或尝试其他线路。',
};

export function detailPlaybackFailure(status?: number): PlaybackFailure {
  const httpStatus = httpErrorStatus(status);
  return {
    stage: '读取片源详情',
    reason: httpStatus
      ? '详情请求返回错误，播放器还未取得播放地址。'
      : '未能取得片源详情。当前无法确认是连接、片源响应还是设备访问限制。',
    status: httpStatus,
  };
}

export function nativePlaybackFailure(code?: number): PlaybackFailure {
  switch (code) {
    case 1: return { stage: '加载视频', reason: '播放器报告这次加载被中止。' };
    case 2: return { stage: '加载视频', reason: '播放器报告网络加载失败，具体原因未确定。' };
    case 3: return { stage: '解码视频', reason: '播放器报告解码失败。视频格式、数据损坏或设备支持情况都可能影响解码。' };
    case 4: return { stage: '开始播放', reason: '设备无法打开这条媒体地址。仅凭播放器反馈无法判断是线路响应还是媒体格式所致。' };
    default: return UNKNOWN_PLAYBACK_FAILURE;
  }
}

export function hlsPlaybackFailure(type: string, details: string, status?: number): PlaybackFailure {
  switch (details) {
    case 'manifestIncompatibleCodecsError':
    case 'bufferIncompatibleCodecsError':
      return { stage: '检查媒体编码', reason: '播放器报告当前线路的编码与设备不兼容。' };
    case 'bufferAddCodecError':
      return { stage: '准备媒体缓冲', reason: '播放器未能为这条线路建立媒体缓冲，具体原因未确定。' };
    case 'manifestParsingError':
    case 'levelParsingError':
    case 'levelEmptyError':
      return { stage: '解析播放列表', reason: '播放器无法从播放列表中读出可播放的视频。' };
    case 'manifestLoadError':
    case 'manifestLoadTimeOut':
    case 'levelLoadError':
    case 'levelLoadTimeOut':
    case 'audioTrackLoadError':
    case 'audioTrackLoadTimeOut':
      return hlsLoadFailure('加载播放列表', details.endsWith('TimeOut'), status);
    case 'fragLoadError':
    case 'fragLoadTimeOut':
      return hlsLoadFailure('加载视频分片', details.endsWith('TimeOut'), status);
    case 'keyLoadError':
    case 'keyLoadTimeOut':
      return hlsLoadFailure('加载解密密钥', details.endsWith('TimeOut'), status);
    case 'fragParsingError':
      return { stage: '解析视频分片', reason: '播放器无法读取这个视频分片的媒体数据。' };
    default:
      if (type === 'networkError') return hlsLoadFailure('加载视频', false, status);
      if (type === 'mediaError') return { stage: '处理视频', reason: '播放器报告媒体处理错误，尚无法确定是解码、缓冲还是其他问题。' };
      return UNKNOWN_PLAYBACK_FAILURE;
  }
}

function hlsLoadFailure(stage: string, timedOut: boolean, status?: number): PlaybackFailure {
  const httpStatus = httpErrorStatus(status);
  return {
    stage,
    reason: timedOut
      ? '请求超时，播放器未能及时收到数据。'
      : httpStatus
        ? '请求返回错误，播放器未能加载所需数据。'
        : '请求没有成功完成。当前无法确认是网络、源站限制还是线路失效。',
    status: httpStatus,
  };
}
