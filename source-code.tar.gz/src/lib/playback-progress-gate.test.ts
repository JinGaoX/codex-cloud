import { describe, expect, it } from 'vitest';
import { PlaybackProgressGate } from './playback-progress-gate';

describe('PlaybackProgressGate', () => {
  it('恢复旧秒数、未播放的timeupdate与卸载不产生新观看', () => {
    const gate = new PlaybackProgressGate();
    gate.observe(620, 7200);
    gate.pause(620, 7200);
    expect(gate.take()).toBeNull();
  });

  it('只有seek、metadata和暂停，不能把目标位置当成观看', () => {
    const gate = new PlaybackProgressGate();
    gate.seekStart(); gate.observe(1800, 7200); gate.seekEnd(1800);
    gate.pause(1800, 7200);
    expect(gate.take()).toBeNull();
  });

  it('playing本身仍不等于位置实际前进', () => {
    const gate = new PlaybackProgressGate();
    gate.start(620); gate.observe(620, 7200); gate.pause(620, 7200);
    expect(gate.take()).toBeNull();
  });

  it('正常播放后暂停会保留尚未timeupdate的最后几秒', () => {
    const gate = new PlaybackProgressGate();
    gate.start(20); gate.observe(22, 7200);
    expect(gate.take()).toEqual({ position: 22, duration: 7200 });
    gate.pause(24.75, 7200);
    expect(gate.take()).toEqual({ position: 24.75, duration: 7200 });
  });

  it('重复pause、隐藏、卸载及相同位置不刷新保存时间', () => {
    const gate = new PlaybackProgressGate();
    gate.start(20); gate.observe(22, 7200); gate.pause(22.5, 7200);
    expect(gate.take()).toEqual({ position: 22.5, duration: 7200 });
    gate.pause(22.5, 7200); gate.observe(22.5, 7200);
    expect(gate.take()).toBeNull();
  });

  it('暂停seek不覆盖此前真实位置，随后实际播放才记录新位置', () => {
    const gate = new PlaybackProgressGate();
    gate.start(20); gate.pause(24, 7200);
    gate.seekStart(); gate.seekEnd(600); gate.observe(600, 7200);
    expect(gate.take()).toEqual({ position: 24, duration: 7200 });
    gate.pause(600, 7200);
    expect(gate.take()).toBeNull();
    gate.start(600); gate.observe(600.5, 7200);
    expect(gate.take()).toEqual({ position: 600.5, duration: 7200 });
  });

  it('播放中seek跳跃不作为进度，但seek后的连续前进可以保存', () => {
    const gate = new PlaybackProgressGate();
    gate.start(20); gate.observe(22, 7200); gate.take();
    gate.seekStart(); gate.observe(1000, 7200);
    expect(gate.take()).toBeNull();
    gate.seekEnd(1000); gate.observe(1000, 7200);
    expect(gate.take()).toBeNull();
    gate.observe(1000.2, 7200);
    expect(gate.take()).toEqual({ position: 1000.2, duration: 7200 });
  });

  it('切源或换集reset后旧playing状态、pending及旧位置不会沿用', () => {
    const gate = new PlaybackProgressGate();
    gate.start(20); gate.observe(23, 7200); gate.reset();
    gate.observe(1200, 3600); gate.pause(1200, 3600);
    expect(gate.take()).toBeNull();
    gate.start(1200); gate.observe(1200.3, 3600);
    expect(gate.take()).toEqual({ position: 1200.3, duration: 3600 });
  });

  it('后台仍在实际播放时可刷新，暂停后切回或离开不会刷新', () => {
    const gate = new PlaybackProgressGate();
    gate.start(100); gate.observe(105, 7200);
    expect(gate.take()).toEqual({ position: 105, duration: 7200 });
    gate.pause(106, 7200); gate.take();
    gate.observe(106, 7200);
    expect(gate.take()).toBeNull();
  });

  it('同集传输重建中断seek后，实际playing重新建立有效观察基准', () => {
    const gate = new PlaybackProgressGate();
    gate.start(100); gate.observe(102, 7200); gate.take();
    gate.seekStart(); gate.pause(500, 7200);
    expect(gate.take()).toBeNull();
    gate.start(102); gate.observe(102.5, 7200);
    expect(gate.take()).toEqual({ position: 102.5, duration: 7200 });
  });

  it('片尾最终源时间可以保存，重置后不会复写已结束记录', () => {
    const gate = new PlaybackProgressGate();
    gate.start(98); gate.observe(100, 100);
    expect(gate.take()).toEqual({ position: 100, duration: 100 });
    gate.reset(); gate.pause(100, 100);
    expect(gate.take()).toBeNull();
  });

  it('过滤广告后的源时间照常保存，不转换为压缩播放时间', () => {
    const gate = new PlaybackProgressGate();
    gate.start(302); gate.observe(321.2, 7200);
    expect(gate.take()).toEqual({ position: 321.2, duration: 7200 });
  });

  it.each([NaN, Infinity, -1])('无效位置%s不能生成记录', (position) => {
    const gate = new PlaybackProgressGate();
    gate.start(0); gate.observe(position, 7200); gate.pause(position, 7200);
    expect(gate.take()).toBeNull();
  });

  it.each([0, NaN, Infinity, -1])('无效时长%s不能生成记录', (duration) => {
    const gate = new PlaybackProgressGate();
    gate.start(0); gate.observe(2, duration);
    expect(gate.take()).toBeNull();
  });
});
