import type { SaveTarget } from './download-saver';

const TEMP_FOLDER = 'pps-video-exports-v1';
const PERSISTENT_FOLDER = 'pps-video-download-results-v1';
const TEMP_NAME = /^\d{13}-[a-f0-9-]{36}\.mp4$/;
const STORAGE_ID = /^[a-f0-9]{8}-(?:[a-f0-9]{4}-){3}[a-f0-9]{12}$/i;
const STALE_AFTER_MS = 2 * 24 * 60 * 60 * 1000;
const SAVE_GRACE_MS = 120_000;

export interface PreparedWebDownload {
  kind: 'prepared';
  url: string;
  filename: string;
  bytes: number;
  storage: 'disk' | 'memory';
  storageId?: string;
  /** Delay cleanup if the browser was asked to save this file. */
  dispose: (saveRequested?: boolean, retainStorage?: boolean) => void;
}

export interface StagedWebDownload {
  target: SaveTarget;
  prepare: () => Promise<PreparedWebDownload>;
}

export function supportsTemporaryWebFile(): boolean {
  return typeof navigator !== 'undefined'
    && typeof navigator.storage?.getDirectory === 'function'
    && typeof FileSystemFileHandle !== 'undefined'
    && typeof FileSystemFileHandle.prototype.createWritable === 'function';
}

export function isWebDownloadStorageId(value: unknown): value is string {
  return typeof value === 'string' && STORAGE_ID.test(value);
}

function persistentName(storageId: string): string {
  if (!isWebDownloadStorageId(storageId)) throw new TypeError('Invalid download storage ID.');
  return `${storageId}.mp4`;
}

function preparedFile(
  blob: Blob, filename: string, release: () => Promise<void>, storageId?: string,
): PreparedWebDownload {
  const url = URL.createObjectURL(blob);
  let disposed = false;
  return {
    kind: 'prepared',
    url,
    filename,
    bytes: blob.size,
    storage: 'disk',
    ...(storageId && { storageId }),
    dispose(saveRequested, retainStorage = false) {
      if (disposed) return;
      disposed = true;
      const cleanup = () => {
        URL.revokeObjectURL(url);
        if (!retainStorage) void release().catch(() => {});
      };
      if (saveRequested) setTimeout(cleanup, SAVE_GRACE_MS);
      else cleanup();
    },
  };
}

async function clearExpiredFiles(folder: FileSystemDirectoryHandle, now: number) {
  // TypeScript's DOM library omits directory iteration in some supported versions.
  const entries = (folder as FileSystemDirectoryHandle & { keys?: () => AsyncIterable<string> }).keys?.();
  if (!entries) return;
  for await (const name of entries) {
    if (TEMP_NAME.test(name) && now - Number(name.slice(0, 13)) > STALE_AFTER_MS) {
      await folder.removeEntry(name).catch(() => {});
    }
  }
}

/** Write sequentially to browser-owned disk and expose a file only after close succeeds. */
export async function createTemporaryWebFile(filename: string, storageId?: string): Promise<StagedWebDownload> {
  const root = await navigator.storage.getDirectory();
  const folder = await root.getDirectoryHandle(storageId === undefined ? TEMP_FOLDER : PERSISTENT_FOLDER, { create: true });
  const now = Date.now();
  if (storageId === undefined) void clearExpiredFiles(folder, now).catch(() => {});
  const temporaryName = storageId === undefined ? `${now}-${crypto.randomUUID()}.mp4` : persistentName(storageId);
  const release = () => folder.removeEntry(temporaryName).catch(() => {});
  let file: FileSystemFileHandle;
  let writer: WritableStreamDefaultWriter;
  try {
    file = await folder.getFileHandle(temporaryName, { create: true });
    writer = (await file.createWritable()).getWriter();
  } catch (error) {
    await release();
    throw error;
  }
  let complete = false;
  return {
    target: {
      kind: 'fs',
      async write(bytes) { await writer.write(bytes); },
      async close() { await writer.close(); complete = true; },
      async abort() {
        try { if (!complete) await writer.abort(); }
        catch { /* Still remove the incomplete file. */ }
        await release();
      },
    },
    async prepare() {
      if (!complete) throw new Error('视频尚未保存完整。');
      const blob = await file.getFile();
      if (!blob.size) throw new Error('下载没有得到可保存的视频。');
      return preparedFile(blob, filename, release, storageId);
    },
  };
}

/** A new writable stream only replaces the on-disk file after it closes successfully. */
export async function restorePreparedWebDownload(storageId: string, filename: string): Promise<PreparedWebDownload | null> {
  const name = persistentName(storageId);
  try {
    const root = await navigator.storage.getDirectory();
    const folder = await root.getDirectoryHandle(PERSISTENT_FOLDER);
    const handle = await folder.getFileHandle(name);
    const file = await handle.getFile();
    return file.size ? preparedFile(file, filename, () => folder.removeEntry(name), storageId) : null;
  } catch (error) {
    if (error instanceof DOMException && error.name === 'NotFoundError') return null;
    throw error;
  }
}

export async function removePersistentWebDownload(storageId: string): Promise<void> {
  const name = persistentName(storageId);
  try {
    const root = await navigator.storage.getDirectory();
    const folder = await root.getDirectoryHandle(PERSISTENT_FOLDER);
    await folder.removeEntry(name);
  } catch (error) {
    if (!(error instanceof DOMException) || error.name !== 'NotFoundError') throw error;
  }
}
