import { appPath } from './app-path';

export type AppUpdatePhase = 'idle' | 'checking' | 'current' | 'available' | 'applying' | 'failed' | 'unsupported';
export interface AppUpdateState {
  phase: AppUpdatePhase;
  /** User-triggered feedback stays inside Settings; there is no global banner. */
  message?: string;
}

const initialState: AppUpdateState = { phase: 'idle' };
let state = initialState;
const listeners = new Set<() => void>();
let registration: ServiceWorkerRegistration | undefined;
let registrationPromise: Promise<ServiceWorkerRegistration> | undefined;
let observeRegistration: ((current: ServiceWorkerRegistration) => void) | undefined;
let waiting: ServiceWorker | null = null;
let reloadRequested = false;
let reloadReady = false;
let activationTimer: ReturnType<typeof setTimeout> | undefined;
let installationTimer: ReturnType<typeof setTimeout> | undefined;
let checkSequence = 0;
export const APP_UPDATE_CHECK_TIMEOUT_MS = 15_000;
export const APP_UPDATE_INSTALL_TIMEOUT_MS = 70_000;

function bounded<T>(operation: Promise<T>, timeout: number): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('App update timed out')), timeout);
    operation.then((value) => { clearTimeout(timer); resolve(value); }, (error: unknown) => { clearTimeout(timer); reject(error); });
  });
}

function clearInstallationTimer(): void {
  if (installationTimer !== undefined) clearTimeout(installationTimer);
  installationTimer = undefined;
}

function observeInstallationDeadline(): void {
  clearInstallationTimer();
  publish({ phase: 'checking', message: '正在下载新版应用，请保持联网。' });
  installationTimer = setTimeout(() => {
    installationTimer = undefined;
    if (state.phase === 'checking') publish({ phase: 'failed', message: '新版下载超时，旧版和本机资料仍保留，请稍后重试。' });
  }, APP_UPDATE_INSTALL_TIMEOUT_MS);
}

function clearActivationTimer(): void {
  if (activationTimer !== undefined) clearTimeout(activationTimer);
  activationTimer = undefined;
}

export const getAppUpdateState = () => state;
export const getServerAppUpdateState = () => initialState;
export function subscribeAppUpdates(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

function publish(next: AppUpdateState): void {
  if (next.phase !== 'checking') clearInstallationTimer();
  state = next;
  for (const listener of listeners) listener();
}

function hasPlayingMedia(): boolean {
  return [...document.querySelectorAll<HTMLMediaElement>('video, audio')]
    .some((media) => !media.paused && !media.ended);
}

function inspectWaiting(): boolean {
  waiting = registration?.waiting ?? null;
  if (waiting && navigator.serviceWorker.controller) {
    publish({ phase: 'available' });
    return true;
  }
  return false;
}

function registerAppWorker(): Promise<ServiceWorkerRegistration> {
  if (registrationPromise) return registrationPromise;
  const pending = bounded(navigator.serviceWorker.register(appPath('/sw-standalone.js'), {
    scope: appPath('/'), updateViaCache: 'none',
  }), APP_UPDATE_CHECK_TIMEOUT_MS);
  registrationPromise = pending;
  // A transient initial network failure must not poison every later manual check.
  void pending.catch(() => {
    if (registrationPromise === pending) registrationPromise = undefined;
  });
  return pending;
}

/** Register and prepare public app files silently; never interrupt a playing video. */
export function startQuietAppUpdates(): () => void {
  if (!('serviceWorker' in navigator) || !window.isSecureContext) {
    publish({ phase: 'unsupported' });
    return () => {};
  }
  let disposed = false;
  let hadController = !!navigator.serviceWorker.controller;
  const removeListeners: (() => void)[] = [];
  const onControllerChange = () => {
    if (!reloadRequested) {
      // Another open tab may have activated the new worker. This page still
      // runs its old bundle until explicitly reloaded; never report it current.
      if (hadController) {
        reloadReady = true;
        publish({ phase: 'available', message: '新版已准备好，点击更新即可重新打开。' });
      }
      hadController = true;
      return;
    }
    clearActivationTimer();
    reloadRequested = false;
    if (hasPlayingMedia()) {
      reloadReady = true;
      publish({ phase: 'available', message: '新版已准备好，请暂停视频后重新打开。' });
      return;
    }
    window.location.reload();
  };
  navigator.serviceWorker.addEventListener('controllerchange', onControllerChange);
  removeListeners.push(() => navigator.serviceWorker.removeEventListener('controllerchange', onControllerChange));

  const observed = new WeakSet<ServiceWorkerRegistration>();
  const observe = (current: ServiceWorkerRegistration) => {
    if (disposed) return;
    registration = current;
    if (observed.has(current)) return;
    observed.add(current);
    const inspectInstalling = () => {
      const worker = current.installing;
      if (!worker) return;
      if (state.phase === 'checking') observeInstallationDeadline();
      const onStateChange = () => {
        if (disposed || inspectWaiting()) return;
        if (worker.state === 'activated') publish({ phase: reloadReady ? 'available' : 'current' });
        else if (worker.state === 'redundant' && state.phase === 'checking') publish({ phase: 'failed' });
      };
      worker.addEventListener('statechange', onStateChange);
      removeListeners.push(() => worker.removeEventListener('statechange', onStateChange));
    };
    current.addEventListener('updatefound', inspectInstalling);
    removeListeners.push(() => current.removeEventListener('updatefound', inspectInstalling));
    inspectInstalling();
    inspectWaiting();
  };
  observeRegistration = observe;
  void registerAppWorker().then(observe).catch(() => {
    if (!disposed) publish({ phase: 'failed' });
  });

  return () => {
    disposed = true;
    checkSequence++;
    reloadRequested = false;
    if (observeRegistration === observe) observeRegistration = undefined;
    clearActivationTimer();
    clearInstallationTimer();
    if (state.phase === 'checking') publish({ phase: 'idle' });
    else if (state.phase === 'applying') publish({ phase: 'available' });
    for (const remove of removeListeners) remove();
  };
}

/** Status is shown only in the update settings panel the user opened. */
export async function checkForAppUpdate(): Promise<void> {
  if (!('serviceWorker' in navigator) || !window.isSecureContext) {
    publish({ phase: 'unsupported' });
    return;
  }
  if (state.phase === 'checking' || state.phase === 'applying') return;
  const sequence = ++checkSequence;
  publish({ phase: 'checking' });
  try {
    await bounded((async () => {
      if (!registration) {
      // Existing offline installs may have a usable registration even if register
      // could not refresh its script on startup. New installs can retry normally.
        const current = await navigator.serviceWorker.getRegistration(appPath('/')) ?? await registerAppWorker();
        if (sequence !== checkSequence) return;
        registration = current;
        observeRegistration?.(current);
      }
      if (sequence !== checkSequence || !registration) return;
      if (inspectWaiting()) return;
      await registration.update();
    })(), APP_UPDATE_CHECK_TIMEOUT_MS);
    if (sequence !== checkSequence || !registration) return;
    if (!inspectWaiting() && !registration.installing) {
      publish({ phase: reloadReady ? 'available' : 'current' });
    } else if (registration.installing && getAppUpdateState().phase === 'checking') observeInstallationDeadline();
  } catch {
    if (sequence === checkSequence) {
      checkSequence++;
      if (registration?.installing && getAppUpdateState().phase === 'checking') observeInstallationDeadline();
      else publish({ phase: 'failed', message: '检查更新超时或网络暂不可用，请联网后重试。' });
    }
  }
}

/** Explicit activation only; a controller update from another tab never reloads this one. */
export function applyAppUpdate(): void {
  if (hasPlayingMedia()) {
    publish({ phase: 'available', message: '请先暂停视频，再更新应用。' });
    return;
  }
  if (reloadReady) {
    reloadReady = false;
    window.location.reload();
    return;
  }
  waiting = registration?.waiting ?? waiting;
  if (!waiting) return;
  // A different tab may already have activated this worker. This click still
  // explicitly opts this paused page into reloading its prepared app resources.
  if (waiting.state === 'activated') {
    window.location.reload();
    return;
  }
  reloadRequested = true;
  publish({ phase: 'applying' });
  clearActivationTimer();
  activationTimer = setTimeout(() => {
    reloadRequested = false;
    publish({ phase: 'available', message: '暂未完成更新，可以稍后重试。' });
  }, 15_000);
  try {
    waiting.postMessage({ type: 'ACTIVATE_UPDATE' });
  } catch {
    clearActivationTimer();
    reloadRequested = false;
    publish({ phase: 'failed', message: '暂未完成更新，请重新检查。' });
  }
}
