type KeyboardViewport = Pick<VisualViewport, 'width' | 'height' | 'scale'>;

interface KeyboardGeometry {
  viewport: KeyboardViewport | null;
  layoutWidth: number;
  layoutHeight: number;
  editableFocused: boolean;
}

/** Focus alone also covers dismissed and hardware keyboards. Require occluded space. */
export function isSoftwareKeyboardVisible({ viewport, layoutWidth, layoutHeight, editableFocused }: KeyboardGeometry): boolean {
  if (!editableFocused || !viewport || layoutWidth <= 0 || layoutHeight <= 0) return false;
  const { width, height, scale } = viewport;
  if (![layoutWidth, layoutHeight, width, height, scale].every((value) => Number.isFinite(value) && value > 0)) return false;

  // Pinch zoom reduces CSS viewport dimensions without opening a keyboard.
  const visibleWidth = width * scale;
  const visibleHeight = height * scale;
  // Rotation can report the old layout and new visual viewport in separate events.
  if (Math.abs(layoutWidth - visibleWidth) > Math.max(8, layoutWidth * .04)) return false;

  // Browser chrome and hardware-keyboard accessory rows are much smaller than an
  // on-screen keyboard. Floating keyboards that do not occlude the viewport keep
  // navigation available, as do browsers without usable visualViewport geometry.
  return layoutHeight - visibleHeight >= Math.max(120, layoutHeight * .18);
}

function hasEditableFocus(active: Element | null): boolean {
  if (!(active instanceof HTMLElement) || active.inputMode === 'none') return false;
  if (active.isContentEditable) return true;
  if (active instanceof HTMLTextAreaElement) return !active.readOnly && !active.disabled;
  return active instanceof HTMLInputElement && !active.readOnly && !active.disabled &&
    /^(text|search|password|email|url|tel|number)$/.test(active.type);
}

/** Recheck geometry when iOS dismisses its keyboard without blurring the field. */
export function observeSoftwareKeyboard(
  onChange: (visible: boolean) => void,
  browserWindow: Window = window,
  browserDocument: Document = document,
): () => void {
  const viewport = browserWindow.visualViewport;
  if (!viewport) {
    onChange(false);
    return () => {};
  }

  let frame: number | undefined;
  let orientationTimer: number | undefined;
  const sync = () => {
    frame = undefined;
    const root = browserDocument.documentElement;
    onChange(isSoftwareKeyboardVisible({
      viewport,
      layoutWidth: root.clientWidth || browserWindow.innerWidth,
      layoutHeight: Math.max(root.clientHeight, browserWindow.innerHeight),
      editableFocused: hasEditableFocus(browserDocument.activeElement),
    }));
  };
  const schedule = () => {
    if (frame === undefined) frame = browserWindow.requestAnimationFrame(sync);
  };
  const onOrientationChange = () => {
    schedule();
    browserWindow.clearTimeout(orientationTimer);
    // Safari may settle the layout after the first rotation resize event.
    orientationTimer = browserWindow.setTimeout(schedule, 300);
  };

  browserDocument.addEventListener('focusin', schedule);
  browserDocument.addEventListener('focusout', schedule);
  browserDocument.addEventListener('visibilitychange', schedule);
  viewport.addEventListener('resize', schedule);
  viewport.addEventListener('scroll', schedule);
  browserWindow.addEventListener('resize', schedule);
  browserWindow.addEventListener('orientationchange', onOrientationChange);
  sync();

  return () => {
    if (frame !== undefined) browserWindow.cancelAnimationFrame(frame);
    browserWindow.clearTimeout(orientationTimer);
    browserDocument.removeEventListener('focusin', schedule);
    browserDocument.removeEventListener('focusout', schedule);
    browserDocument.removeEventListener('visibilitychange', schedule);
    viewport.removeEventListener('resize', schedule);
    viewport.removeEventListener('scroll', schedule);
    browserWindow.removeEventListener('resize', schedule);
    browserWindow.removeEventListener('orientationchange', onOrientationChange);
  };
}
