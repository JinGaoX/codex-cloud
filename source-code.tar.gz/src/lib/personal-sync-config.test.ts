import { describe, expect, it } from 'vitest';
import { parseSyncConfiguration, syncAuthStorageKey } from './personal-sync-config';

const endpoint = 'https://family-project.supabase.co';
const publicKey = 'sb_publishable_test_only_12345678';
const jwt = (role: string) => [btoa('{"alg":"HS256","typ":"JWT"}'), btoa(JSON.stringify({ role, iss: 'supabase' })), 'test-signature'].map((part) => part.replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_')).join('.');

describe('个人同步公开配置', () => {
  it('未配置时明确关闭，不注入演示账号或后端', () => {
    expect(parseSyncConfiguration()).toBeNull();
    expect(parseSyncConfiguration(' ', ' ')).toBeNull();
  });
  it('接受公开密钥并规范为 HTTPS origin', () => {
    expect(parseSyncConfiguration(endpoint + '/', publicKey)).toEqual({ url: endpoint, publishableKey: publicKey });
  });
  it('兼容 role=anon 的旧公开 JWT', () => {
    expect(parseSyncConfiguration(endpoint, jwt('anon'))?.publishableKey).toBe(jwt('anon'));
  });
  it.each(['sb_secret_do_not_publish_1234', jwt('service_role'), jwt('authenticated'), 'not-a-key'])('拒绝非公开密钥 %s', (key) => {
    expect(() => parseSyncConfiguration(endpoint, key)).toThrow('公开连接密钥');
  });
  it.each(['http://family-project.supabase.co', endpoint + '/rest/v1', 'https://name:password@family-project.supabase.co', endpoint + '?', endpoint + '#', endpoint + '/?secret=private'])('拒绝不安全或带路径/参数的地址 %s', (url) => {
    expect(() => parseSyncConfiguration(url, publicKey)).toThrow('HTTPS');
  });
  it('缺少任一配置就报错，不回退其他服务', () => {
    expect(() => parseSyncConfiguration(endpoint)).toThrow('不完整');
    expect(() => parseSyncConfiguration(undefined, publicKey)).toThrow('不完整');
  });
  it('不同后端的认证缓存分开保存', () => {
    expect(syncAuthStorageKey({ url: endpoint, publishableKey: publicKey }))
      .not.toBe(syncAuthStorageKey({ url: 'https://other.supabase.co', publishableKey: publicKey }));
  });
});
