import Dexie, { liveQuery } from 'dexie';
import type { SupabaseClient } from '@supabase/supabase-js';
import { db, type FavoriteEntry, type HistoryEntry, type ProgressEntry } from './db';
import { useAppStore } from './store';
import { databaseNameForScope, scopeId, settingsKeyForScope, type AccountScope } from './account-scope';
import { flushPendingPersist, PERSIST_KEY } from './persist-storage';
import { snapshotToRecords, validateSyncResponse, type SnapshotRecord, type SyncRecord } from './personal-sync-model';
import { PersonalSyncQueue, type SyncQueueState } from './personal-sync-queue';
import { planSyncApply, type LocalSyncSnapshot } from './personal-sync-apply';
import { ownsSyncLease, releaseSyncLease, renewSyncLease, tryAcquireSyncLease, SYNC_LEASE_HEARTBEAT_MS, type SyncLease } from './personal-sync-lease';
import type { SourceConfig } from './types';

export interface PersonalSyncStatus {
  status: 'local' | 'idle' | 'syncing' | 'offline' | 'error' | 'conflict' | 'auth-required';
  pendingCount: number; conflictCount: number; lastSyncedAt: number | null; error: string | null;
}
interface SourceProjection {
  id: string; customAPIs: SourceConfig[]; selectedKeys: string[];
  expected: { customAPIs: SourceConfig[]; selectedKeys: string[] };
}
interface StoredValue {
  queue: SyncQueueState; aliases: SourceConfig[]; lastSyncedAt: number | null; sourceProjection?: SourceProjection;
}
class LeaseLost extends Error { constructor() { super('另一个页面已接管同步，本机资料仍然保留'); } }
class SnapshotChanged extends Error { constructor() { super('本机记录有新修改，将在下次同步时重试'); } }
const object = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);
const sorted = (value: unknown): unknown => Array.isArray(value) ? value.map(sorted) : object(value)
  ? Object.fromEntries(Object.entries(value).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, entry]) => [key, sorted(entry)])) : value;
const same = (a: unknown, b: unknown) => JSON.stringify(sorted(a)) === JSON.stringify(sorted(b));
const view = (value: { customAPIs: SourceConfig[]; selectedKeys: string[] }) => ({ customAPIs: value.customAPIs, selectedKeys: value.selectedKeys });

/** Only explicit logout removes private account cache. Original guest data is never removed. */
export async function clearAccountCache(scope: AccountScope) {
  flushPendingPersist();
  const name = databaseNameForScope(scope);
  if (name === 'libretv') throw new Error('不能删除本机游客资料');
  if (db.name === name) db.close();
  await Dexie.delete(name);
  await Dexie.delete('pps-sync-meta-v1:' + scopeId(scope));
  localStorage.removeItem(settingsKeyForScope(PERSIST_KEY, scope));
  localStorage.removeItem(settingsKeyForScope('pps-sync-projection', scope));
}

/** One fenced writer per account DB; the player keeps local records without remote seeking. */
export class PersonalSyncRuntime {
  private queue = new PersonalSyncQueue();
  private aliases: SourceConfig[] = [];
  private lastSyncedAt: number | null = null;
  private sourceProjection: SourceProjection | undefined;
  private lease: SyncLease | null = null;
  private readonly ownerToken = crypto.randomUUID();
  private stopped = true;
  private applying = false;
  private heartbeating = false;
  private serial: Promise<unknown> = Promise.resolve();
  private releasePending: Promise<void> = Promise.resolve();
  private inFlight: Promise<void> | null = null;
  private abort: AbortController | null = null;
  private timer: ReturnType<typeof setInterval> | undefined;
  private heartbeatTimer: ReturnType<typeof setInterval> | undefined;
  private captureTimer: ReturnType<typeof setTimeout> | undefined;
  private cleanups: Array<() => void> = [];
  private state: PersonalSyncStatus = { status: 'idle', pendingCount: 0, conflictCount: 0, lastSyncedAt: null, error: null };

  constructor(private client: SupabaseClient, private scope: AccountScope,
    private onChange: (state: PersonalSyncStatus) => void, private database: typeof db = db) {}
  private exclusive<T>(operation: () => Promise<T>): Promise<T> {
    const next = this.serial.then(operation);
    this.serial = next.catch(() => {});
    return next;
  }
  private report(patch: Partial<PersonalSyncStatus> = {}) {
    this.state = { ...this.state, ...patch, pendingCount: Object.keys(this.queue.state.pending).length,
      conflictCount: Object.keys(this.queue.state.conflicts).length, lastSyncedAt: this.lastSyncedAt };
    if (!this.stopped) this.onChange(this.state);
  }
  private checkpoint(): StoredValue {
    return structuredClone({ queue: this.queue.state, aliases: this.aliases, lastSyncedAt: this.lastSyncedAt, sourceProjection: this.sourceProjection });
  }
  private restore(value: StoredValue) {
    this.queue = new PersonalSyncQueue(structuredClone(value.queue));
    this.aliases = structuredClone(value.aliases ?? []);
    this.lastSyncedAt = value.lastSyncedAt ?? null;
    this.sourceProjection = value.sourceProjection && structuredClone(value.sourceProjection);
  }
  private async fence(claim: SyncLease) {
    const current = () => !this.stopped && this.lease?.epoch === claim.epoch && this.lease.ownerToken === claim.ownerToken;
    // stop()/account switch can happen while the IndexedDB ownership read is pending.
    if (!current() || !await ownsSyncLease(this.database, claim) || !current()) throw new LeaseLost();
  }
  private dropLeadership() { this.lease = null; this.abort?.abort(); }
  private async save(claim: SyncLease) {
    const value = this.checkpoint();
    await this.database.transaction('rw', this.database.personalSyncState, async () => {
      await this.fence(claim);
      await this.database.personalSyncState.put({ key: 'main', value });
      await this.fence(claim);
    });
  }
  private remember(sources: SourceConfig[]) {
    for (const source of sources) if (!this.aliases.some((known) => known.key === source.key && known.url === source.url)) this.aliases.push({ ...source });
  }
  private async snapshot(): Promise<LocalSyncSnapshot> {
    const store = useAppStore.getState();
    const customAPIs = structuredClone(store.customAPIs), envSources = structuredClone(store.envSources), selectedKeys = [...store.selectedKeys];
    const [history, progress, favorites] = await this.database.transaction('r',
      [this.database.history, this.database.progress, this.database.favorites], () => Promise.all([
        this.database.history.toArray(), this.database.progress.toArray(), this.database.favorites.toArray(),
      ]));
    const sources = [...envSources, ...customAPIs];
    this.remember(sources);
    return { sources, customAPIs, envSources, selectedKeys, history, progress, favorites, sourceAliases: this.aliases };
  }
  private async recoverProjection() {
    const projection = this.sourceProjection;
    if (!projection) return;
    if (this.stopped || !this.lease) throw new LeaseLost();
    const marker = settingsKeyForScope('pps-sync-projection', this.scope);
    if (localStorage.getItem(marker) === projection.id) return;
    const previousApplying = this.applying;
    this.applying = true;
    try {
      const current = view(useAppStore.getState());
      const target = view(projection);
      if (!same(current, target) && !projection.expected) {
        throw new Error('片源恢复日志缺少原始基线，已保留本机资料并暂停同步');
      }
      // The committed target may not have reached localStorage before a crash.
      // Reapply only if the original source view still exists. A later edit wins.
      if (!same(current, target) && same(current, projection.expected)) {
        useAppStore.setState({ customAPIs: structuredClone(projection.customAPIs), selectedKeys: [...projection.selectedKeys] });
      }
      flushPendingPersist();
      const persisted: unknown = JSON.parse(localStorage.getItem(settingsKeyForScope(PERSIST_KEY, this.scope)) ?? '{}');
      if (!object(persisted) || !object(persisted.state) || !same(view(useAppStore.getState()), {
        customAPIs: persisted.state.customAPIs, selectedKeys: persisted.state.selectedKeys,
      })) throw new Error('账号片源尚未保存到本机，请检查存储空间后重试');
      localStorage.setItem(marker, projection.id);
    } finally { this.applying = previousApplying; }
  }
  private async ensureLeadership(): Promise<boolean> {
    if (this.stopped) return false;
    if (!useAppStore.persist.hasHydrated()) throw new Error('本机片源配置尚未恢复，已暂停同步以保护资料');
    if (this.lease && await ownsSyncLease(this.database, this.lease)) return true;
    this.dropLeadership();
    const claim = await tryAcquireSyncLease(this.database, scopeId(this.scope), this.ownerToken);
    if (!claim) return false;
    this.lease = claim;
    try {
      const saved = await this.database.transaction('r', this.database.personalSyncState, async () => {
        await this.fence(claim); return this.database.personalSyncState.get('main');
      });
      if (saved) {
        if (!object(saved.value) || !object(saved.value.queue) || saved.value.queue.version !== 1) throw new Error('本机同步日志格式损坏，原资料未覆盖');
        this.restore(saved.value as unknown as StoredValue);
      } else { this.queue = new PersonalSyncQueue(); this.aliases = []; this.lastSyncedAt = null; this.sourceProjection = undefined; }
      await this.recoverProjection();
      await this.fence(claim);
      return true;
    } catch (error) { this.dropLeadership(); await releaseSyncLease(this.database, claim); throw error; }
  }
  private async capture() {
    if (this.stopped || this.applying || !this.lease) return;
    const claim = this.lease, before = this.checkpoint();
    try {
      await this.recoverProjection();
      const raw = await this.snapshot(), snapshot = await snapshotToRecords(raw);
      const preserve = [...snapshot.values()].filter((row) => row.kind === 'progress').length < raw.progress.length;
      this.queue.capture(snapshot, preserve ? new Set(['progress']) : undefined);
      await this.save(claim);
      this.report();
    } catch (error) { this.restore(before); if (error instanceof LeaseLost) this.dropLeadership(); throw error; }
  }
  private scheduleCapture = () => {
    if (this.stopped || this.applying || !this.lease) return;
    clearTimeout(this.captureTimer);
    this.captureTimer = setTimeout(() => { void this.exclusive(() => this.capture()).catch((error: unknown) => {
      this.report({ status: 'error', error: error instanceof Error ? error.message : '本机同步队列保存失败' });
    }); }, 600);
  };
  private async heartbeat() {
    if (this.stopped || this.heartbeating) return;
    this.heartbeating = true;
    try {
      if (this.lease) {
        const renewing = this.lease;
        const renewed = await renewSyncLease(this.database, renewing);
        if (this.stopped) { if (renewed) await releaseSyncLease(this.database, renewed); return; }
        // An expired lease may have been reacquired while the old renewal awaited IDB.
        // Its result must not drop or replace the new epoch's writer or network request.
        if (this.lease?.epoch !== renewing.epoch || this.lease.ownerToken !== renewing.ownerToken) return;
        if (!renewed) this.dropLeadership(); else this.lease = renewed;
      }
      if (!this.lease && await this.exclusive(() => this.ensureLeadership())) void this.syncNow();
    } catch (error) { this.report({ status: 'error', error: error instanceof Error ? error.message : '本机同步协调失败' }); }
    finally { this.heartbeating = false; }
  }
  private async waitForStoreHydration() {
    if (useAppStore.persist.hasHydrated()) return;
    await new Promise<void>((resolve, reject) => {
      let unsubscribe = () => {};
      const timer = setTimeout(() => { unsubscribe(); reject(new Error('本机片源配置尚未恢复，已暂停同步以保护资料')); }, 15_000);
      const finish = () => { clearTimeout(timer); unsubscribe(); resolve(); };
      unsubscribe = useAppStore.persist.onFinishHydration(finish);
      this.cleanups.push(() => { clearTimeout(timer); unsubscribe(); reject(new Error('同步已停止')); });
      if (useAppStore.persist.hasHydrated()) finish();
    });
  }
  async start() {
    if (!this.stopped) return;
    if (this.database.name !== databaseNameForScope(this.scope) || !this.database.tables.some((table) => table.name === 'personalSyncState')) throw new Error('当前资料空间与登录账号不一致');
    this.stopped = false;
    await this.waitForStoreHydration();
    if (this.stopped) return;
    const subscription = liveQuery(() => Promise.all([this.database.history.toArray(), this.database.progress.toArray(), this.database.favorites.toArray()]))
      .subscribe({ next: this.scheduleCapture, error: () => this.report({ status: 'error', error: '本机记录暂时无法读取' }) });
    const unsubscribe = useAppStore.subscribe((next, previous) => {
      if (next.customAPIs !== previous.customAPIs || next.envSources !== previous.envSources || next.selectedKeys !== previous.selectedKeys) this.scheduleCapture();
    });
    const sync = () => { if (!this.stopped) void this.syncNow(); };
    const onVisible = () => { if (document.visibilityState === 'visible') sync(); else if (this.lease) void this.exclusive(() => this.capture()).catch(() => {}); };
    const onStorage = (event: StorageEvent) => {
      if (event.key === settingsKeyForScope(PERSIST_KEY, this.scope)) {
        void Promise.resolve(useAppStore.persist.rehydrate()).then(this.scheduleCapture).catch(() => this.report({ status: 'error', error: '另一页面的片源修改暂时无法读取' }));
      }
    };
    window.addEventListener('online', sync); window.addEventListener('focus', sync); window.addEventListener('storage', onStorage);
    document.addEventListener('visibilitychange', onVisible);
    this.cleanups.push(() => subscription.unsubscribe(), unsubscribe, () => window.removeEventListener('online', sync),
      () => window.removeEventListener('focus', sync), () => window.removeEventListener('storage', onStorage), () => document.removeEventListener('visibilitychange', onVisible));
    this.timer = setInterval(sync, 30_000);
    this.heartbeatTimer = setInterval(() => { void this.heartbeat(); }, SYNC_LEASE_HEARTBEAT_MS);
    await this.exclusive(async () => { if (await this.ensureLeadership()) await this.capture(); });
    void this.syncNow();
  }
  stop() {
    this.stopped = true;
    clearInterval(this.timer); clearInterval(this.heartbeatTimer); clearTimeout(this.captureTimer);
    this.abort?.abort();
    for (const cleanup of this.cleanups.splice(0)) cleanup();
    const claim = this.lease; this.lease = null;
    if (claim) this.releasePending = this.releasePending.then(() => releaseSyncLease(this.database, claim)).catch(() => {});
  }
  syncNow(): Promise<void> {
    if (this.stopped) return Promise.resolve();
    if (this.inFlight) return this.inFlight;
    this.inFlight = this.performSync().finally(() => { this.inFlight = null; });
    return this.inFlight;
  }
  private async performSync() {
    try {
      const leader = await this.exclusive(async () => {
        if (!await this.ensureLeadership()) return false;
        await this.capture(); return true;
      });
      if (!leader || this.stopped || !this.lease) return;
      if (Object.keys(this.queue.state.conflicts).length) { this.report({ status: 'conflict' }); return; }
      if (typeof navigator !== 'undefined' && !navigator.onLine) { this.report({ status: 'offline', error: null }); return; }
      const { data: sessionData } = await this.client.auth.getSession();
      if (sessionData.session?.user.id !== this.scope.userId) { this.report({ status: 'auth-required', error: '登录已失效，本机资料保留，请重新登录此账号' }); return; }
      this.report({ status: 'syncing', error: null });
      for (let pass = 0; pass < 5 && !this.stopped && this.lease; pass++) {
        const claim = this.lease; await this.fence(claim);
        const sent = this.queue.batch(), controller = new AbortController();
        this.abort = controller;
        const timeout = setTimeout(() => controller.abort(), 15_000);
        let result;
        try {
          result = await this.client.rpc('pps_sync', { p_cursor: this.queue.state.cursor,
            p_changes: sent.map((change) => ({ kind: change.kind, key: change.key, payload: change.payload, baseRevision: change.baseRevision })) })
            .setHeader('Authorization', 'Bearer ' + sessionData.session.access_token).abortSignal(controller.signal);
        } finally { clearTimeout(timeout); }
        await this.fence(claim);
        if (result.error) {
          if (['PGRST301', 'PGRST303', '42501'].includes(result.error.code)) {
            this.report({ status: 'auth-required', error: '登录权限已失效，请重新登录；本机资料未删除' }); return;
          }
          throw new Error('同步服务暂时不可用，稍后可重试');
        }
        const response = validateSyncResponse(result.data);
        await this.exclusive(() => this.durableApply(claim, () => this.queue.receive(response, sent), true));
        if (Object.keys(this.queue.state.conflicts).length) { this.report({ status: 'conflict', error: null }); return; }
        if (!Object.keys(this.queue.state.pending).length) break;
      }
      this.report({ status: 'idle', error: null });
    } catch (error) {
      if (error instanceof LeaseLost) this.dropLeadership();
      if (!this.stopped) this.report({ status: error instanceof SnapshotChanged ? 'idle' : 'offline', error: error instanceof Error ? error.message : '同步暂时失败，本机记录已保留' });
    }
  }
  /** Cursor, outbox, media and source-recovery intent share one fenced IDB commit. */
  private async durableApply(claim: SyncLease, choose: (current: Map<string, SnapshotRecord>) => SyncRecord[], markSynced: boolean, localEdit = false) {
    for (let attempt = 0; attempt < 3; attempt++) {
      await this.capture();
      const checkpoint = this.checkpoint();
      let committed = false;
      this.applying = true;
      try {
        const raw = await this.snapshot(), current = await snapshotToRecords(raw);
        // Media can advance after capture() and before this raw snapshot is read.
        // Queue that newly observed edit before interpreting an older acknowledgement.
        const unmapped = [...current.values()].filter((row) => row.kind === 'progress').length < raw.progress.length;
        this.queue.capture(current, unmapped ? new Set(['progress']) : undefined);
        const rows = choose(current), plan = planSyncApply(raw, rows);
        this.remember(plan.projected.sources);
        const baseline = await snapshotToRecords({ ...plan.projected, sourceAliases: this.aliases });
        const preserveProgress = [...baseline.values()].filter((row) => row.kind === 'progress').length < plan.projected.progress.length;
        if (localEdit) this.queue.capture(baseline, preserveProgress ? new Set(['progress']) : undefined);
        else {
          const preserved = Object.fromEntries(Object.entries(checkpoint.queue.baseline).filter(([id]) =>
            !baseline.has(id) && (checkpoint.queue.records[id]?.kind ?? checkpoint.queue.pending[id]?.kind) === 'progress' && preserveProgress));
          this.queue.setBaseline(baseline); Object.assign(this.queue.state.baseline, preserved);
        }
        if (plan.sourcesChanged) this.sourceProjection = { id: crypto.randomUUID(), customAPIs: plan.projected.customAPIs,
          selectedKeys: plan.projected.selectedKeys, expected: view(raw) };
        if (markSynced) this.lastSyncedAt = Date.now();
        const value = this.checkpoint();
        await this.database.transaction('rw', [this.database.history, this.database.progress, this.database.favorites, this.database.personalSyncState], async () => {
          await this.fence(claim);
          for (const mutation of plan.mutations) if (!same(await this.database.table(mutation.kind).get(mutation.key), mutation.before)) throw new SnapshotChanged();
          if (plan.sourcesChanged && !same(view(useAppStore.getState()), view(raw))) throw new SnapshotChanged();
          for (const mutation of plan.mutations) {
            const table = this.database.table(mutation.kind);
            if (mutation.after) await table.put(mutation.after); else await table.delete(mutation.key);
          }
          await this.fence(claim);
          if (plan.sourcesChanged && !same(view(useAppStore.getState()), view(raw))) throw new SnapshotChanged();
          await this.database.personalSyncState.put({ key: 'main', value });
          await this.fence(claim);
        });
        committed = true;
        if (plan.sourcesChanged) await this.recoverProjection();
        this.report(); return;
      } catch (error) {
        if (!committed) this.restore(checkpoint);
        if (error instanceof SnapshotChanged && attempt < 2) continue;
        throw error;
      } finally { this.applying = false; this.scheduleCapture(); }
    }
  }
  async resolveConflicts(choice: 'local' | 'cloud') {
    await this.exclusive(async () => {
      if (!await this.ensureLeadership() || !this.lease) throw new Error('另一页面正在同步，请在该页面处理或稍后重试');
      await this.durableApply(this.lease, () => this.queue.resolve(choice), false);
    });
    this.report({ status: 'idle', error: null }); await this.syncNow();
  }
  async importGuest() {
    if (this.stopped) throw new Error('请先登录账号');
    await this.exclusive(async () => {
      if (!await this.ensureLeadership() || !this.lease) throw new Error('另一页面正在同步，请关闭该页面后重试合并');
      if (!await Dexie.exists('libretv')) return;
      const guest = new Dexie('libretv');
      try {
        await guest.open();
        let settings: Record<string, unknown> = {};
        try { const saved: unknown = JSON.parse(localStorage.getItem(PERSIST_KEY) ?? '{}'); if (object(saved) && object(saved.state)) settings = saved.state; } catch { /* Guest settings remain intact. */ }
        const sources = Array.isArray(settings.customAPIs) ? settings.customAPIs.filter((item): item is SourceConfig =>
          object(item) && typeof item.key === 'string' && typeof item.url === 'string' && typeof item.name === 'string') : [];
        const [history, progress, favorites] = await guest.transaction('r', ['history', 'progress', 'favorites'], () => Promise.all([
          guest.table<HistoryEntry>('history').toArray(), guest.table<ProgressEntry>('progress').toArray(), guest.table<FavoriteEntry>('favorites').toArray(),
        ]));
        const imported = await snapshotToRecords({ sources, selectedKeys: Array.isArray(settings.selectedKeys) ? settings.selectedKeys.filter((key): key is string => typeof key === 'string') : [], history, progress, favorites });
        await this.durableApply(this.lease, (current) => [...imported].filter(([id]) => !current.has(id))
          .map(([, row]) => ({ ...row, revision: 0, deleted: false, updatedAt: null })), false, true);
      } finally { guest.close(); }
    });
    await this.syncNow();
  }
  async prepareLogout(discardPending: boolean) {
    const leader = await this.exclusive(async () => { if (!await this.ensureLeadership()) return false; await this.capture(); return true; });
    if (!discardPending) {
      if (!leader) return false;
      await this.syncNow();
      if (Object.keys(this.queue.state.pending).length || Object.keys(this.queue.state.conflicts).length) return false;
    }
    this.stop(); await this.serial; await this.releasePending;
    return true;
  }
}
