import { sha256 } from '@noble/hashes/sha2.js';
import type { FavoriteEntry, HistoryEntry, ProgressEntry } from './db';
import type { LiveSourceConfig, SourceConfig } from './types';
import type { LiveRecentEntry, LiveSubscription } from './store';

export type SyncKind = 'sources' | 'history' | 'progress' | 'favorites' | 'liveSources' | 'liveFavorites' | 'liveRecent';

export interface SyncRecord {
  kind: SyncKind;
  key: string;
  payload: Record<string, unknown> | null;
  revision: number;
  deleted: boolean;
  updatedAt: number | null;
}

export interface SyncChange {
  kind: SyncKind;
  key: string;
  baseRevision: number;
  payload: Record<string, unknown> | null;
  /** 本机排队标识，不是服务端所有权或版本依据。 */
  opId?: string;
}

export interface SyncResponse {
  revision: number;
  accepted: boolean;
  records: SyncRecord[];
  conflicts: SyncRecord[];
}

export interface SnapshotRecord {
  kind: SyncKind;
  key: string;
  payload: Record<string, unknown>;
}

export interface PersonalSyncSnapshot {
  sources: SourceConfig[];
  /** 已见过但可能已从当前列表删除的映射；只帮助解析旧记录，不恢复片源列表。 */
  sourceAliases?: SourceConfig[];
  selectedKeys: string[];
  history: HistoryEntry[];
  progress: ProgressEntry[];
  favorites: FavoriteEntry[];
  /** 不包含本机抓取时间和统一订阅归属；这些状态只属于接收设备。 */
  liveSubscriptions?: LiveSubscription[];
  liveEnvSources?: LiveSourceConfig[];
  liveSelectedUrls?: string[];
  liveFavorites?: string[];
  liveRecent?: LiveRecentEntry[];
}

const KINDS = new Set<SyncKind>(['sources', 'history', 'progress', 'favorites', 'liveSources', 'liveFavorites', 'liveRecent']);
const MAX_KEY_BYTES = 4096;
const MAX_PAYLOAD_BYTES = 64 * 1024;
const MAX_RESPONSE_RECORDS = 20_000;
const encoder = new TextEncoder();

const object = (value: unknown): value is Record<string, unknown> => {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
};
const finite = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value) && value >= 0;
const integer = (value: unknown): value is number => finite(value) && Number.isSafeInteger(value);
const string = (value: unknown, max = 2048): value is string => typeof value === 'string' && value.length <= max;
const identifier = (value: unknown): value is string => string(value, MAX_KEY_BYTES) && value.length > 0
  && !/[\u0000-\u001f\u007f]/.test(value);
const bytes = (value: string) => encoder.encode(value).byteLength;

export function recordId(kind: SyncKind, key: string): string {
  return JSON.stringify([kind, key]);
}

/** URL 本身才是跨设备片源身份；不猜测同名片源或影片属于同一内容。 */
export function canonicalSourceIdentity(value: string): string | null {
  if (!value || value.length > MAX_KEY_BYTES || /[\u0000-\u001f\u007f]/.test(value)) return null;
  try {
    const url = new URL(value.trim());
    if (!['http:', 'https:'].includes(url.protocol) || !url.hostname || url.username || url.password) return null;
    // hash 不进入实际 HTTP 请求；path 的末尾 /、query 的值及次序可能有意义，保留。
    url.hash = '';
    const identity = url.href;
    return bytes(identity) <= MAX_KEY_BYTES ? identity : null;
  } catch {
    return null;
  }
}

const hex = (digest: Uint8Array) => Array.from(digest, (value) => value.toString(16).padStart(2, '0')).join('');
/** 应用远端删除记录时也可同步定位，算法与异步快照生成完全一致。 */
export function canonicalSourceKey(identity: string): string {
  return `sync_${hex(sha256(encoder.encode(identity))).slice(0, 24)}`;
}

/** Safari/ArkWeb 可使用 WebCrypto；HTTP 本机环境不提供 subtle 时仍得到同一 SHA-256。 */
async function sourceKeyForSnapshot(identity: string): Promise<string> {
  if (globalThis.crypto?.subtle) {
    try {
      return `sync_${hex(new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(identity)))).slice(0, 24)}`;
    } catch {
      // 某些 WebView 暴露 subtle 却拒绝本机上下文；使用项目已有、相同算法的后备。
    }
  }
  return canonicalSourceKey(identity);
}

/** 限制为真正的 JSON 数据，避免函数、原型修改键、循环引用或无限深度进入本机资料。 */
function validJson(value: unknown, ancestors = new Set<object>(), depth = 0): boolean {
  if (value === null || typeof value === 'boolean') return true;
  if (typeof value === 'string') return !value.includes('\u0000');
  if (typeof value === 'number') return Number.isFinite(value);
  if (depth > 24 || (!Array.isArray(value) && !object(value)) || ancestors.has(value)) return false;
  ancestors.add(value);
  const valid = Array.isArray(value)
    ? value.every((item) => validJson(item, ancestors, depth + 1))
    : Object.entries(value).every(([key, item]) => !['__proto__', 'prototype', 'constructor'].includes(key)
      && validJson(item, ancestors, depth + 1));
  ancestors.delete(value);
  return valid;
}

function optionalText(payload: Record<string, unknown>, key: string, max = 8192) {
  return payload[key] === undefined || string(payload[key], max);
}

function tupleKey(key: string, length: number): unknown[] | null {
  try {
    const tuple: unknown = JSON.parse(key);
    return Array.isArray(tuple) && tuple.length === length && JSON.stringify(tuple) === key ? tuple : null;
  } catch {
    return null;
  }
}

function validIdentity(value: unknown): value is string {
  return identifier(value) && (value.startsWith('builtin:')
    ? value.length > 'builtin:'.length
    : canonicalSourceIdentity(value) === value);
}

function validMediaIdentity(payload: Record<string, unknown>, key: string, progress: boolean): boolean {
  const tuple = tupleKey(key, progress ? 3 : 2);
  if (!tuple || !validIdentity(tuple[0]) || !identifier(tuple[1]) || payload.vodId !== tuple[1]
    || payload.sourceKey !== canonicalSourceKey(tuple[0])) return false;
  if (payload.sourceUrl !== undefined && (!string(payload.sourceUrl, MAX_KEY_BYTES)
    || canonicalSourceIdentity(payload.sourceUrl) !== tuple[0])) return false;
  return !progress || (integer(tuple[2]) && payload.episodeIndex === tuple[2]);
}

function validRecordKey(kind: SyncKind, key: string): boolean {
  if (kind === 'sources' || kind === 'liveSources' || kind === 'liveFavorites' || kind === 'liveRecent') return canonicalSourceIdentity(key) === key;
  const tuple = tupleKey(key, kind === 'progress' ? 3 : 2);
  return !!tuple && validIdentity(tuple[0]) && identifier(tuple[1])
    && (kind !== 'progress' || integer(tuple[2]));
}

function validPayload(kind: SyncKind, key: string, payload: unknown): payload is Record<string, unknown> {
  if (!object(payload) || !validJson(payload) || bytes(JSON.stringify(payload)) > MAX_PAYLOAD_BYTES) return false;
  if (kind === 'liveSources') {
    const source = payload.source;
    return object(source) && identifier(source.url) && canonicalSourceIdentity(source.url) === key
      && optionalText(source, 'name', 2048) && optionalText(source, 'epg', MAX_KEY_BYTES)
      && (source.epg === undefined || source.epg === '' || canonicalSourceIdentity(source.epg as string) !== null)
      && !('lastSync' in source) && !('fromSubscriptions' in source) && typeof payload.selected === 'boolean';
  }
  if (kind === 'liveFavorites' || kind === 'liveRecent') {
    if (!identifier(payload.url) || canonicalSourceIdentity(payload.url) !== key) return false;
    if (kind === 'liveFavorites') return true;
    return string(payload.name) && finite(payload.timestamp) && optionalText(payload, 'logo')
      && optionalText(payload, 'group') && optionalText(payload, 'tvgId') && optionalText(payload, 'epg', MAX_KEY_BYTES)
      && optionalText(payload, 'sourceUrl', MAX_KEY_BYTES)
      && (payload.epg === undefined || payload.epg === '' || canonicalSourceIdentity(payload.epg as string) !== null)
      && (payload.sourceUrl === undefined || canonicalSourceIdentity(payload.sourceUrl as string) !== null);
  }
  if (kind === 'sources') {
    const source = payload.source;
    return object(source) && string(source.name) && identifier(source.url)
      && canonicalSourceIdentity(source.url) === key && source.key === canonicalSourceKey(key)
      && typeof payload.selected === 'boolean' && optionalText(source, 'detail')
      && (source.detail === undefined || source.detail === '' || canonicalSourceIdentity(source.detail as string) !== null)
      && (source.isAdult === undefined || typeof source.isAdult === 'boolean');
  }
  if (!validMediaIdentity(payload, key, kind === 'progress')) return false;
  if (kind === 'progress') {
    return finite(payload.position) && finite(payload.duration) && finite(payload.updatedAt);
  }
  if ('id' in payload) return false;
  if (!finite(payload.timestamp) || !optionalText(payload, 'pic')) return false;
  if (kind === 'history') {
    return string(payload.title) && integer(payload.episodeIndex) && integer(payload.totalEpisodes)
      && finite(payload.playbackPosition) && finite(payload.duration);
  }
  return string(payload.name) && string(payload.sourceName) && optionalText(payload, 'year')
    && optionalText(payload, 'remarks') && optionalText(payload, 'typeName') && optionalText(payload, 'area')
    && (payload.isAdult === undefined || typeof payload.isAdult === 'boolean');
}

function validateRecord(value: unknown, revision: number): SyncRecord {
  if (!object(value) || !KINDS.has(value.kind as SyncKind) || !identifier(value.key) || bytes(value.key) > MAX_KEY_BYTES
    || !validRecordKey(value.kind as SyncKind, value.key)
    || !integer(value.revision) || value.revision > revision || typeof value.deleted !== 'boolean'
    || !(value.updatedAt === null || finite(value.updatedAt))
    || (value.deleted ? value.payload !== null : !validPayload(value.kind as SyncKind, value.key, value.payload))) {
    throw new Error('同步服务返回了无效记录，未写入本机资料');
  }
  return {
    kind: value.kind as SyncKind, key: value.key, revision: value.revision, deleted: value.deleted,
    updatedAt: value.updatedAt, payload: value.payload === null ? null : JSON.parse(JSON.stringify(value.payload)),
  };
}

/** 必须在应用任何一条远端变更前校验整包；任一坏行使整个响应失败。 */
export function validateSyncResponse(value: unknown): SyncResponse {
  if (!object(value) || !integer(value.revision) || typeof value.accepted !== 'boolean'
    || !Array.isArray(value.records) || !Array.isArray(value.conflicts)
    || value.records.length + value.conflicts.length > MAX_RESPONSE_RECORDS) {
    throw new Error('同步服务响应格式不正确，未写入本机资料');
  }
  const revision = value.revision;
  const validateList = (rows: unknown[]): SyncRecord[] => {
    const seen = new Set<string>();
    return rows.map((row) => {
      const record = validateRecord(row, revision);
      const id = recordId(record.kind, record.key);
      if (seen.has(id)) throw new Error('同步服务返回重复记录，未写入本机资料');
      seen.add(id);
      return record;
    });
  };
  const records = validateList(value.records);
  const conflicts = validateList(value.conflicts);
  if (value.accepted && conflicts.length > 0) throw new Error('同步服务冲突状态不正确，未写入本机资料');
  return { revision, accepted: value.accepted, records, conflicts };
}

interface SourceIdentity {
  identity: string;
  sourceKey: string;
  sourceUrl?: string;
}

/**
 * 仅生成同步快照，不修改资料库或重命名正在播放的本机片源。
 * 找不到可靠来源的旧进度留在本机，不能用 custom_0 或片名猜测远端来源。
 */
export async function snapshotToRecords(input: PersonalSyncSnapshot): Promise<Map<string, SnapshotRecord>> {
  const out = new Map<string, SnapshotRecord>();
  const selected = new Set(input.selectedKeys);
  const known = new Map<string, Map<string, SourceIdentity>>();
  const identityCache = new Map<string, Promise<string>>();
  const keyFor = (identity: string) => {
    if (!identityCache.has(identity)) identityCache.set(identity, sourceKeyForSnapshot(identity));
    return identityCache.get(identity)!;
  };
  const remember = (localKey: string, source: SourceIdentity) => {
    const options = known.get(localKey) ?? new Map<string, SourceIdentity>();
    options.set(source.identity, source);
    known.set(localKey, options);
  };
  const identify = async (localKey: string, url?: string): Promise<SourceIdentity | null> => {
    if (!identifier(localKey)) return null;
    if (url) {
      const identity = canonicalSourceIdentity(url);
      if (!identity) return null;
      return { identity, sourceKey: await keyFor(identity), sourceUrl: url };
    }
    const existing = known.get(localKey);
    if (existing?.size === 1) return [...existing.values()][0];
    if (existing?.size) return null;
    const identity = `builtin:${localKey}`;
    return { identity, sourceKey: await keyFor(identity) };
  };
  const put = (record: SnapshotRecord, timestampField?: string) => {
    // 清除可选的 undefined，并克隆输入；不让修改快照回写原对象。
    let payload: unknown;
    try { payload = JSON.parse(JSON.stringify(record.payload)); } catch { return; }
    if (!identifier(record.key) || bytes(record.key) > MAX_KEY_BYTES || !validPayload(record.kind, record.key, payload)) return;
    const next: SnapshotRecord = { ...record, payload };
    const id = recordId(next.kind, next.key);
    const previous = out.get(id);
    if (previous && timestampField && Number(previous.payload[timestampField]) > Number(next.payload[timestampField])) return;
    out.set(id, next);
  };

  for (const source of input.sources) {
    if (!canonicalSourceIdentity(source.url)) continue;
    const resolved = await identify(source.key, source.url);
    if (!resolved) continue;
    remember(source.key, resolved);
    const previous = out.get(recordId('sources', resolved.identity));
    put({ kind: 'sources', key: resolved.identity, payload: {
      source: { ...(previous?.payload.source as SourceConfig | undefined ?? source), key: resolved.sourceKey },
      selected: selected.has(source.key) || previous?.payload.selected === true,
    } });
  }

  const liveSelected = new Set((input.liveSelectedUrls ?? []).map(canonicalSourceIdentity).filter(Boolean));
  for (const source of [...(input.liveEnvSources ?? []), ...(input.liveSubscriptions ?? [])]) {
    const identity = canonicalSourceIdentity(source.url);
    if (!identity) continue;
    const previous = out.get(recordId('liveSources', identity));
    put({ kind: 'liveSources', key: identity, payload: {
      source: { url: source.url, name: source.name, epg: source.epg },
      selected: liveSelected.has(identity) || previous?.payload.selected === true,
    } });
  }
  for (const url of input.liveFavorites ?? []) {
    const identity = canonicalSourceIdentity(url);
    if (identity) put({ kind: 'liveFavorites', key: identity, payload: { url } });
  }
  for (const recent of input.liveRecent ?? []) {
    const identity = canonicalSourceIdentity(recent.url);
    if (!identity) continue;
    put({ kind: 'liveRecent', key: identity, payload: {
      url: recent.url, name: recent.name, logo: recent.logo, group: recent.group, tvgId: recent.tvgId,
      epg: recent.epg, sourceUrl: recent.sourceUrl, timestamp: recent.timestamp,
    } }, 'timestamp');
  }

  const currentKeys = new Set(known.keys());
  for (const source of input.sourceAliases ?? []) {
    if (currentKeys.has(source.key) || !canonicalSourceIdentity(source.url)) continue;
    const resolved = await identify(source.key, source.url);
    if (resolved) remember(source.key, resolved);
  }

  // 历史/收藏内的 sourceUrl 可补充已删除的源，但从不把它重新加入用户片源列表。
  for (const history of input.history) {
    const resolved = await identify(history.sourceKey, history.sourceUrl);
    if (!resolved) continue;
    remember(history.sourceKey, resolved);
    const payload: Record<string, unknown> = { ...history };
    delete payload.id;
    put({ kind: 'history', key: JSON.stringify([resolved.identity, history.vodId]), payload: {
      ...payload, sourceKey: resolved.sourceKey, sourceUrl: history.sourceUrl ?? resolved.sourceUrl,
    } }, 'timestamp');
  }
  for (const favorite of input.favorites) {
    const resolved = await identify(favorite.sourceKey, favorite.sourceUrl);
    if (!resolved) continue;
    remember(favorite.sourceKey, resolved);
    const payload: Record<string, unknown> = { ...favorite };
    delete payload.id;
    put({ kind: 'favorites', key: JSON.stringify([resolved.identity, favorite.vodId]), payload: {
      ...payload, sourceKey: resolved.sourceKey, sourceUrl: favorite.sourceUrl ?? resolved.sourceUrl,
    } }, 'timestamp');
  }

  const prefixes = [...known.keys()].sort((a, b) => b.length - a.length);
  for (const progress of input.progress) {
    const localKey = prefixes.find((prefix) => progress.key.startsWith(prefix + '_'));
    if (!localKey) continue;
    const candidates = known.get(localKey);
    if (candidates?.size !== 1) continue;
    const resolved = [...candidates.values()][0];
    const remaining = progress.key.slice(localKey.length + 1);
    const lastSeparator = remaining.lastIndexOf('_');
    if (lastSeparator < 1 || !/^\d+$/.test(remaining.slice(lastSeparator + 1))) continue;
    const vodId = remaining.slice(0, lastSeparator);
    const episodeIndex = Number(remaining.slice(lastSeparator + 1));
    if (!integer(episodeIndex)) continue;
    put({ kind: 'progress', key: JSON.stringify([resolved.identity, vodId, episodeIndex]), payload: {
      sourceKey: resolved.sourceKey, sourceUrl: resolved.sourceUrl, vodId, episodeIndex,
      position: progress.position, duration: progress.duration, updatedAt: progress.updatedAt,
    } }, 'updatedAt');
  }
  return out;
}
