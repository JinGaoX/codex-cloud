import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const fixture = vi.hoisted(() => ({
  scope: { userId: 'fixture-user', endpoint: 'https://owned-fixture.supabase.co' }, currentUser: 'fixture-user',
  state: { sourceHealth: {} as Record<string, { ok: boolean; failStreak: number; timestamp: number; error?: string; permanent?: boolean }>, selectedKeys: ['selected-fixture'] },
  persisted: '' as string | null, flush: vi.fn(),
}));
vi.mock('./account-scope', () => ({
  ACTIVE_ACCOUNT_SCOPE: fixture.scope,
  readActiveAccountScope: () => ({ ...fixture.scope, userId: fixture.currentUser }),
  scopeId: (scope: unknown) => JSON.stringify(scope),
  settingsKeyForScope: (key: string, scope: { userId: string }) => `${key}:account:${scope.userId}`,
}));
vi.mock('./persist-storage', () => ({ flushPendingPersist: fixture.flush, readPersistedSettings: () => fixture.persisted }));
vi.mock('./store', () => ({ useAppStore: { getState: () => fixture.state,
  setState: (patch: Partial<typeof fixture.state>) => { Object.assign(fixture.state, patch); } } }));
import { obsoleteDirectHealthKeys, repairAccountSourceTransportHealth } from './account-source-relay-health';

beforeEach(() => {
  const values = new Map<string, string>();
  vi.stubGlobal('localStorage', { getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => values.set(key, value) });
  fixture.currentUser = fixture.scope.userId;
  fixture.state.sourceHealth = {
    oldCors: { ok: false, failStreak: 3, timestamp: 100, error: '无法直接访问该源：可能是网络、证书或 CORS 跨域限制。', permanent: true },
    httpError: { ok: false, failStreak: 3, timestamp: 100, error: '源站返回 HTTP 404' },
    timeout: { ok: false, failStreak: 3, timestamp: 100, error: '该源搜索超时' },
    healthy: { ok: true, failStreak: 0, timestamp: 100 },
  };
  fixture.state.selectedKeys = ['selected-fixture'];
  fixture.flush.mockReset().mockImplementation(() => { fixture.persisted = JSON.stringify({ state: fixture.state }); });
  fixture.persisted = JSON.stringify({ state: fixture.state });
});
afterEach(() => vi.unstubAllGlobals());

describe('账号点播传输的一次性健康度恢复', () => {
  it('只清理旧直连CORS/网络惩罚，不改选中源、HTTP错误、超时或正常源', () => {
    const selected = fixture.state.selectedKeys;
    expect(obsoleteDirectHealthKeys(fixture.state.sourceHealth)).toEqual(['oldCors']);
    repairAccountSourceTransportHealth();
    expect(fixture.state.sourceHealth).not.toHaveProperty('oldCors');
    expect(Object.keys(fixture.state.sourceHealth)).toEqual(['httpError', 'timeout', 'healthy']);
    expect(fixture.state.selectedKeys).toBe(selected);
    expect(localStorage.getItem('pps-account-source-relay-health-v1:account:fixture-user')).toBe('done');
  });

  it('只执行一次，之后的真实网络失败不自动清除', () => {
    repairAccountSourceTransportHealth();
    fixture.state.sourceHealth.newFailure = { ok: false, failStreak: 3, timestamp: 200, error: 'NetworkError' };
    repairAccountSourceTransportHealth();
    expect(fixture.state.sourceHealth.newFailure).toBeDefined();
    expect(fixture.flush).toHaveBeenCalledTimes(1);
  });

  it('账号正在切换或落盘失败时不写完成标记', () => {
    fixture.currentUser = 'other-user';
    repairAccountSourceTransportHealth();
    expect(fixture.state.sourceHealth.oldCors).toBeDefined(); expect(fixture.flush).not.toHaveBeenCalled();
    fixture.currentUser = fixture.scope.userId;
    fixture.flush.mockImplementation(() => {});
    repairAccountSourceTransportHealth();
    expect(localStorage.getItem('pps-account-source-relay-health-v1:account:fixture-user')).toBeNull();
  });
});
