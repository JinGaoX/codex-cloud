import { describe, expect, it } from 'vitest';
import type { HistoryEntry, ProgressEntry } from './db';
import { HOME_RESUME_COMPLETION_MAX_REMAINING_SECONDS, isHomeResumeComplete, selectHomeResume } from './home-resume';

const history = (patch: Partial<HistoryEntry> = {}): HistoryEntry => ({
  id: 'custom_0_film', sourceKey: 'custom_0', sourceUrl: 'https://example.com/api', vodId: 'film', title: '测试影片',
  episodeIndex: 0, totalEpisodes: 1, playbackPosition: 120, duration: 1200, timestamp: 1000, ...patch,
});
const progress = (patch: Partial<ProgressEntry> = {}): ProgressEntry => ({
  key: 'custom_0_film_0', position: 120, duration: 1200, updatedAt: 1000, ...patch,
});

describe('首页共享续播选择', () => {
  it('没有记录时不制造主横幅或续播卡', () => {
    expect(selectHomeResume([], [])).toEqual({ hero: null, others: [], total: 0 });
  });

  it('按实际进度时间排序，打开旧片造成的history新时间不抢主横幅', () => {
    const visited = history({ timestamp: 9000 });
    const watched = history({ id: 'custom_0_new', vodId: 'new', title: '最近实际播放', timestamp: 1500 });
    const result = selectHomeResume([visited, watched], [progress({ updatedAt: 1000 }), progress({ key: 'custom_0_new_0', updatedAt: 2000, position: 333 })]);
    expect(result.hero).toMatchObject({ title: '最近实际播放', watchedAt: 2000, playbackPosition: 333 });
    expect(result.others[0]).toMatchObject({ title: '测试影片', watchedAt: 1000 });
  });

  it('刚打开新集没有实际进度时，恢复此前真实观看的集数而非继承的位置组合', () => {
    const result = selectHomeResume([history({ episodeIndex: 4, totalEpisodes: 12, timestamp: 9000 })], [progress({ key: 'custom_0_film_2', position: 456, updatedAt: 2000 })]);
    expect(result.hero).toMatchObject({ episodeIndex: 2, playbackPosition: 456, watchedAt: 2000, hasEpisodeContext: true });
  });

  it('最新实际逐集进度可纠正旧history的集数和时长，但保留原定位身份', () => {
    const record = history({ totalEpisodes: 12 });
    const result = selectHomeResume([record], [progress(), progress({ key: 'custom_0_film_7', position: 780, duration: 2600, updatedAt: 3000 })]);
    expect(result.hero).toMatchObject({ id: record.id, sourceKey: record.sourceKey, sourceUrl: record.sourceUrl, vodId: record.vodId,
      episodeIndex: 7, playbackPosition: 780, duration: 2600, percent: 30, watchedAt: 3000 });
  });

  it('旧记录没有逐集表时保留其真实秒数与集数', () => {
    expect(selectHomeResume([history({ episodeIndex: 3, totalEpisodes: 10 })], []).hero)
      .toMatchObject({ episodeIndex: 3, playbackPosition: 120, duration: 1200, percent: 10, watchedAt: 1000 });
  });

  it('未知总时长显示null百分比，不伪造进度或电影/电视剧类型', () => {
    const result = selectHomeResume([history({ duration: 0, totalEpisodes: 0, playbackPosition: 82 })], []);
    expect(result.hero).toMatchObject({ duration: 0, playbackPosition: 82, percent: null, hasEpisodeContext: false });
    expect(result.hero).not.toHaveProperty('type');
  });

  it('仅打开零进度的更新记录不挤掉真实续播，也不出现空白条目', () => {
    const result = selectHomeResume([history(), history({ id: 'new', vodId: 'new', title: '只是打开', timestamp: 99999, playbackPosition: 0 })], []);
    expect(result.total).toBe(1);
    expect(result.hero?.title).toBe('测试影片');
  });

  it.each([0, -1, NaN, Infinity])('无效历史播放位置%s不会生成续播', (position) => {
    expect(selectHomeResume([history({ playbackPosition: position })], []).hero).toBeNull();
  });

  it.each([-1, NaN, 1.5, Infinity])('无效历史集数%s不会推断为第1集', (episodeIndex) => {
    expect(selectHomeResume([history({ episodeIndex })], []).hero).toBeNull();
  });

  it('合法逐集进度可以恢复损坏的旧集数字段', () => {
    expect(selectHomeResume([history({ episodeIndex: NaN })], [progress({ key: 'custom_0_film_2' })]).hero?.episodeIndex).toBe(2);
  });

  it('完成启发式同时要求至少95%和最后两分钟，未知总时长不判已看完', () => {
    expect(isHomeResumeComplete(949, 1000)).toBe(false);
    expect(isHomeResumeComplete(950, 1000)).toBe(true);
    expect(isHomeResumeComplete(1000, 1000)).toBe(true);
    expect(isHomeResumeComplete(200, 0)).toBe(false);
    expect(isHomeResumeComplete(200, Infinity)).toBe(false);
    expect(HOME_RESUME_COMPLETION_MAX_REMAINING_SECONDS).toBe(120);
    expect(isHomeResumeComplete(90, 100)).toBe(false);
  });

  it('长片虽到95%但还有5分钟，仍保留真实续播', () => {
    const record = history({ playbackPosition: 5700, duration: 6000 });
    expect(isHomeResumeComplete(5700, 6000)).toBe(false);
    expect(selectHomeResume([record], []).hero).toMatchObject({ playbackPosition: 5700, duration: 6000, percent: 95 });
  });

  it('长片最后120秒与121秒准确区分，且不自动推进下一集', () => {
    expect(isHomeResumeComplete(5879, 6000)).toBe(false);
    expect(isHomeResumeComplete(5880, 6000)).toBe(true);
    expect(selectHomeResume([history({ episodeIndex: 2, totalEpisodes: 10, playbackPosition: 5880, duration: 6000 })], []).hero).toBeNull();
  });

  it('已超过总时长仍视为结束，不因舍入差异再占主横幅', () => {
    expect(isHomeResumeComplete(6001, 6000)).toBe(true);
    expect(selectHomeResume([history({ playbackPosition: 6001, duration: 6000 })], []).hero).toBeNull();
  });

  it('最新保存位置已近尾时不把更早的未完成位置捡回来', () => {
    expect(selectHomeResume([history({ totalEpisodes: 12 })], [progress(), progress({ key: 'custom_0_film_2', position: 950, duration: 1000, updatedAt: 2000 })]).hero).toBeNull();
  });

  it('自然结束清除当前集progress后，近尾history阻止旧集重新占据主横幅', () => {
    const result = selectHomeResume([history({ episodeIndex: 11, totalEpisodes: 12, playbackPosition: 1190, timestamp: 5000 })],
      [progress({ key: 'custom_0_film_2', updatedAt: 2000 })]);
    expect(result.hero).toBeNull();
    expect(result.others).toEqual([]);
  });

  it('较早一集已近尾且下一集未知时不擅自推进', () => {
    expect(selectHomeResume([history({ episodeIndex: 2, totalEpisodes: 12, playbackPosition: 1190 })], []).hero).toBeNull();
  });

  it('比旧完成记录更新的真实重播进度可以再次继续', () => {
    expect(selectHomeResume([history({ playbackPosition: 1190, timestamp: 1000 })], [progress({ position: 30, updatedAt: 2000 })]).hero)
      .toMatchObject({ playbackPosition: 30, watchedAt: 2000 });
  });

  it('同名跨源只保留最近实际记录，并排除主横幅重复项', () => {
    const copy = history({ id: 'custom_1_other', sourceKey: 'custom_1', vodId: 'other', totalEpisodes: 2, timestamp: 2000 });
    const result = selectHomeResume([history(), copy], []);
    expect(result.hero).toMatchObject({ sourceKey: 'custom_1', vodId: 'other' });
    expect(result.total).toBe(1);
    expect(result.others).toEqual([]);
  });

  it('同主机默认标题相同的两个直连视频按完整URL分别保留', () => {
    const records = ['https://media.example/a.mp4', 'https://media.example/b.mp4'].map((url, i) => history({
      id: `__direct___${url}`, sourceKey: '__direct__', sourceUrl: undefined,
      vodId: url, title: '视频 · media.example', timestamp: 1000 + i,
    }));
    const result = selectHomeResume(records, []);
    expect(result.total).toBe(2);
    expect(result.hero?.vodId).toBe('https://media.example/b.mp4');
    expect(result.others[0]?.vodId).toBe('https://media.example/a.mp4');
  });

  it('同名最近源已看完会排除其他源旧的半途副本', () => {
    const completed = history({ id: 'custom_1_other', sourceKey: 'custom_1', vodId: 'other', timestamp: 2000, playbackPosition: 1190 });
    expect(selectHomeResume([history(), completed], [])).toEqual({ hero: null, others: [], total: 0 });
  });

  it('完整标题保留季数、年份、剪辑版信息，不做模糊合并', () => {
    const records = ['测试影片', '测试影片 第二季', '测试影片（2024）', '测试影片 导演剪辑版'].map((title, i) => history({ id: String(i), vodId: String(i), title, timestamp: i + 1 }));
    const result = selectHomeResume(records, []);
    expect(result.total).toBe(4);
    expect(result.others).toHaveLength(3);
  });

  it('重复标题只做空白、全半角和大小写归一化', () => {
    const records = [' P P S ', 'Ｐ Ｐ Ｓ', 'p p s'].map((title, i) => history({ id: String(i), vodId: String(i), title, timestamp: i + 1 }));
    expect(selectHomeResume(records, []).total).toBe(1);
  });

  it('来源和vod含下划线时只拆末尾集数，不把其他影片进度串入', () => {
    const record = history({ id: 'legacy-id', sourceKey: 'custom_long_0', vodId: 'film_part_4', totalEpisodes: 10 });
    const entries = [progress({ key: 'custom_long_0_film_part_4_3', position: 321, updatedAt: 3000 }),
      progress({ key: 'custom_long_0_film_part_4_other_5', position: 500, updatedAt: 9999 }),
      progress({ key: 'custom_long_0_film_part_40_9', position: 500, updatedAt: 99999 })];
    expect(selectHomeResume([record], entries).hero).toMatchObject({ episodeIndex: 3, playbackPosition: 321, watchedAt: 3000 });
  });

  it('不合法progress key或时间不覆盖可用旧记录', () => {
    const entries = [progress({ key: 'custom_0_film_01', position: 500 }), progress({ key: 'custom_0_film_-1', position: 500 }),
      progress({ updatedAt: Infinity, position: 500 }), progress({ updatedAt: NaN, position: 500 }), progress({ position: 0 })];
    expect(selectHomeResume([history()], entries).hero?.playbackPosition).toBe(120);
  });

  it('丢失标题或定位字段的损坏导入记录不生成假卡片', () => {
    expect(selectHomeResume([history({ title: '' }), history({ sourceKey: '' }), history({ vodId: '' })], []).hero).toBeNull();
  });

  it('合理数量截断只影响展示，不伪造或删除其余历史', () => {
    const records = Array.from({ length: 12 }, (_, i) => history({ id: String(i), vodId: String(i), title: `影片${i}`, timestamp: i + 1 }));
    const snapshot = structuredClone(records);
    const result = selectHomeResume(records, []);
    expect(result.hero?.title).toBe('影片11');
    expect(result.others.map((item) => item.title)).toEqual(['影片10', '影片9', '影片8', '影片7']);
    expect(result.total).toBe(12);
    expect(records).toEqual(snapshot);
    expect(selectHomeResume(records, [], 0).others).toEqual([]);
    expect(selectHomeResume(records, [], Infinity).others).toHaveLength(4);
  });

  it('模型不修改输入的history或progress对象', () => {
    const records = [history({ title: '  测试影片  ', episodeIndex: 2 })], saved = [progress({ key: 'custom_0_film_1', position: 300 })];
    const snapshot = structuredClone({ records, saved });
    selectHomeResume(records, saved);
    expect({ records, saved }).toEqual(snapshot);
  });
});
