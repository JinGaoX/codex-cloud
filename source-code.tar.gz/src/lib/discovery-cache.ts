import { DISCOVERY_LISTS, DOUBAN_BROWSE_TAGS, DOUBAN_DISCOVERY_PAGE_SIZE, type DiscoveryItem, type DiscoveryResponse } from './discovery';

/** Public metadata only; existing settings, favorites and progress keys are untouched. */
export const DISCOVERY_CACHE_KEY = 'libretv-public-discovery-cache-v1';
export const DISCOVERY_CACHE_MAX_BYTES = 256 * 1024;
export const DISCOVERY_CACHE_MAX_ENTRIES = 12;
export const DISCOVERY_CACHE_MAX_AGE_MS = 7 * 24 * 60 * 60_000;
export interface DiscoveryCacheStorage { getItem(key: string): string | null; setItem(key: string, value: string): void }

const allowedKeys = new Set([
  ...DISCOVERY_LISTS.map((entry) => `list:${entry.id}`),
  ...Object.entries(DOUBAN_BROWSE_TAGS).flatMap(([type, tags]) => tags.map((tag) => `douban:${type}:${tag}`)),
]);
const record = (value: unknown): value is Record<string, unknown> => !!value && typeof value === 'object' && !Array.isArray(value);
const byteLength = (value: string) => new TextEncoder().encode(value).byteLength;

function browserStorage(): DiscoveryCacheStorage | undefined {
  try { return typeof window === 'undefined' ? undefined : window.localStorage; } catch { return undefined; }
}

function safeImage(value: unknown): string | undefined {
  if (typeof value !== 'string') return undefined;
  if (value === '') return '';
  try { const url = new URL(value); return url.protocol === 'https:' && !url.username && !url.password ? url.href : undefined; }
  catch { return undefined; }
}

/** Rebuild an allowlisted object; never revive arbitrary API fields from storage. */
function cleanResponse(value: unknown, now: number): DiscoveryResponse | undefined {
  if (!record(value) || !Array.isArray(value.items) || value.items.length < 1 || value.items.length > 50 ||
    typeof value.retrievedAt !== 'number' || !Number.isFinite(value.retrievedAt) || value.retrievedAt <= 0 ||
    value.retrievedAt > now + 60_000 || now - value.retrievedAt > DISCOVERY_CACHE_MAX_AGE_MS) return undefined;
  const items: DiscoveryItem[] = [];
  for (const row of value.items) {
    if (!record(row) || typeof row.id !== 'string' || !row.id || row.id.length > 200 ||
      typeof row.title !== 'string' || !row.title.trim() || row.title.length > 150 ||
      !Array.isArray(row.genres) || row.genres.length > 20 || row.genres.some((genre) => typeof genre !== 'string' || genre.length > 30)) return undefined;
    const cover = safeImage(row.cover);
    if (cover === undefined) return undefined;
    const rating = typeof row.rating === 'string' ? Number(row.rating) : NaN;
    const alternatives = Array.isArray(row.coverFallbacks)
      ? row.coverFallbacks.slice(0, 3).map(safeImage).filter((image): image is string => !!image) : [];
    items.push({
      id: row.id, title: row.title.trim(), cover, genres: [...row.genres] as string[], isTv: row.isTv === true,
      ...(alternatives.length ? { coverFallbacks: [...new Set(alternatives)] } : {}),
      ...(Number.isFinite(rating) && rating > 0 && rating <= 10 ? { rating: String(rating) } : {}),
      ...(typeof row.rank === 'number' && Number.isInteger(row.rank) && row.rank > 0 && row.rank <= 1000 ? { rank: row.rank } : {}),
    });
  }
  return { items, retrievedAt: value.retrievedAt,
    ...(value.nextPageStart === DOUBAN_DISCOVERY_PAGE_SIZE ? { nextPageStart: DOUBAN_DISCOVERY_PAGE_SIZE } : {}),
  };
}

function readRecords(storage: DiscoveryCacheStorage, now: number): Record<string, DiscoveryResponse> {
  const raw = storage.getItem(DISCOVERY_CACHE_KEY);
  if (!raw || byteLength(raw) > DISCOVERY_CACHE_MAX_BYTES) return {};
  const parsed: unknown = JSON.parse(raw);
  if (!record(parsed) || parsed.version !== 1 || !record(parsed.entries)) return {};
  const records: Record<string, DiscoveryResponse> = {};
  for (const [key, value] of Object.entries(parsed.entries).slice(0, DISCOVERY_CACHE_MAX_ENTRIES)) {
    if (!allowedKeys.has(key)) continue;
    const cleaned = cleanResponse(value, now);
    if (cleaned) records[key] = cleaned;
  }
  return records;
}

export function readDiscoveryCache(key: string, storage = browserStorage(), now = Date.now()): DiscoveryResponse | undefined {
  if (!storage || !allowedKeys.has(key)) return undefined;
  try { return readRecords(storage, now)[key]; } catch { return undefined; }
}

/** Save successes only, bounded independently from private settings and records. */
export function writeDiscoveryCache(key: string, response: DiscoveryResponse, storage = browserStorage(), now = Date.now()): boolean {
  if (!storage || !allowedKeys.has(key)) return false;
  const cleaned = cleanResponse(response, now);
  if (!cleaned) return false;
  try {
    let records: Record<string, DiscoveryResponse>;
    try { records = readRecords(storage, now); } catch { records = {}; }
    const ordered = Object.entries({ ...records, [key]: cleaned }).sort((a, b) => b[1].retrievedAt - a[1].retrievedAt)
      .slice(0, DISCOVERY_CACHE_MAX_ENTRIES);
    let serialized = JSON.stringify({ version: 1, entries: Object.fromEntries(ordered) });
    while (byteLength(serialized) > DISCOVERY_CACHE_MAX_BYTES && ordered.length > 1) {
      ordered.pop();
      serialized = JSON.stringify({ version: 1, entries: Object.fromEntries(ordered) });
    }
    if (byteLength(serialized) > DISCOVERY_CACHE_MAX_BYTES) return false;
    storage.setItem(DISCOVERY_CACHE_KEY, serialized);
    return true;
  } catch { return false; }
}
