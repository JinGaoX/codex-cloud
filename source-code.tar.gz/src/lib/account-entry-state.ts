import type { PersonalSyncStatus } from './personal-sync-runtime';

export interface AccountEntryState extends Pick<PersonalSyncStatus, 'status' | 'pendingCount' | 'conflictCount' | 'lastSyncedAt'> {
  ready: boolean;
  configured: boolean;
  scopeActive: boolean;
  user: { id: string } | null;
}

export interface AccountEntryPresentation {
  label: string;
  description: string;
  indicator: 'none' | 'busy' | 'success' | 'pending' | 'warning';
}

/** Read-only presentation: an idle runtime alone is not evidence of a successful sync. */
export function accountEntryPresentation(state: AccountEntryState): AccountEntryPresentation {
  const entry = (label: string, detail: string, indicator: AccountEntryPresentation['indicator']): AccountEntryPresentation => ({
    label, description: `账号与同步：${detail}`, indicator,
  });
  if (!state.ready) return entry('账号', '正在读取账号状态', 'busy');
  if (!state.scopeActive) return entry('登录', state.configured ? '登录个人账号，不登录继续使用本机资料' : '登录服务尚未配置，当前使用本机资料', 'none');
  if (!state.configured) return entry('未连接', '同步服务尚未配置，账号资料仍独立保存在本机', 'warning');
  if (state.status === 'auth-required') return entry('重新登录', '需要重新登录，尚未同步的资料保留在本机账号空间', 'warning');
  if (!state.user) return entry('待确认', '当前账号尚未确认', 'warning');
  if (state.status === 'conflict' || state.conflictCount > 0) return entry('待处理', '资料有不同版本需要处理，同步已暂停', 'warning');
  if (state.status === 'error') return entry('同步异常', '同步暂未完成，可打开账号面板重试', 'warning');
  const pending = Number.isSafeInteger(state.pendingCount) && state.pendingCount > 0 ? state.pendingCount : 0;
  const queued = pending ? `，${pending} 项待同步` : '';
  if (state.status === 'offline') return entry('离线', `离线，等待联网${queued}`, 'pending');
  if (state.status === 'syncing') return entry('同步中', `正在同步${queued}`, 'busy');
  if (pending) return entry('待同步', `${pending} 项资料等待同步`, 'pending');
  if (state.status === 'idle' && typeof state.lastSyncedAt === 'number' && Number.isFinite(state.lastSyncedAt) && state.lastSyncedAt > 0) return entry('已同步', '已完成同步，没有待同步资料', 'success');
  return entry('等待同步', '已登录，等待首次同步完成', 'pending');
}
