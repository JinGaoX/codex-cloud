import type { DiscoveryItem } from './discovery';

export interface LibraryGridLayout {
  columns: 2 | 3 | 4 | 5 | 6 | 7;
  size: 20 | 21 | 24;
}

/** Use the grid's available content width, after navigation and gutters, for both layout and paging. */
export function libraryGridLayout(contentWidth: number): LibraryGridLayout {
  if (contentWidth >= 1240) return { columns: 7, size: 21 };
  if (contentWidth >= 1000) return { columns: 6, size: 24 };
  if (contentWidth >= 820) return { columns: 5, size: 20 };
  if (contentWidth >= 560) return { columns: 4, size: 20 };
  if (contentWidth >= 300) return { columns: 3, size: 21 };
  return { columns: 2, size: 20 };
}

/** Legacy viewport sizing retained for callers with stored viewport-based expectations. */
export function libraryDisplaySize(width: number): 20 | 21 | 24 {
  if (width >= 1360) return 21;
  if (width >= 1000) return 24;
  if (width >= 600 || width < 360) return 20;
  return 21;
}

export interface LibraryBatch<T extends DiscoveryItem = DiscoveryItem> {
  items: T[];
  start: number;
  retrievedAt: number;
  nextPageStart?: number;
}
export interface LibraryWindow<T extends DiscoveryItem = DiscoveryItem> extends LibraryBatch<T> {
  incomplete?: boolean;
  repeated?: boolean;
}
export interface LibraryWindowOptions<T extends DiscoveryItem> {
  start: number;
  size: number;
  batchSize: number;
  limit: number;
  signal?: AbortSignal;
  loadBatch: (start: number, signal?: AbortSignal) => Promise<LibraryBatch<T>>;
  /** Bounded provider-batch fingerprints, shared across display pages of one filter. */
  seenBatches?: Map<number, readonly string[]>;
}

function checkAbort(signal?: AbortSignal): void {
  if (signal?.aborted) throw signal.reason ?? new DOMException('已取消', 'AbortError');
}

async function waitForBatch<T>(promise: Promise<T>, signal?: AbortSignal): Promise<T> {
  checkAbort(signal);
  if (!signal) return promise;
  let abort: (() => void) | undefined;
  try {
    return await Promise.race([promise, new Promise<never>((_, reject) => {
      abort = () => reject(signal.reason ?? new DOMException('已取消', 'AbortError'));
      signal.addEventListener('abort', abort, { once: true });
      if (signal.aborted) abort();
    })]);
  } finally { if (abort) signal.removeEventListener('abort', abort); }
}

/** Stitch contiguous provider positions, retaining real order/rank and a successful prefix on failure. */
export async function fetchLibraryWindow<T extends DiscoveryItem>(options: LibraryWindowOptions<T>): Promise<LibraryWindow<T>> {
  const { start, size, batchSize, limit, signal, loadBatch, seenBatches } = options;
  if (![start, size, batchSize, limit].every(Number.isSafeInteger) || start < 0 || start >= limit || size < 1 || size > 30 || ![20, 25, 50].includes(batchSize) || limit > 5000) {
    throw new Error('不支持的影视展示范围');
  }
  checkAbort(signal);
  const items: T[] = [];
  const ids = new Set<string>();
  let retrievedAt = Number.POSITIVE_INFINITY;
  let batchStart = Math.floor(start / batchSize) * batchSize;
  const end = Math.min(start + size, limit);
  let incomplete = false;
  let repeated = false;
  let hasMore = false;
  // At most three bounded provider batches; no crawl-to-fill or invented cards.
  for (let attempt = 0; attempt < 3 && batchStart < end; attempt++, batchStart += batchSize) {
    let batch: LibraryBatch<T>;
    try {
      batch = await waitForBatch(loadBatch(batchStart, signal), signal);
      checkAbort(signal);
    } catch (error) {
      checkAbort(signal);
      if (!items.length) throw error;
      incomplete = true;
      break;
    }
    if (batch.start !== batchStart || batch.items.length > batchSize) {
      if (items.length) { incomplete = true; break; }
      throw new Error('来源分页范围不匹配');
    }
    const batchIds = batch.items.map(item => item.id);
    repeated = batchIds.length > 0 && !!seenBatches && [...seenBatches].some(([offset, previous]) =>
      offset < batchStart && previous.length > 0 && batchIds.every(id => previous.includes(id)));
    if (seenBatches) {
      seenBatches.delete(batchStart);
      seenBatches.set(batchStart, batchIds);
      while (seenBatches.size > 16) seenBatches.delete(seenBatches.keys().next().value!);
    }
    if (repeated) { incomplete = true; break; }
    retrievedAt = Math.min(retrievedAt, batch.retrievedAt);
    const from = Math.max(0, start - batchStart);
    const to = Math.min(batch.items.length, end - batchStart);
    for (const item of batch.items.slice(from, to)) {
      if (ids.has(item.id)) { repeated = true; incomplete = true; break; }
      ids.add(item.id); items.push(item);
    }
    if (repeated) break;
    const providerHasMore = batch.nextPageStart !== undefined;
    // A filtered/duplicate-shortened provider batch cannot silently shift absolute offsets.
    if (providerHasMore && (batch.items.length !== batchSize || batch.nextPageStart !== batchStart + batchSize)) { incomplete = true; break; }
    hasMore = end < batchStart + batch.items.length || providerHasMore;
    if (!providerHasMore) break;
  }
  return { items, start, retrievedAt: Number.isFinite(retrievedAt) ? retrievedAt : Date.now(),
    ...(!incomplete && hasMore && start + size < limit ? { nextPageStart: start + size } : {}),
    ...(incomplete ? { incomplete: true } : {}), ...(repeated ? { repeated: true } : {}),
  };
}
