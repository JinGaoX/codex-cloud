/**
 * Restore decoder continuity only at a proven continuous main-program join
 * surrounding an already removed advertisement. Advertisement classification,
 * media bytes and media timestamps are deliberately outside this module.
 * Unknown transport/codec layouts retain the already filtered playlist.
 */
import { analyzeHlsPtsPlaylist, type HlsPtsFilterResult } from './hls-pts-filter';

const CLOCK_WRAP = 2 ** 33;
const EPSILON = 90; // One millisecond in the MPEG 90 kHz clock, not the ad detector's 2 seconds.
const AUDIO_RATES = [96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350];
const GLOBAL_TAG = /^#EXT-X-(?:KEY|MAP|VERSION|TARGETDURATION|MEDIA-SEQUENCE|DISCONTINUITY-SEQUENCE|PLAYLIST-TYPE|INDEPENDENT-SEGMENTS|START|DEFINE|ENDLIST|SESSION-DATA|SESSION-KEY|DATERANGE)(?::|$)/;

export interface HlsSpliceContinuityOptions {
  fetcher?: typeof fetch;
  resolveProbeUrl?: (absoluteUri: string) => string;
  timeoutMs?: number;
  maxSegmentBytes?: number;
  maxTotalBytes?: number;
  maxSegments?: number;
}

export interface HlsSpliceContinuitySession {
  smooth(originalContent: string, result: HlsPtsFilterResult, playlistUrl: string, signal?: AbortSignal): Promise<HlsPtsFilterResult>;
  destroy(): void;
}

interface Sps {
  id: number; bytes: Uint8Array; profile: number;
  simple?: { frameBits: number; pocType: number; pocBits: number; refs: number; progressive: boolean; gaps: boolean };
}
interface Pps {
  id: number; spsId: number; bytes: Uint8Array;
  bottomPoc: boolean; simple: boolean;
}
interface Picture {
  pts: number; dts: number; idr: boolean; sps: Sps; pps: Pps;
  firstMb: number; frameNum?: number; poc?: number; simple: boolean;
}
export interface TsSpliceProbe {
  /** Opaque transport identity includes the program, PCR PID and every elementary stream. */
  transport: string;
  video: Picture[];
  audio: { first: number; end: number; config: string };
}

function sameBytes(a: Uint8Array, b: Uint8Array): boolean {
  return a.length === b.length && a.every((value, i) => value === b[i]);
}
function delta(a: number, b: number): number {
  const difference = a - b;
  return difference - Math.round(difference / CLOCK_WRAP) * CLOCK_WRAP;
}
function close(a: number, b: number): boolean { return Math.abs(delta(a, b)) <= EPSILON; }
function concat(parts: Uint8Array[]): Uint8Array {
  const value = new Uint8Array(parts.reduce((sum, part) => sum + part.length, 0));
  let cursor = 0;
  for (const part of parts) { value.set(part, cursor); cursor += part.length; }
  return value;
}

/** A bounded RBSP reader. Truncation is an unknown stream, never an implicit zero. */
class Bits {
  private data: Uint8Array;
  private at = 0;
  constructor(nal: Uint8Array) {
    const bytes: number[] = [];
    for (let i = 1; i < nal.length; i++) {
      if (i >= 3 && nal[i] === 3 && nal[i - 1] === 0 && nal[i - 2] === 0) continue;
      bytes.push(nal[i]);
    }
    this.data = Uint8Array.from(bytes);
  }
  read(count: number): number {
    if (count < 0 || count > 24 || this.at + count > this.data.length * 8) throw new Error('truncated_rbsp');
    let value = 0;
    while (count--) { value = value * 2 + ((this.data[this.at >> 3] >> (7 - (this.at & 7))) & 1); this.at++; }
    return value;
  }
  ue(): number {
    let zeros = 0;
    while (!this.read(1)) if (++zeros > 20) throw new Error('large_golomb');
    return 2 ** zeros - 1 + this.read(zeros);
  }
}

function spsOf(bytes: Uint8Array): Sps {
  const bits = new Bits(bytes);
  const profile = bits.read(8);
  bits.read(8); bits.read(8);
  const id = bits.ue();
  if (id > 31) throw new Error('sps_id');
  const result: Sps = { id, bytes, profile };
  // The non-IDR proof intentionally supports a small, fully understood subset.
  // IDR joins only need the directly observed, byte-identical parameter sets.
  if (profile !== 66) return result;
  const frameBits = bits.ue() + 4;
  const pocType = bits.ue();
  if (frameBits > 16 || (pocType !== 0 && pocType !== 2)) return result;
  const pocBits = pocType === 0 ? bits.ue() + 4 : 0;
  if (pocBits > 16) return result;
  const refs = bits.ue();
  const gaps = !!bits.read(1);
  bits.ue(); bits.ue();
  const progressive = !!bits.read(1);
  result.simple = { frameBits, pocType, pocBits, refs, progressive, gaps };
  return result;
}
function ppsOf(bytes: Uint8Array): Pps {
  const bits = new Bits(bytes);
  const id = bits.ue(), spsId = bits.ue();
  if (id > 255 || spsId > 31) throw new Error('pps_id');
  const entropy = bits.read(1), bottomPoc = !!bits.read(1), groups = bits.ue();
  if (groups !== 0) return { id, spsId, bytes, bottomPoc, simple: false };
  const refs0 = bits.ue(), refs1 = bits.ue(), weighted = bits.read(1), bipred = bits.read(2);
  return { id, spsId, bytes, bottomPoc, simple: !entropy && !bottomPoc && !refs0 && !refs1 && !weighted && !bipred };
}
function pictureOf(nal: Uint8Array, pts: number, dts: number, sets: { sps: Map<number, Sps>; pps: Map<number, Pps> }): Picture {
  const bits = new Bits(nal);
  const firstMb = bits.ue();
  const type = bits.ue() % 5, pps = sets.pps.get(bits.ue());
  const sps = pps && sets.sps.get(pps.spsId);
  if (!pps || !sps) throw new Error('missing_active_parameter_set');
  const idr = (nal[0] & 31) === 5;
  const picture: Picture = { pts, dts, idr, sps, pps, firstMb, simple: false };
  const config = sps.simple;
  if (!config || !pps.simple || !config.progressive || config.refs !== 1 || config.gaps || !(nal[0] & 0x60) || (type !== 0 && type !== 2)) return picture;
  picture.frameNum = bits.read(config.frameBits);
  if (idr) bits.ue();
  if (config.pocType === 0) picture.poc = bits.read(config.pocBits);
  if (type === 0) {
    if (bits.read(1)) { if (bits.ue() !== 0) return picture; }
    if (bits.read(1)) return picture; // Custom reference lists are outside the proof.
  }
  // Baseline PPS fields after weighted prediction precede the redundant-picture flag.
  const pb = new Bits(pps.bytes);
  pb.ue(); pb.ue(); pb.read(1); pb.read(1); pb.ue(); pb.ue(); pb.ue(); pb.read(1); pb.read(2);
  pb.ue(); pb.ue(); pb.ue(); pb.read(1); pb.read(1);
  if (pb.read(1)) return picture;
  if (idr) { bits.read(1); if (bits.read(1)) return picture; }
  else if (bits.read(1)) return picture; // Adaptive MMCO/long-term references are not inferred.
  picture.simple = true;
  return picture;
}

function nalsOf(bytes: Uint8Array): Uint8Array[] {
  const starts: { prefix: number; data: number }[] = [];
  for (let i = 0; i + 3 < bytes.length; i++) {
    if (bytes[i] === 0 && bytes[i + 1] === 0 && (bytes[i + 2] === 1 || (bytes[i + 2] === 0 && bytes[i + 3] === 1))) {
      const data = i + (bytes[i + 2] === 1 ? 3 : 4);
      starts.push({ prefix: i, data }); i = data - 1;
    }
  }
  if (!starts.length || starts[0].prefix !== 0) throw new Error('incomplete_annex_b');
  return starts.map((start, i) => bytes.subarray(start.data, starts[i + 1]?.prefix ?? bytes.length));
}
function timestamp(bytes: Uint8Array, at: number, prefix: number): number {
  if (at + 5 > bytes.length || (bytes[at] >> 4) !== prefix || !(bytes[at] & 1) || !(bytes[at + 2] & 1) || !(bytes[at + 4] & 1)) throw new Error('invalid_timestamp');
  return ((bytes[at] >> 1) & 7) * 2 ** 30 + bytes[at + 1] * 2 ** 22 + ((bytes[at + 2] >> 1) & 127) * 2 ** 15 + bytes[at + 3] * 2 ** 7 + (bytes[at + 4] >> 1);
}
function pesOf(parts: Uint8Array[]): { pts: number; dts: number; data: Uint8Array } {
  let bytes = concat(parts);
  if (bytes.length < 14 || bytes[0] || bytes[1] || bytes[2] !== 1 || (bytes[6] & 0xc0) !== 0x80) throw new Error('invalid_pes');
  const length = (bytes[4] << 8) | bytes[5];
  if (length) { if (bytes.length !== length + 6) throw new Error('incomplete_pes'); bytes = bytes.subarray(0, length + 6); }
  const flags = bytes[7] >> 6;
  if ((flags !== 2 && flags !== 3) || bytes[8] < (flags === 3 ? 10 : 5) || bytes.length <= 9 + bytes[8]) throw new Error('pes_timing');
  const pts = timestamp(bytes, 9, flags === 3 ? 3 : 2), dts = flags === 3 ? timestamp(bytes, 14, 1) : pts;
  return { pts, dts, data: bytes.subarray(9 + bytes[8]) };
}

/** Full bounded normal TS fragments only; never probes or decodes advertisement bytes. */
export function readTsSpliceProbe(bytes: Uint8Array): TsSpliceProbe | null {
  try {
    let sync = -1;
    for (let i = 0; i < Math.min(4096, bytes.length - 376); i++) {
      if (bytes[i] === 0x47 && bytes[i + 188] === 0x47 && bytes[i + 376] === 0x47) { sync = i; break; }
    }
    if (sync < 0 || (bytes.length - sync) % 188) return null;
    let pmtPid = -1, program = -1, videoPid = -1, audioPid = -1, transport = '';
    const counters = new Map<number, number>();
    const buffers = new Map<number, Uint8Array[]>();
    const video: Picture[] = [];
    const sets = { sps: new Map<number, Sps>(), pps: new Map<number, Pps>() };
    let audio: TsSpliceProbe['audio'] | undefined;
    const flush = (pid: number) => {
      const parts = buffers.get(pid);
      if (!parts?.length) return;
      const pes = pesOf(parts);
      if (pid === videoPid) {
        let picture: Picture | undefined;
        let auds = 0;
        for (const nal of nalsOf(pes.data)) {
          if (!nal.length || (nal[0] & 0x80)) throw new Error('invalid_nal');
          const type = nal[0] & 31;
          if (type === 7) {
            const sps = spsOf(nal), previous = sets.sps.get(sps.id);
            if (sets.sps.size && !previous) throw new Error('multiple_parameter_sets');
            if (previous && !sameBytes(previous.bytes, sps.bytes)) throw new Error('sps_redefinition');
            sets.sps.set(sps.id, sps);
          } else if (type === 8) {
            const pps = ppsOf(nal), previous = sets.pps.get(pps.id);
            if (sets.pps.size && !previous) throw new Error('multiple_parameter_sets');
            if (previous && !sameBytes(previous.bytes, pps.bytes)) throw new Error('pps_redefinition');
            sets.pps.set(pps.id, pps);
          }
          else if (type === 9) { if (++auds > 1) throw new Error('multiple_pictures_per_pes'); }
          else if (type === 1 || type === 5) {
            const next = pictureOf(nal, pes.pts, pes.dts, sets);
            if ((!picture && next.firstMb !== 0) || (picture && (next.firstMb <= picture.firstMb || picture.frameNum === undefined || next.frameNum === undefined || picture.idr !== next.idr || picture.frameNum !== next.frameNum || picture.poc !== next.poc || !sameBytes(picture.pps.bytes, next.pps.bytes) || !sameBytes(picture.sps.bytes, next.sps.bytes)))) throw new Error('multiple_or_partial_pictures_per_pes');
            if (picture) next.simple = next.simple && picture.simple;
            picture = next;
          } else if (![6, 12].includes(type)) throw new Error('unsupported_avc_extension');
        }
        if (!picture) throw new Error('missing_picture');
        video.push(picture);
      } else {
        let cursor = 0, frames = 0, config = '', rate = 0;
        while (cursor < pes.data.length) {
          const b = pes.data.subarray(cursor);
          if (b.length < 7 || b[0] !== 255 || (b[1] & 0xf6) !== 0xf0 || (b[6] & 3)) throw new Error('unsupported_aac');
          const header = b[1] & 1 ? 7 : 9;
          rate = AUDIO_RATES[(b[2] >> 2) & 15];
          const channels = ((b[2] & 1) << 2) | (b[3] >> 6);
          const length = ((b[3] & 3) << 11) | (b[4] << 3) | (b[5] >> 5);
          const nextConfig = `${b[1] & 8}:${b[2] >> 6}:${rate}:${channels}`;
          if (!rate || !channels || length < header || length > b.length || (config && config !== nextConfig)) throw new Error('incomplete_or_changed_aac');
          config = nextConfig; cursor += length; frames++;
        }
        if (!frames || (audio && (audio.config !== config || !close(pes.pts, audio.end)))) throw new Error('audio_gap');
        audio = { first: audio?.first ?? pes.pts, end: pes.pts + frames * 1024 * 90000 / rate, config };
      }
      buffers.set(pid, []);
    };
    for (let pos = sync; pos < bytes.length; pos += 188) {
      if (bytes[pos] !== 0x47 || (bytes[pos + 1] & 0x80) || (bytes[pos + 3] & 0xc0)) return null;
      const pid = ((bytes[pos + 1] & 31) << 8) | bytes[pos + 2], starts = !!(bytes[pos + 1] & 0x40), afc = (bytes[pos + 3] >> 4) & 3;
      if (!afc) return null;
      let at = pos + 4;
      if (afc & 2) {
        const length = bytes[at++];
        if (length > 183 || at + length > pos + 188 || (length && (bytes[at] & 0x80))) return null;
        at += length;
      }
      if (!(afc & 1) || pid === 8191) continue;
      if (at >= pos + 188) return null;
      const cc = bytes[pos + 3] & 15, previous = counters.get(pid);
      if (previous !== undefined && cc !== (previous + 1) % 16) return null;
      counters.set(pid, cc);
      if (pid === 0 || pid === pmtPid) {
        if (!starts) return null; // Multi-packet PSI is deliberately unsupported.
        const section = at + 1 + bytes[at];
        if (section + 12 > pos + 188) return null;
        const end = section + 3 + (((bytes[section + 1] & 15) << 8) | bytes[section + 2]) - 4;
        if (end > pos + 188 || end < section + 8 || !(bytes[section + 5] & 1) || bytes[section + 6] || bytes[section + 7]) return null;
        if (pid === 0) {
          if (bytes[section] !== 0 || end !== section + 12) return null; // Exactly one program.
          const nextProgram = (bytes[section + 8] << 8) | bytes[section + 9], nextPid = ((bytes[section + 10] & 31) << 8) | bytes[section + 11];
          if (!nextProgram || (program !== -1 && (program !== nextProgram || pmtPid !== nextPid))) return null;
          program = nextProgram; pmtPid = nextPid;
        } else {
          if (bytes[section] !== 2 || ((bytes[section + 3] << 8) | bytes[section + 4]) !== program) return null;
          const pcrPid = ((bytes[section + 8] & 31) << 8) | bytes[section + 9];
          const info = ((bytes[section + 10] & 15) << 8) | bytes[section + 11];
          const streams: string[] = [];
          let nextVideo = -1, nextAudio = -1;
          for (let cursor = section + 12 + info; cursor < end;) {
            if (cursor + 5 > end) return null;
            const type = bytes[cursor], elementary = ((bytes[cursor + 1] & 31) << 8) | bytes[cursor + 2];
            const descriptorLength = ((bytes[cursor + 3] & 15) << 8) | bytes[cursor + 4];
            if (cursor + 5 + descriptorLength > end) return null;
            streams.push(`${type}:${elementary}:${Array.from(bytes.subarray(cursor + 5, cursor + 5 + descriptorLength)).join(',')}`);
            if (type === 0x1b && nextVideo === -1) nextVideo = elementary;
            else if (type === 0x0f && nextAudio === -1) nextAudio = elementary;
            else return null; // No separate/unknown/multiple audio or video tracks.
            cursor += 5 + descriptorLength;
          }
          if (nextVideo < 0 || nextAudio < 0 || nextVideo === nextAudio) return null;
          const identity = `${program}:${pmtPid}:${pcrPid}:${Array.from(bytes.subarray(section + 12, section + 12 + info)).join(',')}:${streams.join('|')}`;
          if (transport && transport !== identity) return null;
          transport = identity; videoPid = nextVideo; audioPid = nextAudio;
        }
      } else if (pid === videoPid || pid === audioPid) {
        if (starts) { flush(pid); buffers.set(pid, []); }
        else if (!buffers.has(pid)) return null;
        buffers.get(pid)!.push(bytes.subarray(at, pos + 188));
      } else if (starts && bytes[at] === 0 && bytes[at + 1] === 0 && bytes[at + 2] === 1) return null;
    }
    flush(videoPid); flush(audioPid);
    if (!transport || video.length < 2 || !audio) return null;
    return { transport, video, audio };
  } catch { return null; }
}

/** Decoding and presentation timelines must both continue, including 33-bit wrap. */
export function canJoinTsSplice(left: TsSpliceProbe, right: TsSpliceProbe): boolean {
  if (left.transport !== right.transport || left.audio.config !== right.audio.config || !close(right.audio.first, left.audio.end)) return false;
  const last = left.video.at(-1)!, first = right.video[0];
  if (!sameBytes(last.sps.bytes, first.sps.bytes) || !sameBytes(last.pps.bytes, first.pps.bytes)) return false;
  const durations = [delta(last.dts, left.video.at(-2)!.dts), delta(right.video[1].dts, first.dts)];
  const cadence = durations[0];
  if (cadence <= 0 || cadence > 22500 || Math.abs(durations[1] - cadence) > EPSILON || !close(first.dts, last.dts + cadence)) return false;
  // Every inspected picture must stay in the same directly observed configuration.
  for (const probe of [left, right]) for (let i = 0; i < probe.video.length; i++) {
    const picture = probe.video[i];
    if (!sameBytes(picture.sps.bytes, first.sps.bytes) || !sameBytes(picture.pps.bytes, first.pps.bytes)) return false;
    if (i && Math.abs(delta(picture.dts, probe.video[i - 1].dts) - cadence) > EPSILON) return false;
  }
  const leftMaxPts = Math.max(...left.video.map((picture) => delta(picture.pts, last.dts)));
  const rightMinPts = Math.min(...right.video.map((picture) => delta(picture.pts, last.dts)));
  if (Math.abs(rightMinPts - leftMaxPts - cadence) > EPSILON) return false;
  if (first.idr) return true;
  // Non-IDR frames are accepted only when their sole reference is the preceding
  // retained picture. B frames, long-term/reference-list changes and unknown
  // parameter sets retain the discontinuity; a later IDR is not used as a guess.
  const pictures = [...left.video, ...right.video];
  for (let i = 0; i < pictures.length; i++) {
    const picture = pictures[i], config = picture.sps.simple;
    if (!picture.simple || !config || !close(picture.pts, picture.dts)) return false;
    if (!i || picture.idr) continue;
    const previous = pictures[i - 1];
    if (picture.frameNum !== (previous.frameNum! + 1) % 2 ** config.frameBits) return false;
    if (config.pocType === 0 && picture.poc !== (previous.poc! + 2) % 2 ** config.pocBits) return false;
  }
  return true;
}

function linesOf(content: string): string[] { return content.match(/[^\n]*(?:\n|$)/g)?.filter(Boolean) ?? []; }
interface Bridge { left: string; right: string; lines: number[] }
function bridgesOf(original: string, result: HlsPtsFilterResult, playlistUrl: string): { lines: string[]; bridges: Bridge[] } | null {
  if (result.status !== 'filtered' || !result.removedGroups.length) return null;
  if (/^#EXT-X-MEDIA:/m.test(original)) return null;
  playlistUrl = new URL(playlistUrl, typeof document === 'undefined' ? undefined : document.baseURI).href;
  const analysis = analyzeHlsPtsPlaylist(original, playlistUrl);
  if (analysis.reason || result.totalGroups !== analysis.groups.length) return null;
  const source = linesOf(original), removedLines = new Set<number>(), removedSegments = new Set<number>(), groups = new Set<number>();
  let duration = 0;
  for (const removed of result.removedGroups) {
    const group = analysis.groups[removed.index];
    if (!group || groups.has(group.index) || group.startSegmentIndex !== removed.startSegmentIndex || group.endSegmentIndex !== removed.endSegmentIndex || group.segmentCount !== removed.segmentCount || group.startSeconds !== removed.startSeconds || group.durationMillis / 1000 !== removed.durationSeconds) return null;
    groups.add(group.index); duration += removed.durationSeconds;
    for (let i = group.startSegmentIndex; i <= group.endSegmentIndex; i++) removedSegments.add(i);
    for (let i = group.lineStart; i <= group.lineEnd; i++) if (!GLOBAL_TAG.test(source[i].trim())) removedLines.add(i);
  }
  if (Math.abs(duration - result.removedSeconds) > 0.000001) return null;
  const survivors = source.map((line, index) => ({ line, index })).filter(({ index }) => !removedLines.has(index));
  // Do not trust arbitrary caller metadata: every surviving byte must match the
  // original PTS filter's exact output before removing even one discontinuity.
  if (survivors.map(({ line }) => line).join('') !== result.content) return null;
  const media = source.flatMap((line, index) => line.trim() && !line.trim().startsWith('#') ? [{ index, uri: line.trim() }] : []);
  const bridges: Bridge[] = [];
  for (let i = 0; i < media.length; i++) {
    if (!removedSegments.has(i)) continue;
    const start = i;
    while (i + 1 < media.length && removedSegments.has(i + 1)) i++;
    if (!start || i + 1 === media.length) continue;
    const left = media[start - 1], right = media[i + 1];
    const lines = survivors.flatMap(({ line, index }, survivingIndex) => index > left.index && index < right.index && line.trim() === '#EXT-X-DISCONTINUITY' ? [survivingIndex] : []);
    if (lines.length) bridges.push({ left: new URL(left.uri, playlistUrl).href, right: new URL(right.uri, playlistUrl).href, lines });
  }
  return { lines: survivors.map(({ line }) => line), bridges };
}

function aborted(): Error { return new Error('splice_probe_aborted'); }
function cancelBody(body: ReadableStream<Uint8Array> | null): void {
  try { void body?.cancel().catch(() => {}); } catch { /* Cancellation is best effort, never a new wait. */ }
}
function cancellable<T>(promise: Promise<T>, signal: AbortSignal): Promise<T> {
  return new Promise((resolve, reject) => {
    const cancel = () => reject(aborted());
    if (signal.aborted) return cancel();
    signal.addEventListener('abort', cancel, { once: true });
    promise.then(resolve, reject).finally(() => signal.removeEventListener('abort', cancel));
  });
}
function bounded(value: number | undefined, fallback: number, min: number, max: number): number {
  return Number.isFinite(value) ? Math.max(min, Math.min(max, Math.floor(value!))) : fallback;
}

export function createHlsSpliceContinuitySession(options: HlsSpliceContinuityOptions = {}): HlsSpliceContinuitySession {
  const fetcher = options.fetcher ?? fetch;
  const timeout = bounded(options.timeoutMs, 2500, 1, 5000);
  const maxBytes = bounded(options.maxSegmentBytes, 2 * 1024 * 1024, 188 * 3, 4 * 1024 * 1024);
  const maxTotal = bounded(options.maxTotalBytes, 8 * 1024 * 1024, 188 * 3, 16 * 1024 * 1024);
  const maxSegments = bounded(options.maxSegments, 8, 2, 16);
  const lifetime = new AbortController();
  const pending = new Set<AbortController>();
  const decisions: { original: string; filtered: string; url: string; content: string }[] = [];
  let active = 0;
  const queue = new Set<() => void>();
  const acquire = (signal: AbortSignal): Promise<(() => void) | null> => new Promise((resolve) => {
    const cancel = () => { queue.delete(grant); resolve(null); };
    const grant = () => {
      signal.removeEventListener('abort', cancel);
      queue.delete(grant);
      if (signal.aborted) { resolve(null); return; }
      active++;
      let released = false;
      resolve(() => {
        if (released) return;
        released = true; active--;
        if (active < 2) queue.values().next().value?.();
      });
    };
    if (signal.aborted) resolve(null);
    else if (active < 2) grant();
    else { queue.add(grant); signal.addEventListener('abort', cancel, { once: true }); }
  });
  return {
    destroy() { lifetime.abort(); for (const controller of pending) controller.abort(); decisions.length = 0; },
    async smooth(original, result, playlistUrl, signal) {
      if (lifetime.signal.aborted || signal?.aborted) return result;
      let plan: ReturnType<typeof bridgesOf>;
      try { plan = bridgesOf(original, result, playlistUrl); } catch { return result; }
      if (!plan?.bridges.length) return result;
      const known = decisions.find((entry) => entry.original === original && entry.filtered === result.content && entry.url === playlistUrl);
      if (known) return { ...result, content: known.content };
      const controller = new AbortController(), cancel = () => controller.abort();
      pending.add(controller);
      signal?.addEventListener('abort', cancel, { once: true });
      lifetime.signal.addEventListener('abort', cancel, { once: true });
      const timer = setTimeout(cancel, timeout);
      const probes = new Map<string, TsSpliceProbe | null>();
      const urls = [...new Set(plan.bridges.flatMap((bridge) => [bridge.left, bridge.right]))].slice(0, maxSegments);
      let next = 0, total = 0;
      const probe = async (url: string) => {
        let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
        let release: (() => void) | null = null;
        try {
          release = await acquire(controller.signal);
          if (!release) return null;
          const request = fetcher(options.resolveProbeUrl?.(url) ?? url, { signal: controller.signal, cache: 'no-store' });
          void request.then((response) => { if (controller.signal.aborted) cancelBody(response.body); }, () => {});
          const response = await cancellable(request, controller.signal);
          if (!response.ok || (response.status !== 200 && response.status !== 206) || !response.body) { cancelBody(response.body); return null; }
          const declared = response.headers.get('Content-Length');
          if (declared && (!/^\d+$/.test(declared) || Number(declared) > maxBytes)) { cancelBody(response.body); return null; }
          const range = response.headers.get('Content-Range');
          if (response.status === 206 && (!range || !/^bytes 0-\d+\/\d+$/.test(range) || Number(range.match(/\/(\d+)$/)![1]) !== Number(range.match(/-(\d+)/)![1]) + 1)) { cancelBody(response.body); return null; }
          reader = response.body.getReader();
          const parts: Uint8Array[] = [];
          let size = 0;
          while (true) {
            const chunk = await cancellable(reader.read(), controller.signal);
            if (chunk.done) break;
            size += chunk.value.length; total += chunk.value.length;
            if (size > maxBytes || total > maxTotal) return null;
            parts.push(chunk.value);
          }
          if (!size || (declared && size !== Number(declared)) || (range && size !== Number(range.match(/\/(\d+)$/)?.[1]))) return null;
          return readTsSpliceProbe(concat(parts));
        } catch { return null; }
        finally {
          if (reader) { try { void reader.cancel().catch(() => {}); reader.releaseLock(); } catch { /* An outstanding read/cancel must not outlive the deadline here. */ } }
          release?.();
        }
      };
      try {
        await Promise.all(Array.from({ length: Math.min(2, urls.length) }, async () => {
          while (next < urls.length && !controller.signal.aborted && total < maxTotal) { const url = urls[next++]; probes.set(url, await probe(url)); }
        }));
        if (signal?.aborted || lifetime.signal.aborted) return result;
        const dropped = new Set<number>();
        for (const bridge of plan.bridges) {
          const left = probes.get(bridge.left), right = probes.get(bridge.right);
          if (left && right && canJoinTsSplice(left, right)) bridge.lines.forEach((line) => dropped.add(line));
        }
        const content = plan.lines.filter((_, i) => !dropped.has(i)).join('');
        const existing = decisions.find((entry) => entry.original === original && entry.filtered === result.content && entry.url === playlistUrl);
        if (existing) return { ...result, content: existing.content };
        decisions.push({ original, filtered: result.content, url: playlistUrl, content });
        while (decisions.length > 4 || (decisions.length > 1 && decisions.reduce((sum, entry) => sum + entry.original.length + entry.filtered.length + entry.content.length, 0) > 6 * 1024 * 1024)) decisions.shift();
        return { ...result, content };
      } catch { return result; }
      finally { clearTimeout(timer); pending.delete(controller); controller.abort(); signal?.removeEventListener('abort', cancel); lifetime.signal.removeEventListener('abort', cancel); }
    },
  };
}
