import { describe, expect, it, vi } from 'vitest';
import { analyzeHlsPtsPlaylist, type HlsPtsFilterResult } from './hls-pts-filter';
import { canJoinTsSplice, createHlsSpliceContinuitySession, readTsSpliceProbe } from './hls-splice-continuity';

const BASE = 'https://media.example/movie/index.m3u8';
const WRAP = 2 ** 33;
function ue(value: number): string { const valueBits = (value + 1).toString(2); return '0'.repeat(valueBits.length - 1) + valueBits; }
function nal(header: number, bits: string): number[] {
  const data = bits + '1' + '0'.repeat((7 - bits.length % 8) % 8);
  return [header, ...data.match(/.{8}/g)!.map((byte) => parseInt(byte, 2))];
}
function fixed(value: number, bits: number): string { return value.toString(2).padStart(bits, '0'); }
const SPS = nal(0x67, fixed(66, 8) + fixed(0xc0, 8) + fixed(11, 8) + ue(0) + ue(0) + ue(2) + ue(1) + '0' + ue(19) + ue(10) + '1100');
const PPS = nal(0x68, ue(0) + ue(0) + '00' + ue(0) + ue(0) + ue(0) + '000' + ue(0) + ue(0) + ue(0) + '100');
function picture(frame: number, idr: boolean, changedFrame = false): number[] {
  return nal(idr ? 0x65 : 0x41, ue(0) + ue(idr ? 2 : 0) + ue(0) + fixed(changedFrame ? (frame + 2) % 16 : frame % 16, 4) + (idr ? ue(0) + '00' : '000') + ue(0));
}
function clock(value: number, prefix = 2): number[] {
  const ticks = (Math.round(value) % WRAP + WRAP) % WRAP;
  return [(prefix << 4) | ((Math.floor(ticks / 2 ** 30) & 7) << 1) | 1, Math.floor(ticks / 2 ** 22) & 255, ((Math.floor(ticks / 2 ** 15) & 127) << 1) | 1, Math.floor(ticks / 2 ** 7) & 255, ((ticks % 128) << 1) | 1];
}
function pes(stream: number, time: number, payload: number[]): number[] {
  const length = payload.length + 8;
  return [0, 0, 1, stream, length >> 8, length & 255, 0x80, 0x80, 5, ...clock(time), ...payload];
}
function packet(pid: number, bytes: number[], cc = 0): Uint8Array<ArrayBuffer> {
  if (bytes.length > 183) throw new Error('fixture_packet_too_large');
  const data = new Uint8Array(188).fill(255), adaptation = 183 - bytes.length;
  data.set([0x47, 0x40 | (pid >> 8), pid & 255, 0x30 | cc, adaptation]);
  if (adaptation) data[5] = 0;
  data.set(bytes, 5 + adaptation);
  return data;
}
function joined(parts: Uint8Array[]): Uint8Array<ArrayBuffer> {
  const data = new Uint8Array(parts.length * 188);
  parts.forEach((part, i) => data.set(part, i * 188));
  return data;
}
function segment(start = 90000, options: { idr?: boolean; frame?: number; badFrame?: boolean; sps?: number[]; audioRate?: number; missingAudio?: boolean; missingSps?: boolean } = {}): Uint8Array<ArrayBuffer> {
  const pat = packet(0, [0, 0, 0xb0, 13, 0, 1, 0xc1, 0, 0, 0, 1, 0xf0, 0, 0, 0, 0, 0]);
  const pmt = packet(4096, [0, 2, 0xb0, 23, 0, 1, 0xc1, 0, 0, 0xe1, 0, 0xf0, 0, 0x1b, 0xe1, 0, 0xf0, 0, 0x0f, 0xe1, 1, 0xf0, 0, 0, 0, 0, 0]);
  const packets = [pat, pmt];
  for (let i = 0; i < 8; i++) {
    const sps = options.sps ?? SPS;
    const avc = [...(options.missingSps ? [] : [0, 0, 1, ...sps, 0, 0, 1, ...PPS]), 0, 0, 1, ...picture((options.frame ?? 0) + i, !!options.idr && i === 0, !!options.badFrame && i === 0)];
    packets.push(packet(256, pes(0xe0, start + i * 3600, avc), i));
  }
  if (!options.missingAudio) for (let i = 0; i < 15; i++) {
    const rateIndex = options.audioRate ?? 3;
    packets.push(packet(257, pes(0xc0, start + i * 1920, [255, 0xf1, 0x40 | (rateIndex << 2), 0x80, 1, 0x3f, 0xfc, 0, 0]), i));
  }
  return joined(packets);
}
function fixture(crlf = false) {
  const original = ['#EXTM3U', '#EXT-X-VERSION:3', '#EXT-X-TARGETDURATION:1', '#EXT-X-MEDIA-SEQUENCE:8', '#EXTINF:0.32,', 'left.ts', '#EXT-X-DISCONTINUITY', '#EXTINF:0.2,', 'ad.ts', '#EXT-X-DISCONTINUITY', '#EXT-X-DISCONTINUITY', '#EXTINF:0.32,', 'right.ts', '#EXT-X-DISCONTINUITY', '#EXTINF:0.32,', 'ordinary.ts', '#EXT-X-ENDLIST', ''].join(crlf ? '\r\n' : '\n');
  const eol = crlf ? '\r\n' : '\n';
  const filtered = original.replace(['#EXT-X-DISCONTINUITY', '#EXTINF:0.2,', 'ad.ts', ''].join(eol), '');
  const analysis = analyzeHlsPtsPlaylist(original, BASE), group = analysis.groups[1];
  const result: HlsPtsFilterResult = { content: filtered, status: 'filtered', reason: 'pts_continuity', complete: true, totalGroups: analysis.groups.length, probedGroups: analysis.groups.length, removedSeconds: 0.2, removedGroups: [{ index: 1, startSegmentIndex: group.startSegmentIndex, endSegmentIndex: group.endSegmentIndex, startSeconds: group.startSeconds, segmentCount: group.segmentCount, durationSeconds: 0.2 }] };
  return { original, result };
}
function fetching(left = segment(90000, { idr: true }), right = segment(118800, { frame: 8 })) {
  return vi.fn<typeof fetch>(async (input) => {
    const url = String(input);
    if (url.endsWith('/left.ts')) return new Response(left);
    if (url.endsWith('/right.ts')) return new Response(right);
    throw new Error('Probe must never fetch an ad or unrelated media');
  });
}

describe('strict full-TS splice evidence', () => {
  it('accepts a continuous Baseline P-only single-reference stream without requiring an IDR', () => {
    const left = readTsSpliceProbe(segment(90000, { idr: true }));
    const right = readTsSpliceProbe(segment(118800, { frame: 8 }));
    expect(left).not.toBeNull(); expect(right).not.toBeNull();
    expect(right!.video[0].idr).toBe(false);
    expect(canJoinTsSplice(left!, right!)).toBe(true);
  });

  it('also accepts an independent IDR with matching directly observed parameters', () => {
    expect(canJoinTsSplice(readTsSpliceProbe(segment())!, readTsSpliceProbe(segment(118800, { idr: true }))!)).toBe(true);
  });

  it('normalizes the full 33-bit clock rather than overflowing a 32-bit integer', () => {
    const start = WRAP - 28800;
    expect(canJoinTsSplice(readTsSpliceProbe(segment(start, { idr: true }))!, readTsSpliceProbe(segment(0, { frame: 8 }))!)).toBe(true);
  });

  it('rejects missing main time, a reference-frame jump, or a changed SPS even when resolution could match', () => {
    const left = readTsSpliceProbe(segment(90000, { idr: true }))!;
    expect(canJoinTsSplice(left, readTsSpliceProbe(segment(122400, { frame: 8 }))!)).toBe(false);
    expect(canJoinTsSplice(left, readTsSpliceProbe(segment(118800, { frame: 8, badFrame: true }))!)).toBe(false);
    const sps = [...SPS]; sps[3]++;
    expect(canJoinTsSplice(left, readTsSpliceProbe(segment(118800, { idr: true, sps }))!)).toBe(false);
  });

  it('does not infer missing parameters, missing audio, truncated packets or scrambled media', () => {
    expect(readTsSpliceProbe(segment(118800, { missingSps: true }))).toBeNull();
    expect(readTsSpliceProbe(segment(118800, { missingAudio: true }))).toBeNull();
    expect(readTsSpliceProbe(segment().subarray(0, -1))).toBeNull();
    const scrambled = segment(); scrambled[188 * 2 + 3] |= 0x80;
    expect(readTsSpliceProbe(scrambled)).toBeNull();
    const brokenCc = segment(); brokenCc[188 * 3 + 3] ^= 1;
    expect(readTsSpliceProbe(brokenCc)).toBeNull();
    // AAC frequency changed while timestamps still describe the former frequency.
    expect(readTsSpliceProbe(segment(118800, { audioRate: 4 }))).toBeNull();
  });
});

describe('ad-removal-preserving bounded continuity session', () => {
  it('removes only duplicate bridge discontinuities, retaining CRLF, every surviving URI/EXTINF and ordinary discontinuity', async () => {
    const { original, result } = fixture(true), fetcher = fetching();
    const session = createHlsSpliceContinuitySession({ fetcher });
    const actual = await session.smooth(original, result, BASE);
    expect(actual.content).toBe(result.content.replace('#EXT-X-DISCONTINUITY\r\n#EXT-X-DISCONTINUITY\r\n', ''));
    expect(actual.content).toContain('right.ts\r\n#EXT-X-DISCONTINUITY\r\n#EXTINF:0.32,\r\nordinary.ts');
    expect({ ...actual, content: '' }).toEqual({ ...result, content: '' });
    expect(fetcher).toHaveBeenCalledTimes(2);
    expect(fetcher.mock.calls.every(([url]) => !String(url).includes('ad.ts'))).toBe(true);
    // A completed decision freezes both successful joins and conservative refusals.
    expect((await session.smooth(original, result, BASE)).content).toBe(actual.content);
    expect(fetcher).toHaveBeenCalledTimes(2);
    session.destroy();
  });

  it('keeps the already filtered result when transport or decoder continuity cannot be proven', async () => {
    const { original, result } = fixture();
    const session = createHlsSpliceContinuitySession({ fetcher: fetching(segment(), segment(122400, { frame: 8 })) });
    expect(await session.smooth(original, result, BASE)).toEqual(result);
    session.destroy();
  });

  it('rejects forged removal metadata and reordered/edited filtered bytes before fetching', async () => {
    const { original, result } = fixture(), fetcher = fetching();
    const session = createHlsSpliceContinuitySession({ fetcher });
    expect(await session.smooth(original, { ...result, content: result.content.replace('right.ts', 'different.ts') }, BASE)).toMatchObject({ content: result.content.replace('right.ts', 'different.ts') });
    expect(await session.smooth(original, { ...result, removedGroups: [{ ...result.removedGroups[0], segmentCount: 2 }] }, BASE)).toMatchObject({ content: result.content });
    expect(fetcher).not.toHaveBeenCalled();
    session.destroy();
  });

  it('resolves browser-relative playlist URLs using document.baseURI, and refuses them without a browser base', async () => {
    const { original, result } = fixture();
    const fetcher = vi.fn<typeof fetch>(async () => { throw new Error('No media read in this URL-resolution test'); });
    const session = createHlsSpliceContinuitySession({ fetcher });
    expect(await session.smooth(original, result, '/movie/index.m3u8')).toEqual(result);
    expect(fetcher).not.toHaveBeenCalled();
    vi.stubGlobal('document', { baseURI: 'https://media.example/app/' });
    try {
      expect(await session.smooth(original, result, '/movie/index.m3u8')).toEqual(result);
      expect(fetcher.mock.calls.map(([url]) => String(url)).sort()).toEqual(['https://media.example/movie/left.ts', 'https://media.example/movie/right.ts']);
    } finally { vi.unstubAllGlobals(); session.destroy(); }
  });

  it.each(['#EXT-X-KEY:METHOD=AES-128,URI="secret"', '#EXT-X-BYTERANGE:188@0', '#EXT-X-MAP:URI="init.mp4"'])('rechecks unsupported playlist protection: %s', async (tag) => {
    const { original, result } = fixture(), fetcher = fetching();
    const session = createHlsSpliceContinuitySession({ fetcher });
    expect(await session.smooth(original.replace('#EXTM3U', `#EXTM3U\n${tag}`), result, BASE)).toEqual(result);
    expect(fetcher).not.toHaveBeenCalled(); session.destroy();
  });

  it('bounds payload reads even when the server omits length or returns a truncated HTTP range', async () => {
    const { original, result } = fixture();
    const oversized = createHlsSpliceContinuitySession({ fetcher: fetching(), maxSegmentBytes: 188 * 3 });
    expect(await oversized.smooth(original, result, BASE)).toEqual(result); oversized.destroy();
    const ranged = createHlsSpliceContinuitySession({ fetcher: vi.fn<typeof fetch>(async () => new Response(segment(), { status: 206, headers: { 'Content-Range': 'bytes 0-1023/50000' } })) });
    expect(await ranged.smooth(original, result, BASE)).toEqual(result); ranged.destroy();
  });

  it('fails closed on network errors, timeout, caller abort and destroy, without restoring advertisement media', async () => {
    const { original, result } = fixture();
    const failed = createHlsSpliceContinuitySession({ fetcher: vi.fn<typeof fetch>(async () => { throw new Error('offline'); }) });
    expect(await failed.smooth(original, result, BASE)).toEqual(result); failed.destroy();
    const stalled = createHlsSpliceContinuitySession({ fetcher: vi.fn<typeof fetch>(() => new Promise(() => {})), timeoutMs: 10 });
    expect(await stalled.smooth(original, result, BASE)).toEqual(result); stalled.destroy();
    const controller = new AbortController(); controller.abort();
    const fetcher = fetching(), session = createHlsSpliceContinuitySession({ fetcher });
    expect(await session.smooth(original, result, BASE, controller.signal)).toEqual(result);
    session.destroy(); expect(await session.smooth(original, result, BASE)).toEqual(result);
    expect(fetcher).not.toHaveBeenCalled();
  });

  it('does not wait for an uncooperative stream cancel, and cancels late responses after timeout', async () => {
    const { original, result } = fixture();
    const cancel = vi.fn(() => new Promise<void>(() => {}));
    const stream = createHlsSpliceContinuitySession({ timeoutMs: 10, fetcher: vi.fn<typeof fetch>(async () => new Response(new ReadableStream({ pull() { return new Promise(() => {}); }, cancel }))) });
    expect(await stream.smooth(original, result, BASE)).toEqual(result);
    expect(cancel).toHaveBeenCalledTimes(2); stream.destroy();
    const lateCancel = vi.fn();
    const late = createHlsSpliceContinuitySession({ timeoutMs: 10, fetcher: vi.fn<typeof fetch>(() => new Promise((resolve) => setTimeout(() => resolve(new Response(new ReadableStream({ cancel: lateCancel }))), 25))) });
    expect(await late.smooth(original, result, BASE)).toEqual(result);
    await new Promise((resolve) => setTimeout(resolve, 35));
    expect(lateCancel).toHaveBeenCalledTimes(2); late.destroy();
  });

  it('shares at most two network slots across simultaneous playlist smoothing calls', async () => {
    const { original, result } = fixture();
    const responses: (() => void)[] = [];
    const fetcher = vi.fn<typeof fetch>((url) => new Promise((resolve) => responses.push(() => resolve(new Response(String(url).endsWith('left.ts') ? segment(90000, { idr: true }) : segment(118800, { frame: 8 }))))));
    const session = createHlsSpliceContinuitySession({ fetcher });
    const first = session.smooth(original, result, BASE), second = session.smooth(original, result, BASE + '?second');
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(fetcher).toHaveBeenCalledTimes(2);
    responses.splice(0).forEach((resolve) => resolve());
    await new Promise((resolve) => setTimeout(resolve, 0));
    expect(fetcher).toHaveBeenCalledTimes(4);
    responses.splice(0).forEach((resolve) => resolve());
    const actual = await Promise.all([first, second]);
    expect(actual.every((value) => value.content !== result.content)).toBe(true);
    session.destroy();
  });
});
