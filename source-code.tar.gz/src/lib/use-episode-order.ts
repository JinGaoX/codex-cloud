'use client';

import { useSyncExternalStore } from 'react';
import { createEpisodeOrderStore } from './episode-order';

const episodeOrder = createEpisodeOrderStore();

/** Display order only: the source's episode indexes remain unchanged. */
export function useEpisodeOrder() {
  const reversed = useSyncExternalStore(episodeOrder.subscribe, episodeOrder.getSnapshot, episodeOrder.getServerSnapshot);
  return [reversed, episodeOrder.setReversed] as const;
}
