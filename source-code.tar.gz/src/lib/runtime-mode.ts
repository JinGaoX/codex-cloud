/** Public build-time capability flag. No credentials belong in this module. */
export const IS_ANDROID_NATIVE = process.env.NEXT_PUBLIC_APP_MODE === 'android';
export const IS_NATIVE = process.env.NEXT_PUBLIC_APP_MODE === 'native' || IS_ANDROID_NATIVE;
/** ArkWeb has its own platform bridge; it must never use Capacitor plugins. */
export const IS_HARMONY = process.env.NEXT_PUBLIC_APP_MODE === 'harmony';
export const IS_STANDALONE = process.env.NEXT_PUBLIC_APP_MODE === 'standalone' || IS_NATIVE || IS_HARMONY;
export const SUPPORTS_WEB_DOWNLOADS = process.env.NEXT_PUBLIC_APP_MODE === 'standalone';
/** IPTV is available in the hosted and independent web apps. */
export const SUPPORTS_LIVE_TV = IS_ANDROID_NATIVE || (!IS_NATIVE && !IS_HARMONY);
