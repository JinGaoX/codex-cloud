/** Public build-time capability flag. No credentials belong in this module. */
export const IS_NATIVE = process.env.NEXT_PUBLIC_APP_MODE === 'native';
/** ArkWeb has its own platform bridge; it must never use Capacitor plugins. */
export const IS_HARMONY = process.env.NEXT_PUBLIC_APP_MODE === 'harmony';
export const IS_STANDALONE = process.env.NEXT_PUBLIC_APP_MODE === 'standalone' || IS_NATIVE || IS_HARMONY;
