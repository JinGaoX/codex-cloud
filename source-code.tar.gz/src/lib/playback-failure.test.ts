import { describe, expect, it } from 'vitest';
import { detailPlaybackFailure, hlsPlaybackFailure, nativePlaybackFailure, UNKNOWN_PLAYBACK_FAILURE } from './playback-failure';

describe('播放失败原因', () => {
  it('区分片源详情接口与视频加载，并保留明确的 HTTP 错误状态', () => {
    expect(detailPlaybackFailure(502)).toMatchObject({ stage: '读取片源详情', status: 502 });
    expect(hlsPlaybackFailure('networkError', 'manifestLoadError', 403)).toMatchObject({ stage: '加载播放列表', status: 403 });
    expect(hlsPlaybackFailure('networkError', 'fragLoadError', 404)).toMatchObject({ stage: '加载视频分片', status: 404 });
  });

  it('超时与没有响应的错误各自提示，避免从浏览器网络错误猜测具体原因', () => {
    expect(hlsPlaybackFailure('networkError', 'fragLoadTimeOut', 0)).toMatchObject({
      stage: '加载视频分片', reason: expect.stringContaining('超时'), status: undefined,
    });
    expect(detailPlaybackFailure(200)).toMatchObject({ reason: expect.stringContaining('无法确认'), status: undefined });
  });

  it('明确的解码与不兼容信号区别于无法打开地址或无法建立缓冲', () => {
    expect(nativePlaybackFailure(3).stage).toBe('解码视频');
    expect(nativePlaybackFailure(4).reason).toContain('无法判断');
    expect(hlsPlaybackFailure('mediaError', 'manifestIncompatibleCodecsError').stage).toBe('检查媒体编码');
    expect(hlsPlaybackFailure('mediaError', 'bufferAddCodecError').stage).toBe('准备媒体缓冲');
  });

  it('不会显示未知错误携带的地址或密钥', () => {
    expect(hlsPlaybackFailure('otherError', 'https://media.invalid?token=test-only', 0)).toEqual(UNKNOWN_PLAYBACK_FAILURE);
    expect(nativePlaybackFailure()).toEqual(UNKNOWN_PLAYBACK_FAILURE);
  });
});
