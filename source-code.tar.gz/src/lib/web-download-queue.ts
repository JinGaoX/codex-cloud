import type { PreparedWebDownload } from './web-download-file-target';
import type { WebVideoDownloadOptions, WebVideoDownloadProgress, WebVideoDownloadVariant } from './web-video-download';

interface Selection {
  kind: WebVideoDownloadOptions['kind'];
  variant: WebVideoDownloadVariant;
}

export interface WebDownloadEntry {
  url: string;
  title: string;
  sourceName: string;
  selection?: Selection;
}

type TaskState =
  | { status: 'queued' | 'checking' | 'cancelling' | 'cancelled' }
  | { status: 'downloading'; progress?: WebVideoDownloadProgress }
  | { status: 'error'; reason: string }
  | { status: 'ready'; file: PreparedWebDownload | { kind: 'attachment'; url: string; filename: string }; handedToBrowser: boolean };

export type WebDownloadTask = WebDownloadEntry & { id: string; selection?: Selection } & TaskState;
interface Snapshot {
  tasks: readonly WebDownloadTask[];
  open: boolean;
}

const INITIAL: Snapshot = { tasks: [], open: false };
let snapshot = INITIAL;
let running: { id: string; controller: AbortController } | null = null;
let memoryAwaitingRelease = 0;
const listeners = new Set<() => void>();

export const getWebDownloads = () => snapshot;
export const getWebDownloadsServerSnapshot = () => INITIAL;
export function subscribeWebDownloads(listener: () => void) {
  listeners.add(listener);
  return () => { listeners.delete(listener); };
}

function publish(next: Snapshot) {
  snapshot = next;
  for (const listener of listeners) listener();
}

export function showWebDownloads() {
  if (!snapshot.open) publish({ ...snapshot, open: true });
}

export function hideWebDownloads() {
  if (snapshot.open) publish({ ...snapshot, open: false });
}

function update(task: WebDownloadTask, state: TaskState, selection = task.selection) {
  const { id, title, sourceName, url } = task;
  publish({ ...snapshot, tasks: snapshot.tasks.map((entry) => entry.id === id
    ? { id, title, sourceName, url, selection, ...state } : entry) });
}

export function webDownloadErrorMessage(error: unknown, fallback: string) {
  const message = error instanceof Error ? error.message.trim() : '';
  return message.length <= 240 && /[\u3400-\u9fff]/.test(message) && !/(?:https?:\/\/|\?|(?:token|key|signature)=)/i.test(message)
    ? message : fallback;
}

async function drain() {
  if (running) return;
  const task = snapshot.tasks.find(({ status }) => status === 'queued');
  if (!task) return;
  const controller = new AbortController();
  const signal = controller.signal;
  running = { id: task.id, controller };
  let selection = task.selection;
  try {
    update(task, { status: 'checking' });
    const engine = await import('./web-video-download');
    signal.throwIfAborted();
    if (!selection) {
      const options = await engine.inspectWebVideoDownload(task.url, signal);
      if (!options.variants[0]) throw new Error('没有找到可下载的画质。');
      selection = { kind: options.kind, variant: options.variants[0] };
    }
    signal.throwIfAborted();
    if (selection.kind === 'mp4' && selection.variant.directAttachment) {
      update(task, { status: 'ready', handedToBrowser: false,
        file: { kind: 'attachment', url: selection.variant.url, filename: engine.webDownloadFilename(task.title) } }, selection);
      return;
    }
    const occupiedMemory = snapshot.tasks.reduce((bytes, entry) => (
      entry.status === 'ready' && entry.file.kind === 'prepared' && entry.file.storage === 'memory'
        ? bytes + entry.file.bytes : bytes
    ), memoryAwaitingRelease);
    update(task, { status: 'downloading' }, selection);
    const file = await engine.downloadWebVideo({
      ...selection, title: task.title, signal, background: true,
      memoryBudget: Math.max(0, engine.WEB_DOWNLOAD_MEMORY_LIMIT - occupiedMemory),
      onProgress(progress) {
        if (!signal.aborted) update(task, { status: 'downloading', progress }, selection);
      },
    });
    if (typeof file !== 'object') throw new Error('未能准备可保存的视频。');
    if (signal.aborted) file.dispose();
    signal.throwIfAborted();
    update(task, { status: 'ready', file, handedToBrowser: false }, selection);
  } catch (error) {
    update(task, signal.aborted ? { status: 'cancelled' } : {
      status: 'error',
      reason: webDownloadErrorMessage(error, '下载没有完成。可以重试当前画质。'),
    }, selection);
  } finally {
    running = null;
    void drain();
  }
}

export function enqueueWebDownloads(entries: readonly WebDownloadEntry[]) {
  const tasks = [...snapshot.tasks];
  for (const entry of entries) {
    const duplicate = tasks.some((task) => task.url === entry.url && task.title === entry.title
      && (task.selection?.variant.url === entry.selection?.variant.url || !task.selection || !entry.selection)
      && !['cancelled', 'error'].includes(task.status));
    if (entry.url && !duplicate) tasks.push({ ...entry, id: crypto.randomUUID(), status: 'queued' });
  }
  publish({ tasks, open: true });
  void drain();
}

export function cancelWebDownload(id: string) {
  const task = snapshot.tasks.find((entry) => entry.id === id);
  if (!task) return;
  if (task.status === 'queued') update(task, { status: 'cancelled' });
  else if (running?.id === id && (task.status === 'checking' || task.status === 'downloading')) {
    update(task, { status: 'cancelling' });
    running.controller.abort();
  }
}

export function retryWebDownload(id: string) {
  const task = snapshot.tasks.find((entry) => entry.id === id);
  if (task?.status !== 'error' && task?.status !== 'cancelled') return;
  update(task, { status: 'queued' });
  void drain();
}

export function markWebDownloadSaveRequested(id: string) {
  const task = snapshot.tasks.find((entry) => entry.id === id);
  if (task?.status === 'ready') update(task, { status: 'ready', file: task.file, handedToBrowser: true });
}

export function removeWebDownload(id: string) {
  const task = snapshot.tasks.find((entry) => entry.id === id);
  if (!task || running?.id === id || task.status === 'queued') return;
  if (task.status === 'ready' && task.file.kind === 'prepared') {
    const { file, handedToBrowser } = task;
    if (handedToBrowser && file.storage === 'memory') {
      const bytes = file.bytes;
      memoryAwaitingRelease += bytes;
      setTimeout(() => { memoryAwaitingRelease -= bytes; }, 120_000);
    }
    file.dispose(handedToBrowser);
  }
  publish({ ...snapshot, tasks: snapshot.tasks.filter((entry) => entry.id !== id) });
}
