import {
  removePersistentWebDownload,
  restorePreparedWebDownload,
  supportsTemporaryWebFile,
  type PreparedWebDownload,
} from './web-download-file-target';
import { removeWebHlsCheckpoint } from './web-download-checkpoint';
import {
  deleteWebDownloadRecord,
  readWebDownloadRecord,
  readWebDownloadRecords,
  storeWebDownloadRecord,
  type WebDownloadRecord,
} from './web-download-records';
import type { WebVideoDownloadOptions, WebVideoDownloadProgress, WebVideoDownloadVariant } from './web-video-download';

interface Selection {
  kind: WebVideoDownloadOptions['kind'];
  variant: WebVideoDownloadVariant;
}

export interface WebDownloadEntry {
  url: string;
  title: string;
  sourceName: string;
  selection?: Selection;
}

type TaskState =
  | { status: 'queued' | 'checking' | 'cancelling' | 'cancelled' }
  | { status: 'restoring' | 'downloading' | 'pausing' | 'paused' }
  | { status: 'error'; reason: string }
  | { status: 'ready'; file: PreparedWebDownload | { kind: 'attachment'; url: string; filename: string }; handedToBrowser: boolean };

interface TaskMetadata {
  id: string;
  createdAt: number;
  durable?: boolean;
  progress?: WebVideoDownloadProgress;
}

export type WebDownloadTask = WebDownloadEntry & TaskMetadata & TaskState;
interface Snapshot {
  tasks: readonly WebDownloadTask[];
  open: boolean;
}
interface ActiveDownload {
  id: string;
  controller: AbortController;
  wakePausedDownload?: () => void;
  backgrounded?: boolean;
}

const INITIAL: Snapshot = { tasks: [], open: false };
let snapshot = INITIAL;
let running: ActiveDownload | null = null;
let memoryAwaitingRelease = 0;
let initialization: Promise<void> | undefined;
const storedTasks = new Set<string>();
const restartCancelledTasks = new Set<string>();
const listeners = new Set<() => void>();

export const getWebDownloads = () => snapshot;
export const getWebDownloadsServerSnapshot = () => INITIAL;
export function subscribeWebDownloads(listener: () => void) {
  listeners.add(listener);
  return () => { listeners.delete(listener); };
}

function publish(next: Snapshot) {
  snapshot = next;
  for (const listener of listeners) listener();
}

export function showWebDownloads() {
  if (!snapshot.open) publish({ ...snapshot, open: true });
  void initializeWebDownloads();
}

export function hideWebDownloads() {
  if (snapshot.open) publish({ ...snapshot, open: false });
}

function replaceTask(task: WebDownloadTask, persist = true) {
  const saved = persist && storeWebDownloadRecord(task);
  if (saved) storedTasks.add(task.id);
  publish({ ...snapshot, tasks: snapshot.tasks.map((entry) => entry.id === task.id ? task : entry) });
  return saved;
}

function update(task: WebDownloadTask, state: TaskState & { progress?: WebVideoDownloadProgress }, persist = true) {
  const { id, title, sourceName, url, createdAt, selection, durable } = task;
  return replaceTask({ id, title, sourceName, url, createdAt, selection, durable, ...state }, persist);
}

function findTask(id: string) {
  return snapshot.tasks.find((entry) => entry.id === id);
}

function hasCheckpoint(task: Pick<WebDownloadTask, 'durable' | 'selection'>) {
  return task.durable && task.selection?.kind === 'hls';
}

export function canPauseWebDownload(task: WebDownloadTask) {
  return (task.status === 'downloading' || task.status === 'restoring') && task.selection?.kind === 'hls'
    && (!task.progress || task.progress.current < task.progress.total);
}

async function withTaskLock(id: string, work: () => Promise<void>) {
  const locks = navigator.locks;
  if (!locks) {
    await work();
    return true;
  }
  return locks.request(`pps-web-download:${id}`, { ifAvailable: true }, async (lock) => {
    if (!lock) return false;
    await work();
    return true;
  });
}

async function clearTaskFiles(task: WebDownloadEntry & Pick<TaskMetadata, 'id' | 'durable'>) {
  if (!task.durable) return;
  await Promise.allSettled([
    task.selection?.kind === 'hls' && removeWebHlsCheckpoint(task.id),
    removePersistentWebDownload(task.id),
  ]);
}

async function restoreTask(record: WebDownloadRecord): Promise<WebDownloadTask> {
  const { id, createdAt, title, sourceName, url, selection, durable, status, progress, file, handedToBrowser } = record;
  const task = { id, createdAt, title, sourceName, url, selection, durable };
  if (status === 'ready') {
    if (file?.kind === 'attachment') return { ...task, status, file, handedToBrowser: !!handedToBrowser };
    if (file?.kind === 'disk') {
      const restored = await restorePreparedWebDownload(file.storageId, file.filename).catch(() => null);
      if (restored?.bytes === file.bytes) {
        return { ...task, status, file: restored, handedToBrowser: !!handedToBrowser };
      }
      restored?.dispose(false, true);
    }
    return { ...task, status: 'error', reason: '本机暂存的视频已不可用，请重新下载。' };
  }
  if (status === 'cancelling') {
    const cancelled: WebDownloadTask = { ...task, status: 'cancelled' };
    const acquired = await withTaskLock(id, async () => {
      await clearTaskFiles(task);
      storeWebDownloadRecord(cancelled);
    }).catch(() => false);
    return acquired ? cancelled : { ...task, status: 'error', reason: '这个任务正在另一个 PPS 窗口中处理。' };
  }
  if (status === 'queued' || status === 'cancelled') return { ...task, status };
  if (status === 'error') {
    return { ...task, status, progress: hasCheckpoint(task) ? progress : undefined,
      reason: typeof record.reason === 'string' ? record.reason : '下载没有完成。可以重试。' };
  }
  if (hasCheckpoint(task) || status === 'checking') return { ...task, status: 'paused', progress };
  return { ...task, status: 'error', reason: '下载已中断。当前格式或浏览器需要从头重试。' };
}

export function initializeWebDownloads() {
  if (!initialization && typeof window !== 'undefined') {
    initialization = (async () => {
      const records = readWebDownloadRecords();
      const tasks = await Promise.all(records.map(restoreTask));
      for (const task of tasks) storedTasks.add(task.id);
      publish({ ...snapshot, tasks });
      void drain();
    })();
  }
  return initialization;
}

/** Hold the active queue slot and the open file writer until resume or cancel. */
async function waitForResume(active: ActiveDownload) {
  const task = findTask(active.id);
  if (task?.status !== 'pausing') return;
  const { signal } = active.controller;
  signal.throwIfAborted();
  await new Promise<void>((resolve) => {
    const wake = () => {
      signal.removeEventListener('abort', wake);
      active.wakePausedDownload = undefined;
      resolve();
    };
    active.wakePausedDownload = wake;
    signal.addEventListener('abort', wake, { once: true });
    update(task, { status: 'paused', progress: task.progress });
  });
  signal.throwIfAborted();
}

export function webDownloadErrorMessage(error: unknown, fallback: string) {
  const message = error instanceof Error ? error.message.trim() : '';
  return message.length <= 240 && /[\u3400-\u9fff]/.test(message) && !/(?:https?:\/\/|\?|(?:token|key|signature)=)/i.test(message)
    ? message : fallback;
}

async function runTask(task: WebDownloadTask, active: ActiveDownload) {
  const signal = active.controller.signal;
  let selection = task.selection;
  let retainedProgress = task.progress;
  try {
    const record = readWebDownloadRecord(task.id);
    if (storedTasks.has(task.id) && !record) {
      publish({ ...snapshot, tasks: snapshot.tasks.filter((entry) => entry.id !== task.id) });
      storedTasks.delete(task.id);
      return;
    }
    if (record?.status === 'ready') {
      const restored = await restoreTask(record);
      if (restored.status === 'ready') {
        replaceTask(restored, false);
        return;
      }
    }
    const restartCancelled = restartCancelledTasks.delete(task.id);
    if (record?.status === 'cancelling' || record?.status === 'cancelled') {
      await clearTaskFiles(record);
      if (record.status === 'cancelling' || !restartCancelled) {
        update(task, { status: 'cancelled' });
        return;
      }
    }
    if (record?.durable) {
      task = { ...task, durable: true, selection: record.selection ?? selection };
      selection = task.selection;
      if (hasCheckpoint(task) && record.progress) retainedProgress = record.progress;
    }
    update(task, { status: retainedProgress?.current ? 'restoring' : 'checking', progress: retainedProgress });
    const engine = await import('./web-video-download');
    signal.throwIfAborted();
    if (!selection) {
      const options = await engine.inspectWebVideoDownload(task.url, signal);
      if (!options.variants[0]) throw new Error('没有找到可下载的画质。');
      selection = { kind: options.kind, variant: options.variants[0] };
    }
    signal.throwIfAborted();
    task = { ...task, selection };
    if (selection.kind === 'mp4' && selection.variant.directAttachment) {
      update(task, { status: 'ready', handedToBrowser: false,
        file: { kind: 'attachment', url: selection.variant.url, filename: engine.webDownloadFilename(task.title) } });
      return;
    }
    const occupiedMemory = snapshot.tasks.reduce((bytes, entry) => (
      entry.status === 'ready' && entry.file.kind === 'prepared' && entry.file.storage === 'memory'
        ? bytes + entry.file.bytes : bytes
    ), memoryAwaitingRelease);
    const transferState = active.backgrounded && selection.kind === 'hls' ? 'pausing'
      : retainedProgress?.current ? 'restoring' : 'downloading';
    const durable = supportsTemporaryWebFile() && storedTasks.has(task.id);
    const saved = replaceTask({ ...task, durable, status: transferState, progress: retainedProgress });
    if (!saved && task.durable && retainedProgress?.current) throw new Error('无法保存续传记录，请稍后重试。');
    task = { ...task, durable: durable && saved };
    if (durable && !saved) replaceTask({ ...task, status: transferState, progress: undefined }, false);
    const file = await engine.downloadWebVideo({
      ...selection, title: task.title, signal, background: true,
      checkpointId: task.durable ? task.id : undefined,
      memoryBudget: Math.max(0, engine.WEB_DOWNLOAD_MEMORY_LIMIT - occupiedMemory),
      waitForResume: selection.kind === 'hls' ? () => waitForResume(active) : undefined,
      onProgress(progress) {
        if (signal.aborted) return;
        const current = findTask(task.id);
        if (current?.status === 'downloading' || current?.status === 'pausing' || current?.status === 'restoring') {
          if (current.progress && progress.current < current.progress.current) return;
          const status = current.status === 'restoring' ? 'downloading' : current.status;
          update(current, { status, progress });
        }
      },
    });
    if (typeof file !== 'object') throw new Error('未能准备可保存的视频。');
    if (signal.aborted) file.dispose();
    signal.throwIfAborted();
    const recorded = update(task, { status: 'ready', file, handedToBrowser: false });
    if (recorded && hasCheckpoint(task)) await removeWebHlsCheckpoint(task.id).catch(() => {});
  } catch (error) {
    if (signal.aborted) {
      update(task, { status: 'cancelled' });
      await clearTaskFiles(task);
      return;
    }
    const progress = hasCheckpoint(task) ? findTask(task.id)?.progress ?? retainedProgress : undefined;
    if (active.backgrounded && hasCheckpoint(task)) update(task, { status: 'paused', progress });
    else update(task, { status: 'error', progress,
      reason: webDownloadErrorMessage(error, '下载没有完成。可以重试当前画质。') });
  }
}

async function drain() {
  if (running || document.visibilityState === 'hidden') return;
  const task = snapshot.tasks.find(({ status }) => status === 'queued' || status === 'paused');
  if (task?.status !== 'queued') return;
  const active: ActiveDownload = { id: task.id, controller: new AbortController() };
  running = active;
  try {
    const acquired = await withTaskLock(task.id, async () => {
      if (document.visibilityState !== 'hidden' && findTask(task.id)?.status === 'queued') await runTask(task, active);
    });
    if (!acquired) update(task, { status: 'error', progress: task.progress, reason: '这个任务正在另一个 PPS 窗口中处理。' }, false);
  } catch {
    update(task, { status: 'error', progress: task.progress, reason: '暂时无法打开下载任务，请重试。' }, false);
  } finally {
    running = null;
    void drain();
  }
}

export function enqueueWebDownloads(entries: readonly WebDownloadEntry[]) {
  showWebDownloads();
  void addEntries(entries);
}

async function addEntries(entries: readonly WebDownloadEntry[]) {
  await initializeWebDownloads();
  const tasks = [...snapshot.tasks];
  // A whole batch can be queued in one millisecond. Persist its original order.
  let createdAt = tasks.reduce((next, task) => Math.max(next, task.createdAt + 1), Date.now());
  for (const entry of entries) {
    const duplicate = tasks.some((task) => task.url === entry.url && task.title === entry.title
      && (task.selection?.variant.url === entry.selection?.variant.url || !task.selection || !entry.selection)
      && !['cancelled', 'error'].includes(task.status));
    if (entry.url && !duplicate) {
      const task: WebDownloadTask = { ...entry, id: crypto.randomUUID(), createdAt: createdAt++, status: 'queued' };
      if (storeWebDownloadRecord(task)) storedTasks.add(task.id);
      tasks.push(task);
    }
  }
  publish({ ...snapshot, tasks });
  void drain();
}

export function cancelWebDownload(id: string) {
  const task = findTask(id);
  if (!task) return;
  if (running?.id === id && ['checking', 'restoring', 'downloading', 'pausing', 'paused'].includes(task.status)) {
    update(task, { status: 'cancelling' });
    running.controller.abort();
  } else if (task.status === 'queued' || task.status === 'paused') {
    void cancelInactiveTask(task);
  }
}

async function cancelInactiveTask(task: WebDownloadTask) {
  const acquired = await withTaskLock(task.id, async () => {
    const current = findTask(task.id);
    if (current?.status !== 'queued' && current?.status !== 'paused') return;
    update(current, { status: 'cancelling' });
    await clearTaskFiles(current);
    update(current, { status: 'cancelled' });
  }).catch(() => false);
  if (!acquired) update(task, { status: 'error', progress: task.progress, reason: '这个任务正在另一个 PPS 窗口中处理。' }, false);
  void drain();
}

export function pauseWebDownload(id: string) {
  const task = findTask(id);
  if (running?.id === id && task && canPauseWebDownload(task)) {
    update(task, { status: 'pausing', progress: task.progress });
  }
}

export function resumeWebDownload(id: string) {
  const task = findTask(id);
  const active = running;
  if (task?.status !== 'paused') return;
  if (active?.id === id) {
    active.backgrounded = false;
    update(task, { status: 'downloading', progress: task.progress });
    active.wakePausedDownload?.();
  } else {
    update(task, { status: 'queued', progress: task.progress }, false);
    void drain();
  }
}

export function handleWebDownloadVisibilityChange() {
  if (document.visibilityState !== 'hidden') {
    void drain();
    return;
  }
  if (!running) return;
  const task = findTask(running.id);
  if (task?.status === 'checking' || (task && canPauseWebDownload(task))) {
    running.backgrounded = true;
    if (task.status !== 'checking') pauseWebDownload(task.id);
  }
}

export function retryWebDownload(id: string) {
  const task = findTask(id);
  if (task?.status !== 'error' && task?.status !== 'cancelled') return;
  if (task.status === 'cancelled') restartCancelledTasks.add(id);
  update(task, { status: 'queued', progress: task.progress }, false);
  void drain();
}

export function markWebDownloadSaveRequested(id: string) {
  const task = findTask(id);
  if (task?.status === 'ready') update(task, { status: 'ready', file: task.file, handedToBrowser: true });
}

export function removeWebDownload(id: string) {
  const task = findTask(id);
  if (!task || running?.id === id || ['queued', 'checking', 'restoring', 'downloading', 'pausing', 'paused', 'cancelling'].includes(task.status)) return;
  void removeInactiveTask(task);
}

async function removeInactiveTask(task: WebDownloadTask) {
  const { id } = task;
  await withTaskLock(id, async () => {
    const record = readWebDownloadRecord(id);
    if (storedTasks.has(id) && !deleteWebDownloadRecord(id)) return;
    storedTasks.delete(id);
    restartCancelledTasks.delete(id);
    if (task.status === 'ready' && task.file.kind === 'prepared') {
      const { file, handedToBrowser } = task;
      if (handedToBrowser && file.storage === 'memory') {
        const bytes = file.bytes;
        memoryAwaitingRelease += bytes;
        setTimeout(() => { memoryAwaitingRelease -= bytes; }, 120_000);
      }
      file.dispose(handedToBrowser);
      if (hasCheckpoint(task)) await removeWebHlsCheckpoint(id).catch(() => {});
    } else await clearTaskFiles(record ?? task);
    publish({ ...snapshot, tasks: snapshot.tasks.filter((entry) => entry.id !== id) });
  }).catch(() => false);
}
