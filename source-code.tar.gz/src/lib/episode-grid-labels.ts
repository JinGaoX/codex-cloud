import type { EpisodeLabel } from './episode-labels';

export interface EpisodeGridLabel {
  primary: string;
  secondary?: string;
  dated: boolean;
}

/** Format only a complete, valid calendar date at the start of a source label. */
export function episodeGridLabel(episode: EpisodeLabel): EpisodeGridLabel {
  if (!episode.title) return { primary: `第${episode.number}集`, dated: false };

  const title = episode.title;
  const date = title.match(/^(?:第\s*)?(\d{4})(\d{2})(\d{2})(?!\d)(?:期)?(.*)$/u)
    ?? title.match(/^(?:第\s*)?(\d{4})-(\d{2})-(\d{2})(?!\d)(?:期)?(.*)$/u)
    ?? title.match(/^(?:第\s*)?(\d{4})年(\d{1,2})月(\d{1,2})日(?:期)?(.*)$/u);
  if (!date) return { primary: title, dated: false };

  const [, rawYear, rawMonth, rawDay, suffix] = date;
  const year = Number(rawYear), month = Number(rawMonth), day = Number(rawDay);
  const leap = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const days = [31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (year < 1 || month < 1 || month > 12 || day < 1 || day > days[month - 1]) {
    return { primary: title, dated: false };
  }
  const secondary = suffix.trim();
  return {
    primary: `${rawYear}-${rawMonth.padStart(2, '0')}-${rawDay.padStart(2, '0')}`,
    ...(secondary ? { secondary } : {}),
    dated: true,
  };
}
