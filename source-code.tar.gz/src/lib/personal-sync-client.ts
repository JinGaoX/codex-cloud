import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { syncAuthStorageKey, type SyncConfiguration } from './personal-sync-config';

let singleton: { config: SyncConfiguration; client: SupabaseClient } | undefined;

/** Account UI, sync and the owned relay share one auth client and refresh lock. */
export function getPersonalSyncClient(config: SyncConfiguration): SupabaseClient {
  if (!singleton || singleton.config.url !== config.url || singleton.config.publishableKey !== config.publishableKey) {
    singleton = { config, client: createClient(config.url, config.publishableKey, {
      auth: { storageKey: syncAuthStorageKey(config), persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
    }) };
  }
  return singleton.client;
}
