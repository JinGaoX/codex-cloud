import { resolveNativeHlsFallback } from './native-hls-fallback';

interface RecoveryCallbacks {
  isCurrent: () => boolean;
  onResolved: (url: string) => void;
  onUnavailable: () => void;
}

/** One completed compatibility attempt per episode, shared by media/play errors. */
export class NativeHlsRecovery {
  private attempted = false;
  private pending: AbortController | undefined;

  constructor(private readonly resolve = resolveNativeHlsFallback) {}

  tryRecover(url: string, callbacks: RecoveryCallbacks): boolean {
    if (this.pending) return true;
    if (this.attempted || !callbacks.isCurrent()) return false;
    this.attempted = true;
    const controller = new AbortController();
    this.pending = controller;
    const finish = (child?: string) => {
      if (this.pending !== controller || controller.signal.aborted) return;
      this.pending = undefined;
      if (!callbacks.isCurrent()) return;
      if (child) callbacks.onResolved(child);
      else callbacks.onUnavailable();
    };
    void Promise.resolve().then(() => {
      if (controller.signal.aborted) return undefined;
      return this.resolve(url, { signal: controller.signal });
    }).then(finish, () => finish()).catch(() => {
      // Presentation callbacks cannot create an unhandled rejection.
    });
    return true;
  }

  cancel(): void {
    if (!this.pending) return;
    this.pending.abort();
    this.pending = undefined;
    // A settings reload may restart an interrupted attempt, but a completed
    // child retry cannot recursively unwrap again after its own media error.
    this.attempted = false;
  }

  reset(): void {
    this.cancel();
    this.attempted = false;
  }
}
