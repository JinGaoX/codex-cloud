/**
 * Error-only native HLS recovery. Keep the original URL for normal playback;
 * only unwrap an unambiguous master after native playback has failed.
 * A real HTTPS child URL also remains usable by an AirPlay receiver.
 */
export interface NativeHlsFallbackOptions {
  signal?: AbortSignal;
  fetcher?: typeof fetch;
}

const MAX_PLAYLIST_BYTES = 512 * 1024;
const MAX_PLAYLIST_REQUESTS = 3;
const REQUEST_TIMEOUT_MS = 4000;
const TOTAL_TIMEOUT_MS = 8000;

/** No local-network probes, protocol downgrade, credentials, or variable expansion. */
function publicHttpsUrl(raw: string, base?: string): string | undefined {
  try {
    if (/\{\$/.test(raw)) return undefined;
    const url = new URL(raw, base);
    const host = url.hostname.toLowerCase();
    if (url.protocol !== 'https:' || url.username || url.password
      || !host.includes('.') || /(?:^|\.)(?:localhost|local|internal)$/.test(host)
      || host.startsWith('[')) return undefined;
    if (/^\d+\.\d+\.\d+\.\d+$/.test(host)) {
      const [a, b] = host.split('.').map(Number);
      if (a === 0 || a === 10 || a === 127 || a >= 224
        || (a === 100 && b >= 64 && b <= 127)
        || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31)
        || (a === 192 && (b === 0 || b === 168))
        || (a === 198 && (b === 18 || b === 19))) return undefined;
    }
    // Fragments do not identify different HTTP resources; do not let them hide cycles.
    url.hash = '';
    return url.href;
  } catch { return undefined; }
}

function attributes(raw: string): Map<string, string> | undefined {
  const values = new Map<string, string>();
  let rest = raw;
  while (rest) {
    const match = rest.match(/^([A-Z0-9-]+)=("[^"\r\n]*"|[^,"\s]+)(,|$)/);
    if (!match || values.has(match[1])) return undefined;
    values.set(match[1], match[2].startsWith('"') ? match[2].slice(1, -1) : match[2]);
    rest = rest.slice(match[0].length);
    if (match[3] === ',' && !rest) return undefined;
  }
  return values;
}

type Playlist = { kind: 'master'; child: string } | { kind: 'media' };

function inspectPlaylist(text: string, base: string): Playlist | undefined {
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).map((line) => line.trim());
  if (lines[0] !== '#EXTM3U' || text.includes('{$')) return undefined;
  // These masters can depend on additional renditions, keys, variables, start
  // offsets or steering metadata. A child alone would not preserve their meaning.
  if (lines.some((line) => /^#EXT-X-(?:MEDIA|SESSION-KEY|SESSION-DATA|DEFINE|CONTENT-STEERING|START|I-FRAME-STREAM-INF|IMAGE-STREAM-INF):/.test(line))) return undefined;

  if (lines.some((line) => line.startsWith('#EXT-X-STREAM-INF:'))) {
    const permittedTags = /^#(?:EXTM3U$|EXT-X-(?:VERSION:\d+$|INDEPENDENT-SEGMENTS$|STREAM-INF:))/;
    let child: string | undefined;
    let awaitingUri = false;
    let variants = 0;
    for (const line of lines) {
      if (!line) continue;
      if (line.startsWith('#EXT-X-STREAM-INF:')) {
        if (awaitingUri || ++variants > 1) return undefined;
        const attrs = attributes(line.slice('#EXT-X-STREAM-INF:'.length));
        const bandwidth = attrs?.get('BANDWIDTH');
        if (!attrs || !bandwidth || !/^\d+$/.test(bandwidth)
          || !Number.isSafeInteger(Number(bandwidth)) || Number(bandwidth) <= 0) return undefined;
        const supported = new Set(['BANDWIDTH', 'AVERAGE-BANDWIDTH', 'CODECS', 'RESOLUTION', 'FRAME-RATE',
          'CLOSED-CAPTIONS', 'PROGRAM-ID', 'VIDEO-RANGE', 'HDCP-LEVEL']);
        if ([...attrs.keys()].some((key) => !supported.has(key))
          || (attrs.has('CLOSED-CAPTIONS') && attrs.get('CLOSED-CAPTIONS') !== 'NONE')
          || (attrs.has('HDCP-LEVEL') && attrs.get('HDCP-LEVEL') !== 'NONE')) return undefined;
        awaitingUri = true;
      } else if (!line.startsWith('#')) {
        if (!awaitingUri) return undefined;
        child = publicHttpsUrl(line, base);
        if (!child) return undefined;
        awaitingUri = false;
      } else if (line.startsWith('#EXT') && !permittedTags.test(line)) return undefined;
    }
    return child && variants === 1 && !awaitingUri ? { kind: 'master', child } : undefined;
  }

  // Do not mistake an arbitrary #EXTM3U text file, an empty playlist, or a
  // truncated EXTINF entry for a usable media playlist.
  let awaitingSegment = false;
  let segments = 0;
  let targetDuration = false;
  for (const line of lines) {
    if (line.startsWith('#EXT-X-TARGETDURATION:')) {
      if (targetDuration || !/^#EXT-X-TARGETDURATION:[1-9]\d*$/.test(line)) return undefined;
      targetDuration = true;
    } else if (line.startsWith('#EXTINF:')) {
      if (awaitingSegment || !/^#EXTINF:(?:\d+(?:\.\d+)?),/.test(line)
        || Number(line.slice(8).split(',')[0]) <= 0) return undefined;
      awaitingSegment = true;
    } else if (line && !line.startsWith('#')) {
      if (!awaitingSegment || !publicHttpsUrl(line, base)) return undefined;
      awaitingSegment = false;
      segments++;
    } else if (line.startsWith('#EXT') && /(?:^|[:,])URI=/.test(line)) {
      const attrs = attributes(line.slice(line.indexOf(':') + 1));
      if (!attrs?.has('URI') || !publicHttpsUrl(attrs.get('URI')!, base)) return undefined;
    }
  }
  return targetDuration && segments > 0 && !awaitingSegment ? { kind: 'media' } : undefined;
}

async function abortable<T>(operation: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) throw signal.reason;
  let onAbort: (() => void) | undefined;
  try {
    return await Promise.race([
      operation,
      new Promise<never>((_resolve, reject) => {
        onAbort = () => reject(signal.reason ?? new DOMException('Aborted', 'AbortError'));
        signal.addEventListener('abort', onAbort, { once: true });
      }),
    ]);
  } finally {
    if (onAbort) signal.removeEventListener('abort', onAbort);
  }
}

async function readPlaylist(url: string, fetcher: typeof fetch, signal: AbortSignal): Promise<{ text: string; url: string }> {
  const controller = new AbortController();
  const onAbort = () => controller.abort(signal.reason);
  signal.addEventListener('abort', onAbort, { once: true });
  if (signal.aborted) onAbort();
  const timeout = setTimeout(() => controller.abort(new DOMException('Playlist timeout', 'TimeoutError')), REQUEST_TIMEOUT_MS);
  let reader: ReadableStreamDefaultReader<Uint8Array> | undefined;
  let response: Response | undefined;
  try {
    if (controller.signal.aborted) throw controller.signal.reason;
    const pending = fetcher(url, {
      method: 'GET', mode: 'cors', credentials: 'omit', cache: 'no-store', redirect: 'follow',
      headers: { Accept: 'application/vnd.apple.mpegurl, application/x-mpegURL, text/plain;q=0.8' },
      signal: controller.signal,
    }).then((loaded) => {
      if (controller.signal.aborted) {
        void loaded.body?.cancel().catch(() => {});
        throw controller.signal.reason;
      }
      return loaded;
    });
    response = await abortable(pending, controller.signal);
    if (!response.ok || response.type === 'opaque' || response.type === 'opaqueredirect') throw new Error('playlist_unavailable');
    const finalUrl = publicHttpsUrl(response.url || url);
    if (!finalUrl) throw new Error('unsafe_playlist_redirect');
    const length = Number(response.headers.get('content-length'));
    if (Number.isFinite(length) && length > MAX_PLAYLIST_BYTES) throw new Error('playlist_size');
    reader = response.body?.getReader();
    if (!reader) throw new Error('playlist_body_unavailable');
    const decoder = new TextDecoder('utf-8', { fatal: true });
    let bytes = 0;
    let text = '';
    while (true) {
      const chunk = await abortable(reader.read(), controller.signal);
      if (chunk.done) break;
      bytes += chunk.value.byteLength;
      if (bytes > MAX_PLAYLIST_BYTES) throw new Error('playlist_size');
      text += decoder.decode(chunk.value, { stream: true });
    }
    text += decoder.decode();
    return { text, url: finalUrl };
  } finally {
    clearTimeout(timeout);
    signal.removeEventListener('abort', onAbort);
    if (reader) void reader.cancel().catch(() => {});
    else if (response) void response.body?.cancel().catch(() => {});
    controller.abort();
  }
}

/** Returns a verified real child URL, or undefined; never changes video state. */
export async function resolveNativeHlsFallback(rawUrl: string, options: NativeHlsFallbackOptions = {}): Promise<string | undefined> {
  const initial = publicHttpsUrl(rawUrl);
  if (!initial || options.signal?.aborted) return undefined;
  const controller = new AbortController();
  const onAbort = () => controller.abort(options.signal?.reason);
  options.signal?.addEventListener('abort', onAbort, { once: true });
  if (options.signal?.aborted) onAbort();
  const timeout = setTimeout(() => controller.abort(new DOMException('Recovery timeout', 'TimeoutError')), TOTAL_TIMEOUT_MS);
  try {
    let current = initial;
    const seen = new Set<string>();
    for (let request = 0; request < MAX_PLAYLIST_REQUESTS; request++) {
      if (controller.signal.aborted || seen.has(current)) return undefined;
      seen.add(current);
      const loaded = await readPlaylist(current, options.fetcher ?? fetch, controller.signal);
      if (controller.signal.aborted || (loaded.url !== current && seen.has(loaded.url))) return undefined;
      seen.add(loaded.url);
      const playlist = inspectPlaylist(loaded.text, loaded.url);
      if (!playlist) return undefined;
      if (playlist.kind === 'media') return request > 0 && loaded.url !== initial ? loaded.url : undefined;
      current = playlist.child;
    }
    return undefined;
  } catch { return undefined; }
  finally {
    clearTimeout(timeout);
    options.signal?.removeEventListener('abort', onAbort);
    controller.abort();
  }
}
