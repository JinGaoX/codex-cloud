/** Persistence observes source time only; it never seeks, filters or alters media. */
export interface WatchedProgress {
  position: number;
  duration: number;
}

const validPosition = (position: number) => Number.isFinite(position) && position >= 0;

/**
 * A loaded/restored/seeked position is not a viewing event. Only forward movement
 * after a real playing event makes a new snapshot eligible for persistence.
 */
export class PlaybackProgressGate {
  private playing = false;
  private seeking = false;
  private anchor: number | null = null;
  private pending: WatchedProgress | null = null;
  private saved: WatchedProgress | null = null;

  reset(): void {
    this.playing = false;
    this.seeking = false;
    this.anchor = null;
    this.pending = null;
    this.saved = null;
  }

  start(position: number): void {
    this.playing = true;
    this.seeking = false;
    this.anchor = validPosition(position) ? position : null;
  }

  seekStart(): void {
    this.seeking = true;
    this.anchor = null;
    // Preserve an unsaved real observation; do not replace it with the seek target.
  }

  seekEnd(position: number): void {
    this.seeking = false;
    this.anchor = validPosition(position) ? position : null;
  }

  observe(position: number, duration: number): void {
    if (!validPosition(position) || !this.playing || this.seeking) return;
    const previous = this.anchor;
    this.anchor = position;
    if (previous !== null && position > previous && Number.isFinite(duration) && duration > 0) {
      this.pending = { position, duration };
    }
  }

  pause(position: number, duration: number): void {
    // The pause event can precede the last timeupdate; preserve those final seconds.
    this.observe(position, duration);
    this.playing = false;
  }

  take(): WatchedProgress | null {
    const snapshot = this.pending;
    this.pending = null;
    if (!snapshot || snapshot.position < 1) return null;
    if (this.saved?.position === snapshot.position && this.saved.duration === snapshot.duration) return null;
    this.saved = snapshot;
    return snapshot;
  }
}
