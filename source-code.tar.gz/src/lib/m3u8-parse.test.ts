import { afterEach, describe, expect, it, vi } from 'vitest';
import { parseM3u8Playlist } from './m3u8-parse';
import * as pts from './hls-pts-filter';

const original = '#EXTM3U\n#EXTINF:300,\nfirst.ts\n#EXT-X-DISCONTINUITY\n#EXTINF:18,\nshort.ts\n#EXT-X-DISCONTINUITY\n#EXTINF:300,\nlast.ts\n#EXT-X-ENDLIST';
const filtered = original.replace('#EXT-X-DISCONTINUITY\n#EXTINF:18,\nshort.ts\n', '');

function unchanged(content: string): pts.HlsPtsFilterResult {
  return { content, status: 'unchanged', reason: 'no_ad', removedGroups: [], removedSeconds: 0,
    probedGroups: 0, totalGroups: 0, complete: true };
}

function makeSession(transform: (content: string) => string = (content) => content): pts.HlsPtsFilterSession {
  return {
    filter: vi.fn(async (content: string) => unchanged(transform(content))),
    destroy: vi.fn(),
  };
}

afterEach(() => {
  vi.unstubAllGlobals();
  vi.restoreAllMocks();
});

describe('下载与预取清单共用 PTS 判定', () => {
  it('外部会话贯穿 master 递归，分片与时长按返回清单计算且不擅自销毁', async () => {
    const master = '#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=2000000,RESOLUTION=1920x1080\nmedia/index.m3u8';
    const session = makeSession((content) => content === original ? filtered : content);
    vi.stubGlobal('fetch', vi.fn(async (url: string) => new Response(url.endsWith('/main.m3u8') ? master : original)));
    const parsed = await parseM3u8Playlist('https://cdn.example/main.m3u8', 0, undefined, { ptsSession: session });
    expect(session.filter).toHaveBeenNthCalledWith(1, master, 'https://cdn.example/main.m3u8', undefined);
    expect(session.filter).toHaveBeenNthCalledWith(2, original, 'https://cdn.example/media/index.m3u8', undefined);
    expect(parsed.segments.map((s) => s.url)).toEqual(['https://cdn.example/media/first.ts', 'https://cdn.example/media/last.ts']);
    expect(parsed.totalDuration).toBe(600);
    expect(parsed.variants?.[0].height).toBe(1080);
    expect(session.destroy).not.toHaveBeenCalled();
  });

  it('stripLeadAd=false 完全不创建或调用过滤会话，正常短组原样保留', async () => {
    const factory = vi.spyOn(pts, 'createHlsPtsFilterSession');
    const session = makeSession(() => filtered);
    const fetcher = vi.fn(async () => new Response(original));
    vi.stubGlobal('fetch', fetcher);
    const parsed = await parseM3u8Playlist('https://cdn.example/index.m3u8', 0, undefined, { stripLeadAd: false, ptsSession: session });
    expect(factory).not.toHaveBeenCalled();
    expect(session.filter).not.toHaveBeenCalled();
    expect(session.destroy).not.toHaveBeenCalled();
    expect(fetcher).toHaveBeenCalledOnce();
    expect(parsed.totalDuration).toBe(618);
    expect(parsed.segments).toHaveLength(3);
  });

  it('本次解析创建的会话在递归错误后销毁，不留下后台探测', async () => {
    const session = makeSession();
    vi.spyOn(pts, 'createHlsPtsFilterSession').mockReturnValue(session);
    vi.stubGlobal('fetch', vi.fn(async () => new Response('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=100\nagain.m3u8')));
    await expect(parseM3u8Playlist('https://cdn.example/index.m3u8')).rejects.toThrow('m3u8 嵌套超过 5 层');
    expect(session.destroy).toHaveBeenCalledOnce();
  });

  it('开始前已取消时不发任何请求，仍清理本次拥有的会话', async () => {
    const controller = new AbortController();
    const session = makeSession();
    vi.spyOn(pts, 'createHlsPtsFilterSession').mockReturnValue(session);
    const fetcher = vi.fn();
    vi.stubGlobal('fetch', fetcher);
    controller.abort();
    await expect(parseM3u8Playlist('https://cdn.example/index.m3u8', 0, undefined, { signal: controller.signal })).rejects.toMatchObject({ name: 'AbortError' });
    expect(fetcher).not.toHaveBeenCalled();
    expect(session.filter).not.toHaveBeenCalled();
    expect(session.destroy).toHaveBeenCalledOnce();
  });

  it('清单网络接收取消信号，失败后清理本次会话', async () => {
    const controller = new AbortController();
    const session = makeSession();
    vi.spyOn(pts, 'createHlsPtsFilterSession').mockReturnValue(session);
    vi.stubGlobal('fetch', vi.fn((_url: string, init: RequestInit) => new Promise<Response>((_resolve, reject) => {
      init.signal?.addEventListener('abort', () => reject(init.signal?.reason));
    })));
    const pending = parseM3u8Playlist('https://cdn.example/index.m3u8', 0, undefined, { signal: controller.signal });
    controller.abort();
    await expect(pending).rejects.toMatchObject({ name: 'AbortError' });
    expect(session.filter).not.toHaveBeenCalled();
    expect(session.destroy).toHaveBeenCalledOnce();
  });

  it('探测期间取消，即使过滤器返回原清单也不继续输出下载分片', async () => {
    const controller = new AbortController();
    const session = makeSession();
    session.filter = vi.fn(async (content: string) => { controller.abort(); return unchanged(content); });
    vi.stubGlobal('fetch', vi.fn(async () => new Response(original)));
    await expect(parseM3u8Playlist('https://cdn.example/index.m3u8', 0, undefined, {
      signal: controller.signal, ptsSession: session,
    })).rejects.toMatchObject({ name: 'AbortError' });
    expect(session.filter).toHaveBeenCalledWith(original, 'https://cdn.example/index.m3u8', controller.signal);
    expect(session.destroy).not.toHaveBeenCalled();
  });

  it('相对分片与探测使用重定向后的最终清单地址', async () => {
    const session = makeSession();
    const response = new Response('#EXTM3U\n#EXTINF:4,\none.ts\n#EXT-X-ENDLIST');
    Object.defineProperty(response, 'url', { value: 'https://other.example/final/index.m3u8' });
    vi.stubGlobal('fetch', vi.fn(async () => response));
    const parsed = await parseM3u8Playlist('https://cdn.example/redirect.m3u8', 0, undefined, { ptsSession: session });
    expect(parsed.segments[0].url).toBe('https://other.example/final/one.ts');
    expect(session.filter).toHaveBeenCalledWith(expect.any(String), 'https://other.example/final/index.m3u8', undefined);
  });
});
