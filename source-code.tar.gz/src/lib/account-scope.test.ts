import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { AccountScope } from './account-scope';

const A: AccountScope = { userId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa', endpoint: 'https://first.supabase.co' };
const B: AccountScope = { ...A, userId: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb' };
const values = new Map<string, string>();

beforeEach(() => {
  vi.resetModules();
  values.clear();
  vi.stubGlobal('localStorage', {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => values.set(key, value),
    removeItem: (key: string) => values.delete(key),
  });
});
afterEach(() => vi.unstubAllGlobals());

describe('本机账号资料空间', () => {
  it('游客保留原数据库和设置键，初始化不写入或删除存储', async () => {
    values.set('libretv-settings', 'guest');
    const scope = await import('./account-scope');
    expect(scope.ACTIVE_ACCOUNT_SCOPE).toBeNull();
    expect(scope.databaseNameForScope(null)).toBe('libretv');
    expect(scope.settingsKeyForScope('libretv-settings', null)).toBe('libretv-settings');
    expect([...values]).toEqual([['libretv-settings', 'guest']]);
  });

  it('按账号及项目 origin 分开，等价的 origin 使用同一标识', async () => {
    const scope = await import('./account-scope');
    const otherProject = { ...A, endpoint: 'https://second.supabase.co' };
    expect(new Set([scope.scopeId(A), scope.scopeId(B), scope.scopeId(otherProject), scope.scopeId(null)]).size).toBe(4);
    expect(scope.scopeId({ ...A, userId: A.userId.toUpperCase(), endpoint: 'https://FIRST.supabase.co:443/' })).toBe(scope.scopeId(A));
    expect(scope.databaseNameForScope(A)).not.toBe(scope.databaseNameForScope(B));
    expect(scope.settingsKeyForScope('libretv-settings', A)).not.toBe(scope.settingsKeyForScope('libretv-settings', otherProject));
  });

  it('切换标记不会改变当前模块快照；新加载的模块才使用新空间', async () => {
    const oldModule = await import('./account-scope');
    oldModule.setActiveAccountScope(A);
    expect(oldModule.readActiveAccountScope()).toEqual(A);
    expect(oldModule.ACTIVE_ACCOUNT_SCOPE).toBeNull();
    vi.resetModules();
    const newModule = await import('./account-scope');
    expect(newModule.ACTIVE_ACCOUNT_SCOPE).toEqual(A);
    expect(Object.isFrozen(newModule.ACTIVE_ACCOUNT_SCOPE)).toBe(true);
    newModule.setActiveAccountScope(null);
    expect(newModule.ACTIVE_ACCOUNT_SCOPE).toEqual(A);
    expect(newModule.readActiveAccountScope()).toBeNull();
  });

  it.each([
    'not-json', 'null', '[]', '"account"',
    JSON.stringify({ ...A, userId: 'someone' }),
    JSON.stringify({ ...A, endpoint: 'http://first.supabase.co' }),
    JSON.stringify({ ...A, endpoint: 'https://user:secret@first.supabase.co' }),
    JSON.stringify({ ...A, endpoint: 'https://first.supabase.co/path' }),
    JSON.stringify({ ...A, endpoint: 'https://first.supabase.co?key=secret' }),
    JSON.stringify({ ...A, endpoint: 'https://first.supabase.co#account' }),
  ])('畸形标记按游客处理且不覆盖原资料：%s', async (raw) => {
    values.set('pps-active-account-v1', raw);
    const scope = await import('./account-scope');
    expect(scope.readActiveAccountScope()).toBeNull();
    expect(scope.ACTIVE_ACCOUNT_SCOPE).toBeNull();
    expect(values.get('pps-active-account-v1')).toBe(raw);
  });

  it('非法切换及存储失败必须报错，原标记保持不变', async () => {
    const scope = await import('./account-scope');
    scope.setActiveAccountScope(A);
    expect(() => scope.setActiveAccountScope({ ...B, endpoint: 'file:///private' })).toThrow();
    expect(scope.readActiveAccountScope()).toEqual(A);
    vi.stubGlobal('localStorage', {
      getItem: () => { throw new Error('storage unavailable'); },
      setItem: () => { throw new Error('storage unavailable'); },
      removeItem: () => { throw new Error('storage unavailable'); },
    });
    expect(scope.readActiveAccountScope()).toBeNull();
    expect(() => scope.setActiveAccountScope(B)).toThrow('storage unavailable');
    expect(() => scope.setActiveAccountScope(null)).toThrow('storage unavailable');
  });

  it('SSR 无浏览器存储时安全返回游客', async () => {
    vi.stubGlobal('localStorage', undefined);
    const scope = await import('./account-scope');
    expect(scope.ACTIVE_ACCOUNT_SCOPE).toBeNull();
    expect(scope.readActiveAccountScope()).toBeNull();
  });
});
