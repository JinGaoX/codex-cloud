/** Family IDs are aliases for existing Auth users, never a new account scope. */
const FAMILY_LOGIN_DOMAIN = 'pps.invalid';
// Match the email syntax accepted by an HTML email input, as before short IDs.
const EMAIL_INPUT = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

export function personalLoginEmail(identifier: string): string {
  const value = identifier.trim();
  if (/^[0-9]{1,64}$/.test(value)) return `${value}@${FAMILY_LOGIN_DOMAIN}`;
  if (value.length <= 254 && EMAIL_INPUT.test(value)) return value;
  throw new Error('请输入数字家庭账号（如 001）或完整邮箱。');
}

/** Display only; the authenticated email and UUID remain untouched. */
export function personalAccountLabel(email: string): string {
  const match = /^([0-9]{1,64})@pps\.invalid$/i.exec(email);
  return match ? match[1] : email;
}
