import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const fixture = vi.hoisted(() => ({
  scope: { userId: '00000000-0000-4000-8000-000000000001', endpoint: 'https://owned-fixture.supabase.co' },
  currentUser: '00000000-0000-4000-8000-000000000001', currentEndpoint: 'https://owned-fixture.supabase.co',
  configEndpoint: 'https://owned-fixture.supabase.co', session: vi.fn(),
}));
vi.mock('./account-scope', () => ({
  ACTIVE_ACCOUNT_SCOPE: fixture.scope,
  readActiveAccountScope: () => ({ userId: fixture.currentUser, endpoint: fixture.currentEndpoint }),
  scopeId: (scope: unknown) => JSON.stringify(scope),
}));
vi.mock('./personal-sync-config', () => ({ getSyncConfiguration: () => ({ url: fixture.configEndpoint, publishableKey: 'sb_publishable_fixture_only' }) }));
vi.mock('./personal-sync-client', () => ({ getPersonalSyncClient: () => ({ auth: { getSession: fixture.session } }) }));

import { accountSourceRelayEnabled, accountSourceRelayText } from './account-source-relay';
import { clearStandaloneDetailCache, standaloneApi } from './standalone-api';

const sourceUrl = 'http://cms-fixture.invalid/api.php/provide/vod?token=fixture';
const source = { key: 'fixture', name: '测试', url: sourceUrl };
const json = (value: unknown, status = 200) => new Response(JSON.stringify(value), { status, headers: { 'content-type': 'application/json' } });
const reply = (text = '{"list":[]}', url = sourceUrl) => json({ text, url });
beforeEach(() => {
  fixture.currentUser = fixture.scope.userId; fixture.currentEndpoint = fixture.scope.endpoint; fixture.configEndpoint = fixture.scope.endpoint;
  fixture.session.mockReset().mockResolvedValue({ data: { session: { access_token: 'fixture-not-a-real-token', user: { id: fixture.scope.userId } } }, error: null });
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue(reply()));
});
afterEach(() => { clearStandaloneDetailCache(); vi.useRealTimers(); vi.unstubAllGlobals(); });

describe('本人账号的点播API服务', () => {
  it('优先POST到配置的本人HTTPS服务，HTTP API只在请求体内，令牌不会发送给片源', async () => {
    expect(accountSourceRelayEnabled()).toBe(true);
    expect(await accountSourceRelayText(sourceUrl)).toEqual({ text: '{"list":[]}', url: sourceUrl });
    expect(fetch).toHaveBeenCalledTimes(1);
    const [target, options] = vi.mocked(fetch).mock.calls[0];
    expect(target).toBe(`${fixture.scope.endpoint}/functions/v1/pps-source-relay`);
    expect(options).toMatchObject({ method: 'POST', mode: 'cors', credentials: 'omit', cache: 'no-store', redirect: 'error',
      body: JSON.stringify({ url: sourceUrl }), headers: { Authorization: 'Bearer fixture-not-a-real-token', apikey: 'sb_publishable_fixture_only' } });
  });

  it('其他用户、其他项目或已切换账号绝不发送旧账号凭据', async () => {
    fixture.session.mockResolvedValueOnce({ data: { session: { access_token: 'other-fixture-token', user: { id: 'other-user' } } }, error: null });
    await expect(accountSourceRelayText(sourceUrl)).rejects.toThrow('重新登录');
    fixture.configEndpoint = 'https://other-fixture.supabase.co';
    await expect(accountSourceRelayText(sourceUrl)).rejects.toThrow('重新登录');
    fixture.configEndpoint = fixture.scope.endpoint; fixture.currentUser = 'other-user';
    await expect(accountSourceRelayText(sourceUrl)).rejects.toThrow('重新登录');
    expect(fetch).not.toHaveBeenCalled();
  });

  it('读取会话期间切换账号会停止发送，取消操作也不发送请求', async () => {
    fixture.session.mockImplementationOnce(async () => {
      fixture.currentUser = 'other-user';
      return { data: { session: { access_token: 'fixture-token', user: { id: fixture.scope.userId } } }, error: null };
    });
    await expect(accountSourceRelayText(sourceUrl)).rejects.toThrow('重新登录');
    fixture.currentUser = fixture.scope.userId;
    const controller = new AbortController(); controller.abort(new DOMException('取消', 'AbortError'));
    await expect(accountSourceRelayText(sourceUrl, controller.signal)).rejects.toThrow('取消');
    expect(fetch).not.toHaveBeenCalled();
  });

  it('新源未同步提示先保存和同步，错误消息不暴露服务器原文或令牌', async () => {
    vi.mocked(fetch).mockResolvedValueOnce(json({ code: 'SOURCE_NOT_SYNCED', error: 'internal token fixture-private' }, 403));
    const result = await standaloneApi.testSource(sourceUrl);
    expect(result.ok).toBe(false); expect(result.error).toContain('完成同步'); expect(result.error).not.toContain('fixture-private');
    vi.mocked(fetch).mockRejectedValueOnce(new TypeError('fixture-not-a-real-token'));
    await expect(accountSourceRelayText(sourceUrl)).rejects.toThrow('暂时无法连接');
  });

  it('会话等待与忽略abort的网络适配器均有时限', async () => {
    vi.useFakeTimers();
    fixture.session.mockReturnValueOnce(new Promise(() => {}));
    const sessionRequest = expect(accountSourceRelayText(sourceUrl)).rejects.toThrow('重新登录');
    await vi.advanceTimersByTimeAsync(3_001); await sessionRequest;
    expect(fetch).not.toHaveBeenCalled();
    vi.mocked(fetch).mockReturnValueOnce(new Promise(() => {}));
    const networkRequest = expect(accountSourceRelayText(sourceUrl)).rejects.toMatchObject({ name: 'TimeoutError' });
    await vi.advanceTimersByTimeAsync(15_001); await networkRequest;
  });

  it('响应体超限、错误结构与有账号密码的最终地址都拒绝', async () => {
    vi.mocked(fetch).mockResolvedValueOnce(new Response('x', { headers: { 'content-length': String(7 * 1024 * 1024) } }));
    await expect(accountSourceRelayText(sourceUrl)).rejects.toThrow('过大');
    vi.mocked(fetch).mockResolvedValueOnce(json({ text: {}, url: sourceUrl }));
    await expect(accountSourceRelayText(sourceUrl)).rejects.toThrow('响应异常');
    vi.mocked(fetch).mockResolvedValueOnce(reply('{"list":[]}', 'https://user:fixture@cms-fixture.invalid/api'));
    await expect(accountSourceRelayText(sourceUrl)).rejects.toThrow('响应异常');
  });

  it('搜索、测活和详情都使用本人服务，同时保留HTTPS播放过滤', async () => {
    vi.mocked(fetch).mockImplementation(async () => reply(JSON.stringify({ list: [{ vod_id: 1, vod_name: '测试影片', vod_play_url:
      '不可播$http://media-fixture.invalid/1.mp4#可播$https://media-fixture.invalid/2.mp4' }] })));
    expect((await standaloneApi.testSource(sourceUrl)).ok).toBe(true);
    expect((await standaloneApi.search('测试影片', [source], false)).list).toHaveLength(1);
    expect((await standaloneApi.detail('1', source)).episodes).toEqual(['https://media-fixture.invalid/2.mp4']);
    expect(vi.mocked(fetch).mock.calls.every(([url]) => url === `${fixture.scope.endpoint}/functions/v1/pps-source-relay`)).toBe(true);
    const request = JSON.parse(String(vi.mocked(fetch).mock.calls[0][1]?.body)) as { url: string };
    expect(new URL(request.url).searchParams.get('ac')).toBe('videolist');
  });

  it('已登录账号的M3U仍直连且不附带认证头', async () => {
    vi.mocked(fetch).mockResolvedValueOnce(new Response('#EXTM3U\n#EXTINF:-1,频道\nhttps://media-fixture.invalid/live.m3u8'));
    const playlist = await standaloneApi.livePlaylist('https://live-fixture.invalid/list.m3u');
    expect(playlist.channels).toHaveLength(1);
    expect(vi.mocked(fetch).mock.calls[0][0]).toBe('https://live-fixture.invalid/list.m3u');
    expect(vi.mocked(fetch).mock.calls[0][1]?.headers).not.toHaveProperty('Authorization');
    expect(fixture.session).not.toHaveBeenCalled();
  });

  it.each(['AUTH_REQUIRED', 'RELAY_UNAVAILABLE', 'SOURCE_NOT_SYNCED', 'RATE_LIMITED'])('%s不记为坏源，搜索与手动测活均保留中立标志', async (code) => {
    vi.mocked(fetch).mockImplementation(async () => json({ code }, 503));
    expect(await standaloneApi.testSource(sourceUrl)).toMatchObject({ ok: false, healthIgnored: true });
    const outcomes: unknown[] = [];
    const result = await standaloneApi.search('测试', [source], false, { onSource: (outcome) => outcomes.push(outcome) });
    expect(outcomes).toEqual([expect.objectContaining({ ok: false, healthIgnored: true })]);
    expect(result.failures[0]).toMatchObject({ healthIgnored: true });
  });

  it('真实源站失败仍计入片源健康度', async () => {
    vi.mocked(fetch).mockResolvedValue(json({ code: 'UPSTREAM_FAILED' }, 502));
    const result = await standaloneApi.testSource(sourceUrl);
    expect(result.ok).toBe(false); expect(result.healthIgnored).not.toBe(true);
  });

  it('账号搜索允许服务冷启动超过10秒，成功第一页在后续分页超时时仍保留', async () => {
    vi.useFakeTimers();
    vi.mocked(fetch).mockImplementationOnce(() => new Promise((resolve) => setTimeout(() => resolve(reply(JSON.stringify({
      pagecount: 2, list: [{ vod_id: 1, vod_name: '测试影片' }],
    }))), 10_500))).mockImplementationOnce(() => new Promise(() => {}));
    const request = standaloneApi.search('测试影片', [source], false);
    await vi.advanceTimersByTimeAsync(18_001);
    const result = await request;
    expect(result.list).toHaveLength(1); expect(result.partial).toBe(true); expect(result.failures).toEqual([]);
  });
});
