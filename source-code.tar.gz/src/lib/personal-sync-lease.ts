import type Dexie from 'dexie';

export const SYNC_LEASE_KEY = 'lease';
export const SYNC_LEASE_TTL_MS = 15_000;
export const SYNC_LEASE_HEARTBEAT_MS = 5_000;

/** epoch 为本机 fencing token；旧网络响应不能借用后来重新取得的租约。 */
export interface SyncLease {
  readonly scopeId: string;
  readonly ownerToken: string;
  readonly epoch: number;
  readonly expiresAt: number;
}

interface LeaseRow { key: string; value: SyncLease }

const validText = (value: unknown, maximum: number): value is string =>
  typeof value === 'string' && value.length > 0 && value.length <= maximum && !/[\u0000-\u001f\u007f]/.test(value);
const validTime = (value: unknown): value is number =>
  typeof value === 'number' && Number.isSafeInteger(value) && value >= 0;

function assertArguments(scopeId: string, ownerToken: string, now: number): void {
  if (!validText(scopeId, 2048) || !validText(ownerToken, 256) || !validTime(now)
    || now > Number.MAX_SAFE_INTEGER - SYNC_LEASE_TTL_MS) {
    throw new Error('同步租约参数不正确');
  }
}

function validateLease(value: unknown): SyncLease {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('同步租约资料损坏');
  const lease = value as Record<string, unknown>;
  if (!validText(lease.scopeId, 2048) || typeof lease.ownerToken !== 'string'
    || (lease.ownerToken !== '' && !validText(lease.ownerToken, 256))
    || !validTime(lease.epoch) || lease.epoch < 1 || !validTime(lease.expiresAt)) {
    throw new Error('同步租约资料损坏');
  }
  return { scopeId: lease.scopeId, ownerToken: lease.ownerToken, epoch: lease.epoch, expiresAt: lease.expiresAt };
}

const sameOwner = (current: SyncLease, claim: SyncLease) => current.scopeId === claim.scopeId
  && current.ownerToken === claim.ownerToken && current.epoch === claim.epoch;

/**
 * personalSyncState 与本机账号数据同库。readwrite 事务将多个标签页的竞争原子化，
 * 不依赖 Navigator Locks、localStorage 的非原子读写或单标签页内存状态。
 * 本模块不创建表，也不写入保存 outbox 的其它记录。
 */
export async function tryAcquireSyncLease(
  db: Dexie, scopeId: string, ownerToken: string, now = Date.now(),
): Promise<SyncLease | null> {
  assertArguments(scopeId, ownerToken, now);
  const table = db.table<LeaseRow, string>('personalSyncState');
  return db.transaction('rw', table, async () => {
    const row = await table.get(SYNC_LEASE_KEY);
    const current = row ? validateLease(row.value) : null;
    if (current && current.scopeId !== scopeId) throw new Error('同步租约与当前账号不一致');
    if (current && current.expiresAt > now) {
      return current.ownerToken === ownerToken ? Object.freeze(current) : null;
    }
    const epoch = (current?.epoch ?? 0) + 1;
    if (!Number.isSafeInteger(epoch)) throw new Error('同步租约版本超出范围');
    const claim = Object.freeze({ scopeId, ownerToken, epoch, expiresAt: now + SYNC_LEASE_TTL_MS });
    await table.put({ key: SYNC_LEASE_KEY, value: claim });
    return claim;
  });
}

/** 续期只能延长仍有效的同一 epoch；过期后必须重新争取新租约。 */
export async function renewSyncLease(db: Dexie, claim: SyncLease, now = Date.now()): Promise<SyncLease | null> {
  assertArguments(claim.scopeId, claim.ownerToken, now);
  if (!Number.isSafeInteger(claim.epoch) || claim.epoch < 1) throw new Error('同步租约版本不正确');
  const table = db.table<LeaseRow, string>('personalSyncState');
  return db.transaction('rw', table, async () => {
    const row = await table.get(SYNC_LEASE_KEY);
    if (!row) return null;
    const current = validateLease(row.value);
    if (!sameOwner(current, claim) || current.expiresAt <= now) return null;
    const renewed = Object.freeze({ ...current, expiresAt: now + SYNC_LEASE_TTL_MS });
    await table.put({ key: SYNC_LEASE_KEY, value: renewed });
    return renewed;
  });
}

/**
 * 在含 personalSyncState 的主数据事务中调用，可将检查与响应落盘放在同一事务内。
 * 只检查后退出事务再异步落盘，仍会有过期接手窗口；调用方须保持事务边界。
 */
export async function ownsSyncLease(db: Dexie, claim: SyncLease, now = Date.now()): Promise<boolean> {
  assertArguments(claim.scopeId, claim.ownerToken, now);
  const row = await db.table<LeaseRow, string>('personalSyncState').get(SYNC_LEASE_KEY);
  if (!row) return false;
  const current = validateLease(row.value);
  return sameOwner(current, claim) && current.expiresAt > now;
}

/** 保留 epoch，防止删除再创建后版本回到 1；旧持有者无权释放后续租约。 */
export async function releaseSyncLease(db: Dexie, claim: SyncLease): Promise<void> {
  assertArguments(claim.scopeId, claim.ownerToken, 0);
  const table = db.table<LeaseRow, string>('personalSyncState');
  await db.transaction('rw', table, async () => {
    const row = await table.get(SYNC_LEASE_KEY);
    if (!row) return;
    const current = validateLease(row.value);
    if (!sameOwner(current, claim)) return;
    await table.put({ key: SYNC_LEASE_KEY, value: { ...current, ownerToken: '', expiresAt: 0 } });
  });
}
