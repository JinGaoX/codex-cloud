import { describe, expect, it } from 'vitest';
import { accountEntryPresentation, type AccountEntryState } from './account-entry-state';

const active: AccountEntryState = {
  ready: true, configured: true, scopeActive: true, user: { id: 'account-fixture' },
  status: 'idle', pendingCount: 0, conflictCount: 0, lastSyncedAt: null,
};

describe('account entry presentation', () => {
  it('keeps local users local and does not claim a connection while loading or unconfigured', () => {
    expect(accountEntryPresentation({ ...active, ready: false }).label).toBe('账号');
    expect(accountEntryPresentation({ ...active, scopeActive: false, user: null }).label).toBe('登录');
    expect(accountEntryPresentation({ ...active, scopeActive: false, configured: false, user: null }).description).toContain('尚未配置');
    expect(accountEntryPresentation({ ...active, configured: false }).indicator).toBe('warning');
  });

  it('requires a confirmed account and a successful timestamp before saying synced', () => {
    expect(accountEntryPresentation(active).label).toBe('等待同步');
    expect(accountEntryPresentation({ ...active, status: 'local' }).label).toBe('等待同步');
    expect(accountEntryPresentation({ ...active, status: 'local', lastSyncedAt: 1000 }).label).toBe('等待同步');
    expect(accountEntryPresentation({ ...active, user: null, lastSyncedAt: 1000 }).label).toBe('待确认');
    expect(accountEntryPresentation({ ...active, lastSyncedAt: 1000 })).toMatchObject({ label: '已同步', indicator: 'success' });
    expect(accountEntryPresentation({ ...active, lastSyncedAt: Number.NaN }).label).toBe('等待同步');
  });

  it('gives pending, in-flight and offline work priority over an old success', () => {
    const pending = { ...active, pendingCount: 3, lastSyncedAt: 1000 };
    expect(accountEntryPresentation(pending)).toMatchObject({ label: '待同步', description: '账号与同步：3 项资料等待同步' });
    expect(accountEntryPresentation({ ...pending, status: 'syncing' }).label).toBe('同步中');
    expect(accountEntryPresentation({ ...pending, status: 'offline' })).toMatchObject({ label: '离线', indicator: 'pending' });
  });

  it('surfaces authentication, conflicts and errors rather than an old success', () => {
    const previousSuccess = { ...active, lastSyncedAt: 1000 };
    expect(accountEntryPresentation({ ...previousSuccess, status: 'auth-required' }).label).toBe('重新登录');
    expect(accountEntryPresentation({ ...previousSuccess, status: 'conflict' }).label).toBe('待处理');
    expect(accountEntryPresentation({ ...previousSuccess, conflictCount: 2 }).label).toBe('待处理');
    expect(accountEntryPresentation({ ...previousSuccess, status: 'error' }).label).toBe('同步异常');
  });
});
