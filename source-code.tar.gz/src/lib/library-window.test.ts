import { describe, expect, it, vi } from 'vitest';
import { QueryClient } from '@tanstack/react-query';
import type { DiscoveryItem } from './discovery';
import { fetchLibraryWindow, libraryDisplaySize, libraryGridLayout, type LibraryBatch } from './library-window';
import { libraryWindowStart, readLibraryView, withLibraryWindow } from '../components/library-browser-state';

const rows = (start: number, count: number): DiscoveryItem[] => Array.from({ length: count }, (_, index) => ({ id: String(start + index), title: `真实片名${start + index}`, cover: '', genres: [], rank: start + index + 1 }));
const provider = (total = 100, batchSize = 20) => vi.fn(async (start: number): Promise<LibraryBatch> => ({
  items: rows(start, Math.min(batchSize, Math.max(0, total - start))), start, retrievedAt: 123,
  ...(start + batchSize < total ? { nextPageStart: start + batchSize } : {}),
}));
const ids = (items: DiscoveryItem[]) => items.map(item => Number(item.id));

describe('full-row public library display windows', () => {
  it.each([[390, 21], [834, 20], [1194, 24], [1440, 21], [359, 20], [600, 20], [1000, 24], [1360, 21]])('matches CSS columns at %ipx', (width, count) => {
    expect(libraryDisplaySize(width)).toBe(count);
  });

  it.each([[299, 2, 20], [300, 3, 21], [342, 3, 21], [559, 3, 21], [560, 4, 20], [760, 4, 20], [819, 4, 20], [820, 5, 20], [999, 5, 20], [1000, 6, 24], [1239, 6, 24], [1240, 7, 21]])('matches complete rows to %ipx of actual content space', (width, columns, size) => {
    expect(libraryGridLayout(width)).toEqual({ columns, size });
    expect(size % columns).toBe(0);
  });

  it('changes desktop rows when its rail toggles without rotating to another absolute position', () => {
    const viewport = 1440, gutters = 2 * (viewport * .03);
    const expanded = libraryGridLayout(viewport - 176 - gutters);
    const collapsed = libraryGridLayout(viewport - 72 - gutters);
    expect(expanded).toEqual({ columns: 6, size: 24 });
    expect(collapsed).toEqual({ columns: 7, size: 21 });
    const original = readLibraryView(new URLSearchParams('size=21&offset=42&page=3'));
    const narrower = withLibraryWindow(original, expanded.size);
    const wider = withLibraryWindow(narrower, collapsed.size);
    expect(libraryWindowStart(narrower)).toBe(42);
    expect(wider).toEqual(original);
    const tablet = 1194;
    expect(libraryGridLayout(tablet - 72 - 2 * tablet * .03)).toEqual({ columns: 6, size: 24 });
  });

  it.each([20, 21, 24])('keeps consecutive %i-item pages gap-free across native 20-item batches', async size => {
    const loadBatch = provider(100);
    const fingerprints = new Map<number, readonly string[]>();
    const windows = [];
    for (let start = 0; start < size * 3; start += size) windows.push(await fetchLibraryWindow({ start, size, batchSize: 20, limit: 5000, loadBatch, seenBatches: fingerprints }));
    expect(ids(windows.flatMap(window => window.items))).toEqual(Array.from({ length: size * 3 }, (_, i) => i));
    expect(windows.every(window => !window.incomplete)).toBe(true);
    expect(loadBatch.mock.calls.every(([start]) => start % 20 === 0)).toBe(true);
  });

  it('reuses intersecting QueryClient batches rather than refetching page2 or losing its remainder', async () => {
    const client = new QueryClient(), fetcher = provider(100);
    try {
      const loadBatch = (start: number) => client.fetchQuery({ queryKey: ['fixture-batch', start], queryFn: () => fetcher(start), staleTime: 60_000 });
      const first = await fetchLibraryWindow({ start: 0, size: 21, batchSize: 20, limit: 5000, loadBatch });
      const second = await fetchLibraryWindow({ start: 21, size: 21, batchSize: 20, limit: 5000, loadBatch });
      expect(fetcher.mock.calls.map(([start]) => start)).toEqual([0, 20, 40]);
      expect(ids([...first.items, ...second.items])).toEqual(Array.from({ length: 42 }, (_, i) => i));
    } finally { client.clear(); }
  });

  it('keeps the absolute first item on rotation, then appends the next range at the new size', async () => {
    const loadBatch = provider(200);
    const rotated = await fetchLibraryWindow({ start: 42, size: 24, batchSize: 20, limit: 5000, loadBatch });
    const next = await fetchLibraryWindow({ start: rotated.nextPageStart!, size: 24, batchSize: 20, limit: 5000, loadBatch });
    expect(ids([...rotated.items, ...next.items])).toEqual(Array.from({ length: 48 }, (_, i) => 42 + i));
  });

  it('preserves real Top250 ranks across its native 25-item page boundary and real ending', async () => {
    const loadBatch = provider(250, 25);
    const first = await fetchLibraryWindow({ start: 0, size: 21, batchSize: 25, limit: 250, loadBatch });
    const second = await fetchLibraryWindow({ start: 21, size: 21, batchSize: 25, limit: 250, loadBatch });
    expect(first.items.at(-1)?.rank).toBe(21); expect(second.items[0].rank).toBe(22);
    const last = await fetchLibraryWindow({ start: 231, size: 21, batchSize: 25, limit: 250, loadBatch });
    expect(last.items).toHaveLength(19); expect(last.items.at(-1)?.rank).toBe(250); expect(last.nextPageStart).toBeUndefined();
    expect(loadBatch.mock.calls.every(([start]) => start % 25 === 0)).toBe(true);
  });

  it('does not pad a real 10-item weekly list or a short filtered page', async () => {
    const weekly = await fetchLibraryWindow({ start: 0, size: 21, batchSize: 50, limit: 50, loadBatch: provider(10, 50) });
    expect(weekly.items).toHaveLength(10); expect(weekly.nextPageStart).toBeUndefined(); expect(weekly.incomplete).toBeUndefined();
    const short = await fetchLibraryWindow({ start: 42, size: 21, batchSize: 20, limit: 5000, loadBatch: provider(43) });
    expect(ids(short.items)).toEqual([42]); expect(short.nextPageStart).toBeUndefined();
  });

  it('retains only the continuous successful prefix on later failure and prevents skipping ahead', async () => {
    const loadBatch = vi.fn(async (start: number): Promise<LibraryBatch> => {
      if (start === 20) throw new Error('failed second batch');
      return { items: rows(start, 20), start, retrievedAt: 12, nextPageStart: start + 20 };
    });
    const partial = await fetchLibraryWindow({ start: 0, size: 21, batchSize: 20, limit: 5000, loadBatch });
    expect(ids(partial.items)).toEqual(Array.from({ length: 20 }, (_, i) => i));
    expect(partial.incomplete).toBe(true); expect(partial.nextPageStart).toBeUndefined();
    expect(loadBatch.mock.calls.map(([start]) => start)).toEqual([0, 20]);
    await expect(fetchLibraryWindow({ start: 20, size: 21, batchSize: 20, limit: 5000, loadBatch })).rejects.toThrow('failed second');
  });

  it('allows retry to complete the same page before moving on', async () => {
    const client = new QueryClient(); let fail = true;
    const fetcher = vi.fn(async (start: number): Promise<LibraryBatch> => {
      if (start === 20 && fail) throw new Error('temporary');
      return { items: rows(start, 20), start, retrievedAt: 1, nextPageStart: start + 20 };
    });
    const loadBatch = (start: number) => client.fetchQuery({ queryKey: ['retry-batch', start], queryFn: () => fetcher(start), staleTime: 60_000, retry: false });
    try {
      expect((await fetchLibraryWindow({ start: 0, size: 21, batchSize: 20, limit: 5000, loadBatch })).items).toHaveLength(20);
      fail = false;
      const retry = await fetchLibraryWindow({ start: 0, size: 21, batchSize: 20, limit: 5000, loadBatch });
      expect(retry.items).toHaveLength(21); expect(retry.nextPageStart).toBe(21);
      expect(fetcher.mock.calls.map(([start]) => start)).toEqual([0, 20, 20]);
    } finally { client.clear(); }
  });

  it('stops a source that repeats or overlaps complete batches and keeps fingerprints bounded', async () => {
    const seenBatches = new Map<number, readonly string[]>();
    const repeated = await fetchLibraryWindow({ start: 0, size: 21, batchSize: 20, limit: 5000, seenBatches,
      loadBatch: async start => ({ items: rows(0, 20), start, retrievedAt: 1, nextPageStart: start + 20 }) });
    expect(repeated.items).toHaveLength(20); expect(repeated.repeated).toBe(true); expect(repeated.nextPageStart).toBeUndefined();
    const overlap = await fetchLibraryWindow({ start: 0, size: 21, batchSize: 20, limit: 5000,
      loadBatch: async start => ({ items: rows(start === 20 ? 19 : 0, 20), start, retrievedAt: 1, nextPageStart: start + 20 }) });
    expect(overlap.items).toHaveLength(20); expect(overlap.repeated).toBe(true);
    for (let start = 100; start < 1000; start += 20) await fetchLibraryWindow({ start, size: 20, batchSize: 20, limit: 5000, seenBatches, loadBatch: provider(2000) });
    expect(seenBatches.size).toBe(16);
  });

  it('does not silently shift positions when a provider shortens or mislabels a still-pageable batch', async () => {
    const result = await fetchLibraryWindow({ start: 0, size: 21, batchSize: 20, limit: 5000,
      loadBatch: async start => ({ items: rows(start, 19), start, retrievedAt: 1, nextPageStart: start + 20 }) });
    expect(result.incomplete).toBe(true); expect(result.items).toHaveLength(19); expect(result.nextPageStart).toBeUndefined();
  });

  it('cancels the display window immediately without cancelling a reusable public batch on rotation', async () => {
    const client = new QueryClient(), controller = new AbortController();
    let release!: (batch: LibraryBatch) => void;
    const pending = new Promise<LibraryBatch>(resolve => { release = resolve; });
    const fetcher = vi.fn(() => pending);
    const loadBatch = () => client.fetchQuery({ queryKey: ['shared-rotation'], queryFn: fetcher, staleTime: 60_000 });
    try {
      const old = fetchLibraryWindow({ start: 0, size: 21, batchSize: 20, limit: 5000, loadBatch, signal: controller.signal });
      const rejection = expect(old).rejects.toMatchObject({ name: 'AbortError' });
      controller.abort(); await rejection;
      const rotated = fetchLibraryWindow({ start: 0, size: 20, batchSize: 20, limit: 5000, loadBatch });
      release({ items: rows(0, 20), start: 0, retrievedAt: 1, nextPageStart: 20 });
      expect((await rotated).items).toHaveLength(20); expect(fetcher).toHaveBeenCalledTimes(1);
    } finally { client.clear(); }
  });

  it('reuses a loading batch during a sidebar resize while preserving the first item and subsequent range', async () => {
    const client = new QueryClient(), controller = new AbortController();
    let release!: (batch: LibraryBatch) => void;
    const pending = new Promise<LibraryBatch>(resolve => { release = resolve; });
    const fetcher = vi.fn((start: number): Promise<LibraryBatch> => start === 40 ? pending : Promise.resolve({ items: rows(start, 20), start, retrievedAt: 1, nextPageStart: start + 20 }));
    const loadBatch = (start: number) => client.fetchQuery({ queryKey: ['sidebar-batch', start], queryFn: () => fetcher(start), staleTime: 60_000 });
    try {
      const expanded = fetchLibraryWindow({ start: 42, size: libraryGridLayout(1178).size, batchSize: 20, limit: 5000, loadBatch, signal: controller.signal });
      const rejection = expect(expanded).rejects.toMatchObject({ name: 'AbortError' });
      controller.abort(); await rejection;
      const size = libraryGridLayout(1282).size;
      const collapsed = fetchLibraryWindow({ start: 42, size, batchSize: 20, limit: 5000, loadBatch });
      release({ items: rows(40, 20), start: 40, retrievedAt: 1, nextPageStart: 60 });
      const first = await collapsed;
      const second = await fetchLibraryWindow({ start: first.nextPageStart!, size, batchSize: 20, limit: 5000, loadBatch });
      expect(ids([...first.items, ...second.items])).toEqual(Array.from({ length: 42 }, (_, i) => 42 + i));
      expect(fetcher.mock.calls.map(([start]) => start)).toEqual([40, 60, 80]);
    } finally { client.clear(); }
  });

  it('honors pre-abort and the 5000-item safety cap without requesting impossible offsets', async () => {
    const controller = new AbortController(); controller.abort(); const loadBatch = provider(5000);
    await expect(fetchLibraryWindow({ start: 0, size: 21, batchSize: 20, limit: 5000, loadBatch, signal: controller.signal })).rejects.toMatchObject({ name: 'AbortError' });
    expect(loadBatch).not.toHaveBeenCalled();
    const final = await fetchLibraryWindow({ start: 4998, size: 21, batchSize: 20, limit: 5000, loadBatch });
    expect(ids(final.items)).toEqual([4998, 4999]); expect(final.nextPageStart).toBeUndefined();
    expect(loadBatch.mock.calls.map(([start]) => start)).toEqual([4980]);
    await expect(fetchLibraryWindow({ start: 5000, size: 21, batchSize: 20, limit: 5000, loadBatch })).rejects.toThrow('展示范围');
  });
});
