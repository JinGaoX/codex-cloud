/**
 * 触屏指针判定。
 *
 * 用途：播放器控制栏交互分流（issue LibreSpark/LibreTV#937）——
 * 提供初始输入方式；点播控制器还会根据真实 pointer/touch 事件更新，
 * 不把 Artplayer 的 UA 移动端判定当作触屏能力。全屏触屏空闲后隐藏，
 * 暂停/设置/拖动/键盘焦点期间保持可见，桌面鼠标仍快速收起。
 *
 * 用媒体查询而非 UA 嗅探：`(hover: none) and (pointer: coarse)` 对
 * iPad 鼠标模式 / 触屏笔记本等混合形态的语义比解析 UA 可靠。
 */
export function prefersTouchPointer(
  match?: (query: string) => { matches: boolean }
): boolean {
  try {
    if (match) return match('(hover: none) and (pointer: coarse)').matches;
    // SSR / 老浏览器没有 matchMedia：按桌面（非触屏）处理，行为与现状一致
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return false;
    return window.matchMedia('(hover: none) and (pointer: coarse)').matches;
  } catch {
    return false;
  }
}
