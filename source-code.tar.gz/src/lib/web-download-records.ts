import type { WebDownloadTask } from './web-download-queue';

const STORAGE_PREFIX = 'pps-web-download-v1:';
const TASK_ID = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i;
const TASK_STATES = new Set([
  'queued', 'checking', 'restoring', 'downloading', 'pausing', 'paused', 'cancelling', 'cancelled', 'error', 'ready',
]);

type SavedFile =
  | { kind: 'attachment'; url: string; filename: string }
  | { kind: 'disk'; storageId: string; filename: string; bytes: number }
  | { kind: 'memory' };

export interface WebDownloadRecord {
  id: string;
  createdAt: number;
  url: string;
  title: string;
  sourceName: string;
  selection?: WebDownloadTask['selection'];
  status: WebDownloadTask['status'];
  progress?: WebDownloadTask['progress'];
  durable?: boolean;
  reason?: string;
  file?: SavedFile;
  handedToBrowser?: boolean;
}

function validUrl(value: unknown): value is string {
  if (typeof value !== 'string') return false;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password;
  } catch { return false; }
}

export function readWebDownloadRecord(id: string): WebDownloadRecord | null {
  if (!TASK_ID.test(id)) return null;
  try {
    const json = localStorage.getItem(STORAGE_PREFIX + id);
    if (!json) return null;
    const entry = JSON.parse(json) as WebDownloadRecord;
    if (entry?.id !== id || !Number.isFinite(entry.createdAt) || !validUrl(entry.url)
      || typeof entry.title !== 'string' || typeof entry.sourceName !== 'string' || !TASK_STATES.has(entry.status)) return null;
    const selection = entry.selection;
    if (selection && ((!['hls', 'mp4'].includes(selection.kind))
      || (!validUrl(selection.variant?.url) && typeof selection.variant?.unsupported !== 'string'))) return null;
    const file = entry.file;
    if (file?.kind === 'attachment' && (!validUrl(file.url) || typeof file.filename !== 'string')) return null;
    if (file?.kind === 'disk' && (file.storageId !== id || typeof file.filename !== 'string'
      || !Number.isFinite(file.bytes) || file.bytes <= 0)) return null;
    const progress = entry.progress;
    if (progress && (!Number.isFinite(progress.current) || progress.current < 0
      || !Number.isFinite(progress.total) || progress.total < 0
      || (progress.percentage !== undefined && (!Number.isFinite(progress.percentage)
        || progress.percentage < 0 || progress.percentage > 100)))) delete entry.progress;
    return entry;
  } catch { return null; }
}

export function readWebDownloadRecords() {
  try {
    const records: WebDownloadRecord[] = [];
    for (let index = 0; index < localStorage.length; index++) {
      const key = localStorage.key(index);
      if (!key?.startsWith(STORAGE_PREFIX)) continue;
      const entry = readWebDownloadRecord(key.slice(STORAGE_PREFIX.length));
      if (entry) records.push(entry);
    }
    return records.sort((a, b) => a.createdAt - b.createdAt);
  } catch { return []; }
}

export function storeWebDownloadRecord(task: WebDownloadTask) {
  const { id, createdAt, title, sourceName, url, selection, status, progress, durable } = task;
  const record: WebDownloadRecord = { id, createdAt, title, sourceName, url, selection, status, progress, durable };
  if (status === 'error') record.reason = task.reason;
  if (status === 'ready') {
    record.handedToBrowser = task.handedToBrowser;
    const file = task.file;
    record.file = file.kind === 'attachment' ? file : file.storageId
      ? { kind: 'disk', storageId: file.storageId, filename: file.filename, bytes: file.bytes }
      : { kind: 'memory' };
  }
  try {
    localStorage.setItem(STORAGE_PREFIX + id, JSON.stringify(record));
    return true;
  } catch { return false; }
}

export function deleteWebDownloadRecord(id: string) {
  try {
    localStorage.removeItem(STORAGE_PREFIX + id);
    return true;
  } catch { return false; }
}
