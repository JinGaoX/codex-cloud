export interface PlaybackStartCallbacks {
  /** Both the media load and this play request must still be current. */
  isCurrent: () => boolean;
  onStarted: () => void;
  onBlocked: () => void;
  /** A current load interruption may release its pending indicator silently. */
  onInterrupted?: () => void;
  onError: (reason: unknown) => void;
}

/**
 * Call from the user's event handler, after assigning the intended media.
 * Do not move play() into a promise callback: Safari needs the original tap.
 * The caller owns the load/request identity so late promises cannot change a
 * later episode's UI. A cancelled request is not an autoplay permission error.
 */
export function requestVideoPlayback(
  video: Pick<HTMLMediaElement, 'play'>,
  callbacks: PlaybackStartCallbacks,
): void {
  const rejected = (reason: unknown) => {
    if (!callbacks.isCurrent()) return;
    const name = reason && typeof reason === 'object' && 'name' in reason ? reason.name : undefined;
    if (name === 'AbortError') {
      callbacks.onInterrupted?.();
      return;
    }
    if (name === 'NotAllowedError') callbacks.onBlocked();
    else callbacks.onError(reason);
  };

  if (!callbacks.isCurrent()) return;
  try {
    // Keep this synchronous even though completing playback is asynchronous.
    const started = video.play();
    void Promise.resolve(started).then(() => {
      if (callbacks.isCurrent()) callbacks.onStarted();
    }, rejected).catch(() => {
      // Notification callbacks must not create an unhandled promise rejection.
    });
  } catch (reason) {
    rejected(reason);
  }
}
