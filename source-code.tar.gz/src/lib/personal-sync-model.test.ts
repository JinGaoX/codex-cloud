import { webcrypto } from 'node:crypto';
import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  canonicalSourceIdentity, canonicalSourceKey, recordId, snapshotToRecords, validateSyncResponse,
  type PersonalSyncSnapshot, type SnapshotRecord, type SyncRecord, type SyncResponse,
} from './personal-sync-model';
import type { HistoryEntry, FavoriteEntry } from './db';

const URL_A = 'https://first.example/api.php/provide/vod';
const URL_B = 'https://second.example/api.php/provide/vod';
const source = (key = 'custom_0', url = URL_A, name = '片源甲') => ({ key, url, name });
const history = (sourceKey = 'custom_0', sourceUrl: string | undefined = URL_A, timestamp = 1000): HistoryEntry => ({
  id: `${sourceKey}_film`, sourceKey, sourceUrl, vodId: 'film', title: '同名影片', pic: '/poster.webp',
  episodeIndex: 2, totalEpisodes: 5, playbackPosition: 120, duration: 1800, timestamp,
});
const favorite = (sourceKey = 'custom_0', sourceUrl = URL_A): FavoriteEntry => ({
  id: JSON.stringify([sourceKey, 'film']), sourceKey, sourceUrl, vodId: 'film', name: '同名影片',
  sourceName: '片源甲', pic: '/poster.webp', timestamp: 1000,
});
const snapshot = (patch: Partial<PersonalSyncSnapshot> = {}): PersonalSyncSnapshot => ({
  sources: [source()], selectedKeys: ['custom_0'], history: [history()],
  progress: [{ key: 'custom_0_film_2', position: 120, duration: 1800, updatedAt: 1000 }],
  favorites: [favorite()], ...patch,
});
const rows = (data: Map<string, SnapshotRecord>, kind: string) => [...data.values()].filter((row) => row.kind === kind);
const wire = (row: SnapshotRecord, revision = 1): SyncRecord => ({ ...row, revision, deleted: false, updatedAt: 1000 });
const response = (records: SyncRecord[], patch: Partial<SyncResponse> = {}): SyncResponse => ({
  revision: 1, accepted: true, records, conflicts: [], ...patch,
});

afterEach(() => vi.unstubAllGlobals());

describe('同步影片与片源的稳定身份', () => {
  it('同 API 在两台设备的 custom_0/custom_9 得到相同来源、影片与分集身份', async () => {
    const a = await snapshotToRecords(snapshot());
    const b = await snapshotToRecords(snapshot({
      sources: [source('custom_9')], selectedKeys: ['custom_9'], history: [history('custom_9')],
      progress: [{ key: 'custom_9_film_2', position: 120, duration: 1800, updatedAt: 1000 }], favorites: [favorite('custom_9')],
    }));
    expect([...a]).toEqual([...b]);
    for (const row of a.values()) {
      if (row.kind !== 'sources') expect(row.payload.sourceKey).toMatch(/^sync_[0-9a-f]{24}$/);
      expect(row.payload).not.toHaveProperty('id');
    }
  });

  it('两台设备相同 custom_0 对应不同 URL 时不能按片名或临时key合并', async () => {
    const a = await snapshotToRecords(snapshot());
    const b = await snapshotToRecords(snapshot({ sources: [source('custom_0', URL_B)], history: [history('custom_0', URL_B)],
      favorites: [favorite('custom_0', URL_B)] }));
    expect([...a.keys()].every((key) => !b.has(key))).toBe(true);
  });

  it('更改显示名称保持片源、影片和进度身份', async () => {
    const a = await snapshotToRecords(snapshot());
    const b = await snapshotToRecords(snapshot({ sources: [source('custom_0', URL_A, '新的名称')] }));
    expect([...a.keys()]).toEqual([...b.keys()]);
    expect(rows(b, 'sources')[0].payload.source).toMatchObject({ name: '新的名称' });
    expect(rows(a, 'history')).toEqual(rows(b, 'history'));
  });

  it('URL仅规范实际等价部分，查询令牌/查询次序/真实path末尾斜杠均保留', () => {
    expect(canonicalSourceIdentity('https://FIRST.example:443/api#local')).toBe('https://first.example/api');
    expect(canonicalSourceIdentity(URL_A + '?token=one')).not.toBe(canonicalSourceIdentity(URL_A + '?token=two'));
    expect(canonicalSourceIdentity(URL_A + '?a=1&b=2')).not.toBe(canonicalSourceIdentity(URL_A + '?b=2&a=1'));
    expect(canonicalSourceIdentity(URL_A + '/')).not.toBe(canonicalSourceIdentity(URL_A));
    expect(canonicalSourceIdentity('http://first.example/api')).toBe('http://first.example/api');
    expect(canonicalSourceIdentity('https://name:password@first.example/api')).toBeNull();
    expect(canonicalSourceIdentity('file:///secret')).toBeNull();
  });

  it('WebCrypto 缺失或拒绝时与标准 SHA-256 结果完全一致', async () => {
    vi.stubGlobal('crypto', webcrypto);
    const normal = canonicalSourceKey(URL_A);
    const fromSnapshot = async () => (rows(await snapshotToRecords(snapshot()), 'sources')[0].payload.source as { key: string }).key;
    expect(await fromSnapshot()).toBe(normal);
    vi.stubGlobal('crypto', undefined);
    expect(await fromSnapshot()).toBe(normal);
    vi.stubGlobal('crypto', { subtle: { digest: () => Promise.reject(new Error('blocked')) } });
    expect(await fromSnapshot()).toBe(normal);
  });

  it('known source key 按最长前缀匹配，影片ID含下划线且最后一个数字才是分集索引', async () => {
    const data = await snapshotToRecords(snapshot({ sources: [source('custom', URL_B), source('custom_more', URL_A)],
      history: [], favorites: [], progress: [{ key: 'custom_more_video_name_18_2', position: 30, duration: 600, updatedAt: 900 }] }));
    expect(rows(data, 'progress')).toEqual([expect.objectContaining({
      key: JSON.stringify([URL_A, 'video_name_18', 2]),
      payload: expect.objectContaining({ vodId: 'video_name_18', episodeIndex: 2, position: 30, sourceUrl: URL_A }),
    })]);
  });

  it('复看或回退按原进度和修改时间保存，不能取位置最大值', async () => {
    const data = await snapshotToRecords(snapshot({ sources: [source(), source('alias')], history: [], favorites: [], progress: [
      { key: 'custom_0_film_2', position: 1000, duration: 1800, updatedAt: 1000 },
      { key: 'alias_film_2', position: 30, duration: 1800, updatedAt: 2000 },
    ] }));
    expect(rows(data, 'progress')[0].payload).toMatchObject({ position: 30, updatedAt: 2000 });
  });

  it('已删除片源从history或aliases解析旧进度，不会自动恢复sources配置', async () => {
    const fromHistory = await snapshotToRecords(snapshot({ sources: [], favorites: [] }));
    expect(rows(fromHistory, 'sources')).toHaveLength(0);
    expect(rows(fromHistory, 'progress')).toHaveLength(1);
    const aliasesOnly = await snapshotToRecords(snapshot({ sources: [], sourceAliases: [source()], history: [], favorites: [] }));
    expect(rows(aliasesOnly, 'sources')).toHaveLength(0);
    expect(rows(aliasesOnly, 'progress')[0].key).toBe(JSON.stringify([URL_A, 'film', 2]));
  });

  it('当前sources优先于旧aliases；历史明确揭示key复用时进度必须跳过', async () => {
    const preferred = await snapshotToRecords(snapshot({ sources: [source('custom_0', URL_B)],
      sourceAliases: [source()], history: [], favorites: [] }));
    expect(rows(preferred, 'progress')[0].payload.sourceUrl).toBe(URL_B);
    const ambiguous = await snapshotToRecords(snapshot({ sources: [source('custom_0', URL_B)], sourceAliases: [source()], favorites: [] }));
    expect(rows(ambiguous, 'history')[0].payload.sourceUrl).toBe(URL_A);
    expect(rows(ambiguous, 'progress')).toHaveLength(0);
    const ambiguousAliases = await snapshotToRecords(snapshot({ sources: [], sourceAliases: [source(), source('custom_0', URL_B)],
      history: [], favorites: [] }));
    expect(rows(ambiguousAliases, 'progress')).toHaveLength(0);
  });

  it('未知/非法旧进度仅跳过云同步，原始数组不变且大量合法逐集记录不被截断', async () => {
    const progress = Array.from({ length: 300 }, (_, index) => ({
      key: `custom_0_film_${index}`, position: index + 1, duration: 1800, updatedAt: index + 1000,
    }));
    progress.push({ key: 'unknown_film_1', position: 1, duration: 1800, updatedAt: 1 });
    progress.push({ key: 'custom_0_film_invalid', position: 1, duration: 1800, updatedAt: 1 });
    const input = snapshot({ progress });
    const original = JSON.stringify(input);
    const data = await snapshotToRecords(input);
    expect(rows(data, 'progress')).toHaveLength(300);
    expect(JSON.stringify(input)).toBe(original);
  });

  it('没有URL的内置来源只用稳定builtin标识，不能按相同标题合并', async () => {
    const builtin = await snapshotToRecords(snapshot({ sources: [], progress: [], favorites: [], history: [
      { ...history('builtin_a'), sourceUrl: undefined }, { ...history('builtin_b'), sourceUrl: undefined },
    ] }));
    expect(rows(builtin, 'history').map((row) => row.key)).toEqual([
      JSON.stringify(['builtin:builtin_a', 'film']), JSON.stringify(['builtin:builtin_b', 'film']),
    ]);
  });
});

describe('RPC同步响应必须整包验证', () => {
  it('完整数据与删除标记通过，验证后的payload不会引用原响应对象', async () => {
    const data = await snapshotToRecords(snapshot());
    const original = response([...data.values()].map((row) => wire(row)));
    const result = validateSyncResponse(original);
    result.records[0].payload!.selected = false;
    expect(original.records[0].payload!.selected).toBe(true);
    const deleted = { kind: 'history' as const, key: JSON.stringify([URL_A, 'film']), payload: null,
      revision: 2, deleted: true, updatedAt: null };
    expect(validateSyncResponse(response([deleted], { revision: 2 })).records[0]).toEqual(deleted);
    expect(recordId('history', 'a_b')).not.toBe(recordId('progress', 'a_b'));
  });

  it('仅一条坏行也拒绝整个响应，错误不能被过滤后部分写入', async () => {
    const data = await snapshotToRecords(snapshot());
    const valid = [...data.values()].map((row) => wire(row));
    expect(() => validateSyncResponse(response([...valid, { ...valid[0], kind: 'arbitrary' } as unknown as SyncRecord]))).toThrow('无效记录');
    expect(() => validateSyncResponse(response([{ ...valid[0], revision: 2 }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...valid[0], deleted: true }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...valid[0], updatedAt: -1 }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...valid[0], kind: 'history', key: 'invalid', deleted: true, payload: null }]))).toThrow();
    expect(() => validateSyncResponse(response([valid[0], valid[0]]))).toThrow('重复');
  });

  it('错误来源映射、标题字段、进度以及超64KiB payload都拒绝', async () => {
    const data = await snapshotToRecords(snapshot());
    const h = wire(rows(data, 'history')[0]);
    const p = wire(rows(data, 'progress')[0]);
    expect(() => validateSyncResponse(response([{ ...h, payload: { ...h.payload, sourceKey: 'custom_0' } }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...h, payload: { ...h.payload, sourceUrl: URL_B } }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...h, payload: { ...h.payload, title: 123 } }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...p, payload: { ...p.payload, position: Infinity } }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...p, payload: { ...p.payload, episodeIndex: 3 } }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...h, payload: { ...h.payload, extra: '中'.repeat(23_000) } }]))).toThrow();
  });

  it('非JSON/原型修改payload与矛盾accepted状态都拒绝', async () => {
    const h = wire(rows(await snapshotToRecords(snapshot()), 'history')[0]);
    expect(() => validateSyncResponse(response([{ ...h, payload: { ...h.payload, extra: undefined } }]))).toThrow();
    const pollution = JSON.parse('{"__proto__":{"polluted":true}}');
    expect(() => validateSyncResponse(response([{ ...h, payload: { ...h.payload, ...pollution } }]))).toThrow();
    expect(() => validateSyncResponse(response([], { conflicts: [h] }))).toThrow('冲突状态');
    expect(() => validateSyncResponse({ revision: '1', accepted: true, records: [], conflicts: [] })).toThrow();
    expect(() => validateSyncResponse(response([], { revision: Number.MAX_SAFE_INTEGER + 1 }))).toThrow();
    expect(validateSyncResponse(response([], { accepted: false, conflicts: [h] })).conflicts).toHaveLength(1);
  });
});

describe('直播源、频道收藏和最近观看同步身份', () => {
  const playlist = 'https://live-fixture.invalid/channels.m3u?token=fixture';
  const channel = 'https://stream-fixture.invalid/channel.m3u8';
  const epg = 'https://live-fixture.invalid/guide.xml';

  it('按真实URL同步直播源启用状态、名称和EPG，排除设备抓取与统一订阅归属', async () => {
    const input = snapshot({ liveSubscriptions: [{ url: playlist, name: '家庭直播', epg,
      lastSync: 123, fromSubscriptions: ['https://local-fixture.invalid/sources.json'] }],
    liveSelectedUrls: [playlist] });
    const original = JSON.stringify(input);
    const data = await snapshotToRecords(input);
    expect(rows(data, 'liveSources')).toEqual([{ kind: 'liveSources', key: playlist,
      payload: { source: { url: playlist, name: '家庭直播', epg }, selected: true } }]);
    expect(JSON.stringify(input)).toBe(original);
    const disabled = await snapshotToRecords({ ...input, liveSelectedUrls: [] });
    expect(rows(disabled, 'liveSources')[0].payload.selected).toBe(false);
    const environment = await snapshotToRecords(snapshot({ liveEnvSources: [{ key: 'live_env', url: playlist, name: '环境直播', epg }],
      liveSelectedUrls: [playlist] }));
    expect(rows(environment, 'liveSources')).toHaveLength(1);
    expect(rows(environment, 'liveSources')[0].payload.source).not.toHaveProperty('key');
  });

  it('频道同URL的收藏与最近观看独立成行，别名去重按最近的观看时间取整条元数据', async () => {
    const data = await snapshotToRecords(snapshot({ liveFavorites: [channel, channel + '#fragment'], liveRecent: [
      { url: channel, name: '旧台名', timestamp: 100 },
      { url: channel + '#fragment', name: '新台名', timestamp: 200, logo: '/logo.webp', group: '央视', tvgId: 'fixture-tv', epg, sourceUrl: playlist },
    ] }));
    expect(rows(data, 'liveFavorites')).toHaveLength(1);
    expect(rows(data, 'liveRecent')).toEqual([{ kind: 'liveRecent', key: channel, payload: {
      url: channel + '#fragment', name: '新台名', timestamp: 200, logo: '/logo.webp', group: '央视', tvgId: 'fixture-tv', epg, sourceUrl: playlist,
    } }]);
    const responseRows = [...data.values()].map((row) => wire(row));
    expect(validateSyncResponse(response(responseRows)).records).toHaveLength(responseRows.length);
    expect(recordId('liveFavorites', channel)).not.toBe(recordId('liveRecent', channel));
  });

  it('直播每类支持持久删除标记，不能将频道与片源伪造成不同身份或危险协议', async () => {
    for (const kind of ['liveSources', 'liveFavorites', 'liveRecent'] as const) {
      expect(validateSyncResponse(response([{ kind, key: channel, payload: null, revision: 1, deleted: true, updatedAt: null }])).records[0].deleted).toBe(true);
      expect(() => validateSyncResponse(response([{ kind, key: 'javascript:alert(1)', payload: null, revision: 1, deleted: true, updatedAt: null }]))).toThrow();
    }
    const data = await snapshotToRecords(snapshot({ liveSubscriptions: [{ url: playlist, fromSubscriptions: [] }],
      liveFavorites: [channel], liveRecent: [{ url: channel, name: '频道', timestamp: 1 }] }));
    const sourceRow = wire(rows(data, 'liveSources')[0]);
    const favoriteRow = wire(rows(data, 'liveFavorites')[0]);
    const recentRow = wire(rows(data, 'liveRecent')[0]);
    expect(() => validateSyncResponse(response([{ ...sourceRow, payload: { ...sourceRow.payload, selected: 'yes' } }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...sourceRow, payload: { source: { url: playlist, fromSubscriptions: [] }, selected: true } }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...favoriteRow, payload: { url: 'https://other-fixture.invalid/channel.m3u8' } }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...recentRow, payload: { ...recentRow.payload, timestamp: -1 } }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...recentRow, payload: { ...recentRow.payload, epg: 'file:///private.xml' } }]))).toThrow();
    expect(() => validateSyncResponse(response([{ ...recentRow, payload: { ...recentRow.payload, sourceUrl: 'https://user:secret@fixture.invalid/' } }]))).toThrow();
  });
});
