import type { SearchResultItem, SourceConfig, VideoInfo } from './types';

/** Reuse the detail-page favorite identity; an episode URL is never a CMS film ID. */
export function watchFavoriteItem(
  source: SourceConfig | undefined,
  vodId: string,
  title: string,
  info?: VideoInfo,
): SearchResultItem | null {
  if (!source?.key || !vodId) return null;
  return {
    sourceKey: source.key,
    sourceName: source.name,
    vodId,
    name: title || info?.title || '未知视频',
    ...(source.url ? { sourceUrl: source.url } : {}),
    ...(source.isAdult !== undefined ? { isAdult: source.isAdult } : {}),
    ...(info?.cover ? { pic: info.cover } : {}),
    ...(info?.typeName ? { typeName: info.typeName } : {}),
    ...(info?.year ? { year: info.year } : {}),
    ...(info?.area ? { area: info.area } : {}),
    ...(info?.remarks ? { remarks: info.remarks } : {}),
  };
}
