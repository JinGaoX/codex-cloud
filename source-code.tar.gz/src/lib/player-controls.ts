import type Artplayer from 'artplayer';
import { DESKTOP_CONTROL_HIDE_MS, FULLSCREEN_TOUCH_CONTROL_HIDE_MS } from './control-hide';

export interface ControlPlaybackState {
  playing: boolean;
  fullscreen: boolean;
  seeking: boolean;
  settings: boolean;
}

/** 每个播放器单独持有计时器，不依赖 Artplayer 的 UA 或全局隐藏时间。 */
export class ControlVisibilityController {
  private timer: ReturnType<typeof setTimeout> | undefined;
  private holds = new Set<string>();
  private disposed = false;
  private touch: boolean;
  private visible: boolean;

  constructor(private options: {
    touch: boolean;
    visible: boolean;
    readState: () => ControlPlaybackState;
    show: (visible: boolean) => void;
  }) {
    this.touch = options.touch;
    this.visible = options.visible;
  }

  private blocked() {
    const state = this.options.readState();
    return !state.playing || state.seeking || state.settings || this.holds.size > 0;
  }

  private setVisible(visible: boolean) {
    this.visible = visible;
    this.options.show(visible);
  }

  private schedule() {
    clearTimeout(this.timer);
    this.timer = undefined;
    if (this.disposed || !this.visible || this.blocked()) return;
    if (this.touch && !this.options.readState().fullscreen) return;
    this.timer = setTimeout(() => {
      this.timer = undefined;
      if (!this.disposed && !this.blocked()) this.setVisible(false);
    }, this.touch ? FULLSCREEN_TOUCH_CONTROL_HIDE_MS : DESKTOP_CONTROL_HIDE_MS);
  }

  activity(touch = this.touch) {
    if (this.disposed) return;
    this.touch = touch;
    this.setVisible(true);
    this.schedule();
  }

  input(touch: boolean) {
    if (this.disposed) return;
    this.touch = touch;
    this.schedule();
  }

  /** 暂停、切全屏、打开设置等状态变化；保护操作结束后重新计完整空闲时间。 */
  refresh() {
    if (this.disposed) return;
    if (this.blocked()) this.setVisible(true);
    this.schedule();
  }

  hold(reason: string, active: boolean, reveal = true) {
    if (this.disposed) return;
    if (active) this.holds.add(reason);
    else this.holds.delete(reason);
    // 视频表面 touchstart 只停计时，不先显示：否则 iOS 合成 click 会立即翻回隐藏。
    if (active && reveal) this.setVisible(true);
    this.schedule();
  }

  tap(dismissedMenu = false) {
    if (this.disposed) return;
    this.touch = true;
    // 关闭设置的这一次点按只收起菜单，不顺带把刚露出的播放控制栏也收掉。
    this.setVisible(dismissedMenu || this.blocked() || !this.visible);
    this.schedule();
  }

  mouseLeave() {
    if (!this.disposed && !this.touch && !this.blocked()) {
      clearTimeout(this.timer);
      this.timer = undefined;
      this.setVisible(false);
    }
  }

  /** 库的 UA click / timeupdate 不能覆盖本实例的交互保护与隐藏状态。 */
  reconcile(visible: boolean) {
    if (!this.disposed && visible !== this.visible) this.options.show(this.visible);
  }

  dispose() {
    this.disposed = true;
    clearTimeout(this.timer);
    this.holds.clear();
  }
}

const INTERACTIVE = '.art-controls, .art-progress, .art-settings, .art-contextmenus, .art-state, .art-layer, button, a, input, select, textarea, [role="button"], [role="slider"]';
const TOUCH_CLICK_WINDOW_MS = 900;
const TAP_MAX_MOVEMENT_PX = 12;
export const SURFACE_LONG_PRESS_MS = 500;

/** 只用于辨别手势，播放倍速仍由 PlayerShell 原有长按逻辑负责。 */
export function isSurfaceTap(start: { x: number; y: number; time: number }, end: { x: number; y: number; time: number }) {
  return end.time - start.time < SURFACE_LONG_PRESS_MS
    && Math.hypot(end.x - start.x, end.y - start.y) <= TAP_MAX_MOVEMENT_PX;
}

/** DOM 适配层只处理控件可见性，不读写 currentTime、播放地址或媒体管线。 */
export function attachPlayerControlVisibility(art: Artplayer, element: HTMLElement, prefersTouch: boolean) {
  const doc = element.ownerDocument;
  const cleanups: Array<() => void> = [];
  let touchInput = prefersTouch;
  let lastTouchAt = -Infinity;
  let keyboard = false;
  let touchStart: { x: number; y: number; time: number } | undefined;
  let touchMoved = false;
  let touchWasSurface = false;
  let suppressSurfaceClickUntil = -Infinity;
  const controller = new ControlVisibilityController({
    touch: prefersTouch,
    visible: art.controls.show,
    readState: () => ({
      playing: art.playing,
      fullscreen: art.fullscreen || art.fullscreenWeb,
      seeking: art.video.seeking,
      settings: art.setting.show || art.contextmenu.show,
    }),
    show: (visible) => { art.controls.show = visible; },
  });
  const interactive = (target: EventTarget | null) => target instanceof Element && !!target.closest(INTERACTIVE);
  const listen = <K extends keyof HTMLElementEventMap>(target: HTMLElement | Document, name: K,
    listener: (event: HTMLElementEventMap[K]) => void, options?: AddEventListenerOptions | boolean) => {
    target.addEventListener(name, listener as EventListener, options);
    cleanups.push(() => target.removeEventListener(name, listener as EventListener, options));
  };
  const refresh = () => controller.refresh();
  const activity = () => controller.activity(touchInput);
  const reconcile = (visible: boolean) => controller.reconcile(visible);
  const mediaEvents = ['video:play', 'video:playing', 'video:pause', 'video:ended', 'video:seeking', 'video:seeked'] as const;
  for (const name of mediaEvents) art.on(name, refresh);
  art.on('fullscreen', activity);
  art.on('fullscreenWeb', activity);
  art.on('setting', refresh);
  art.on('contextmenu', refresh);
  art.on('control', reconcile);
  cleanups.push(() => {
    for (const name of mediaEvents) art.off(name, refresh);
    art.off('fullscreen', activity);
    art.off('fullscreenWeb', activity);
    art.off('setting', refresh);
    art.off('contextmenu', refresh);
    art.off('control', reconcile);
  });

  listen(element, 'pointerdown', (event) => {
    keyboard = false;
    controller.hold('keyboard-focus', false);
    if (event.pointerType === 'touch' || event.pointerType === 'pen') {
      touchInput = true;
      lastTouchAt = Date.now();
    } else if (Date.now() - lastTouchAt > TOUCH_CLICK_WINDOW_MS) touchInput = false;
    controller.input(touchInput);
    if (interactive(event.target)) {
      controller.activity(touchInput);
      controller.hold('pointer', true);
    }
  }, true);
  // mousemove 合成事件不能抢在触屏 click 之前显示控件（旧 iPhone 闪隐问题）。
  listen(element, 'mousemove', (event) => {
    const synthetic = (event as MouseEvent & { sourceCapabilities?: { firesTouchEvents?: boolean } }).sourceCapabilities?.firesTouchEvents;
    if (touchInput || synthetic || Date.now() - lastTouchAt < TOUCH_CLICK_WINDOW_MS) return;
    controller.activity(false);
  });
  listen(element, 'pointermove', (event) => {
    if (event.pointerType !== 'mouse' || Date.now() - lastTouchAt < TOUCH_CLICK_WINDOW_MS) return;
    touchInput = false;
    controller.activity(false);
  });
  listen(element, 'mouseleave', () => controller.mouseLeave());
  // 老 WebView 仍有 touch/mouse 事件；拖动进度条期间即使尚未进入 seeking 也不能隐藏。
  listen(element, 'mousedown', (event) => {
    if (Date.now() - lastTouchAt > TOUCH_CLICK_WINDOW_MS && interactive(event.target)) controller.hold('pointer', true);
  }, true);
  const releasePointer = () => controller.hold('pointer', false);
  listen(doc, 'pointerup', releasePointer);
  listen(doc, 'pointercancel', releasePointer);
  listen(doc, 'mouseup', releasePointer);
  listen(element, 'touchstart', (event) => {
    touchInput = true;
    lastTouchAt = Date.now();
    suppressSurfaceClickUntil = -Infinity;
    controller.input(true);
    keyboard = false;
    controller.hold('keyboard-focus', false);
    const touch = event.touches[0];
    touchWasSurface = !interactive(event.target);
    touchMoved = event.touches.length !== 1;
    touchStart = touch ? { x: touch.clientX, y: touch.clientY, time: Date.now() } : undefined;
    controller.hold('touch', true, !touchWasSurface);
    if (!touchWasSurface) controller.activity(true);
  }, { passive: true, capture: true });
  listen(element, 'touchmove', (event) => {
    const touch = event.touches[0];
    if (touchStart && touch && Math.hypot(touch.clientX - touchStart.x, touch.clientY - touchStart.y) > TAP_MAX_MOVEMENT_PX) touchMoved = true;
  }, { passive: true, capture: true });
  const finishTouch = (event: TouchEvent) => {
    if (!touchStart) return;
    const touch = event.changedTouches[0];
    if (touchWasSurface && (event.type === 'touchcancel' || touchMoved || !touch || !isSurfaceTap(touchStart,
      { x: touch.clientX, y: touch.clientY, time: Date.now() }))) {
      suppressSurfaceClickUntil = Date.now() + TOUCH_CLICK_WINDOW_MS;
    }
    lastTouchAt = Date.now();
    touchStart = undefined;
    controller.hold('touch', false);
    releasePointer();
  };
  listen(doc, 'touchend', finishTouch, true);
  listen(doc, 'touchcancel', finishTouch, true);
  listen(element, 'click', (event) => {
    if (interactive(event.target)) return;
    const syntheticTouch = (event as MouseEvent & { sourceCapabilities?: { firesTouchEvents?: boolean } }).sourceCapabilities?.firesTouchEvents;
    if (!touchInput && !syntheticTouch && Date.now() - lastTouchAt > TOUCH_CLICK_WINDOW_MS) return;
    // 拦在 Artplayer 的 video click 之前：桌面 UA + 触屏不能误触暂停，移动 UA 不能二次 toggle。
    event.preventDefault();
    event.stopImmediatePropagation();
    if (Date.now() <= suppressSurfaceClickUntil) return;
    const dismissedMenu = art.setting.show || art.contextmenu.show;
    // capture 拦住了原生冒泡，但库仍需要 document:click → focus 来收起设置、
    // 维护焦点。只补发此通知，不触发按 UA 分流的 video click（会误暂停）。
    art.emit('document:click', event);
    if (art.contextmenu.show) art.contextmenu.show = false;
    controller.tap(dismissedMenu);
  }, true);
  listen(doc, 'keydown', (event) => {
    keyboard = true;
    if (event.key === 'Tab' && element.contains(doc.activeElement)) controller.hold('keyboard-focus', true);
    else if (element.contains(doc.activeElement)) activity();
  }, true);
  listen(element, 'focusin', () => {
    if (keyboard) controller.hold('keyboard-focus', true);
  });
  listen(element, 'focusout', (event) => {
    if (!element.contains(event.relatedTarget as Node | null)) controller.hold('keyboard-focus', false);
  });
  // 初始暂停也保持可见；自动播放成功后由媒体事件启动独立计时。
  controller.refresh();
  return () => {
    controller.dispose();
    for (const cleanup of cleanups) cleanup();
  };
}
