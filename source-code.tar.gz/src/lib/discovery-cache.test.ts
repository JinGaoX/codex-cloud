import { describe, expect, it } from 'vitest';
import { DISCOVERY_CACHE_KEY, DISCOVERY_CACHE_MAX_AGE_MS, DISCOVERY_CACHE_MAX_BYTES, DISCOVERY_CACHE_MAX_ENTRIES, readDiscoveryCache, writeDiscoveryCache, type DiscoveryCacheStorage } from './discovery-cache';
import { DOUBAN_BROWSE_TAGS, type DiscoveryResponse } from './discovery';

const now = 1_800_000_000_000;
function storage() {
  const values = new Map<string, string>([['libretv-settings', 'private-settings-fixture'], ['history-fixture', 'keep-history']]);
  return { values, getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => { values.set(key, value); } };
}
function response(time = now): DiscoveryResponse {
  return { retrievedAt: time, items: [{ id: 'douban:movie:1', title: '缓存影片', cover: 'https://img9.doubanio.com/test.jpg', genres: ['剧情'], rating: '8.5', rank: 3 }] };
}

describe('bounded public discovery success cache', () => {
  it('retains the successful timestamp and isolates private settings and returned objects', () => {
    const local = storage();
    const entry = response(now - 13 * 60_000);
    expect(writeDiscoveryCache('list:douban_movie_weekly', entry, local, now)).toBe(true);
    const loaded = readDiscoveryCache('list:douban_movie_weekly', local, now)!;
    expect(loaded).toEqual({ ...entry, items: [{ ...entry.items[0], isTv: false }] });
    loaded.items[0].title = '调用方修改'; loaded.items[0].genres.push('改动');
    expect(readDiscoveryCache('list:douban_movie_weekly', local, now)?.items[0].title).toBe('缓存影片');
    expect(local.values.get('libretv-settings')).toBe('private-settings-fixture');
    expect(local.values.get('history-fixture')).toBe('keep-history');
  });

  it('does not replace success with an empty/failed response or archive unknown fields', () => {
    const local = storage();
    const entry = response();
    Object.assign(entry.items[0], { privateSource: 'do-not-persist-this-fixture' });
    expect(writeDiscoveryCache('list:douban_movie_weekly', entry, local, now)).toBe(true);
    expect(writeDiscoveryCache('list:douban_movie_weekly', { retrievedAt: now, items: [] }, local, now)).toBe(false);
    expect(local.values.get(DISCOVERY_CACHE_KEY)).not.toContain('do-not-persist-this-fixture');
    expect(readDiscoveryCache('list:douban_movie_weekly', local, now)?.retrievedAt).toBe(now);
    expect(writeDiscoveryCache('private:source', response(), local, now)).toBe(false);
  });

  it('bounds records and evicts oldest public data without changing other storage', () => {
    const local = storage();
    DOUBAN_BROWSE_TAGS.movie.forEach((tag, index) => {
      expect(writeDiscoveryCache(`douban:movie:${tag}`, response(now - 1000 + index), local, now)).toBe(true);
    });
    const saved = JSON.parse(local.values.get(DISCOVERY_CACHE_KEY)!);
    expect(Object.keys(saved.entries)).toHaveLength(DISCOVERY_CACHE_MAX_ENTRIES);
    expect(readDiscoveryCache('douban:movie:热门', local, now)).toBeUndefined();
    expect(readDiscoveryCache('douban:movie:纪录片', local, now)).toBeDefined();
    expect(local.values.get('libretv-settings')).toBe('private-settings-fixture');
  });

  it('enforces a total byte budget even for long public image URLs', () => {
    const local = storage();
    const large: DiscoveryResponse = { retrievedAt: now - 1, items: Array.from({ length: 50 }, (_, id) => ({
      id: `douban:movie:${id}`, title: '长图片地址', cover: `https://images.example/${'x'.repeat(3000)}-${id}.jpg`, genres: [],
    })) };
    expect(writeDiscoveryCache('douban:movie:热门', large, local, now)).toBe(true);
    expect(writeDiscoveryCache('douban:movie:科幻', { ...large, retrievedAt: now }, local, now)).toBe(true);
    expect(new TextEncoder().encode(local.values.get(DISCOVERY_CACHE_KEY)!).byteLength).toBeLessThanOrEqual(DISCOVERY_CACHE_MAX_BYTES);
    expect(readDiscoveryCache('douban:movie:热门', local, now)).toBeUndefined();
    expect(readDiscoveryCache('douban:movie:科幻', local, now)).toBeDefined();
  });

  it('ignores damaged, expired, future and unsafe data without clearing user storage', () => {
    const local = storage();
    local.values.set(DISCOVERY_CACHE_KEY, '{broken');
    expect(readDiscoveryCache('list:douban_movie_weekly', local, now)).toBeUndefined();
    expect(writeDiscoveryCache('list:douban_movie_weekly', response(now - DISCOVERY_CACHE_MAX_AGE_MS - 1), local, now)).toBe(false);
    expect(writeDiscoveryCache('list:douban_movie_weekly', response(now + 120_000), local, now)).toBe(false);
    const unsafe = response(); unsafe.items[0].cover = 'javascript:alert(1)';
    expect(writeDiscoveryCache('list:douban_movie_weekly', unsafe, local, now)).toBe(false);
    expect(local.values.get('libretv-settings')).toBe('private-settings-fixture');
  });

  it('degrades to query memory if local storage is blocked or full', () => {
    const blocked: DiscoveryCacheStorage = { getItem: () => { throw new Error('blocked'); }, setItem: () => { throw new Error('full'); } };
    expect(() => readDiscoveryCache('list:douban_movie_weekly', blocked, now)).not.toThrow();
    expect(writeDiscoveryCache('list:douban_movie_weekly', response(), blocked, now)).toBe(false);
  });

  it('preserves only the first-page pagination cursor, without persisting arbitrary next URLs', () => {
    const local = storage();
    const entry = { ...response(), nextPageStart: 50 };
    expect(writeDiscoveryCache('douban:movie:热门', entry, local, now)).toBe(true);
    expect(readDiscoveryCache('douban:movie:热门', local, now)?.nextPageStart).toBe(50);
    Object.assign(entry, { nextPageStart: 450, nextPageUrl: 'https://private.example/secret' });
    expect(writeDiscoveryCache('douban:movie:热门', entry, local, now)).toBe(true);
    expect(readDiscoveryCache('douban:movie:热门', local, now)?.nextPageStart).toBeUndefined();
    expect(local.values.get(DISCOVERY_CACHE_KEY)).not.toContain('private.example');
  });
});
