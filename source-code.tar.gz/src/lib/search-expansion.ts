import { isRelevant, normalizeTitle } from './cms-parser';
import type { SearchResultItem } from './types';

/** Related searches are opt-in for manual discovery, never automatic source switching. */
export interface SearchExpansionCandidate {
  kind: 'alternative' | 'series';
  query: string;
}

export interface SearchExpansionPlan {
  originalQuery: string;
  candidates: SearchExpansionCandidate[];
  seriesQuery?: string;
}

export const MAX_SEARCH_EXPANSIONS = 2;

function validSeriesBase(value: string, explicit: boolean): string | undefined {
  const base = value.trim().replace(/[\s:：·\-]+$/u, '');
  const normalized = normalizeTitle(base);
  if (!normalized) return undefined;
  // An explicit season marker provides the boundary even when the real title
  // itself ends in digits ("电影2025第二季"). Keep those digits intact.
  if (explicit) return /\p{L}/u.test(normalized) || normalized.length >= 2 ? base : undefined;
  // Never split a year or numeric title into its final one/two digits.
  if (/\d$/u.test(normalized) || !/\p{L}/u.test(normalized)) return undefined;
  // Unmarked suffixes are ambiguous. Require a meaningful CJK title or an
  // explicitly separated Latin title; do not turn F1/A24 into a series query.
  if ((normalized.match(/[\u3400-\u9fff]/gu)?.length ?? 0) >= 2) return base;
  return normalized.length >= 3 ? base : undefined;
}

function seriesBase(query: string): string | undefined {
  const explicit = query.match(/^(.*?)\s*第\s*([1-9]\d?|[一二两三四五六七八九十]{1,3})\s*[季部]$/u);
  if (explicit) {
    // Validate Chinese numerals rather than accepting arbitrary combinations.
    const number = explicit[2].replace('两', '二');
    if (!/^(?:[1-9]\d?|[一二三四五六七八九]|[一二三四五六七八九]?十[一二三四五六七八九]?)$/u.test(number)) return undefined;
    return validSeriesBase(explicit[1], true);
  }
  const english = query.match(/^(.*?)\s+(?:season\s*|s)([1-9]\d?)$/iu);
  if (english) return validSeriesBase(english[1], true);
  const numbered = query.match(/^(.*?)([1-9]\d?)$/u);
  if (!numbered) return undefined;
  const base = validSeriesBase(numbered[1], false);
  if (!base) return undefined;
  // Attached Latin digits commonly belong to the title itself (Apollo13).
  if (!/[\u3400-\u9fff]/u.test(base) && !/\s$/u.test(numbered[1])) return undefined;
  return base;
}

function connectorAlternative(query: string): string | undefined {
  const connectors = query.match(/[与和]/gu);
  if (connectors?.length !== 1) return undefined;
  const index = query.search(/[与和]/u);
  // A connector at an edge has no two title parts; avoid very broad one-word queries.
  if (!normalizeTitle(query.slice(0, index)) || !normalizeTitle(query.slice(index + 1))) return undefined;
  return query.slice(0, index) + (query[index] === '与' ? '和' : '与') + query.slice(index + 1);
}

/** Produce at most two bounded hypotheses; none is a claim of title equivalence. */
export function getSearchExpansionPlan(query: string, context: 'empty' | 'matched' = 'empty'): SearchExpansionPlan {
  const originalQuery = query.trim().slice(0, 100);
  const candidates: SearchExpansionCandidate[] = [];
  if (!normalizeTitle(originalQuery)) return { originalQuery, candidates };
  // Exact matches establish the real title spelling. A manual series lookup
  // must retain that spelling instead of trying a connector correction.
  const base = seriesBase(originalQuery);
  if (base) {
    // Missing one installment does not imply the original series spelling is
    // wrong. Try both series bases, preserving the original spelling first.
    candidates.push({ kind: 'series', query: base });
    const alternativeBase = context === 'empty' ? connectorAlternative(base) : undefined;
    if (alternativeBase) candidates.push({ kind: 'alternative', query: alternativeBase });
  } else if (context === 'empty') {
    const alternative = connectorAlternative(originalQuery);
    if (alternative) candidates.push({ kind: 'alternative', query: alternative });
  }
  return { originalQuery, candidates: candidates.slice(0, MAX_SEARCH_EXPANSIONS), ...(base ? { seriesQuery: base } : {}) };
}

export function searchResultIdentity(item: Pick<SearchResultItem, 'sourceKey' | 'vodId'>): string {
  return JSON.stringify([item.sourceKey, item.vodId]);
}

/** Preserve real source names/IDs/years, filtering against the actual supplemental query. */
export function filterSearchExpansionResults(
  items: readonly SearchResultItem[],
  candidate: SearchExpansionCandidate,
  excludedItems: readonly SearchResultItem[] = [],
): SearchResultItem[] {
  if (!normalizeTitle(candidate.query)) return [];
  const seen = new Set(excludedItems.map(searchResultIdentity));
  return items.filter((item) => {
    if (!item.sourceKey || !item.vodId || !isRelevant(item.name, candidate.query)) return false;
    const key = searchResultIdentity(item);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}
