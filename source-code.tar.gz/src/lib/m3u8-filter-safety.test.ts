import { describe, expect, it } from 'vitest';
import { stripAdGroups, stripExplicitAdGroups, stripLeadAdGroup } from './m3u8';

function playlist(extraTags = '', includeMiddle = true): string {
  return [
    '#EXTM3U', '#EXT-X-MEDIA-SEQUENCE:100', extraTags,
    '#EXT-X-DISCONTINUITY', '#EXTINF:18,', '/video/ads/intro.ts',
    '#EXT-X-DISCONTINUITY', '#EXTINF:300,', '/movie/body1.ts',
    ...(includeMiddle ? ['#EXT-X-DISCONTINUITY', '#EXTINF:18,', '/video/adjump/middle.ts'] : []),
    '#EXT-X-DISCONTINUITY', '#EXTINF:300,', '/movie/body2.ts', '#EXT-X-ENDLIST',
  ].filter(Boolean).join('\n');
}

describe('通用广告过滤保持加密序号与范围偏移', () => {
  const filters = [
    ['all', stripAdGroups], ['explicit', stripExplicitAdGroups], ['lead', stripLeadAdGroup],
  ] as const;

  it.each(filters)('%s 对缺省IV的AES-128保持原文，包括媒体序号与全部分片', (_name, filter) => {
    const input = playlist('#EXT-X-KEY:METHOD=AES-128,URI="key.bin"');
    expect(filter(input)).toBe(input);
  });

  it.each(filters)('%s 对BYTERANGE保持原文，不改变后继隐式偏移', (_name, filter) => {
    const input = playlist('#EXT-X-BYTERANGE:1024@0').replace('#EXTINF:300,', '#EXTINF:300,\n#EXT-X-BYTERANGE:2048');
    expect(filter(input)).toBe(input);
  });

  it('URI中的IV字样不是显式IV；空或非法IV也保守放过', () => {
    for (const key of [
      '#EXT-X-KEY:METHOD=AES-128,URI="https://keys.example/key?IV=0x1"',
      '#EXT-X-KEY:METHOD=AES-128,URI="https://keys.example/key?x=1,IV=0x1"',
      '#EXT-X-KEY:METHOD=AES-128,URI="key.bin",IV=',
      '#EXT-X-KEY:METHOD=AES-128,URI="key.bin",IV=bad',
    ]) {
      for (const [, filter] of filters) expect(filter(playlist(key))).toBe(playlist(key));
    }
  });

  it.each(filters)('%s 允许显式IV与METHOD=NONE，不把未加密清单一并禁用', (_name, filter) => {
    for (const tag of ['', '#EXT-X-KEY:METHOD=NONE', '#EXT-X-KEY:METHOD=AES-128,URI="key.bin",IV=0x00000000000000000000000000000064']) {
      const input = playlist(tag, false);
      const output = filter(input);
      expect(output).not.toContain('/video/ads/intro.ts');
      expect(output).toContain('/movie/body1.ts');
      expect(output).toContain('/movie/body2.ts');
      expect(output).toContain('#EXT-X-MEDIA-SEQUENCE:100');
      if (tag) expect(output).toContain(tag);
    }
  });

  it('后半段才切到缺省IV的密钥也不能因删除前段广告而改变序号', () => {
    const input = playlist().replace('/movie/body2.ts', '#EXT-X-KEY:METHOD=AES-128,URI="later.key"\n/movie/body2.ts');
    for (const [, filter] of filters) expect(filter(input)).toBe(input);
  });
});
