import { inferGroupRemarks } from './remarks';
import type { SearchResultItem } from './types';

export interface AggregatedGroup {
  key: string;
  name: string;
  year?: string;
  typeName?: string;
  pic?: string;
  remarks?: string;
  items: SearchResultItem[];
}

export const searchResultItemKey = (item: SearchResultItem) => JSON.stringify([item.sourceKey, item.vodId]);

function groupIdentity(name: string, year?: string): string {
  return JSON.stringify([name, year ?? null]);
}

function buildGroup(name: string, year: string | undefined, items: SearchResultItem[]): AggregatedGroup {
  return {
    key: groupIdentity(name, year),
    name,
    year,
    typeName: items.find((item) => item.typeName)?.typeName,
    pic: items.find((item) => item.pic)?.pic,
    remarks: inferGroupRemarks(items.map((item) => item.remarks)),
    items,
  };
}

export function aggregateResults(list: SearchResultItem[]): AggregatedGroup[] {
  const byName = new Map<string, SearchResultItem[]>();
  for (const item of list) {
    const name = item.name?.trim();
    if (!name) continue;
    const bucket = byName.get(name);
    if (bucket) bucket.push(item);
    else byName.set(name, [item]);
  }
  const groups: AggregatedGroup[] = [];
  for (const [name, items] of byName) {
    const years = [...new Set(items.flatMap((item) => item.year ? [item.year] : []))];
    if (years.length <= 1) {
      groups.push(buildGroup(name, years[0], items));
      continue;
    }
    for (const year of years) groups.push(buildGroup(name, year, items.filter((item) => item.year === year)));
    const withoutYear = items.filter((item) => !item.year);
    if (withoutYear.length) groups.push(buildGroup(name, undefined, withoutYear));
  }
  return groups;
}

/** Preserve mounted cards and the order of their source rows within one search. */
export function reconcileSearchGroups(previous: AggregatedGroup[], current: AggregatedGroup[]): AggregatedGroup[] {
  const byIdentity = new Map(previous.map((group) => [groupIdentity(group.name, group.year), group]));
  const previousByName = new Map<string, AggregatedGroup[]>();
  for (const group of previous) {
    const sameName = previousByName.get(group.name) ?? [];
    sameName.push(group);
    previousByName.set(group.name, sameName);
  }
  const currentNameCounts = new Map<string, number>();
  for (const group of current) currentNameCounts.set(group.name, (currentNameCounts.get(group.name) ?? 0) + 1);

  const matches = current.map((group) => {
    const exact = byIdentity.get(groupIdentity(group.name, group.year));
    if (exact) return exact;
    const sameName = previousByName.get(group.name);
    // An unambiguous missing-year group can acquire a year without remounting.
    // Do not transfer state between two remakes or guess when a title splits.
    if (sameName?.length !== 1 || currentNameCounts.get(group.name) !== 1) return undefined;
    const candidate = sameName[0];
    if (candidate.year && group.year) return undefined;
    const memberKeys = new Set(group.items.map(searchResultItemKey));
    return candidate.items.some((item) => memberKeys.has(searchResultItemKey(item))) ? candidate : undefined;
  });
  const keys = new Set(matches.flatMap((match) => match ? [match.key] : []));
  const priorOrder = new Map(previous.map((group, index) => [group.key, index]));
  return current.map((group, index) => {
    const match = matches[index];
    if (!match) {
      let key = group.key;
      while (keys.has(key)) key += '+';
      keys.add(key);
      return key === group.key ? group : { ...group, key };
    }
    const remaining = new Map(group.items.map((item) => [searchResultItemKey(item), item]));
    const items: SearchResultItem[] = [];
    for (const previousItem of match.items) {
      const key = searchResultItemKey(previousItem);
      const item = remaining.get(key);
      if (item) items.push(item);
      remaining.delete(key);
    }
    items.push(...remaining.values());
    return { ...group, key: match.key, items };
  }).sort((a, b) => (priorOrder.get(a.key) ?? previous.length) - (priorOrder.get(b.key) ?? previous.length));
}
