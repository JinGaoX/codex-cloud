import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { ControlVisibilityController, isSurfaceTap, type ControlPlaybackState } from './player-controls';

beforeEach(() => vi.useFakeTimers());
afterEach(() => vi.useRealTimers());

function setup(touch = true, overrides: Partial<ControlPlaybackState> = {}) {
  const state: ControlPlaybackState = { playing: true, fullscreen: true, settings: false, seeking: false, ...overrides };
  const changes: boolean[] = [];
  let visible = true;
  const controller = new ControlVisibilityController({
    touch,
    visible,
    readState: () => state,
    show: (next) => { visible = next; changes.push(next); },
  });
  return { controller, state, changes, visible: () => visible };
}

describe('播放器实例级控件空闲策略', () => {
  it('触屏全屏播放满 3 秒隐藏，媒体没有 timeupdate 也能收起', () => {
    const x = setup();
    x.controller.refresh();
    vi.advanceTimersByTime(2999);
    expect(x.visible()).toBe(true);
    vi.advanceTimersByTime(1);
    expect(x.visible()).toBe(false);
  });

  it('轻点唤出，再轻点收起；重新唤出后获得完整操作时间', () => {
    const x = setup();
    x.controller.activity();
    vi.advanceTimersByTime(3000);
    x.controller.tap();
    expect(x.visible()).toBe(true);
    vi.advanceTimersByTime(500);
    x.controller.tap();
    expect(x.visible()).toBe(false);
    x.controller.tap();
    vi.advanceTimersByTime(2999);
    expect(x.visible()).toBe(true);
    vi.advanceTimersByTime(1);
    expect(x.visible()).toBe(false);
  });

  it('非全屏触屏仍手动收放，不引入新的空闲隐藏', () => {
    const x = setup(true, { fullscreen: false });
    x.controller.activity();
    vi.advanceTimersByTime(60000);
    expect(x.visible()).toBe(true);
    x.controller.tap();
    expect(x.visible()).toBe(false);
    x.controller.tap();
    expect(x.visible()).toBe(true);
  });

  it('切换全屏重新计时，退出全屏取消触屏计时', () => {
    const x = setup(true, { fullscreen: false });
    x.controller.activity();
    vi.advanceTimersByTime(2000);
    x.state.fullscreen = true;
    x.controller.activity();
    vi.advanceTimersByTime(2500);
    expect(x.visible()).toBe(true);
    x.state.fullscreen = false;
    x.controller.refresh();
    vi.advanceTimersByTime(10000);
    expect(x.visible()).toBe(true);
  });

  it.each(['playing', 'settings', 'seeking'] as const)('%s 保护状态下保持显示，结束后给完整 3 秒', (field) => {
    const x = setup();
    x.controller.activity();
    vi.advanceTimersByTime(2900);
    x.state[field] = field !== 'playing';
    x.controller.refresh();
    vi.advanceTimersByTime(10000);
    x.controller.tap();
    expect(x.visible()).toBe(true);
    x.state[field] = field === 'playing';
    x.controller.refresh();
    vi.advanceTimersByTime(2999);
    expect(x.visible()).toBe(true);
    vi.advanceTimersByTime(1);
    expect(x.visible()).toBe(false);
  });

  it('已经隐藏时暂停也会唤出，鼠标离开不隐藏暂停画面上的控制栏', () => {
    const x = setup(false);
    x.controller.activity();
    vi.advanceTimersByTime(800);
    expect(x.visible()).toBe(false);
    x.state.playing = false;
    x.controller.refresh();
    x.controller.mouseLeave();
    vi.advanceTimersByTime(10000);
    expect(x.visible()).toBe(true);
  });

  it('点视频空白关闭设置后保持控件，下一次轻点才收起；关闭后也恢复空闲计时', () => {
    const x = setup(true, { settings: true });
    x.controller.refresh();
    vi.advanceTimersByTime(10000);
    x.state.settings = false; // DOM 适配层先按库原流程派发 focus / 收起菜单。
    x.controller.refresh();
    x.controller.tap(true);
    expect(x.visible()).toBe(true);
    x.controller.tap();
    expect(x.visible()).toBe(false);
    x.controller.tap();
    vi.advanceTimersByTime(3000);
    expect(x.visible()).toBe(false);
    expect(x.state.playing).toBe(true);
  });

  it.each(['keyboard-focus', 'pointer'])('%s 操作不会被定时器或鼠标离开打断', (reason) => {
    const x = setup(false);
    x.controller.activity();
    x.controller.hold(reason, true);
    x.controller.mouseLeave();
    vi.advanceTimersByTime(10000);
    expect(x.visible()).toBe(true);
    x.controller.hold(reason, false);
    vi.advanceTimersByTime(799);
    expect(x.visible()).toBe(true);
    vi.advanceTimersByTime(1);
    expect(x.visible()).toBe(false);
  });

  it('多个同时进行的操作全部结束后才开始隐藏计时', () => {
    const x = setup();
    x.controller.hold('pointer', true);
    x.controller.hold('keyboard-focus', true);
    x.controller.hold('pointer', false);
    vi.advanceTimersByTime(10000);
    expect(x.visible()).toBe(true);
    x.controller.hold('keyboard-focus', false);
    vi.advanceTimersByTime(3000);
    expect(x.visible()).toBe(false);
  });

  it('触屏表面 touchstart 不先显示；合成 click 只切换一次，不闪隐', () => {
    const x = setup();
    x.controller.activity();
    vi.advanceTimersByTime(3000);
    expect(x.visible()).toBe(false);
    x.controller.hold('touch', true, false);
    expect(x.visible()).toBe(false);
    x.controller.reconcile(true); // 模拟 Artplayer 的合成 mousemove。
    expect(x.visible()).toBe(false);
    x.controller.hold('touch', false);
    x.controller.tap();
    expect(x.visible()).toBe(true);
    x.controller.reconcile(false); // 库若再次 toggle，实例策略仍只处理一次。
    expect(x.visible()).toBe(true);
  });

  it('触摸按住期间不超时，结束后正常恢复空闲时间', () => {
    const x = setup();
    x.controller.activity();
    x.controller.hold('touch', true, false);
    vi.advanceTimersByTime(10000);
    expect(x.visible()).toBe(true);
    x.controller.hold('touch', false);
    vi.advanceTimersByTime(3000);
    expect(x.visible()).toBe(false);
  });

  it('桌面鼠标仍 800ms 收起，移动重置计时，离开可立刻收起', () => {
    const x = setup(false);
    x.controller.activity();
    vi.advanceTimersByTime(700);
    x.controller.activity();
    vi.advanceTimersByTime(799);
    expect(x.visible()).toBe(true);
    vi.advanceTimersByTime(1);
    expect(x.visible()).toBe(false);
    x.controller.activity();
    x.controller.mouseLeave();
    expect(x.visible()).toBe(false);
  });

  it('混合设备按实际触摸进入 3 秒策略，换回鼠标使用 800ms', () => {
    const x = setup(false);
    x.controller.tap();
    x.controller.tap();
    vi.advanceTimersByTime(800);
    expect(x.visible()).toBe(true);
    vi.advanceTimersByTime(2200);
    expect(x.visible()).toBe(false);
    x.controller.activity(false);
    vi.advanceTimersByTime(800);
    expect(x.visible()).toBe(false);
  });

  it('触屏长按只切换输入策略，不先唤出控件，也不退回鼠标的 800ms', () => {
    const x = setup(false);
    x.controller.input(true);
    x.controller.hold('touch', true, false);
    vi.advanceTimersByTime(1000);
    x.controller.hold('touch', false);
    vi.advanceTimersByTime(800);
    expect(x.visible()).toBe(true);
    vi.advanceTimersByTime(2200);
    expect(x.visible()).toBe(false);
  });

  it('库 timeupdate 的隐藏不能越过非全屏触屏或操作保护', () => {
    const x = setup(true, { fullscreen: false });
    x.controller.activity();
    x.controller.reconcile(false);
    expect(x.visible()).toBe(true);
    x.state.fullscreen = true;
    x.controller.hold('keyboard-focus', true);
    x.controller.reconcile(false);
    expect(x.visible()).toBe(true);
  });

  it('销毁取消定时器和后续事件，其他实例的时间不受影响', () => {
    const a = setup();
    const b = setup(false);
    a.controller.activity();
    b.controller.activity();
    a.controller.dispose();
    const before = a.changes.length;
    a.controller.tap();
    a.controller.refresh();
    a.controller.hold('pointer', true);
    a.controller.reconcile(false);
    vi.advanceTimersByTime(10000);
    expect(a.changes).toHaveLength(before);
    expect(a.visible()).toBe(true);
    expect(b.visible()).toBe(false);
    expect(vi.getTimerCount()).toBe(0);
  });
});

describe('触屏表面手势识别', () => {
  const start = { x: 100, y: 100, time: 1000 };
  it('普通轻点可切换控件', () => {
    expect(isSurfaceTap(start, { x: 105, y: 102, time: 1100 })).toBe(true);
  });
  it('达到倍速长按阈值后不作为轻点，即使浏览器补发 click', () => {
    expect(isSurfaceTap(start, { ...start, time: 1500 })).toBe(false);
    expect(isSurfaceTap(start, { ...start, time: 3000 })).toBe(false);
  });
  it('拖动不作为轻点，不让调节进度/手势结束后切换控件', () => {
    expect(isSurfaceTap(start, { x: 130, y: 100, time: 1100 })).toBe(false);
  });
});
