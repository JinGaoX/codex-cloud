import { describe, expect, it, vi } from 'vitest';
import { chooseAndroidBackAction, createAndroidBackDispatcher, hasAndroidBackHistory, type AndroidBackPorts, type AndroidBackState } from './android-back-navigation';

const base: AndroidBackState = { documentFullscreen: false, webFullscreen: false, surfaces: [], canGoBack: false, canReturnHome: false };
const surface = (id: string, stackingPath: number[], order = 0) => ({ id, stackingPath, order });

describe('Android hardware back priority', () => {
  it('exits system video fullscreen before touching underlying dialogs or navigation', () => {
    expect(chooseAndroidBackAction({ ...base, documentFullscreen: true, webFullscreen: true,
      surfaces: [surface('settings', [50])], canGoBack: true })).toEqual({ type: 'exit-document-fullscreen' });
  });

  it('exits player webpage fullscreen before closing the page beneath it', () => {
    expect(chooseAndroidBackAction({ ...base, webFullscreen: true, canGoBack: true })).toEqual({ type: 'exit-web-fullscreen' });
  });

  it('dismisses only the confirmation above an underlying settings drawer', () => {
    expect(chooseAndroidBackAction({ ...base, surfaces: [surface('settings', [50]), surface('confirm', [80])], canGoBack: true }))
      .toEqual({ type: 'dismiss-surface', id: 'confirm' });
  });

  it('respects ancestor stacking context rather than the largest descendant z-index', () => {
    expect(chooseAndroidBackAction({ ...base, surfaces: [surface('header-menu', [40, 999], 4), surface('drawer', [50], 2)] }))
      .toEqual({ type: 'dismiss-surface', id: 'drawer' });
  });

  it('closes a nested menu first, using DOM paint order for identical stacks', () => {
    expect(chooseAndroidBackAction({ ...base, surfaces: [surface('drawer', [50], 1), surface('menu', [50], 2)] }))
      .toEqual({ type: 'dismiss-surface', id: 'menu' });
  });

  it('uses the host canGoBack signal, then minimizes instead of terminating the app', () => {
    expect(chooseAndroidBackAction({ ...base, canGoBack: true })).toEqual({ type: 'history-back' });
    expect(chooseAndroidBackAction(base)).toEqual({ type: 'minimize' });
  });

  it('keeps a secondary page inside the app when its history is empty', () => {
    expect(chooseAndroidBackAction({ ...base, canReturnHome: true })).toEqual({ type: 'navigate-home' });
    expect(chooseAndroidBackAction({ ...base, canReturnHome: true, canGoBack: true })).toEqual({ type: 'history-back' });
  });

  it('uses browser history when native WebView loses its SPA back signal after reload', () => {
    expect(hasAndroidBackHistory(false, 1)).toBe(true);
    expect(hasAndroidBackHistory(false, 0)).toBe(false);
    expect(hasAndroidBackHistory(true, 0)).toBe(true);
    expect(hasAndroidBackHistory(false, NaN)).toBe(false);
  });
});

function ports(state: AndroidBackState = base): AndroidBackPorts {
  return {
    readState: vi.fn((canGoBack) => ({ ...state, canGoBack })),
    exitDocumentFullscreen: vi.fn(), exitWebFullscreen: vi.fn(), dismissSurface: vi.fn(),
    historyBack: vi.fn(), navigateHome: vi.fn(), minimize: vi.fn(),
  };
}

describe('Android hardware back dispatch', () => {
  it('navigates home instead of minimizing a secondary route without history', async () => {
    const host = ports({ ...base, canReturnHome: true });
    expect(await createAndroidBackDispatcher(host).handle(false)).toEqual({ type: 'navigate-home' });
    expect(host.navigateHome).toHaveBeenCalledOnce();
    expect(host.minimize).not.toHaveBeenCalled();
  });
  it('does not close multiple drawers during their exit animation', async () => {
    let now = 1000;
    const host = ports({ ...base, surfaces: [surface('top', [80]), surface('underneath', [50])] });
    const dispatcher = createAndroidBackDispatcher(host, () => now);
    await dispatcher.handle(true);
    now += 100;
    expect(await dispatcher.handle(true)).toBeUndefined();
    expect(host.dismissSurface).toHaveBeenCalledOnce();
    expect(host.dismissSurface).toHaveBeenCalledWith('top');
    expect(host.historyBack).not.toHaveBeenCalled();
    expect(host.minimize).not.toHaveBeenCalled();
    now += 200;
    await dispatcher.handle(true);
    expect(host.dismissSurface).toHaveBeenCalledTimes(2);
  });

  it('does not navigate if a still-visible dialog has no dismiss action', async () => {
    const host = ports({ ...base, surfaces: [surface('blocking-dialog', [80])] });
    host.dismissSurface = vi.fn();
    const dispatcher = createAndroidBackDispatcher(host);
    await dispatcher.handle(true);
    expect(host.dismissSurface).toHaveBeenCalledOnce();
    expect(host.dismissSurface).toHaveBeenCalledWith('blocking-dialog');
    expect(host.historyBack).not.toHaveBeenCalled();
    expect(host.minimize).not.toHaveBeenCalled();
  });

  it('never falls through after fullscreen exit fails', async () => {
    const host = ports({ ...base, documentFullscreen: true });
    host.exitDocumentFullscreen = vi.fn().mockRejectedValue(new Error('fullscreen exit refused'));
    expect(await createAndroidBackDispatcher(host).handle(true)).toBeUndefined();
    expect(host.historyBack).not.toHaveBeenCalled();
    expect(host.minimize).not.toHaveBeenCalled();
  });

  it('deduplicates asynchronous native callbacks, even after the cooldown time', async () => {
    let release!: () => void;
    let now = 1000;
    const host = ports({ ...base, documentFullscreen: true });
    host.exitDocumentFullscreen = vi.fn(() => new Promise<void>((resolve) => { release = resolve; }));
    const dispatcher = createAndroidBackDispatcher(host, () => now);
    const first = dispatcher.handle(true);
    now += 1000;
    expect(await dispatcher.handle(true)).toBeUndefined();
    expect(host.exitDocumentFullscreen).toHaveBeenCalledOnce();
    release();
    await first;
  });

  it('ignores late host events after unmount', async () => {
    const host = ports();
    const dispatcher = createAndroidBackDispatcher(host);
    dispatcher.dispose();
    expect(await dispatcher.handle(false)).toBeUndefined();
    expect(host.readState).not.toHaveBeenCalled();
    expect(host.minimize).not.toHaveBeenCalled();
  });
});
