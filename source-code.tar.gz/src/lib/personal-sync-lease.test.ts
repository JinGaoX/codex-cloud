import 'fake-indexeddb/auto';
import Dexie from 'dexie';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import {
  ownsSyncLease, releaseSyncLease, renewSyncLease, tryAcquireSyncLease,
  SYNC_LEASE_HEARTBEAT_MS, SYNC_LEASE_KEY, SYNC_LEASE_TTL_MS,
} from './personal-sync-lease';

const scope = 'https%3A%2F%2Fproject.supabase.co:aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const base = 100_000;
let a: Dexie;
let b: Dexie;
let databaseName: string;

beforeEach(async () => {
  databaseName = `test-sync-lease:${crypto.randomUUID()}`;
  a = new Dexie(databaseName);
  b = new Dexie(databaseName);
  for (const db of [a, b]) {
    db.version(1).stores({ personalSyncState: 'key', history: 'id' });
    await db.open();
  }
});
afterEach(async () => {
  a.close();
  b.close();
  await Dexie.delete(databaseName);
});

describe('同账号跨标签页同步领导租约', () => {
  it('两个连接同时竞争只能一个成功，不能覆盖outbox', async () => {
    await a.table('personalSyncState').put({ key: 'main', value: { pending: ['local-edit'] } });
    const results = await Promise.all(Array.from({ length: 12 }, (_, index) =>
      tryAcquireSyncLease(index % 2 ? a : b, scope, `owner-${index}`, base)));
    const winners = results.filter((claim) => claim !== null);
    expect(winners).toHaveLength(1);
    expect(winners[0]!.epoch).toBe(1);
    expect((await a.table('personalSyncState').get(SYNC_LEASE_KEY)).value).toEqual(winners[0]);
    expect((await a.table('personalSyncState').get('main')).value).toEqual({ pending: ['local-edit'] });
  });

  it('5秒心跳延长15秒有效期，其他页在续期有效期间不能接手', async () => {
    const first = (await tryAcquireSyncLease(a, scope, 'owner-a', base))!;
    expect(first.expiresAt).toBe(base + SYNC_LEASE_TTL_MS);
    const renewed = (await renewSyncLease(a, first, base + SYNC_LEASE_HEARTBEAT_MS))!;
    expect(renewed.epoch).toBe(first.epoch);
    expect(renewed.expiresAt).toBe(base + SYNC_LEASE_HEARTBEAT_MS + SYNC_LEASE_TTL_MS);
    expect(await tryAcquireSyncLease(b, scope, 'owner-b', base + SYNC_LEASE_TTL_MS)).toBeNull();
    // 飞行中的请求可以持有同epoch的旧claim；心跳不使它变成另一任持有者。
    expect(await ownsSyncLease(b, first, base + SYNC_LEASE_TTL_MS)).toBe(true);
  });

  it('崩溃超过TTL后接手epoch递增，旧owner不能续期或释放新租约', async () => {
    const old = (await tryAcquireSyncLease(a, scope, 'owner-a', base))!;
    const next = (await tryAcquireSyncLease(b, scope, 'owner-b', base + SYNC_LEASE_TTL_MS))!;
    expect(next.epoch).toBe(old.epoch + 1);
    expect(await ownsSyncLease(a, old, base + SYNC_LEASE_TTL_MS)).toBe(false);
    expect(await renewSyncLease(a, old, base + SYNC_LEASE_TTL_MS + 1)).toBeNull();
    await releaseSyncLease(a, old);
    expect(await ownsSyncLease(b, next, base + SYNC_LEASE_TTL_MS + 1)).toBe(true);
  });

  it('过期owner即使使用同token重新接手也产生新epoch，旧网络响应失效', async () => {
    const old = (await tryAcquireSyncLease(a, scope, 'same-tab-token', base))!;
    expect(await renewSyncLease(a, old, old.expiresAt)).toBeNull();
    const next = (await tryAcquireSyncLease(a, scope, 'same-tab-token', old.expiresAt))!;
    expect(next.epoch).toBe(old.epoch + 1);
    expect(await ownsSyncLease(a, old, old.expiresAt)).toBe(false);
    await releaseSyncLease(b, old);
    expect(await ownsSyncLease(a, next, old.expiresAt + 1)).toBe(true);
  });

  it('关闭页释放后立即可接手，但epoch不会删除重置', async () => {
    const old = (await tryAcquireSyncLease(a, scope, 'owner-a', base))!;
    await releaseSyncLease(a, old);
    const row = await a.table('personalSyncState').get(SYNC_LEASE_KEY);
    expect(row.value).toMatchObject({ ownerToken: '', epoch: old.epoch, expiresAt: 0 });
    const next = (await tryAcquireSyncLease(b, scope, 'owner-b', base + 1))!;
    expect(next.epoch).toBe(old.epoch + 1);
    expect(await ownsSyncLease(b, next, base + 2)).toBe(true);
  });

  it('活跃owner重复acquire不延长租约或改变epoch，续期必须显式进行', async () => {
    const claim = (await tryAcquireSyncLease(a, scope, 'owner-a', base))!;
    expect(await tryAcquireSyncLease(a, scope, 'owner-a', base + 1000)).toEqual(claim);
    expect(await ownsSyncLease(b, claim, claim.expiresAt)).toBe(false);
    expect(Object.isFrozen(claim)).toBe(true);
  });

  it('过期RPC响应在同一资料事务中检查fence，不能落盘', async () => {
    const old = (await tryAcquireSyncLease(a, scope, 'owner-a', base))!;
    await tryAcquireSyncLease(b, scope, 'owner-b', old.expiresAt);
    await expect(a.transaction('rw', [a.table('personalSyncState'), a.table('history')], async () => {
      if (!await ownsSyncLease(a, old, old.expiresAt)) throw new Error('lease lost');
      await a.table('history').put({ id: 'late-rpc', position: 99 });
    })).rejects.toThrow('lease lost');
    expect(await a.table('history').count()).toBe(0);
  });

  it('同一资料事务内能检查当前租约并写入，无额外嵌套事务错误', async () => {
    const claim = (await tryAcquireSyncLease(a, scope, 'owner-a', base))!;
    await a.transaction('rw', [a.table('personalSyncState'), a.table('history')], async () => {
      expect(await ownsSyncLease(a, claim, base + 1)).toBe(true);
      await a.table('history').put({ id: 'current-rpc', position: 15 });
    });
    expect(await b.table('history').get('current-rpc')).toEqual({ id: 'current-rpc', position: 15 });
  });

  it('账号误绑定、坏租约或非法时间失败关闭，不能重置后假装持有', async () => {
    await expect(tryAcquireSyncLease(a, scope, '', base)).rejects.toThrow('参数');
    await expect(tryAcquireSyncLease(a, scope, 'owner-a', NaN)).rejects.toThrow('参数');
    await expect(tryAcquireSyncLease(a, scope, 'owner-a', Number.MAX_SAFE_INTEGER)).rejects.toThrow('参数');
    await tryAcquireSyncLease(a, scope, 'owner-a', base);
    await expect(tryAcquireSyncLease(b, 'different-account', 'owner-b', base)).rejects.toThrow('账号不一致');
    await a.table('personalSyncState').put({ key: SYNC_LEASE_KEY, value: { scopeId: scope, epoch: 'bad' } });
    await expect(tryAcquireSyncLease(b, scope, 'owner-b', base)).rejects.toThrow('资料损坏');
    expect((await a.table('personalSyncState').get(SYNC_LEASE_KEY)).value.epoch).toBe('bad');
  });
});
