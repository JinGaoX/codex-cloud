import { describe, expect, it, vi } from 'vitest';
import { requestVideoPlayback, type PlaybackStartCallbacks } from './playback-start';

function callbacks(current: () => boolean = () => true): PlaybackStartCallbacks {
  return { isCurrent: current, onStarted: vi.fn(), onBlocked: vi.fn(), onInterrupted: vi.fn(), onError: vi.fn() };
}

function deferred() {
  let resolve!: () => void;
  let reject!: (reason: unknown) => void;
  const promise = new Promise<void>((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}

async function settle() {
  // Drain the play promise and the consumed notification promise.
  await Promise.resolve();
  await Promise.resolve();
}

describe('requestVideoPlayback', () => {
  it('calls play before returning to the click handler, without awaiting readiness', async () => {
    const events: string[] = [];
    const pending = deferred();
    const notices = callbacks();
    events.push('tap');
    requestVideoPlayback({ play: () => { events.push('play'); return pending.promise; } }, notices);
    events.push('handler returned');
    expect(events).toEqual(['tap', 'play', 'handler returned']);
    expect(notices.onStarted).not.toHaveBeenCalled();
    pending.resolve();
    await settle();
    expect(notices.onStarted).toHaveBeenCalledOnce();
  });

  it('only a genuine permission denial requests another user gesture', async () => {
    const notices = callbacks();
    requestVideoPlayback({ play: () => Promise.reject(new DOMException('Tap required', 'NotAllowedError')) }, notices);
    await settle();
    expect(notices.onBlocked).toHaveBeenCalledOnce();
    expect(notices.onError).not.toHaveBeenCalled();
    expect(notices.onStarted).not.toHaveBeenCalled();
  });

  it('ignores an aborted load rather than presenting a misleading play button', async () => {
    const notices = callbacks();
    requestVideoPlayback({ play: () => Promise.reject(new DOMException('Media changed', 'AbortError')) }, notices);
    await settle();
    expect(notices.onBlocked).not.toHaveBeenCalled();
    expect(notices.onError).not.toHaveBeenCalled();
    expect(notices.onStarted).not.toHaveBeenCalled();
    expect(notices.onInterrupted).toHaveBeenCalledOnce();
  });

  it('does not clear the new episode pending state when an old request is interrupted', async () => {
    let current = true;
    const pending = deferred();
    const notices = callbacks(() => current);
    requestVideoPlayback({ play: () => pending.promise }, notices);
    current = false;
    pending.reject(new DOMException('Old load interrupted', 'AbortError'));
    await settle();
    expect(notices.onInterrupted).not.toHaveBeenCalled();
    expect(notices.onStarted).not.toHaveBeenCalled();
    expect(notices.onBlocked).not.toHaveBeenCalled();
    expect(notices.onError).not.toHaveBeenCalled();
  });

  it('reports a format failure as an error rather than a permission denial', async () => {
    const notices = callbacks();
    const reason = new DOMException('Unsupported media', 'NotSupportedError');
    requestVideoPlayback({ play: () => Promise.reject(reason) }, notices);
    await settle();
    expect(notices.onError).toHaveBeenCalledOnce();
    expect(notices.onError).toHaveBeenCalledWith(reason);
    expect(notices.onBlocked).not.toHaveBeenCalled();
  });

  it.each(['resolve', 'reject'] as const)('ignores an old episode promise that later %ss', async (outcome) => {
    let load = 1;
    const oldRequest = deferred();
    const oldNotices = callbacks(() => load === 1);
    requestVideoPlayback({ play: () => oldRequest.promise }, oldNotices);

    load = 2;
    const newRequest = deferred();
    const newNotices = callbacks(() => load === 2);
    requestVideoPlayback({ play: () => newRequest.promise }, newNotices);
    if (outcome === 'resolve') oldRequest.resolve();
    else oldRequest.reject(new DOMException('Late denial', 'NotAllowedError'));
    newRequest.resolve();
    await settle();

    expect(oldNotices.onStarted).not.toHaveBeenCalled();
    expect(oldNotices.onBlocked).not.toHaveBeenCalled();
    expect(oldNotices.onError).not.toHaveBeenCalled();
    expect(newNotices.onStarted).toHaveBeenCalledOnce();
  });

  it.each(['NotAllowedError', 'AbortError', 'NotSupportedError'])('classifies synchronous %s failures too', (name) => {
    const notices = callbacks();
    const reason = new DOMException('Synchronous failure', name);
    expect(() => requestVideoPlayback({ play: () => { throw reason; } }, notices)).not.toThrow();
    expect(notices.onBlocked).toHaveBeenCalledTimes(name === 'NotAllowedError' ? 1 : 0);
    expect(notices.onError).toHaveBeenCalledTimes(name === 'NotSupportedError' ? 1 : 0);
    expect(notices.onInterrupted).toHaveBeenCalledTimes(name === 'AbortError' ? 1 : 0);
  });

  it('does not start a request already superseded before the handler reaches it', () => {
    const play = vi.fn(() => Promise.resolve());
    requestVideoPlayback({ play }, callbacks(() => false));
    expect(play).not.toHaveBeenCalled();
  });

  it('accepts older media implementations whose synchronous play returns no promise', async () => {
    const notices = callbacks();
    requestVideoPlayback({ play: (() => undefined) as unknown as HTMLMediaElement['play'] }, notices);
    await settle();
    expect(notices.onStarted).toHaveBeenCalledOnce();
  });

  it('consumes callback failures instead of leaking an unhandled rejected promise', async () => {
    const notices = callbacks();
    notices.onStarted = vi.fn(() => { throw new Error('Detached UI'); });
    requestVideoPlayback({ play: () => Promise.resolve() }, notices);
    await settle();
    expect(notices.onStarted).toHaveBeenCalledOnce();
  });
});
