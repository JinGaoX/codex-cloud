import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  ANDROID_UPDATE_FEED_URL, checkAndroidAppUpdate, parseAndroidUpdateManifest,
  readAndroidInstalledVersion, validateAndroidPackageUrl,
} from './android-app-updates';

const valid = {
  appId: 'org.libretv.personal', versionCode: 43002, versionName: '2.20.2-personal.43-android.2',
  sha256: 'a'.repeat(64), downloadUrl: 'https://jingaox.github.io/codex-cloud/android/PPS-43002.apk',
};
const response = (data: unknown = valid) => new Response(JSON.stringify(data), { headers: { 'Content-Type': 'application/json' } });
afterEach(() => { vi.useRealTimers(); vi.unstubAllGlobals(); });

describe('Android APK update metadata', () => {
  it('accepts a project APK and canonicalizes its checksum', () => {
    expect(parseAndroidUpdateManifest({ ...valid, sha256: 'B'.repeat(64) })).toEqual({ ...valid, sha256: 'b'.repeat(64) });
    expect(validateAndroidPackageUrl('https://github.com/JinGaoX/codex-cloud/releases/download/android-43002/PPS.apk'))
      .toBe('https://github.com/JinGaoX/codex-cloud/releases/download/android-43002/PPS.apk');
  });

  it.each([
    'http://jingaox.github.io/codex-cloud/android/PPS.apk',
    'https://jingaox.github.io.evil.example/codex-cloud/android/PPS.apk',
    'https://attacker.example/PPS.apk',
    'https://jingaox.github.io/another-project/PPS.apk',
    'https://github.com/other-owner/codex-cloud/releases/download/tag/PPS.apk',
    'https://github.com/JinGaoX/other-repo/releases/download/tag/PPS.apk',
    'https://user:password@jingaox.github.io/codex-cloud/android/PPS.apk',
    'https://jingaox.github.io:8443/codex-cloud/android/PPS.apk',
    'https://jingaox.github.io/codex-cloud/android/../../PPS.apk',
    'https://jingaox.github.io/codex-cloud/android/%2f..%2fPPS.apk',
    'https://jingaox.github.io/codex-cloud/android/PPS.apk?redirect=elsewhere',
    'https://jingaox.github.io/codex-cloud/android/install.html',
  ])('rejects an untrusted package URL: %s', (url) => {
    expect(() => validateAndroidPackageUrl(url)).toThrow('更新信息格式不正确');
  });

  it.each([
    { appId: 'another.app' }, { versionCode: 0 }, { versionCode: -1 }, { versionCode: 1.2 },
    { versionCode: '43002' }, { versionName: '' }, { versionName: 'name\nheader' },
    { sha256: 'short' }, { sha256: 'z'.repeat(64) },
  ])('rejects malformed or foreign metadata: %j', (patch) => {
    expect(() => parseAndroidUpdateManifest({ ...valid, ...patch })).toThrow('更新信息格式不正确');
  });

  it.each([[43001, 'available'], [43002, 'current'], [43003, 'current']] as const)
    ('compares installed build %i numerically', async (build, expected) => {
      const fetcher = vi.fn().mockResolvedValue(response());
      expect((await checkAndroidAppUpdate(build, { fetcher, online: true })).status).toBe(expected);
      expect(fetcher).toHaveBeenCalledWith(ANDROID_UPDATE_FEED_URL, expect.objectContaining({
        credentials: 'omit', cache: 'no-store', redirect: 'error', mode: 'cors',
      }));
    });

  it('does not let a misleading version name override the APK build number', async () => {
    const fetcher = vi.fn().mockResolvedValue(response({ ...valid, versionCode: 6, versionName: '99.99.99' }));
    expect((await checkAndroidAppUpdate(7, { fetcher, online: true })).status).toBe('current');
  });

  it('labels a browser preview instead of claiming the installed app is current', async () => {
    const fetcher = vi.fn().mockResolvedValue(response());
    expect((await checkAndroidAppUpdate(null, { fetcher, online: true })).status).toBe('preview');
  });

  it('reports an unprepared feed without claiming success', async () => {
    const fetcher = vi.fn().mockResolvedValue(new Response('not found', { status: 404 }));
    await expect(checkAndroidAppUpdate(43001, { fetcher, online: true })).rejects.toMatchObject({
      code: 'not-ready', message: '更新服务暂未就绪，请稍后重试。',
    });
  });

  it('does not fetch when the phone is offline', async () => {
    const fetcher = vi.fn();
    await expect(checkAndroidAppUpdate(43001, { fetcher, online: false })).rejects.toMatchObject({ code: 'offline' });
    expect(fetcher).not.toHaveBeenCalled();
  });

  it.each([
    () => new Response('#'.repeat(64 * 1024 + 1)),
    () => new Response('{}', { headers: { 'Content-Length': String(64 * 1024 + 1) } }),
    () => new Response('<html>error document</html>'),
  ])('rejects oversized or non-JSON responses', async (makeResponse) => {
    const fetcher = vi.fn().mockResolvedValue(makeResponse());
    await expect(checkAndroidAppUpdate(43001, { fetcher, online: true })).rejects.toMatchObject({ code: 'invalid' });
  });

  it('times out even when a broken fetch ignores AbortSignal', async () => {
    vi.useFakeTimers();
    const fetcher = vi.fn().mockImplementation(() => new Promise<Response>(() => {}));
    const result = checkAndroidAppUpdate(43001, { fetcher, online: true }).catch((error) => error);
    await vi.advanceTimersByTimeAsync(8001);
    expect(await result).toMatchObject({ code: 'timeout', message: '检查更新超时，请联网后重试。' });
    expect(vi.getTimerCount()).toBe(0);
  });

  it('aborts and releases a stalled response reader', async () => {
    vi.useFakeTimers();
    const cancel = vi.fn();
    const fetcher = vi.fn().mockResolvedValue(new Response(new ReadableStream({ cancel })));
    const result = checkAndroidAppUpdate(43001, { fetcher, online: true }).catch((error) => error);
    await vi.advanceTimersByTimeAsync(8001);
    expect(await result).toMatchObject({ code: 'timeout' });
    expect(cancel).toHaveBeenCalledOnce();
    expect(vi.getTimerCount()).toBe(0);
  });

  it('cancels an old screen check immediately', async () => {
    const controller = new AbortController();
    const fetcher = vi.fn().mockImplementation(() => new Promise<Response>(() => {}));
    const result = checkAndroidAppUpdate(43001, { fetcher, signal: controller.signal, online: true }).catch((error) => error);
    controller.abort();
    expect(await result).toMatchObject({ code: 'cancelled' });
  });
});

describe('installed Android version identity', () => {
  it('reads versionCode from App.getInfo build, retaining its actual version name', async () => {
    expect(await readAndroidInstalledVersion(async () => ({ build: '43001', version: '2.20.2-personal.43-android.1' })))
      .toEqual({ versionCode: 43001, versionName: '2.20.2-personal.43-android.1' });
  });

  it.each(['', 'preview', '-1', '1.2', '0'])('rejects a guessed or invalid installed build: %s', async (build) => {
    await expect(readAndroidInstalledVersion(async () => ({ build, version: 'name' }))).rejects.toMatchObject({ code: 'installed-version' });
  });

  it('bounds a native bridge that never returns', async () => {
    vi.useFakeTimers();
    const result = readAndroidInstalledVersion(() => new Promise(() => {})).catch((error) => error);
    await vi.advanceTimersByTimeAsync(3001);
    expect(await result).toMatchObject({ code: 'installed-version' });
    expect(vi.getTimerCount()).toBe(0);
  });
});
