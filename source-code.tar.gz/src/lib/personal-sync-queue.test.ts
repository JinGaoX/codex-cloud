import { describe, expect, it } from 'vitest';
import { recordId, type SyncRecord, type SyncResponse } from './personal-sync-model';
import { PersonalSyncQueue, type LocalRecord } from './personal-sync-queue';

const key = JSON.stringify(['https://fixture.invalid/api', 'film', 0]);
const id = recordId('progress', key);
const local = (position: number): Map<string, LocalRecord> => new Map([
  [id, { kind: 'progress', key, payload: { position, duration: 7200 } }],
]);
const row = (revision: number, position: number | null): SyncRecord => ({
  kind: 'progress', key, revision, deleted: position === null,
  payload: position === null ? null : { position, duration: 7200 }, updatedAt: revision * 1000,
});
const response = (revision: number, records: SyncRecord[], accepted = true, conflicts: SyncRecord[] = []): SyncResponse => ({ revision, records, accepted, conflicts });
function setup(revision = 1, position = 10) {
  const queue = new PersonalSyncQueue();
  queue.receive(response(revision, [row(revision, position)]), []);
  queue.setBaseline(local(position));
  return queue;
}

describe('个人同步队列的离线、版本和删除行为', () => {
  it('游客未迁入时空队列不会产生任何同步变化', () => {
    const queue = new PersonalSyncQueue();
    queue.capture(new Map());
    expect(queue.batch()).toEqual([]);
    expect(queue.state.cursor).toBe(0);
  });

  it('同一快照重复捕获不重复排队或更换操作标识', () => {
    const queue = setup();
    queue.capture(local(20));
    const first = structuredClone(queue.batch());
    queue.capture(local(20));
    expect(queue.batch()).toEqual(first);
  });

  it('新的重看可以把播放秒数调小，仍基于已知服务器版本', () => {
    const queue = setup(5, 600);
    queue.capture(local(30));
    expect(queue.batch()).toEqual([expect.objectContaining({ payload: { position: 30, duration: 7200 }, baseRevision: 5 })]);
  });

  it('冲突响应保留离线原值和原版本，不擅自选最大秒数', () => {
    const queue = setup(1, 10);
    queue.capture(local(700));
    const sent = queue.batch();
    const safe = queue.receive(response(2, [row(2, 30)], false, [row(2, 30)]), sent);
    expect(safe).toEqual([]);
    expect(queue.state.pending[id]).toMatchObject({ baseRevision: 1, payload: { position: 700 } });
    expect(queue.state.conflicts[id]).toEqual(row(2, 30));
  });

  it('冲突后继续编辑仍保留旧基础版本，只有明确解决才能改基础版本', () => {
    const queue = setup(1, 10);
    queue.capture(local(700));
    queue.receive(response(2, [row(2, 30)], false, [row(2, 30)]), queue.batch());
    queue.capture(local(650));
    expect(queue.state.pending[id]).toMatchObject({ baseRevision: 1, payload: { position: 650 } });
    expect(queue.state.conflicts[id]).toBeDefined();
    queue.resolve('local');
    expect(queue.state.pending[id].baseRevision).toBe(2);
    expect(queue.state.conflicts).toEqual({});
  });

  it('批次被整体拒绝时，非冲突项也不能当作已经上传而删除', () => {
    const queue = setup();
    const otherKey = 'https://fixture.invalid/source';
    const otherId = recordId('sources', otherKey);
    const snapshot = local(20);
    snapshot.set(otherId, { kind: 'sources', key: otherKey, payload: { selected: true } });
    queue.capture(snapshot);
    const sent = queue.batch();
    queue.receive(response(2, [row(2, 30)], false, [row(2, 30)]), sent);
    expect(queue.state.pending[id]).toBeDefined();
    expect(queue.state.pending[otherId]).toBeDefined();
  });

  it('请求途中产生的新进度不会被较早请求的应答覆盖', () => {
    const queue = setup();
    queue.capture(local(20));
    const sent = queue.batch();
    queue.capture(local(30));
    const newOp = queue.state.pending[id].opId;
    expect(newOp).not.toBe(sent[0].opId);
    expect(queue.receive(response(2, [row(2, 20)]), sent)).toEqual([]);
    expect(queue.state.pending[id]).toMatchObject({ opId: newOp, baseRevision: 2, payload: { position: 30 } });
  });

  it('请求途中改回请求前的值，也是需要保存的新编辑', () => {
    const queue = setup();
    queue.capture(local(20));
    const sent = queue.batch();
    queue.capture(local(10));
    expect(queue.receive(response(2, [row(2, 20)]), sent)).toEqual([]);
    expect(queue.state.pending[id]).toMatchObject({ baseRevision: 2, payload: { position: 10 } });
  });

  it('首次新增发送途中又删除，不能被新增请求的成功应答复活', () => {
    const queue = new PersonalSyncQueue();
    queue.capture(local(20));
    const sent = queue.batch();
    queue.capture(new Map());
    expect(queue.receive(response(1, [row(1, 20)]), sent)).toEqual([]);
    expect(queue.state.pending[id]).toMatchObject({ baseRevision: 1, payload: null });
  });

  it('未在本批发送的离线修改，不能被另一行的成功应答自动改成新版本', () => {
    const queue = setup();
    queue.capture(local(700));
    queue.receive(response(2, [row(2, 30)]), []);
    queue.capture(local(650));
    expect(queue.state.pending[id]).toMatchObject({ baseRevision: 1, payload: { position: 650 } });
  });

  it('明确选择云端会返回需要落地的行并去掉冲突本机修改', () => {
    const queue = setup();
    queue.capture(local(700));
    queue.receive(response(2, [row(2, 30)], false, [row(2, 30)]), queue.batch());
    expect(queue.resolve('cloud')).toEqual([row(2, 30)]);
    expect(queue.state.pending).toEqual({});
    expect(queue.state.conflicts).toEqual({});
  });

  it('丢失成功应答后的重试，服务器已有相同值时自动确认，不制造冲突', () => {
    const queue = setup();
    queue.capture(local(30));
    const server = row(2, 30);
    expect(queue.receive(response(2, [server], false, [server]), queue.batch())).toEqual([server]);
    expect(queue.state.pending).toEqual({});
    expect(queue.state.conflicts).toEqual({});
  });

  it('PostgreSQL jsonb 属性次序不影响相同值的确认', () => {
    const queue = setup();
    queue.capture(local(30));
    const server = { ...row(2, 30), payload: { duration: 7200, position: 30 } };
    queue.receive(response(2, [server], false, [server]), queue.batch());
    expect(queue.state.pending).toEqual({});
    expect(queue.state.conflicts).toEqual({});
  });

  it('无法确认已发送内容的伪成功应答不能丢弃队列', () => {
    const queue = setup();
    queue.capture(local(30));
    const before = structuredClone(queue.state);
    expect(() => queue.receive(response(2, []), queue.batch())).toThrow('同步应答未确认');
    expect(queue.state).toEqual(before);
    expect(() => queue.receive(response(2, [row(2, 100)]), queue.batch())).toThrow('同步应答未确认');
    expect(queue.state).toEqual(before);
  });

  it('服务端只确认部分发送项时，整包验证先于任何队列修改', () => {
    const queue = setup();
    const extraKey = 'https://fixture.invalid/source';
    const snapshot = local(30);
    snapshot.set(recordId('sources', extraKey), { kind: 'sources', key: extraKey, payload: { selected: true } });
    queue.capture(snapshot);
    const before = structuredClone(queue.state);
    expect(() => queue.receive(response(2, [row(2, 30)]), queue.batch())).toThrow('同步应答未确认');
    expect(queue.state).toEqual(before);
  });

  it('删除带原版本排队，成功后保留服务器墓碑', () => {
    const queue = setup();
    queue.capture(new Map());
    const sent = queue.batch();
    expect(sent[0]).toMatchObject({ baseRevision: 1, payload: null });
    expect(queue.receive(response(2, [row(2, null)]), sent)).toEqual([row(2, null)]);
    expect(queue.state.pending).toEqual({});
    expect(queue.state.records[id]).toEqual(row(2, null));
    queue.capture(new Map());
    expect(queue.batch()).toEqual([]);
  });

  it('离线旧修改遇到墓碑时必须显式处理，不能自动复活记录', () => {
    const queue = setup();
    queue.capture(local(500));
    queue.receive(response(2, [row(2, null)], false, [row(2, null)]), queue.batch());
    expect(queue.state.pending[id]).toMatchObject({ baseRevision: 1, payload: { position: 500 } });
    expect(queue.state.conflicts[id].deleted).toBe(true);
    expect(queue.resolve('cloud')).toEqual([row(2, null)]);
    queue.setBaseline(new Map());
    queue.capture(new Map());
    expect(queue.batch()).toEqual([]);
  });

  it('删除请求途中重新加入的记录，不会被旧删除应答抹掉', () => {
    const queue = setup();
    queue.capture(new Map());
    const sent = queue.batch();
    queue.capture(local(30));
    expect(queue.receive(response(2, [row(2, null)]), sent)).toEqual([]);
    expect(queue.state.pending[id]).toMatchObject({ baseRevision: 2, payload: { position: 30 } });
  });

  it('片源暂时无法映射时保留既有进度，不误发删除', () => {
    const queue = setup();
    queue.capture(new Map(), new Set(['progress']));
    expect(queue.batch()).toEqual([]);
    expect(queue.state.baseline[id]).toBeDefined();
    queue.capture(local(20));
    expect(queue.state.pending[id]).toMatchObject({ baseRevision: 1, payload: { position: 20 } });
  });

  it('无法映射时也保留离线待传值；映射恢复后可显式删除', () => {
    const queue = setup();
    queue.capture(local(20));
    const original = structuredClone(queue.batch());
    queue.capture(new Map(), new Set(['progress']));
    expect(queue.batch()).toEqual(original);
    queue.capture(new Map());
    expect(queue.state.pending[id]).toMatchObject({ baseRevision: 1, payload: null });
  });

  it('持久化和重启仍保留离线队列、冲突和游标', () => {
    const queue = setup();
    queue.capture(local(500));
    queue.receive(response(2, [row(2, null)], false, [row(2, null)]), queue.batch());
    const saved = JSON.parse(JSON.stringify(queue.state));
    const restarted = new PersonalSyncQueue(saved);
    expect(restarted.state).toEqual(queue.state);
    expect(restarted.batch()[0]).toMatchObject({ baseRevision: 1, payload: { position: 500 } });
  });

  it('服务器游标倒退会在修改本机队列前拒绝', () => {
    const queue = setup(10);
    queue.capture(local(20));
    const before = structuredClone(queue.state);
    expect(() => queue.receive(response(9, [row(9, 30)]), queue.batch())).toThrow('同步版本倒退');
    expect(queue.state).toEqual(before);
  });

  it('每批只取有限条，未入本批的变化仍排队', () => {
    const queue = new PersonalSyncQueue();
    const snapshot = new Map<string, LocalRecord>();
    for (let i = 0; i < 101; i++) {
      const sourceKey = 'https://fixture.invalid/' + i;
      snapshot.set(recordId('sources', sourceKey), { kind: 'sources', key: sourceKey, payload: { selected: true } });
    }
    queue.capture(snapshot);
    expect(queue.batch()).toHaveLength(100);
    expect(Object.keys(queue.state.pending)).toHaveLength(101);
  });
});
