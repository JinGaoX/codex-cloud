import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { clearStandaloneDetailCache, standaloneApi } from './standalone-api';
import { PREVIEW_MEDIA_PREFIX_BYTES } from './preview-resolution';
import type { QualityProbeItem, QualityProbeResult, SourceConfig } from './types';

// Synthetic CMS and media fixtures only; these hosts are never contacted.
const source: SourceConfig = { key: 'fixture', name: '测试片源', url: 'https://cms.example.test/catalog' };
const item = (id: string, configuredSource = source): QualityProbeItem => ({ id, source: configuredSource });
const json = (data: unknown) => new Response(JSON.stringify(data), { headers: { 'content-type': 'application/json' } });
const detail = (id: string, first = `https://media.example.test/${id}.mp4`) => json({
  list: [{ vod_id: id, vod_name: '分辨率测试夹具', vod_remarks: 'HD 4K',
    vod_play_url: `第一集$${first}#第二集$https://media.example.test/${id}-second.mp4` }],
});
function mp4(width: number, height: number): Uint8Array<ArrayBuffer> {
  const bytes = new Uint8Array(52);
  const view = new DataView(bytes.buffer);
  view.setUint32(0, 12);
  bytes.set(new TextEncoder().encode('ftyp'), 4);
  view.setUint32(12, 40);
  bytes.set(new TextEncoder().encode('avc1'), 16);
  view.setUint16(44, width);
  view.setUint16(46, height);
  return bytes;
}
const requestedUrls = () => vi.mocked(fetch).mock.calls.map(([raw]) => new URL(String(raw)));

beforeEach(() => {
  clearStandaloneDetailCache();
  vi.stubGlobal('fetch', vi.fn());
});
afterEach(() => {
  clearStandaloneDetailCache();
  vi.unstubAllGlobals();
});

describe('explicit standalone source-panel resolution probes', () => {
  it('does nothing before an explicit call, and an empty panel makes no requests', async () => {
    await Promise.resolve();
    expect(fetch).not.toHaveBeenCalled();
    const onResult = vi.fn();
    await standaloneApi.qualityProbeStream([], onResult);
    expect(fetch).not.toHaveBeenCalled();
    expect(onResult).not.toHaveBeenCalled();
  });

  it('returns the complete media dimensions and reads only the first episode prefix', async () => {
    vi.mocked(fetch).mockImplementation(async (raw) => new URL(String(raw)).hostname === 'cms.example.test'
      ? detail('1') : new Response(mp4(1920, 800)));
    const results: QualityProbeResult[] = [];
    await standaloneApi.qualityProbeStream([item('1')], (result) => results.push(result));
    expect(results).toEqual([{ sourceKey: 'fixture', vodId: '1', width: 1920, height: 800 }]);
    expect(fetch).toHaveBeenCalledTimes(2);
    const urls = requestedUrls();
    expect(urls[0].searchParams.get('ids')).toBe('1');
    expect(urls[1].href).toBe('https://media.example.test/1.mp4');
    expect(vi.mocked(fetch).mock.calls[1][1]).toMatchObject({
      headers: { Range: `bytes=0-${PREVIEW_MEDIA_PREFIX_BYTES - 1}` },
      credentials: 'omit', cache: 'no-store', referrerPolicy: 'no-referrer',
    });
    for (const [raw, options] of vi.mocked(fetch).mock.calls) {
      expect(String(raw)).not.toMatch(/\/api\/(?:quality|proxy|search|detail)/);
      expect(new URL(String(raw)).protocol).toBe('https:');
      expect(options?.credentials).toBe('omit');
      expect(new Headers(options?.headers).has('authorization')).toBe(false);
    }
  });

  it('leaves dimensions unknown when the playlist only declares bandwidth', async () => {
    vi.mocked(fetch).mockImplementation(async (raw) => new URL(String(raw)).hostname === 'cms.example.test'
      ? detail('1', 'https://media.example.test/master.m3u8')
      : new Response('#EXTM3U\n#EXT-X-STREAM-INF:BANDWIDTH=8000000\nvariant.m3u8'));
    const onResult = vi.fn();
    await standaloneApi.qualityProbeStream([item('1')], onResult);
    expect(onResult).toHaveBeenCalledTimes(1);
    expect(onResult).toHaveBeenCalledWith({ sourceKey: 'fixture', vodId: '1' });
    expect(fetch).toHaveBeenCalledTimes(2);
    expect(requestedUrls().some((url) => url.pathname.endsWith('variant.m3u8'))).toBe(false);
  });

  it('isolates a failed source while another source still returns its full dimensions', async () => {
    const broken: SourceConfig = { ...source, key: 'broken', url: 'https://broken.example.test/catalog' };
    vi.mocked(fetch).mockImplementation(async (raw) => {
      const url = new URL(String(raw));
      if (url.hostname === 'broken.example.test') throw new TypeError('CORS fixture');
      return url.hostname === 'cms.example.test' ? detail('2') : new Response(mp4(720, 1280));
    });
    const results: QualityProbeResult[] = [];
    await standaloneApi.qualityProbeStream([item('1', broken), item('2')], (result) => results.push(result));
    expect(results).toHaveLength(2);
    expect(results.find((result) => result.sourceKey === 'broken')).toEqual({
      sourceKey: 'broken', vodId: '1', error: expect.stringContaining('CORS'),
    });
    expect(results.find((result) => result.sourceKey === 'fixture')).toEqual({
      sourceKey: 'fixture', vodId: '2', width: 720, height: 1280,
    });
  });

  it('keeps the full detail-plus-prefix operation bounded to two concurrent items', async () => {
    const waiting: Array<{ id: string; resolve: (value: Response) => void }> = [];
    vi.mocked(fetch).mockImplementation((raw) => {
      const url = new URL(String(raw));
      return url.hostname === 'cms.example.test'
        ? new Promise<Response>((resolve) => waiting.push({ id: url.searchParams.get('ids')!, resolve }))
        : Promise.resolve(new Response(mp4(640, 360)));
    });
    const onResult = vi.fn();
    const pending = standaloneApi.qualityProbeStream([item('1'), item('2'), item('3')], onResult);
    await vi.waitFor(() => expect(waiting.map((entry) => entry.id)).toEqual(['1', '2']));
    expect(onResult).not.toHaveBeenCalled();
    waiting[0].resolve(detail('1'));
    await vi.waitFor(() => expect(waiting.map((entry) => entry.id)).toEqual(['1', '2', '3']));
    expect(onResult).toHaveBeenCalledTimes(1);
    waiting[1].resolve(detail('2'));
    waiting[2].resolve(detail('3'));
    await pending;
    expect(onResult).toHaveBeenCalledTimes(3);
    expect(fetch).toHaveBeenCalledTimes(6);
  });

  it('rejects a pre-cancelled panel without any requests or callbacks', async () => {
    const controller = new AbortController();
    controller.abort();
    const onResult = vi.fn();
    await expect(standaloneApi.qualityProbeStream([item('1')], onResult, controller.signal))
      .rejects.toMatchObject({ name: 'AbortError' });
    expect(fetch).not.toHaveBeenCalled();
    expect(onResult).not.toHaveBeenCalled();
  });

  it('aborting a pending detail stops callbacks and does not start queued items', async () => {
    vi.mocked(fetch).mockImplementation(() => new Promise<Response>(() => {}));
    const controller = new AbortController();
    const onResult = vi.fn();
    const pending = standaloneApi.qualityProbeStream([item('1'), item('2'), item('3')], onResult, controller.signal);
    const rejected = expect(pending).rejects.toMatchObject({ name: 'AbortError' });
    await vi.waitFor(() => expect(fetch).toHaveBeenCalledTimes(2));
    controller.abort();
    await rejected;
    expect(fetch).toHaveBeenCalledTimes(2);
    expect(onResult).not.toHaveBeenCalled();
  });

  it('does not backfill a result if a late media response arrives after cancellation', async () => {
    let releaseMedia: ((value: Response) => void) | undefined;
    vi.mocked(fetch).mockImplementation((raw) => new URL(String(raw)).hostname === 'cms.example.test'
      ? Promise.resolve(detail('1')) : new Promise<Response>((resolve) => { releaseMedia = resolve; }));
    const controller = new AbortController();
    const onResult = vi.fn();
    const pending = standaloneApi.qualityProbeStream([item('1')], onResult, controller.signal);
    const rejected = expect(pending).rejects.toMatchObject({ name: 'AbortError' });
    await vi.waitFor(() => expect(releaseMedia).toBeDefined());
    controller.abort();
    releaseMedia!(new Response(mp4(1920, 1080)));
    await rejected;
    expect(onResult).not.toHaveBeenCalled();
  });

  it('does not fetch encryption keys or segments when a playlist is encrypted', async () => {
    vi.mocked(fetch).mockImplementation(async (raw) => new URL(String(raw)).hostname === 'cms.example.test'
      ? detail('1', 'https://media.example.test/encrypted.m3u8')
      : new Response('#EXTM3U\n#EXT-X-KEY:METHOD=AES-128,URI="secret.key"\n#EXTINF:10,\nseg.ts'));
    const onResult = vi.fn();
    await standaloneApi.qualityProbeStream([item('1')], onResult);
    expect(onResult).toHaveBeenCalledTimes(1);
    expect(onResult).toHaveBeenCalledWith({ sourceKey: 'fixture', vodId: '1' });
    expect(fetch).toHaveBeenCalledTimes(2);
    expect(requestedUrls().every((url) => !/secret\.key|seg\.ts/.test(url.pathname))).toBe(true);
  });
});
