import { isWebDownloadStorageId } from './web-download-file-target';

const CHECKPOINT_FOLDER = 'pps-hls-download-checkpoints-v1';
const IDENTITY_FILE = 'manifest.sha256';

interface WebHlsCheckpoint {
  readSegment: (index: number) => Promise<File | null>;
  writeSegment: (index: number, data: Uint8Array<ArrayBuffer>) => Promise<void>;
}

async function readFile(folder: FileSystemDirectoryHandle, name: string): Promise<File | null> {
  try {
    const handle = await folder.getFileHandle(name);
    const file = await handle.getFile();
    return file.size ? file : null;
  } catch (error) {
    if (error instanceof DOMException && error.name === 'NotFoundError') return null;
    throw error;
  }
}

async function writeFile(
  folder: FileSystemDirectoryHandle, name: string, data: Uint8Array<ArrayBuffer> | string,
): Promise<void> {
  const handle = await folder.getFileHandle(name, { create: true });
  const writer = (await handle.createWritable()).getWriter();
  try {
    await writer.write(data);
    // Closing commits the new file. An interrupted write can only leave an empty entry.
    await writer.close();
  } catch (error) {
    await writer.abort().catch(() => {});
    throw error;
  } finally {
    writer.releaseLock();
  }
}

/** A null result means this task was previously started with a different validated playlist. */
export async function openWebHlsCheckpoint(id: string, manifestIdentity: string): Promise<WebHlsCheckpoint | null> {
  if (!isWebDownloadStorageId(id)) throw new TypeError('Invalid download storage ID.');
  const hash = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(manifestIdentity));
  const fingerprint = [...new Uint8Array(hash)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
  const root = await navigator.storage.getDirectory();
  const checkpoints = await root.getDirectoryHandle(CHECKPOINT_FOLDER, { create: true });
  const folder = await checkpoints.getDirectoryHandle(id, { create: true });
  const identity = await readFile(folder, IDENTITY_FILE);
  if (identity) {
    if (identity.size !== fingerprint.length || await identity.text() !== fingerprint) return null;
  } else await writeFile(folder, IDENTITY_FILE, fingerprint);

  // Include the fingerprint in each filename so an orphaned segment cannot be used with another playlist.
  const segment = (index: number) => `${fingerprint}-${index}.ts`;
  return {
    readSegment: (index) => readFile(folder, segment(index)),
    writeSegment: (index, data) => writeFile(folder, segment(index), data),
  };
}

export async function removeWebHlsCheckpoint(id: string): Promise<void> {
  if (!isWebDownloadStorageId(id)) throw new TypeError('Invalid download storage ID.');
  try {
    const root = await navigator.storage.getDirectory();
    const checkpoints = await root.getDirectoryHandle(CHECKPOINT_FOLDER);
    await checkpoints.removeEntry(id, { recursive: true });
  } catch (error) {
    if (!(error instanceof DOMException) || error.name !== 'NotFoundError') throw error;
  }
}
