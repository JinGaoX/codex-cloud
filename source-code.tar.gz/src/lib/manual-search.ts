import { normalizeTitle } from './cms-parser';
import { getSearchExpansionPlan } from './search-expansion';
import type { SearchResultItem } from './types';

const SUPPLEMENTARY_LABELS = new Set([
  '电影解说', '影视解说', '电视剧解说', '剧集解说', '动漫解说', '解说',
  '电影预告', '预告片', '预告', '花絮', '片花', '幕后花絮', '幕后特辑',
  '制作特辑', '精彩片段', '删减片段',
]);

/** Only explicit source labels are evidence; this is not a semantic title classifier. */
export function isSupplementarySearchResult(item: Pick<SearchResultItem, 'name' | 'typeName'>, query = ''): boolean {
  const requested = normalizeTitle(query);
  // A user explicitly searching for commentary/trailers should keep those as primary results.
  if (requested && [...SUPPLEMENTARY_LABELS].some((label) => requested.endsWith(label))) return false;
  if (SUPPLEMENTARY_LABELS.has(normalizeTitle(item.typeName ?? ''))) return true;
  const title = item.name ?? '';
  for (const match of title.matchAll(/[\[【(（]([^\[\]【】()（）]{1,24})[\]】)）]/gu)) {
    if (SUPPLEMENTARY_LABELS.has(normalizeTitle(match[1]))) return true;
  }
  const suffix = title.match(/(?:\s|[-—_:：·|/])\s*([^\s\[\]【】()（）]{2,8})\s*$/u)?.[1];
  return !!suffix && SUPPLEMENTARY_LABELS.has(normalizeTitle(suffix));
}

export function partitionSearchResults<T extends Pick<SearchResultItem, 'name' | 'typeName'>>(items: readonly T[], query = ''): { main: T[]; supplementary: T[] } {
  const main: T[] = [], supplementary: T[] = [];
  for (const item of items) (isSupplementarySearchResult(item, query) ? supplementary : main).push(item);
  return { main, supplementary };
}

/** A commentary hit is not proof that the requested full work was found. */
export function getManualSearchPolicy(query: string, items: readonly SearchResultItem[]) {
  const { main } = partitionSearchResults(items, query);
  const full = getSearchExpansionPlan(query, 'empty');
  return {
    automatic: main.length === 0,
    automaticCandidates: full.candidates,
    series: getSearchExpansionPlan(query, 'matched').candidates.filter((candidate) => candidate.kind === 'series'),
    alternatives: full.candidates.filter((candidate) => candidate.kind === 'alternative'),
  };
}
