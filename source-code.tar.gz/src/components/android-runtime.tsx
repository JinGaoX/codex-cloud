'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import type { PluginListenerHandle } from '@capacitor/core';
import { IS_ANDROID_NATIVE } from '@/lib/runtime-mode';
import { createAndroidBackDispatcher, hasAndroidBackHistory, type AndroidBackSurface } from '@/lib/android-back-navigation';
import { appPath } from '@/lib/app-path';

function isVisible(element: HTMLElement): boolean {
  const box = element.getBoundingClientRect();
  const style = getComputedStyle(element);
  return box.width > 0 && box.height > 0 && box.right > 0 && box.bottom > 0
    && box.left < innerWidth && box.top < innerHeight
    && style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0';
}

function stackingPath(element: HTMLElement): number[] {
  const values: number[] = [];
  let current: HTMLElement | null = element;
  while (current) {
    const style = getComputedStyle(current);
    const zIndex = Number.parseInt(style.zIndex, 10);
    if (!Number.isNaN(zIndex)) values.unshift(zIndex);
    else if (style.transform !== 'none' || style.isolation === 'isolate' || Number(style.opacity) < 1) values.unshift(0);
    current = current.parentElement;
  }
  return values;
}

/** Native shell integration only; routes, player instances and account state remain shared. */
export function AndroidRuntime() {
  const router = useRouter();
  useEffect(() => {
    if (!IS_ANDROID_NATIVE) return;
    const previousMarker = document.documentElement.getAttribute('data-android-native');
    document.documentElement.setAttribute('data-android-native', 'true');
    let disposed = false;
    let listener: PluginListenerHandle | undefined;
    let dispatcher: ReturnType<typeof createAndroidBackDispatcher> | undefined;
    let backPending = false;

    void Promise.all([import('@capacitor/core'), import('@capacitor/app')]).then(async ([{ Capacitor, registerPlugin }, { App }]) => {
      if (disposed || !Capacitor.isNativePlatform() || Capacitor.getPlatform() !== 'android') return;
      const host = registerPlugin<{ getNavigationState(): Promise<{ historyIndex: number }> }>('PpsHost');
      const surfaces = new Map<string, HTMLElement>();
      dispatcher = createAndroidBackDispatcher({
        readState: (canGoBack) => {
          surfaces.clear();
          const visibleSurfaces: AndroidBackSurface[] = [];
          document.querySelectorAll<HTMLElement>('[role="dialog"], [role="alertdialog"], details[open]').forEach((element, order) => {
            if (!isVisible(element)) return;
            const id = `back-surface-${order}`;
            surfaces.set(id, element);
            visibleSurfaces.push({ id, stackingPath: stackingPath(element), order });
          });
          return {
            documentFullscreen: Boolean(document.fullscreenElement),
            webFullscreen: Boolean(document.querySelector('.art-video-player.art-fullscreen-web')),
            surfaces: visibleSurfaces,
            canGoBack,
            canReturnHome: window.location.pathname !== '/' || Boolean(window.location.search || window.location.hash),
          };
        },
        exitDocumentFullscreen: () => document.exitFullscreen(),
        exitWebFullscreen: () => {
          // Use ArtPlayer's own control, so its layout, controls and events are
          // restored by the player instead of mutating fullscreen CSS classes.
          document.querySelector<HTMLElement>('.art-video-player.art-fullscreen-web .art-control-fullscreenWeb')?.click();
        },
        dismissSurface: (id) => {
          const surface = surfaces.get(id);
          if (!surface?.isConnected) return;
          if (surface.tagName === 'DETAILS') {
            surface.querySelector<HTMLElement>(':scope > summary')?.click();
            return;
          }
          // ConfirmDialog's secondary ghost button owns onCancel, including
          // custom cancel labels. Never click its primary/confirm action.
          const close = surface.getAttribute('role') === 'alertdialog'
            ? surface.querySelector<HTMLButtonElement>('button.btn-ghost')
            : surface.querySelector<HTMLButtonElement>('button[aria-label="关闭"]');
          if (close && !close.disabled) close.click();
          // A non-dismissable modal consumes back; do not exit underneath it.
        },
        historyBack: () => window.history.back(),
        navigateHome: () => router.replace(appPath('/')),
        minimize: () => App.minimizeApp(),
      });
      listener = await App.addListener('backButton', async ({ canGoBack }) => {
        if (disposed || backPending) return;
        backPending = true;
        let timer: ReturnType<typeof setTimeout> | undefined;
        try {
          const history = await Promise.race([
            host.getNavigationState().catch(() => null),
            new Promise<null>((resolve) => { timer = setTimeout(() => resolve(null), 500); }),
          ]);
          if (!disposed) await dispatcher?.handle(hasAndroidBackHistory(canGoBack, history?.historyIndex ?? -1));
        } finally {
          if (timer) clearTimeout(timer);
          backPending = false;
        }
      });
      if (disposed) {
        dispatcher.dispose();
        await listener.remove();
        listener = undefined;
      }
    }).catch(() => { /* A missing host bridge must not prevent app rendering. */ });

    return () => {
      disposed = true;
      dispatcher?.dispose();
      void listener?.remove().catch(() => {});
      if (previousMarker === null) document.documentElement.removeAttribute('data-android-native');
      else document.documentElement.setAttribute('data-android-native', previousMarker);
    };
  }, [router]);
  return null;
}
