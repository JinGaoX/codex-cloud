'use client';

import { useEffect, useMemo, useState } from 'react';
import { useAppStore } from '@/lib/store';
import { useToast } from './toast';
import { api } from '@/lib/client-api';
import { IS_STANDALONE } from '@/lib/runtime-mode';
import { standaloneMediaUrl } from '@/lib/standalone-media';
import { canonicalSourceIdentity } from '@/lib/personal-sync-model';
import { formatRelativeTime, hostnameOf, validateSourceUrl, cn } from '@/lib/utils';
import { SearchInput, SectionTitle, TestBadge, useSourceTests } from './settings-shared';
import { EmptyState } from './states';
import { Icon } from './icon';

/**
 * 直播源管理（嵌入设置抽屉）：M3U 订阅的添加 / 探活 / 移除 / 导出，
 * 以及部署者预置源展示。工具条、徽章、空态与撤销语义与点播源面板保持一致。
 */

type LiveFilter = 'all' | 'enabled' | 'disabled' | 'sub' | 'manual';

// 与点播源面板保持同一组筛选项与顺序：先状态（已启用 / 已停用），后来源（来自订阅 / 手动添加）
const LIVE_FILTERS: { id: LiveFilter; label: string }[] = [
  { id: 'all', label: '全部' },
  { id: 'enabled', label: '已启用' },
  { id: 'disabled', label: '已停用' },
  { id: 'sub', label: '来自订阅' },
  { id: 'manual', label: '手动添加' },
];

interface LiveRow {
  url: string;
  label: string;
  epgUrl?: string;
  preset: boolean;
  lastSync?: number;
  fromSubscriptions: string[];
}

export function LiveSourceManager() {
  const store = useAppStore();
  const { toast } = useToast();
  const [adding, setAdding] = useState(false);
  /** 正在编辑的手动源 URL（与「添加」共用同一表单） */
  const [editing, setEditing] = useState<string | null>(null);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<LiveFilter>('all');
  const { tests, runTest } = useSourceTests();

  const rows = useMemo<LiveRow[]>(() => {
    const preset: LiveRow[] = store.liveEnvSources.map((s) => ({
      url: s.url,
      label: s.name || hostnameOf(s.url),
      epgUrl: s.epg,
      preset: true,
      fromSubscriptions: [],
    }));
    const subs: LiveRow[] = store.liveSubscriptions.map((s) => ({
      url: s.url,
      label: s.name || hostnameOf(s.url),
      epgUrl: s.epg,
      preset: false,
      lastSync: s.lastSync,
      fromSubscriptions: s.fromSubscriptions,
    }));
    const all = [...preset, ...subs];
    const q = query.trim().toLowerCase();
    return all.filter((r) => {
      if (filter === 'enabled' && !store.liveSelectedUrls.includes(r.url)) return false;
      if (filter === 'disabled' && store.liveSelectedUrls.includes(r.url)) return false;
      if (filter === 'sub' && r.fromSubscriptions.length === 0) return false;
      if (filter === 'manual' && !(r.fromSubscriptions.length === 0 && !r.preset)) return false;
      if (!q) return true;
      return r.label.toLowerCase().includes(q) || r.url.toLowerCase().includes(q);
    });
  }, [store.liveEnvSources, store.liveSubscriptions, store.liveSelectedUrls, query, filter]);

  // 编辑中的手动源（与「添加」共用同一表单）
  const editingSource = editing ? store.liveSubscriptions.find((s) => s.url === editing) : undefined;

  const exportM3u = (url: string) => {
    window.open(api.liveExportUrl(url), '_blank', 'noopener');
  };

  const allEnabled = rows.length > 0 && rows.every((r) => store.liveSelectedUrls.includes(r.url));
  const toggleAll = () => {
    // 只翻转状态与目标不一致的源，一次批量 set 完成（逐条 toggle 会触发 O(n) 次持久化）
    const targets = rows
      .filter((r) => store.liveSelectedUrls.includes(r.url) === allEnabled)
      .map((r) => r.url);
    if (targets.length > 0) useAppStore.getState().toggleLiveSelectedMany(targets);
  };

  const removeWithUndo = (row: LiveRow) => {
    const snapshot = useAppStore.getState().removeLiveSubscription(row.url);
    if (!snapshot) return;
    // 正在编辑的条目被移除时收起表单，避免表单悬空
    if (editing === row.url) setEditing(null);
    toast(`已移除「${row.label}」`, 'info', {
      action: {
        label: '撤销',
        onClick: () => {
          useAppStore.getState().restoreLiveSubscription(snapshot);
          toast('已恢复', 'success');
        },
      },
    });
  };

  const empty = store.liveEnvSources.length === 0 && store.liveSubscriptions.length === 0;

  return (
    <section>
      <SectionTitle
        title="直播源"
        hint={empty ? '添加 M3U 订阅或 M3U8 直播地址' : `共 ${store.liveEnvSources.length + store.liveSubscriptions.length} 个 · 已启用 ${store.liveSelectedUrls.length}`}
        extra={
          <button className="btn-primary btn-sm" onClick={() => setAdding(true)}>
            <Icon name="plus" className="w-3.5 h-3.5" />
            添加直播源
          </button>
        }
      />

      {/* 与点播源一致：由「+ 添加 / 编辑」按钮展开同一表单，而非常驻占位 */}
      <LiveSourceForm
        visible={adding || editingSource !== undefined}
        initial={editingSource}
        onCancel={() => {
          setAdding(false);
          setEditing(null);
        }}
        onSubmit={(data) => {
          if (editing) {
            // 编辑模式：只更新名称与 EPG（地址不可改）
            store.updateLiveSubscription(editing, { name: data.name, epg: data.epg });
          } else {
            store.addLiveSubscription(data.url, data.name, data.epg);
            void runTest(data.url, () => api.liveTest(data.url));
          }
          setAdding(false);
          setEditing(null);
        }}
      />

      {empty && !adding && editingSource === undefined ? (
        <EmptyState
          icon="link"
          title="还没有添加任何直播源"
          description={IS_STANDALONE
            ? '添加允许浏览器跨域读取的 HTTPS M3U 订阅或 M3U8 直播地址，即可浏览与播放频道。'
            : '添加 M3U 地址后即可在「直播」页按分组浏览与播放频道；也可在「数据源订阅」中一次导入点播源与直播源；部署者还可通过 DEFAULT_LIVE_SOURCES 环境变量预置。'}
          action={
            <button className="btn-primary btn-sm" onClick={() => setAdding(true)}>
              添加第一个直播源
            </button>
          }
        />
      ) : (
        <>
          <div className="space-y-2 mb-3">
            <SearchInput value={query} onChange={setQuery} placeholder="搜索名称或地址" />
            <div className="flex flex-wrap items-center gap-1">
              {LIVE_FILTERS.map((f) => (
                <button
                  key={f.id}
                  className={cn(
                    'chip',
                    filter === f.id ? 'bg-accent/10 text-accent font-medium' : 'text-muted hover:text-content hover:bg-hover'
                  )}
                  onClick={() => setFilter(f.id)}
                  aria-pressed={filter === f.id}
                >
                  {f.label}
                </button>
              ))}
              <span className="ml-auto text-[11px] text-faint">显示 {rows.length} 个</span>
            </div>
            <button className="btn-ghost btn-sm" onClick={toggleAll} disabled={rows.length === 0}>
              {allEnabled ? '全部停用' : '全部启用'}
            </button>
          </div>

          {rows.length === 0 ? (
            <EmptyState variant="plain" title="没有符合条件的源" />
          ) : (
            <ul className="space-y-2">
              {rows.map((row) => {
                const enabled = store.liveSelectedUrls.includes(row.url);
                const fromSubscription = row.fromSubscriptions.length > 0;
                return (
                  <li
                    key={row.url}
                    className={cn(
                      'bg-card rounded-lg p-3 transition-colors hover:bg-hover/50',
                      // 未勾选 = 不参与直播列表：淡显，与点播源面板保持同一套停用观感
                      !enabled && 'opacity-70'
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        className="h-4 w-4 accent-accent shrink-0"
                        checked={enabled}
                        onChange={() => useAppStore.getState().toggleLiveSelected(row.url)}
                        aria-label={enabled ? `停用 ${row.label}` : `启用 ${row.label}`}
                        title={enabled ? '已启用，取消勾选可停用' : '已停用，勾选后生效'}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="text-sm font-medium text-content truncate">
                          {row.label}
                          {row.preset && (
                            <span className="ml-1.5 text-[10px] px-1.5 py-0.5 rounded bg-chip text-faint align-middle">
                              部署者预置
                            </span>
                          )}
                          {fromSubscription && (
                            <span
                              className="ml-1.5 text-[10px] px-1.5 py-0.5 rounded bg-accent/10 text-accent align-middle"
                              title={`来自 ${row.fromSubscriptions.length} 个数据源订阅；删除单个订阅不影响此源，仅当不再被任何订阅引用时才会移除`}
                            >
                              订阅
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-faint truncate">
                          {row.url}
                          {!IS_STANDALONE && row.epgUrl && ' · 已配置节目单'}
                          {row.lastSync && ` · 同步于 ${formatRelativeTime(row.lastSync)}`}
                        </div>
                      </div>
                      <TestBadge
                        state={tests[row.url]}
                        onTest={() => runTest(row.url, () => api.liveTest(row.url))}
                        title="读取订阅（频道数量与耗时）"
                        badgeWhenOk={({ count }) => `✓ ${count ?? 0} 频道`}
                      />
                      {!IS_STANDALONE && <button
                        className="rounded-md p-2 text-muted transition-colors hover:bg-hover hover:text-accent shrink-0"
                        onClick={() => exportM3u(row.url)}
                        aria-label="导出 M3U"
                        title="导出为标准 M3U 文件"
                      >
                        <Icon name="download" className="w-4 h-4" />
                      </button>}
                      {row.preset ? null : fromSubscription ? (
                        <>
                          {/* 订阅源由远端列表管理：编辑会被下次同步覆盖、删除会复活，故置为禁用态并指路 */}
                          <button
                            className="rounded-md p-2 text-muted/30 cursor-not-allowed shrink-0"
                            disabled
                            aria-label="订阅源不可单独编辑"
                            title="该源来自数据源订阅，修改会在下次同步时被覆盖；请修改远端订阅内容后重新同步"
                          >
                            <Icon name="edit" className="w-4 h-4" />
                          </button>
                          <button
                            className="rounded-md p-2 text-muted/30 cursor-not-allowed shrink-0"
                            disabled
                            aria-label="订阅源不可单独删除"
                            title="该源来自数据源订阅；请到「数据源订阅」中删除整个订阅"
                          >
                            <Icon name="trash" className="w-4 h-4" />
                          </button>
                        </>
                      ) : (
                        <>
                          <button
                            className="rounded-md p-2 text-muted transition-colors hover:bg-hover hover:text-accent shrink-0"
                            onClick={() => setEditing(row.url)}
                            aria-label="编辑"
                            title={IS_STANDALONE ? '编辑名称' : '编辑名称与节目单地址'}
                          >
                            <Icon name="edit" className="w-4 h-4" />
                          </button>
                          <button
                            className="rounded-md p-2 text-muted transition-colors hover:bg-hover hover:text-danger shrink-0"
                            onClick={() => removeWithUndo(row)}
                            aria-label="删除直播源"
                            title="移除（可在提示中撤销）"
                          >
                            <Icon name="trash" className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </>
      )}
    </section>
  );
}

/** 直播源表单：与点播源一致，由「+ 添加 / 编辑」按钮展开；编辑时地址只读、提交后自动探活（仅新增） */
function LiveSourceForm({
  visible,
  initial,
  onCancel,
  onSubmit,
}: {
  visible: boolean;
  /** 编辑模式：仅允许改名称与 EPG，地址只读 */
  initial?: { url: string; name?: string; epg?: string };
  onCancel: () => void;
  onSubmit: (data: { url: string; name?: string; epg?: string }) => void;
}) {
  const [url, setUrl] = useState('');
  const [name, setName] = useState('');
  const [epg, setEpg] = useState('');
  const { toast } = useToast();

  useEffect(() => {
    if (visible) {
      setUrl(initial?.url ?? '');
      setName(initial?.name ?? '');
      setEpg(initial?.epg ?? '');
    }
  }, [visible, initial]);

  if (!visible) return null;

  const submit = () => {
    const epgUrl = epg.trim();
    if (epgUrl && !canonicalSourceIdentity(epgUrl)) {
      toast('请填写完整的 HTTP 或 HTTPS 节目单地址', 'warning');
      return;
    }
    if (initial) {
      onSubmit({ url: initial.url, name: name.trim() || undefined, epg: epgUrl || undefined });
      return;
    }
    let u = url.trim();
    if (IS_STANDALONE) {
      try { u = standaloneMediaUrl(u); }
      catch {
        toast('请使用不含账号密码的 HTTPS 直播源地址', 'warning');
        return;
      }
    } else if (!validateSourceUrl(u)) {
      toast('订阅地址需以 http:// 或 https:// 开头', 'warning');
      return;
    }
    onSubmit({ url: u, name: name.trim() || undefined, epg: epgUrl || undefined });
  };

  return (
    <div className="space-y-2 border border-line rounded-lg p-3 bg-chip mb-2">
      <input
        className="input w-full disabled:opacity-60"
        aria-label="M3U 订阅地址"
        placeholder="M3U 订阅地址，如 https://example.com/list.m3u"
        value={url}
        maxLength={500}
        disabled={!!initial}
        title={initial ? '地址不可修改；如需更换请删除后重新添加' : undefined}
        onChange={(e) => setUrl(e.target.value)}
      />
      <input
        className="input w-full"
        aria-label="直播源名称（可选）"
        placeholder="名称（可选），如 我的频道列表"
        value={name}
        maxLength={50}
        onChange={(e) => setName(e.target.value)}
      />
      {!IS_STANDALONE && <input
        className="input w-full"
        aria-label="EPG 节目单地址（可选）"
        placeholder="EPG 节目单地址（可选，XMLTV xml/xml.gz）"
        value={epg}
        maxLength={500}
        onChange={(e) => setEpg(e.target.value)}
      />}
      <div className="flex gap-2 justify-end">
        <button className="btn-ghost btn-sm" onClick={onCancel}>
          取消
        </button>
        <button className="btn-primary btn-sm" onClick={submit}>
          添加
        </button>
      </div>
    </div>
  );
}
