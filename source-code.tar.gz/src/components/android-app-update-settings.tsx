'use client';

import { useEffect, useRef, useState } from 'react';
import { Capacitor, registerPlugin } from '@capacitor/core';
import { App } from '@capacitor/app';
import { useAuth } from './auth';
import {
  checkAndroidAppUpdate, readAndroidInstalledVersion, validateAndroidPackageUrl,
  type AndroidInstalledVersion, type AndroidUpdateManifest,
} from '@/lib/android-app-updates';

const PpsHost = registerPlugin<{ openExternal(options: { url: string }): Promise<void> }>('PpsHost');

function isInstalledAndroid(): boolean { return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android'; }

/** APK updates remain an explicit download/install action; no web-shell hot replacement. */
export function AndroidAppUpdateSettings() {
  const { version } = useAuth();
  const [installed, setInstalled] = useState<AndroidInstalledVersion | null>(null);
  const [phase, setPhase] = useState<'idle' | 'checking' | 'available' | 'current' | 'preview' | 'opening' | 'failed'>('idle');
  const [manifest, setManifest] = useState<AndroidUpdateManifest | null>(null);
  const [message, setMessage] = useState('');
  const request = useRef(0);
  const abort = useRef<AbortController | null>(null);
  const active = useRef(true);
  const opening = useRef(false);

  useEffect(() => {
    active.current = true;
    const controller = new AbortController();
    if (isInstalledAndroid()) {
      void readAndroidInstalledVersion(() => App.getInfo(), controller.signal).then((value) => {
        if (!controller.signal.aborted) setInstalled(value);
      }).catch(() => { /* The explicit check retries and presents any host failure. */ });
    }
    return () => {
      active.current = false;
      controller.abort();
      abort.current?.abort();
    };
  }, []);

  const check = async () => {
    if (phase === 'checking' || phase === 'opening') return;
    const id = ++request.current;
    abort.current?.abort();
    const controller = new AbortController();
    abort.current = controller;
    const timeout = setTimeout(() => controller.abort(new DOMException('Update timeout', 'TimeoutError')), 8000);
    setPhase('checking');
    setManifest(null);
    setMessage('正在检查更新…');
    try {
      const current = isInstalledAndroid() ? await readAndroidInstalledVersion(() => App.getInfo(), controller.signal) : null;
      if (current && active.current && id === request.current) setInstalled(current);
      const result = await checkAndroidAppUpdate(current?.versionCode ?? null, { signal: controller.signal });
      if (!active.current || id !== request.current || controller.signal.aborted) return;
      setManifest(result.manifest);
      setPhase(result.status);
      setMessage(result.status === 'available' ? `发现新版本 ${result.manifest.versionName}。`
        : result.status === 'current' ? '当前没有新版本。'
        : '网页预览无法读取已安装版本，可下载安装包。');
    } catch (error) {
      if (!active.current || id !== request.current
        || (controller.signal.aborted && controller.signal.reason?.name !== 'TimeoutError')) return;
      setPhase('failed');
      setMessage(controller.signal.aborted && controller.signal.reason?.name === 'TimeoutError'
        ? '检查更新超时，请联网后重试。'
        : error instanceof Error ? error.message : '暂时无法检查更新，请稍后重试。');
    } finally {
      clearTimeout(timeout);
      if (abort.current === controller) abort.current = null;
    }
  };

  const download = async () => {
    if (!manifest || opening.current || phase === 'opening' || phase === 'checking') return;
    opening.current = true;
    setPhase('opening');
    let timeout: ReturnType<typeof setTimeout> | undefined;
    try {
      const url = validateAndroidPackageUrl(manifest.downloadUrl);
      if (isInstalledAndroid()) {
        await Promise.race([
          PpsHost.openExternal({ url }),
          new Promise<never>((_resolve, reject) => {
            timeout = setTimeout(() => reject(new Error('无法打开下载页面，请稍后重试。')), 8000);
          }),
        ]);
        if (active.current) setMessage('已打开安装包下载页面。下载完成后，请按系统提示安装。');
      } else {
        window.open(url, '_blank', 'noopener,noreferrer');
        if (active.current) setMessage('已尝试打开安装包下载页面。');
      }
      if (active.current) setPhase(isInstalledAndroid() ? 'available' : 'preview');
    } catch (error) {
      if (!active.current) return;
      setPhase('failed');
      setMessage(error instanceof Error ? error.message : '无法打开下载页面，请稍后重试。');
    } finally {
      opening.current = false;
      if (timeout) clearTimeout(timeout);
    }
  };

  const busy = phase === 'checking' || phase === 'opening';
  return <section className="space-y-4">
    <div>
      <h3 className="text-sm font-medium text-content">应用更新</h3>
      {(installed?.versionName || version) && <p className="mt-2 text-xs text-muted">当前版本 {installed?.versionName || version}</p>}
    </div>
    <div className="flex flex-wrap gap-3">
      <button type="button" className="btn-ghost min-h-11" disabled={busy} onClick={() => void check()}>
        {phase === 'checking' ? '正在检查…' : '检查更新'}
      </button>
      {manifest && (phase === 'available' || phase === 'preview' || phase === 'opening') && <button
        type="button" className="btn-primary min-h-11" disabled={busy} onClick={() => void download()}>
        {phase === 'opening' ? '正在打开…' : '下载安装包'}
      </button>}
    </div>
    {message && <p role="status" aria-live="polite" className="text-sm text-muted">{message}</p>}
    <p className="text-xs text-faint">安卓版本通过安装包更新，下载后由你确认安装。请直接覆盖安装，保留原有应用数据。</p>
  </section>;
}
