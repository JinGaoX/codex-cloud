'use client';

import { useEffect, useMemo, useRef, useState, useTransition, type CSSProperties } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { DISCOVERY_LISTS, DISCOVERY_REFRESH_MS, fetchDiscoveryList, type DiscoveryItem } from '@/lib/discovery';
import {
  DEFAULT_LIBRARY_FILTERS, LIBRARY_TYPES, LIBRARY_SORTS, LIBRARY_GENRES, LIBRARY_COUNTRIES,
  LIBRARY_YEARS, LIBRARY_MIN_RATINGS, fetchLibraryPage, fetchTop250Page, libraryRequestKey,
} from '@/lib/library-discovery';
import { requestAppPanel } from '@/lib/app-navigation';
import { useAppStore } from '@/lib/store';
import { appPath } from '@/lib/app-path';
import { IS_STANDALONE } from '@/lib/runtime-mode';
import { fetchLibraryWindow, libraryGridLayout, type LibraryGridLayout } from '@/lib/library-window';
import { SmartImage } from './smart-image';
import { Icon } from './icon';
import { DISCOVERY_NAVIGATION_EVENT, discoveryHref, hasLibraryView, libraryHref, libraryLists, libraryWindowStart, withLibraryWindow, readDiscoveryReturnPosition, readLastLibraryView, readLibraryPosition, readLibraryView, writeLastLibraryView, writeLibraryPosition, type LibraryView } from './library-browser-state';

const RANK_PAGE_SIZE = 25;
const BROWSE_PAGE_SIZE = 20;

export function LibraryBrowser({ embedded = false, onPick }: { embedded?: boolean; onPick?: (title: string) => void } = {}) {
  const router = useRouter();
  const queryClient = useQueryClient();
  const params = useSearchParams();
  const container = useRef<HTMLElement>(null);
  const [gridLayout, setGridLayout] = useState<LibraryGridLayout>();
  const displaySize = gridLayout?.size;
  useEffect(() => {
    const element = container.current;
    if (!element) return;
    const update = (width: number) => {
      if (!Number.isFinite(width) || width <= 0) return;
      const next = libraryGridLayout(width);
      setGridLayout((previous) => previous?.columns === next.columns ? previous : next);
    };
    // The section content box is exactly the poster grid width; the body rail and
    // section gutters must not count as space available to posters.
    const measure = () => {
      const style = getComputedStyle(element);
      update(element.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight));
    };
    measure();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', measure);
      return () => window.removeEventListener('resize', measure);
    }
    const observer = new ResizeObserver(([entry]) => {
      if (entry) update(entry.contentRect.width);
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    // Notify after the router has committed the new URL, never from optimistic filter state.
    if (embedded) window.dispatchEvent(new Event(DISCOVERY_NAVIGATION_EVENT));
  }, [embedded, params]);
  const [rememberedView, setRememberedView] = useState<LibraryView | undefined>();
  const [initialized, setInitialized] = useState(!embedded);
  useEffect(() => { setRememberedView(readLastLibraryView()); setInitialized(true); }, []);
  const [homeLayoutReady, setHomeLayoutReady] = useState(!embedded);
  useEffect(() => {
    if (!embedded) return;
    const marker = document.querySelector('[data-home-viewing-ready]');
    // Legacy /library and independently embedded catalogues have no home rail.
    if (!marker) { setHomeLayoutReady(true); return; }
    const update = () => setHomeLayoutReady(marker.getAttribute('data-home-viewing-ready') === 'true');
    update();
    const observer = new MutationObserver(update);
    observer.observe(marker, { attributes: true, attributeFilter: ['data-home-viewing-ready'] });
    return () => observer.disconnect();
  }, [embedded]);
  const urlView = useMemo(() => embedded && !hasLibraryView(params) && rememberedView ? rememberedView : readLibraryView(params), [embedded, params, rememberedView]);
  // Merge rapid taps against the latest intent, while preserving URL/back navigation.
  const [pendingView, setPendingView] = useState<LibraryView | null>(null);
  const [navigating, startNavigation] = useTransition();
  const intendedView = useRef(urlView);
  const intendedHref = useRef<string | null>(null);
  const rawView = pendingView ?? urlView;
  const view = useMemo(() => displaySize ? withLibraryWindow(rawView, displaySize) : rawView, [displaySize, rawView]);
  const currentHref = libraryHref(view);
  const enabled = useAppStore((state) => state.standaloneDiscoveryEnabled);
  const heading = useRef<HTMLHeadingElement>(null);
  const scrollToSection = useRef(false);
  const restored = useRef<string | null>(null);
  const leaving = useRef(false);
  const batchFingerprints = useRef(new Map<string, Map<number, readonly string[]>>());
  useEffect(() => {
    if (intendedHref.current === null || libraryHref(urlView) === intendedHref.current || !navigating) {
      intendedHref.current = null;
      intendedView.current = urlView;
      setPendingView(null);
    }
  }, [urlView, navigating]);
  useEffect(() => {
    const back = () => { intendedHref.current = null; setPendingView(null); };
    window.addEventListener('popstate', back);
    return () => window.removeEventListener('popstate', back);
  }, []);
  const ranking = view.mode === 'ranking';
  const top250 = ranking && view.list === 'top250';
  const start = libraryWindowStart(view);
  const size = displaySize ?? BROWSE_PAGE_SIZE;
  const scope = ranking ? `ranking:${view.list}` : libraryRequestKey(view);
  const query = useQuery({
    queryKey: ['public-library-window-v2', scope, start, size],
    queryFn: async ({ signal }) => {
      let fingerprints = batchFingerprints.current.get(scope);
      if (!fingerprints) { fingerprints = new Map(); batchFingerprints.current.set(scope, fingerprints); }
      while (batchFingerprints.current.size > 6) batchFingerprints.current.delete(batchFingerprints.current.keys().next().value!);
      return fetchLibraryWindow({ start, size, signal, seenBatches: fingerprints,
        batchSize: ranking ? top250 ? RANK_PAGE_SIZE : 50 : BROWSE_PAGE_SIZE,
        limit: ranking ? top250 ? 250 : 50 : 5000,
        loadBatch: (offset) => queryClient.fetchQuery({
          queryKey: ranking && !top250 ? ['public-library-ranking-v1', view.list]
            : ['public-library-page-v1', top250 ? 'top250' : libraryRequestKey(view), offset],
          staleTime: DISCOVERY_REFRESH_MS, gcTime: DISCOVERY_REFRESH_MS, retry: false,
          queryFn: async ({ signal: batchSignal }) => {
            // Provider batches are shared between adjacent windows and rotations.
            // Cancelling one window must not kill another window's in-flight batch.
            if (top250) return await fetchTop250Page(offset, batchSignal);
            if (ranking) return { ...await fetchDiscoveryList(view.list as Exclude<LibraryView['list'], 'top250'>, batchSignal), start: 0 };
            return await fetchLibraryPage(view, offset, batchSignal);
          },
        }),
      });
    },
    enabled: enabled && initialized && !!displaySize, staleTime: DISCOVERY_REFRESH_MS, gcTime: 2 * 60_000, retry: false,
    refetchOnWindowFocus: true, refetchOnReconnect: true,
    refetchInterval: DISCOVERY_REFRESH_MS, refetchIntervalInBackground: false,
  });
  const items = query.data?.items ?? [];
  const hasNext = query.data?.nextPageStart !== undefined;
  const list = DISCOVERY_LISTS.find((entry) => entry.id === view.list);
  const source = ranking ? top250 ? '豆瓣 Top250' : list?.source ?? '豆瓣榜单' : '豆瓣影视分类';
  const selectedFilters = [view.genre, view.country, view.year ? LIBRARY_YEARS.find((entry) => entry.value === view.year)?.label : '',
    view.minRating ? `${view.minRating}分以上` : ''].filter(Boolean);

  useEffect(() => { if (initialized) writeLastLibraryView(view); }, [initialized, view]);

  useEffect(() => {
    // Restoring before IndexedDB inserts Continue Watching lets browser scroll
    // anchoring move the saved coordinate by the newly inserted rail's height.
    if (!enabled || !initialized || !homeLayoutReady || query.isPending || restored.current === currentHref) return;
    let frame = 0;
    let cancelled = false;
    const restore = () => {
      if (cancelled) return;
      const returnY = embedded ? readDiscoveryReturnPosition(view, window.history.state) : readLibraryPosition(currentHref);
      if (returnY !== undefined && !scrollToSection.current) {
        window.scrollTo({ top: Math.min(returnY, Math.max(0, document.documentElement.scrollHeight - window.innerHeight)), behavior: 'instant' });
      } else if (embedded && (scrollToSection.current || window.location.hash === '#home-discovery')) {
        container.current?.scrollIntoView({ block: 'start', behavior: 'instant' });
      }
      scrollToSection.current = false;
      restored.current = currentHref;
    };
    frame = requestAnimationFrame(restore);
    const cancel = () => { cancelled = true; restored.current = currentHref; cancelAnimationFrame(frame); };
    window.addEventListener('pointerdown', cancel, { once: true });
    window.addEventListener('wheel', cancel, { once: true });
    window.addEventListener('keydown', cancel, { once: true });
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('pointerdown', cancel);
      window.removeEventListener('wheel', cancel);
      window.removeEventListener('keydown', cancel);
    };
  }, [currentHref, embedded, enabled, homeLayoutReady, initialized, query.isPending, view]);

  useEffect(() => {
    let timer: ReturnType<typeof setTimeout> | undefined;
    // The destination can shorten the document before unmount cleanup runs.
    // Save the observed position, never the resulting clamped destination scroll.
    let position = readLibraryPosition(currentHref);
    const save = () => { if (!leaving.current && restored.current === currentHref) writeLibraryPosition(view, position); };
    const onScroll = () => {
      if (leaving.current || restored.current !== currentHref) return;
      position = window.scrollY; clearTimeout(timer); timer = setTimeout(save, 150);
    };
    const onHide = () => { if (!leaving.current) position = window.scrollY; save(); };
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('pagehide', onHide);
    return () => { clearTimeout(timer); save(); window.removeEventListener('scroll', onScroll); window.removeEventListener('pagehide', onHide); };
  }, [currentHref, view]);

  const change = (patch: Partial<LibraryView>) => {
    writeLibraryPosition(view, window.scrollY);
    const next = { ...withLibraryWindow(intendedView.current, displaySize ?? 21), page: 1, offset: 0, ...patch };
    const normalized = readLibraryView(new URLSearchParams(libraryHref(next).split('?')[1]));
    intendedView.current = normalized;
    intendedHref.current = libraryHref(normalized);
    writeLastLibraryView(normalized);
    setPendingView(normalized);
    const majorChange = 'page' in patch || 'offset' in patch || 'mode' in patch || 'type' in patch || 'list' in patch;
    scrollToSection.current = embedded && majorChange;
    const href = embedded ? discoveryHref(normalized) : libraryHref(normalized);
    startNavigation(() => {
      if (embedded && IS_STANDALONE) window.history.pushState(null, '', appPath(href));
      else router.push(href, { scroll: false });
    });
    if (majorChange) heading.current?.focus({ preventScroll: true });
  };
  const refresh = async () => {
    batchFingerprints.current.delete(scope);
    await queryClient.invalidateQueries({ queryKey: ranking && !top250 ? ['public-library-ranking-v1', view.list]
      : ['public-library-page-v1', top250 ? 'top250' : libraryRequestKey(view)], refetchType: 'none' });
    void query.refetch();
  };
  const pick = (item: DiscoveryItem) => {
    leaving.current = true;
    writeLibraryPosition(view, window.scrollY);
    writeLastLibraryView(view);
    if (embedded) {
      window.history.replaceState({ ...window.history.state, ppsDiscoveryReturn: { key: currentHref, scrollY: window.scrollY } }, '', appPath(discoveryHref(view)));
    }
    if (onPick) onPick(item.title);
    else router.push(`/?s=${encodeURIComponent(item.title)}`, { scroll: false });
  };

  const Container = embedded ? 'section' : 'main';
  const Heading = embedded ? 'h2' : 'h1';
  const ResultsHeading = embedded ? 'h3' : 'h2';
  const columns = gridLayout?.columns ?? 3;
  const gridStyle = { '--library-columns': columns, '--library-column-gap': columns >= 6 ? '24px' : columns >= 4 ? '20px' : '12px', '--library-row-gap': columns >= 4 ? '32px' : '24px' } as CSSProperties;
  return <Container ref={container} id={embedded ? 'home-discovery' : 'app-main'} tabIndex={-1} aria-labelledby={embedded ? 'home-discovery-title' : undefined} className={`library-main${embedded ? ' home-discovery library-embedded' : ''}`} style={gridStyle}>
    <div className="library-heading">
      <div>{!embedded && <p className="library-eyebrow">发现下一部好片</p>}<Heading id={embedded ? 'home-discovery-title' : undefined} ref={heading} tabIndex={-1}>{embedded ? '发现影视' : '影视库'}</Heading></div>
      <div className="library-modes" role="group" aria-label="找片方式">
        <button type="button" aria-pressed={!ranking} disabled={view.type === 'show'} onClick={() => change({ mode: 'browse' })}>找片</button>
        <button type="button" aria-pressed={ranking} onClick={() => change({ mode: 'ranking' })}>榜单</button>
      </div>
    </div>
    <p className="library-intro">{view.type === 'show' ? '从近期口碑综艺中挑选。' : '按喜好慢慢挑，找到想看的再搜索片源。'}</p>
    <div className="library-toolbar">
      <div className="library-types" role="group" aria-label="影视类型">
        {LIBRARY_TYPES.map((entry) => <button key={entry.value} type="button" aria-pressed={view.type === entry.value}
          onClick={() => change({ type: entry.value, list: entry.value === 'movie' ? 'top250' : libraryLists(entry.value)[0]?.id ?? 'douban_movie_weekly' })}>{entry.label}</button>)}
      </div>
      {ranking ? <SelectControl label="选择榜单" value={view.list} options={[
        ...(view.type === 'movie' ? [{ value: 'top250', label: '豆瓣 Top250' }] : []),
        ...libraryLists(view.type).map((entry) => ({ value: entry.id, label: entry.label })),
      ]} onChange={(value) => change({ list: value as LibraryView['list'] })} />
        : <SelectControl label="排序" value={view.sort} options={LIBRARY_SORTS} onChange={(value) => change({ sort: value as LibraryView['sort'] })} compact />}
    </div>
    {!ranking && <details className="library-filters">
      <summary><Icon name="filter" /><span>筛选</span><span className="library-filter-summary">{selectedFilters.length ? selectedFilters.join(' · ') : '类型、地区、年代、评分'}</span><Icon name="chevronDown" /></summary>
      <div className="library-filter-fields">
        <SelectControl label="影片类型" value={view.genre} options={LIBRARY_GENRES} onChange={(genre) => change({ genre })} />
        <SelectControl label="地区" value={view.country} options={LIBRARY_COUNTRIES} onChange={(country) => change({ country })} />
        <SelectControl label="年代" value={view.year} options={LIBRARY_YEARS} onChange={(year) => change({ year })} />
        <SelectControl label="最低豆瓣评分" value={String(view.minRating)} options={LIBRARY_MIN_RATINGS.map((entry) => ({ ...entry, value: String(entry.value) }))} onChange={(value) => change({ minRating: Number(value) })} />
      </div>
      {selectedFilters.length > 0 && <button type="button" className="library-reset" onClick={() => change({ ...DEFAULT_LIBRARY_FILTERS, type: view.type, sort: view.sort })}>清除筛选</button>}
    </details>}
    <div className="library-results-heading"><ResultsHeading>{ranking ? top250 ? '豆瓣 Top250' : list?.label : selectedFilters.length ? selectedFilters.join(' · ') : '随心找片'}</ResultsHeading>
      <button type="button" className="library-refresh" aria-label="刷新当前片单" disabled={!enabled || query.isFetching} onClick={() => void refresh()}><Icon name="refresh" /><span>{query.isFetching && !query.isPending ? '刷新中' : '刷新'}</span></button>
    </div>
    {!enabled ? <div className="library-status" role="status"><p>影视发现已关闭。</p><button type="button" className="btn-ghost" onClick={() => requestAppPanel('settings')}>打开设置</button></div>
      : !initialized || !displaySize || query.isPending ? <LibrarySkeleton count={size} /> : <>
        {query.isError && <div className="library-status" role="status"><p>{query.data ? '更新暂时不可用，保留上次获取的内容。' : '片单暂时没加载出来，请稍后重试。'}</p><button type="button" className="btn-ghost" disabled={query.isFetching} onClick={() => void query.refetch()}>重试</button></div>}
        {query.data?.repeated ? <p className="library-status" role="status">来源返回了重复的一页，已停止继续翻页。可以返回上一页或换个筛选条件。</p>
          : query.data?.incomplete && <div className="library-status" role="status"><p>这一页暂未加载完整，已保留成功读取的影片。重试补全后再继续翻页。</p><button type="button" className="btn-ghost" disabled={query.isFetching} onClick={() => void refresh()}>重试补全</button></div>}
        {items.length > 0 ? <div className="library-poster-grid" aria-label={source}>
          {items.map((item) => <LibraryPoster key={item.id} item={item} onPick={pick} embedded={embedded} />)}
        </div> : !query.isError && !query.data?.incomplete && <div className="library-status" role="status"><p>这一页没有找到影片，试试其他条件或返回上一页。</p>{!ranking && selectedFilters.length > 0 && <button type="button" className="btn-ghost" onClick={() => change({ ...DEFAULT_LIBRARY_FILTERS, type: view.type })}>清除筛选</button>}</div>}
        {query.data && <>
          <div className="library-source"><span>{source}</span><span>本机获取 {new Date(query.data.retrievedAt).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span></div>
          <nav className="library-pagination" aria-label="发现影视分页">
            <button type="button" className="btn-ghost" disabled={start <= 0 || query.isFetching} onClick={() => change({ offset: Math.max(0, start - size) })}>上一页</button>
            <p aria-live="polite">第 {view.page} 页<span>本页 {items.length} 部</span></p>
            <button type="button" className="btn-ghost" disabled={!hasNext || query.isFetching} onClick={() => change({ offset: start + size })}>下一页</button>
          </nav>
        </>}
      </>}
  </Container>;
}

function SelectControl({ label, value, options, onChange, compact = false }: {
  label: string; value: string; options: readonly { value: string; label: string }[]; onChange: (value: string) => void; compact?: boolean;
}) {
  return <label className={`library-select${compact ? ' library-select-compact' : ''}`}><span>{label}</span><select aria-label={label} value={value} onChange={(event) => onChange(event.target.value)}>
    {options.map((entry) => <option key={entry.value} value={entry.value}>{entry.label}</option>)}
  </select></label>;
}

function LibraryPoster({ item, onPick, embedded = false }: { item: DiscoveryItem; onPick: (item: DiscoveryItem) => void; embedded?: boolean }) {
  const [failed, setFailed] = useState(false);
  useEffect(() => setFailed(false), [item.id, item.cover]);
  const Heading = embedded ? 'h4' : 'h3';
  return <button type="button" className="library-poster" aria-label={`搜索 ${item.title} 的片源`} onClick={() => onPick(item)}>
    <div className="library-poster-art">
      {item.cover && !failed ? <SmartImage url={item.cover} fallbackUrls={item.coverFallbacks} mode="direct" alt="" loading="lazy" className="library-poster-image" onExhausted={() => setFailed(true)} />
        : <div className="library-poster-placeholder"><Icon name="search" /><span>暂无海报</span></div>}
      <span className="library-poster-scrim" aria-hidden="true" />
      {item.rank !== undefined && <span className="library-poster-rank" aria-label={`原榜第${item.rank}名`}>{item.rank}</span>}
      {item.rating && <span className="library-poster-rating">豆瓣 {item.rating}</span>}
    </div>
    <Heading>{item.title}</Heading>
    {(item.year || item.regions?.length || item.genres.length > 0) && <p>{[item.year, item.regions?.[0], ...item.genres.slice(0, 2)].filter(Boolean).join(' · ')}</p>}
    {item.votes !== undefined && <p>{item.votes.toLocaleString('zh-CN')} 人评分</p>}
  </button>;
}

function LibrarySkeleton({ count = BROWSE_PAGE_SIZE }: { count?: number }) {
  return <div className="library-poster-grid library-skeleton" aria-busy="true" aria-label="正在加载影片">
    {Array.from({ length: count }, (_, index) => <div key={index}><div className="library-poster-art" /><div className="library-skeleton-title" /></div>)}
  </div>;
}
