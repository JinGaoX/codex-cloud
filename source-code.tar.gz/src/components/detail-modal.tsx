'use client';

import { useEffect, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { useRouter } from 'next/navigation';
import { api } from '@/lib/client-api';
import type { QualityEntry, SearchResultItem, VideoDetail } from '@/lib/types';
import { buildWatchUrl } from '@/lib/utils';
import { formatRemarks } from '@/lib/remarks';
import { SmartImage } from './smart-image';
import { useAppStore, resolveSource, readQuality } from '@/lib/store';
import { useToast } from './toast';
import { cn } from '@/lib/utils';
import { addSearchHistory, addFavorite, removeFavorite, favoriteKeyOf, db } from '@/lib/db';
import { copyToClipboard } from '@/lib/clipboard';
import { EmptyState, ErrorState, LoadingState } from './states';
import { useFocusTrap } from './use-focus-trap';
import { Icon } from './icon';
import { probePreviewResolution } from '@/lib/preview-resolution';
import { isQualityEntryFresh, qualityKey, resolutionLabel } from '@/lib/quality';
import { describeEpisode, hasEpisodeTitles } from '@/lib/episode-labels';

/**
 * 详情弹窗：剧集列表 + 排序 + 复制链接。
 * 剧集点击 → /watch 路由（URL 携带定位参数，可分享、可后退）。
 */

export function DetailModal({ item, onClose }: { item: SearchResultItem | null; onClose: () => void }) {
  const store = useAppStore();
  const router = useRouter();
  const { toast } = useToast();
  const [detail, setDetail] = useState<VideoDetail | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [retryAttempt, setRetryAttempt] = useState(0);
  const [reversed, setReversed] = useState(false);
  const [previewQuality, setPreviewQuality] = useState<QualityEntry>();
  const [resolutionLoading, setResolutionLoading] = useState(false);
  const [posterFailed, setPosterFailed] = useState(false);
  const detailIdentityRef = useRef('');
  const abortRef = useRef<AbortController | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const firstPreviewEpisode = detail?.episodes[0];
  const favorite = useLiveQuery(
    () => item ? db.favorites.get(favoriteKeyOf(item.sourceKey, item.vodId)).catch(() => undefined) : undefined,
    [item?.sourceKey, item?.vodId]
  );

  // 打开时把焦点移入弹窗、Tab 圈闭在弹窗内、关闭后归还焦点
  useFocusTrap(Boolean(item), panelRef);

  useEffect(() => setPosterFailed(false), [item?.pic, store.imageProxyMode, store.customImageProxy]);

  // 弹窗打开期间锁定背景滚动
  useEffect(() => {
    if (!item) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = prev;
    };
  }, [item]);

  useEffect(() => {
    detailIdentityRef.current = '';
    if (!item) {
      setDetail(null);
      setError('');
      setLoading(false);
      return;
    }
    const source = resolveSource(store, item.sourceKey, {
      url: item.sourceUrl,
      name: item.sourceName,
    });
    if (!source) {
      setDetail(null);
      setLoading(false);
      setError('点播源配置不存在（可能已被删除），请在设置中重新添加');
      return;
    }
    setLoading(true);
    setDetail(null);
    setReversed(false);
    setError('');
    abortRef.current?.abort();
    const controller = new AbortController();
    abortRef.current = controller;
    api
      .detail(item.vodId, source, controller.signal, item.name)
      .then((d) => {
        if (!controller.signal.aborted) {
          detailIdentityRef.current = `${item.sourceKey}:${item.vodId}`;
          setDetail(d);
        }
      })
      .catch((err) => {
        if (controller.signal.aborted || (err instanceof DOMException && err.name === 'AbortError')) return;
        setError(err instanceof Error ? err.message : '获取详情失败');
      })
      .finally(() => { if (!controller.signal.aborted) setLoading(false); });
    return () => controller.abort();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [item, retryAttempt]);

  // Only the opened detail's first episode is inspected. This is independent of the detail request:
  // CORS/unsupported media headers must never block the episode buttons or start playback.
  useEffect(() => {
    setPreviewQuality(undefined);
    setResolutionLoading(false);
    const firstEpisode = firstPreviewEpisode;
    if (!item || !firstEpisode || detailIdentityRef.current !== `${item.sourceKey}:${item.vodId}`) return;
    const cached = readQuality(item.sourceKey, item.vodId);
    if (resolutionLabel(cached?.width, cached?.height)) return;
    const controller = new AbortController();
    setResolutionLoading(true);
    void probePreviewResolution(firstEpisode, controller.signal)
      .then((size) => {
        if (controller.signal.aborted || !size) return;
        const entry: QualityEntry = { ...size, from: 'probe', timestamp: Date.now() };
        setPreviewQuality(entry);
        useAppStore.getState().setQuality({ [qualityKey(item.sourceKey, item.vodId)]: entry });
      })
      .catch(() => {})
      .finally(() => { if (!controller.signal.aborted) setResolutionLoading(false); });
    return () => controller.abort();
  }, [item, firstPreviewEpisode]);

  useEffect(() => {
    if (!item) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [item, onClose]);

  if (!item) return null;

  const episodes = detail ? (reversed ? [...detail.episodes].reverse() : detail.episodes) : [];
  const titledEpisodes = hasEpisodeTitles(detail?.episodeTitles, detail?.episodes.length ?? 0);
  const info = detail?.videoInfo;
  const storedQuality = store.qualityMap[qualityKey(item.sourceKey, item.vodId)];
  const cachedQuality = storedQuality && isQualityEntryFresh(storedQuality) ? storedQuality : undefined;
  const resolutionEntry = resolutionLabel(cachedQuality?.width, cachedQuality?.height) ? cachedQuality : previewQuality;
  const resolution = resolutionLabel(resolutionEntry?.width, resolutionEntry?.height);

  const play = (index: number) => {
    if (!detail || !detail.episodes[index]) return;
    addSearchHistory(item.name).catch(() => {});
    router.push(
      buildWatchUrl({
        sourceKey: item.sourceKey,
        vodId: item.vodId,
        index,
        title: item.name,
        sourceUrl: item.sourceUrl,
      })
    );
  };

  const copyLinks = async () => {
    if (!detail) return;
    const ok = await copyToClipboard(detail.episodes.join('\n'));
    if (ok) toast('播放链接已复制', 'success');
    else toast('复制失败，请检查浏览器权限', 'error');
  };

  const toggleFavorite = async () => {
    try {
      if (favorite) await removeFavorite(item.sourceKey, item.vodId);
      else {
        const source = resolveSource(store, item.sourceKey);
        await addFavorite({ ...item, sourceUrl: item.sourceUrl ?? source?.url });
      }
      toast(favorite ? '已取消收藏' : '已加入收藏', 'success');
    } catch { toast('收藏保存失败，请检查浏览器存储空间', 'error'); }
  };

  // 备注与卡片同源，同样归一化，避免同一部剧在两处显示不同文案
  const remarks = formatRemarks(info?.remarks);
  const metaRows = [
    info?.typeName && ['类型', info.typeName],
    info?.year && ['年份', info.year],
    info?.area && ['地区', info.area],
    info?.director && ['导演', info.director],
    info?.actor && ['主演', info.actor],
    remarks && ['备注', remarks],
  ].filter(Boolean) as [string, string][];

  return (
    <div
      className="app-detail-overlay fixed inset-0 z-[60] flex items-start justify-center overflow-y-auto bg-black/80 py-10 px-4 animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        ref={panelRef}
        tabIndex={-1}
        className="app-detail-panel bg-surface-raised rounded-xl w-full max-w-3xl shadow-2xl animate-slide-up outline-none"
        role="dialog"
        aria-modal="true"
        aria-label={`${item.name} 详情`}
      >
        <div className="app-detail-header flex items-start justify-between gap-4 p-5 pb-3 border-b border-line">
          <div className="min-w-0">
            <h2 className="text-lg font-semibold text-content break-words">{item.name}</h2>
            <span className="text-sm text-faint">{item.sourceName}</span>
          </div>
          <button className="btn-ghost btn-sm shrink-0" onClick={toggleFavorite} aria-pressed={Boolean(favorite)}>
            <Icon name="heart" className="w-4 h-4" />
            {favorite ? '已收藏' : '收藏'}
          </button>
          <button
            className="p-1.5 rounded-md text-muted hover:text-content hover:bg-hover shrink-0"
            onClick={onClose}
            aria-label="关闭"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="app-detail-body p-5 pt-4">
          {loading && <LoadingState label="正在获取剧集信息..." />}

          {!loading && error && (
            <ErrorState
              message={error || '获取失败'}
              onRetry={() => setRetryAttempt((attempt) => attempt + 1)}
              className="[&_button]:min-h-11 [&_button]:min-w-11"
            />
          )}

          {!loading && !error && detail && (
            <>
              <div className="flex flex-col sm:flex-row gap-4 mb-4">
                {item?.pic && !posterFailed && (
                  <SmartImage
                    url={item.pic}
                    mode={store.imageProxyMode}
                    customProxy={store.customImageProxy}
                    alt={item.name}
                    className="w-24 sm:w-32 aspect-[2/3] object-cover rounded-lg bg-chip shrink-0 self-center sm:self-start"
                    loading="eager"
                    onExhausted={() => setPosterFailed(true)}
                  />
                )}
                <div className="min-w-0 space-y-3">
                  <div className="rounded-lg border border-line bg-chip/40 px-3 py-2 text-sm" aria-live="polite">
                    <p className="text-content">
                      {resolution
                        ? `${resolutionEntry?.from === 'play' ? '已播放分辨率' : '媒体信息分辨率'} ${resolution}`
                        : resolutionLoading ? '正在读取分辨率…' : '分辨率暂未读取到'}
                    </p>
                    <p className="mt-1 text-xs leading-relaxed text-faint">
                      {resolution
                        ? '仅供选片参考；媒体清单可能标注最高档位，不同剧集或档位可能不同，播放页显示当前实际尺寸。'
                        : '可以直接选集播放，视频加载后会自动显示完整尺寸。'}
                    </p>
                  </div>
                  {metaRows.length > 0 && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5 text-sm">
                      {metaRows.map(([k, v]) => (
                        <div key={k} className="truncate" title={`${k}: ${v}`}>
                          <span className="text-faint">{k}:</span>{' '}
                          <span className="text-content">{v}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  {info?.desc && (
                    <p className="text-sm text-muted leading-relaxed line-clamp-3">{info.desc}</p>
                  )}
                </div>
              </div>

              {episodes.length > 0 ? (
                <>
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <div className="flex items-center gap-2">
                      <button
                        className="btn-ghost btn-sm"
                        onClick={() => setReversed((v) => !v)}
                        aria-label={reversed ? '切换为正序排列' : '切换为倒序排列'}
                        title="调整剧集列表的排列顺序"
                      >
                        <Icon
                          name="arrowDown"
                          className={cn('w-3.5 h-3.5 transition-transform', reversed && 'rotate-180')}
                        />
                        {reversed ? '正序排列' : '倒序排列'}
                      </button>
                      <span className="text-sm text-faint">共 {episodes.length} 集</span>
                    </div>
                    <button className="btn-primary btn-sm" onClick={copyLinks}>
                      复制链接
                    </button>
                  </div>
                  <div className={cn('grid gap-2 max-h-[40vh] overflow-y-auto scrollbar-thin pr-1', titledEpisodes ? 'grid-cols-1 sm:grid-cols-2 md:grid-cols-3' : 'grid-cols-3 sm:grid-cols-5 md:grid-cols-7')}>
                    {episodes.map((_, i) => {
                      const realIndex = reversed ? detail.episodes.length - 1 - i : i;
                      const episode = describeEpisode(realIndex, detail.episodeTitles?.[realIndex]);
                      return (
                        <button
                          key={realIndex}
                          className={cn('btn-ghost min-h-11 min-w-0', titledEpisodes ? '!justify-start !px-3 py-3 text-left' : 'btn-sm !px-1 text-center')}
                          aria-label={episode.label}
                          onClick={() => play(realIndex)}
                        >
                          {episode.title ? <><span aria-hidden="true" className="shrink-0 text-xs tabular-nums opacity-70">{episode.number}</span><span className="min-w-0 whitespace-normal break-words [overflow-wrap:anywhere] text-sm leading-6">{episode.title}</span></> : episode.number}
                        </button>
                      );
                    })}
                  </div>
                </>
              ) : (
                <EmptyState
                  icon="alert"
                  title="未找到播放资源"
                  description="该视频可能暂时无法播放，请尝试其他视频"
                />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
