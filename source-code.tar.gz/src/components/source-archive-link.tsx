'use client';

import { useState, type ReactNode } from 'react';
import { APP_BRAND } from '@/lib/app-brand';
import { IS_HARMONY, IS_NATIVE } from '@/lib/runtime-mode';
import { exportNativeSourceArchive, localFileExportMessage } from '@/lib/local-file-export';
import { useToast } from './toast';

/** Installed apps export their bundled corresponding source through a local picker. */
export function SourceArchiveLink({ children, className }: { children: ReactNode; className?: string }) {
  const { toast } = useToast();
  const [exporting, setExporting] = useState(false);
  if (!IS_NATIVE && !IS_HARMONY) return <a href={APP_BRAND.sourceUrl} className={className}>{children}</a>;
  const exportSource = async () => {
    if (exporting) return;
    setExporting(true);
    try {
      toast(localFileExportMessage(await exportNativeSourceArchive()), 'info');
    } catch (error) {
      toast(error instanceof Error ? error.message : '源码导出失败', 'error');
    } finally {
      setExporting(false);
    }
  };
  return <button type="button" className={`${className || ''} disabled:opacity-50`} onClick={exportSource} disabled={exporting}>{children}</button>;
}
