'use client';

import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from 'react';
import { flushSync } from 'react-dom';
import { type AuthChangeEvent, type Session, type SupabaseClient } from '@supabase/supabase-js';
import {
  ACCOUNT_SCOPE_KEY, ACTIVE_ACCOUNT_SCOPE, readActiveAccountScope, scopeId, setActiveAccountScope,
} from '@/lib/account-scope';
import { flushPendingPersist } from '@/lib/persist-storage';
import { getSyncConfiguration, isPersonalSignupEnabled } from '@/lib/personal-sync-config';
import { getPersonalSyncClient } from '@/lib/personal-sync-client';
import { PersonalSyncRuntime, clearAccountCache, type PersonalSyncStatus } from '@/lib/personal-sync-runtime';
import { personalLoginEmail } from '@/lib/personal-login';
import { IS_STANDALONE } from '@/lib/runtime-mode';
import { useAppStore } from '@/lib/store';
import { repairAccountSourceTransportHealth } from '@/lib/account-source-relay-health';

type SyncState = PersonalSyncStatus;
export interface PersonalAccountValue extends SyncState {
  configured: boolean; ready: boolean; user: { id: string; email?: string } | null; scopeActive: boolean; allowSignup: boolean;
  login(identifier: string, password: string): Promise<void>;
  register(email: string, password: string): Promise<{ confirmationRequired: boolean }>;
  logout(discardPending?: boolean): Promise<boolean>;
  returnToLocal(): void;
  syncNow(): Promise<void>;
  importGuest(): Promise<void>;
  resolveConflicts(choice: 'local' | 'cloud'): Promise<void>;
  resetPassword(email: string): Promise<void>;
}
const initialState: SyncState = { status: 'local', pendingCount: 0, conflictCount: 0, lastSyncedAt: null, error: null };
const unavailable = async (): Promise<never> => { throw new Error('账号服务暂时不可用，请稍后重试。'); };
const AccountContext = createContext<PersonalAccountValue>({
  ...initialState, configured: false, ready: false, user: null, scopeActive: false, allowSignup: false,
  login: unavailable, register: unavailable, logout: unavailable, syncNow: unavailable,
  returnToLocal: () => undefined,
  importGuest: unavailable, resolveConflicts: unavailable, resetPassword: unavailable,
});
export const usePersonalAccount = () => useContext(AccountContext);

function authError(error: unknown): Error {
  const message = error instanceof Error ? error.message : '';
  if (/invalid.*(credentials|password)/i.test(message)) return new Error('账号或密码不正确。');
  if (/email.*not.*confirmed/i.test(message)) return new Error('请先完成邮箱验证，再登录。');
  if (/rate.*limit|too many/i.test(message)) return new Error('操作较频繁，请稍后再试。');
  if (/password.*(weak|short|least)/i.test(message)) return new Error('密码强度不足，请使用至少 8 位密码。');
  return new Error(/[\u3400-\u9fff]/.test(message) ? message : '账号服务暂时不可用，请检查网络后重试。');
}

export function PersonalAccountProvider({ children }: { children: ReactNode }) {
  const [configuration] = useState(() => {
    try { return { config: getSyncConfiguration(), error: null as string | null }; }
    catch (error) { return { config: null, error: authError(error).message }; }
  });
  const config = configuration.config;
  const [state, setState] = useState<SyncState>(initialState);
  const [user, setUser] = useState<PersonalAccountValue['user']>(null);
  const [ready, setReady] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const [verifiedScope, setVerifiedScope] = useState(false);
  const [relayHealthReady, setRelayHealthReady] = useState(false);
  const runtime = useRef<PersonalSyncRuntime | null>(null);
  const client = useRef<SupabaseClient | null>(null);
  const actionInProgress = useRef(false);
  const transitioning = useRef(false);
  const generation = useRef(0);
  const stop = useCallback(() => {
    generation.current += 1;
    runtime.current?.stop();
    runtime.current = null;
  }, []);

  useEffect(() => {
    if (!verifiedScope || !IS_STANDALONE) return;
    const prepare = () => { repairAccountSourceTransportHealth(); setRelayHealthReady(true); };
    if (useAppStore.persist.hasHydrated()) prepare();
    else return useAppStore.persist.onFinishHydration(prepare);
  }, [verifiedScope]);

  const returnToGuest = useCallback(() => {
    transitioning.current = true;
    actionInProgress.current = true;
    stop();
    try {
      flushPendingPersist();
      setActiveAccountScope(null);
      window.location.reload();
    } catch (error) {
      transitioning.current = false; actionInProgress.current = false;
      setState((previous) => ({ ...previous, status: 'error', error: authError(error).message }));
    }
  }, [stop]);

  useEffect(() => {
    let alive = true;
    let authRevision = 0;
    setHydrated(true);
    if (!config) {
      setReady(true);
      setState({ ...initialState, error: configuration.error });
      return;
    }
    const api = getPersonalSyncClient(config);
    client.current = api;
    const start = (session: Session | null) => {
      if (!alive) return;
      if (!ACTIVE_ACCOUNT_SCOPE) { setUser(null); setReady(true); return; }
      if (!session || session.user.id !== ACTIVE_ACCOUNT_SCOPE.userId || config.url !== ACTIVE_ACCOUNT_SCOPE.endpoint) {
        stop(); setUser(null); setVerifiedScope(false); setReady(true);
        setState((previous) => ({ ...previous, status: 'auth-required', error: '当前账号状态尚未确认，请重新登录。' }));
        return;
      }
      setUser({ id: session.user.id, email: session.user.email });
      setVerifiedScope(true); setReady(true);
      if (runtime.current) return;
      const currentGeneration = ++generation.current;
      const instance = new PersonalSyncRuntime(api, ACTIVE_ACCOUNT_SCOPE, (next: SyncState) => {
        if (alive && generation.current === currentGeneration) setState(next);
      });
      runtime.current = instance;
      void instance.start().catch((error: unknown) => {
        if (alive && generation.current === currentGeneration) setState((previous) => ({ ...previous, status: 'error', error: authError(error).message }));
      });
    };
    const handleAuth = (event: AuthChangeEvent, session: Session | null) => {
      if (!alive || actionInProgress.current) return;
      const revision = ++authRevision;
      const changedUser = !!ACTIVE_ACCOUNT_SCOPE && !!session && session.user.id !== ACTIVE_ACCOUNT_SCOPE.userId;
      // Stop synchronously before deferring any work: an old runtime must never receive a new account's token.
      if (event === 'SIGNED_OUT' || changedUser) {
        stop(); setVerifiedScope(false);
        if (ACTIVE_ACCOUNT_SCOPE) queueMicrotask(() => { if (alive && revision === authRevision && !actionInProgress.current) returnToGuest(); });
        else setUser(null);
        return;
      }
      queueMicrotask(() => { if (alive && revision === authRevision && !actionInProgress.current) start(session); });
    };
    const { data: { subscription } } = api.auth.onAuthStateChange(handleAuth);
    const initialAuthRevision = authRevision;
    void api.auth.getSession().then(({ data, error }) => {
      if (!alive || actionInProgress.current || initialAuthRevision !== authRevision) return;
      if (error) {
        stop(); setReady(true);
        setState((previous) => ({ ...previous, status: ACTIVE_ACCOUNT_SCOPE ? 'auth-required' : 'local', error: authError(error).message }));
      } else start(data.session);
    }).catch((error: unknown) => {
      if (alive && !actionInProgress.current && initialAuthRevision === authRevision) { stop(); setReady(true); setState((previous) => ({ ...previous, status: ACTIVE_ACCOUNT_SCOPE ? 'auth-required' : 'local', error: authError(error).message })); }
    });
    const onStorage = (event: StorageEvent) => {
      // Explicit logout owns cache cleanup. Another tab may clear the scope marker
      // after the auth broadcast; do not reload this tab before cleanup finishes.
      if (actionInProgress.current || transitioning.current) return;
      if (event.key !== null && event.key !== ACCOUNT_SCOPE_KEY) return;
      if (scopeId(readActiveAccountScope()) !== scopeId(ACTIVE_ACCOUNT_SCOPE)) {
        authRevision += 1;
        transitioning.current = true; actionInProgress.current = true;
        stop(); setVerifiedScope(false); window.location.reload();
      }
    };
    window.addEventListener('storage', onStorage);
    return () => { alive = false; subscription.unsubscribe(); window.removeEventListener('storage', onStorage); stop(); };
  }, [config, configuration.error, stop, returnToGuest]);

  const requireClient = () => {
    if (!config || !client.current) throw new Error('同步服务尚未配置，暂时不能登录。');
    return client.current;
  };
  const activate = (session: Session | null, expectedId?: string) => {
    if (!config || !session?.user.id || (expectedId && session.user.id !== expectedId)) throw new Error('账号验证结果不完整，请重新登录。');
    flushPendingPersist();
    setActiveAccountScope({ userId: session.user.id, endpoint: config.url });
    transitioning.current = true;
    window.location.reload();
  };
  const login = async (identifier: string, password: string) => {
    if (actionInProgress.current) throw new Error('账号操作正在进行，请稍候。');
    const email = personalLoginEmail(identifier);
    actionInProgress.current = true; stop();
    try {
      const { data, error } = await requireClient().auth.signInWithPassword({ email, password });
      if (error) throw error;
      activate(data.session, data.user?.id);
    } catch (error) { throw authError(error); }
    finally { if (!transitioning.current) actionInProgress.current = false; }
  };
  const register = async (email: string, password: string) => {
    if (!isPersonalSignupEnabled()) throw new Error('当前未开放自助注册，请联系管理员创建账号。');
    if (actionInProgress.current) throw new Error('账号操作正在进行，请稍候。');
    if (password.length < 8) throw new Error('请使用至少 8 位密码。');
    actionInProgress.current = true; stop();
    try {
      const { data, error } = await requireClient().auth.signUp({ email: email.trim(), password });
      if (error) throw error;
      if (data.session) activate(data.session, data.user?.id);
      return { confirmationRequired: !data.session };
    } catch (error) { throw authError(error); }
    finally { if (!transitioning.current) actionInProgress.current = false; }
  };
  const logout = async (discardPending = false) => {
    if (actionInProgress.current) throw new Error('账号操作正在进行，请稍候。');
    if (ACTIVE_ACCOUNT_SCOPE && !discardPending && (!runtime.current || !await runtime.current.prepareLogout(false))) return false;
    if (ACTIVE_ACCOUNT_SCOPE && discardPending && runtime.current) await runtime.current.prepareLogout(true);
    actionInProgress.current = true; stop();
    try {
      const { error } = await requireClient().auth.signOut({ scope: 'local' });
      if (error) throw error;
      // Unmount readers/writers before deleting the private cache. Guest data is never touched.
      flushSync(() => { setVerifiedScope(false); setReady(false); setUser(null); });
      if (ACTIVE_ACCOUNT_SCOPE) await clearAccountCache(ACTIVE_ACCOUNT_SCOPE);
      returnToGuest();
      return true;
    } catch (error) {
      setVerifiedScope(false); setReady(true);
      setState((previous) => ({ ...previous, status: 'auth-required', error: authError(error).message }));
      throw authError(error);
    }
    finally { if (!transitioning.current) actionInProgress.current = false; }
  };
  const requireRuntime = () => {
    if (!runtime.current || !verifiedScope) throw new Error('请重新登录后同步，现有本机资料仍然保留。');
    return runtime.current;
  };
  const value: PersonalAccountValue = {
    ...state, configured: !!config, ready, user, scopeActive: !!ACTIVE_ACCOUNT_SCOPE, allowSignup: isPersonalSignupEnabled(),
    login, register, logout, returnToLocal: returnToGuest,
    syncNow: () => requireRuntime().syncNow(),
    importGuest: () => requireRuntime().importGuest(),
    resolveConflicts: (choice) => requireRuntime().resolveConflicts(choice),
    resetPassword: async () => { throw new Error('当前版本暂不支持自助重设密码，请联系账号管理员。'); },
  };
  return (
    <AccountContext.Provider value={value}>
      {!hydrated || (ACTIVE_ACCOUNT_SCOPE && verifiedScope && IS_STANDALONE && !relayHealthReady)
        ? <div role="status" className="flex min-h-screen items-center justify-center text-sm text-muted">正在准备应用…</div> : ACTIVE_ACCOUNT_SCOPE && !verifiedScope ? (
        <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center gap-4 px-6 text-content">
          <h1 className="text-xl font-semibold">{ready ? '账号暂时无法确认' : '正在确认个人账号…'}</h1>
          {ready && <><p role="status" className="text-sm leading-relaxed text-muted">{state.error || '同步服务暂时不可用。原账号资料仍保存在本机，没有合并到游客模式。'}</p>
            <button type="button" className="btn-primary min-h-11" onClick={() => window.location.reload()}>重试账号连接</button>
            <button type="button" className="btn-ghost min-h-11" onClick={returnToGuest}>返回本机模式，保留账号资料</button></>}
        </div>
      ) : children}
    </AccountContext.Provider>
  );
}
