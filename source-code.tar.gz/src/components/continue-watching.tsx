'use client';

import Link from 'next/link';
import { requestAppPanel } from '@/lib/app-navigation';
import { formatTime } from '@/lib/utils';
import { HomeArtwork } from './home-artwork';
import type { HomeResumeTarget } from './home-viewing';

/** Already selected by the shared history read; the hero is never duplicated here. */
export function ContinueWatching({ items }: { items: readonly HomeResumeTarget[] }) {
  if (!items.length) return null;
  return <section className="home-continue" aria-labelledby="continue-watching-title">
    <div className="home-media-section-heading">
      <h2 id="continue-watching-title">继续观看</h2>
      <button type="button" className="home-history-link" onClick={() => requestAppPanel('history')}>查看全部<span aria-hidden="true">›</span></button>
    </div>
    <div className="home-resume-list">
      {items.map(({ item, href }) => <Link key={item.id} href={href} aria-label={`继续观看 ${item.title}`}
        className="home-resume-card" data-history-id={item.id}>
        <div className="home-resume-cover">
          <HomeArtwork key={`${item.title}:${item.pic}`} title={item.title} pic={item.pic} variant="card" />
          <span className="home-resume-play" aria-hidden="true"><svg viewBox="0 0 16 16" fill="currentColor"><path d="m5 2 9 6-9 6V2Z" /></svg></span>
          {item.percent !== null && <div className="home-resume-progress" aria-hidden="true"><div style={{ width: `${item.percent}%` }} /></div>}
        </div>
        <div className="home-resume-copy">
          <p className="home-resume-title" title={item.title}>{item.title}</p>
          <p className="home-resume-position">{item.hasEpisodeContext ? `第 ${item.episodeIndex + 1} 集 · ` : ''}
            {formatTime(item.playbackPosition)}{item.duration > 0 ? ` / ${formatTime(item.duration)}` : ' · 已观看'}</p>
        </div>
      </Link>)}
    </div>
  </section>;
}
