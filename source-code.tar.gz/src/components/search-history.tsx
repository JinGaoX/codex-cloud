'use client';

import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from 'react';
import { useQuery } from '@tanstack/react-query';
import { addSearchHistory, clearSearchHistory, db, MAX_SEARCH_HISTORY, removeSearchHistory, restoreSearchHistory } from '@/lib/db';
import { cn } from '@/lib/utils';
import { useToast } from './toast';
import { Icon } from './icon';

/** Disclosure changes presentation only; the existing database limit is unchanged. */
const COLLAPSED_HISTORY_LIMIT = 5;

/**
 * 「最近搜索」下拉的交互逻辑：聚焦展开、输入时按关键字过滤（浏览器地址栏式交互）。
 * 首页搜索框与顶栏搜索框共用本 hook 与下方 SearchHistoryDropdown，避免两处实现分叉。
 */
export function useSearchHistory(input: string) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState(false);
  // Keep identity rather than an index: deletion/refetch must not highlight a different row.
  const [activeText, setActiveText] = useState<string | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const history = useQuery({
    queryKey: ['searchHistory'],
    queryFn: () => db.searchHistory.orderBy('timestamp').reverse().limit(MAX_SEARCH_HISTORY).toArray(),
  });

  const allMatches = useMemo(() => {
    const all = history.data ?? [];
    const keyword = input.trim().toLowerCase();
    return keyword ? all.filter((h) => h.text.toLowerCase().includes(keyword)) : all;
  }, [history.data, input]);
  const matches = useMemo(() => expanded ? allMatches : allMatches.slice(0, COLLAPSED_HISTORY_LIMIT), [allMatches, expanded]);
  const activeIndex = activeText === null ? -1 : matches.findIndex((item) => item.text === activeText);

  // 唯一命中项与输入内容完全一致时不展开：否则会盖住用户刚敲进去的内容
  const visible = open && allMatches.length > 0 && !(allMatches.length === 1 && allMatches[0].text === input.trim());

  // 点按下拉之外的任意位置收起
  useEffect(() => {
    if (!visible) return;
    const onPointerDown = (e: PointerEvent) => {
      if (!containerRef.current?.contains(e.target as Node)) {
        setOpen(false);
        setExpanded(false);
        setActiveText(null);
      }
    };
    document.addEventListener('pointerdown', onPointerDown);
    return () => document.removeEventListener('pointerdown', onPointerDown);
  }, [visible]);

  const close = () => {
    setOpen(false);
    setExpanded(false);
    setActiveText(null);
  };

  /** 记录一次搜索；顺带刷新下拉数据（历史也会在播放页被写入） */
  const record = (text: string) => {
    addSearchHistory(text)
      .then(() => history.refetch())
      .catch(() => {});
  };

  const remove = (text: string) => {
    setActiveText(null);
    removeSearchHistory(text).then(() => history.refetch());
  };

  const clearAll = async () => {
    const snapshot = history.data ?? [];
    if (snapshot.length === 0) return;
    close();
    await clearSearchHistory();
    await history.refetch();
    // 轻量破坏性操作：给一次撤销机会，不打断式弹确认
    toast('已清空搜索记录', 'info', {
      action: {
        label: '撤销',
        onClick: () => {
          restoreSearchHistory(snapshot).then(() => history.refetch());
        },
      },
    });
  };

  const onFocus = () => {
    setOpen(true);
    history.refetch();
  };

  const onKeyDown = (e: KeyboardEvent<HTMLInputElement>, onPick: (text: string) => void) => {
    if (e.key === 'Escape') {
      close();
      return;
    }
    if (!visible) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActiveText((text) => {
        const index = matches.findIndex((item) => item.text === text);
        return matches[(index + 1) % matches.length].text;
      });
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActiveText((text) => {
        const index = matches.findIndex((item) => item.text === text);
        return matches[index <= 0 ? matches.length - 1 : index - 1].text;
      });
    } else if (e.key === 'Enter' && activeIndex >= 0) {
      // 有高亮项时 Enter 采用该条历史，不再提交输入框原文
      e.preventDefault();
      onPick(matches[activeIndex].text);
    }
  };

  return {
    visible,
    matches,
    totalCount: allMatches.length,
    expanded,
    toggleExpanded: () => { setActiveText(null); setExpanded((value) => !value); },
    activeIndex,
    containerRef,
    close,
    record,
    remove,
    clearAll,
    onFocus,
    onKeyDown,
    /** 输入变化时清掉键盘高亮，避免指向已过滤掉的项 */
    resetActive: () => { setActiveText(null); setExpanded(false); },
  };
}

/**
 * A bounded floating list: five recent matches first, with explicit disclosure.
 * The hook supplies exactly the rendered rows, including keyboard selection.
 */
export function SearchHistoryDropdown({
  id,
  matches,
  activeIndex,
  totalCount,
  expanded,
  onToggleExpand,
  onPick,
  onRemove,
  onClearAll,
}: {
  /** 同时作为 listbox 的 id 前缀：外部输入框用 aria-controls 指向它 */
  id: string;
  matches: { text: string }[];
  activeIndex: number;
  totalCount: number;
  expanded: boolean;
  onToggleExpand: () => void;
  onPick: (text: string) => void;
  onRemove: (text: string) => void;
  onClearAll: () => void;
}) {
  const listRef = useRef<HTMLUListElement>(null);
  useEffect(() => {
    if (activeIndex < 0) return;
    const list = listRef.current;
    const row = list?.children.item(activeIndex);
    if (!list || !(row instanceof HTMLElement)) return;
    const bounds = list.getBoundingClientRect(), item = row.getBoundingClientRect();
    if (item.top < bounds.top) list.scrollTop -= bounds.top - item.top;
    else if (item.bottom > bounds.bottom) list.scrollTop += item.bottom - bounds.bottom;
  }, [activeIndex]);
  return (
    <div
      className={cn(
        'search-history-panel absolute left-0 right-0 top-full z-40 overflow-hidden text-left',
        'rounded-b-xl bg-surface-raised shadow-lg'
      )}
    >
      <div className="search-history-header flex items-center justify-between pl-4 pr-2 border-b border-line">
        <span className="flex items-center gap-1.5 text-xs text-faint">
          <Icon name="clock" className="w-3.5 h-3.5" />
          最近搜索
        </span>
        <button
          type="button"
          className="search-history-clear min-h-11 px-2 rounded-md text-xs text-faint hover:text-danger hover:bg-hover transition-colors"
          onClick={onClearAll}
        >
          清空
        </button>
      </div>
      <ul
        ref={listRef}
        id={id}
        role="listbox"
        aria-label="最近搜索"
        className="search-history-list max-h-[min(45dvh,320px)] overflow-y-auto scrollbar-thin py-1"
      >
        {matches.map((h, i) => (
          <li
            key={h.text}
            id={`${id}-${i}`}
            role="option"
            aria-selected={i === activeIndex}
            className={cn('search-history-row flex items-center hover:bg-hover', i === activeIndex && 'bg-hover')}
          >
            <button
              type="button"
              className="search-history-pick min-h-11 flex-1 min-w-0 pl-4 pr-2 py-2.5 text-left text-sm text-content truncate"
              onClick={() => onPick(h.text)}
            >
              {h.text}
            </button>
            <button
              type="button"
              className="search-history-remove min-h-11 min-w-11 shrink-0 inline-flex items-center justify-center mr-1 rounded-md text-faint hover:text-danger hover:bg-chip transition-colors"
              aria-label={`删除搜索记录 ${h.text}`}
              onClick={() => onRemove(h.text)}
            >
              <Icon name="close" className="w-3.5 h-3.5" />
            </button>
          </li>
        ))}
      </ul>
      {totalCount > COLLAPSED_HISTORY_LIMIT && <button
        type="button"
        className="search-history-toggle min-h-11 w-full px-4 text-left text-sm text-muted hover:text-content hover:bg-hover"
        aria-expanded={expanded}
        aria-controls={id}
        onClick={onToggleExpand}
      >{expanded ? '收起搜索记录' : `展开其余 ${totalCount - matches.length} 条`}</button>}
    </div>
  );
}
