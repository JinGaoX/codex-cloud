'use client';

import { useEffect, useRef, useState } from 'react';
import Artplayer from 'artplayer';
import Hls, { type HlsConfig } from 'hls.js';
import type { PlaybackInfo } from '@/lib/playback-info';
import { createPlaybackTelemetry, type PlaybackResolution } from '@/lib/playback-telemetry';
import { PlaybackProgressGate } from '@/lib/playback-progress-gate';
import { requestVideoPlayback } from '@/lib/playback-start';

import { PlaybackRecovery, describeHlsError } from '@/lib/playback-recovery';
import { createHlsLoader } from '@/lib/hls-loader';
import { createHlsPtsFilterSession, type HlsPtsFilterSession } from '@/lib/hls-pts-filter';
import { createHlsSpliceContinuitySession, type HlsSpliceContinuitySession } from '@/lib/hls-splice-continuity';
import { prepareNativePtsAds, attachNativePtsAdSkips } from '@/lib/native-pts-ads';
import { createHlsAdTimeline, filteredToSourceTime, sourceToFilteredTime, type HlsAdTimeline } from '@/lib/hls-ad-timeline';
import {
  getVideoPrefetcher,
  getNextEpisodePrefetcher,
} from '@/lib/video-prefetcher';
import { loadCacheSettings } from '@/lib/video-cache';
import { formatTime } from '@/lib/utils';
import { prefersTouchPointer } from '@/lib/touch-pointer';
import { isAppleMobile, isFileMedia, selectMediaTransport } from '@/lib/media-transport';
import { IS_STANDALONE } from '@/lib/runtime-mode';
import { appPath } from '@/lib/app-path';
import { standaloneMediaUrl } from '@/lib/standalone-media';
import {
  findActiveSegment,
  findCrossedEnding,
  resolveSegments,
  SEGMENT_COLORS,
  SEGMENT_LABELS,
  type ResolvedSegment,
  type SkipMark,
  type SkipSegment,
} from '@/lib/skip-marks';
import { ART_DEFAULT_CONTROL_HIDE_MS } from '@/lib/control-hide';
import { attachPlayerControlVisibility, SURFACE_LONG_PRESS_MS } from '@/lib/player-controls';

/** 片段时间统一保留 1 位小数：与面板展示保持一致，避免浮点尾巴 */
const round1 = (v: number) => Math.round(v * 10) / 10;

/**
 * 播放器外壳：ArtPlayer + hls.js（旧版 player.js 的 React 化）。
 * 保留：广告分片过滤、自动连播回调、进度回调、快捷键、移动端长按倍速、错误恢复。
 * 移除：DOM 手工操作、watch.html 跳转链、localStorage 状态总线。
 *
 * 关键设计：ArtPlayer 实例只在挂载时创建一次，换集（url 变化）只「切换 HLS 源」
 * 而不销毁重建。否则在「网页全屏（页面全屏）」下整实例重建会丢失全屏上下文、
 * 重建 <video> 元素，触发「黑屏有声」的渲染竞态。
 */

/** 暴露给播放页的读取接口：「记录当前」需要比 5s 节流进度回调更精确的位置 */
export interface PlayerSkipApi {
  getCurrentTime(): number;
  getDuration(): number;
  /** 跳转到指定位置（「试跳」/标记片段起点用） */
  seek(seconds: number): void;
  /** 暂停播放：记录标记前先定格，避免点击到读取之间视频继续走 */
  pause(): void;
  /** 当前是否处于暂停状态 */
  isPaused(): boolean;
  /** Request playback synchronously from an episode tap, after committing its props. */
  play(): void;
}

interface PlayerShellProps {
  url: string;
  title: string;
  adFilter: boolean;
  autoplayNext: boolean;
  /** 当前剧的跳过片段标记（父级按归一化剧名查好后传入，换集/换源不变） */
  skipMark?: SkipMark;
  /**
   * 自动跳过标记的片段：片头/中段跳到片段末尾，片尾（连续播放越过起点）结束本集。
   * 是否连播下一集仍由 autoplayNext 决定。
   */
  autoSkipSegments: boolean;
  /** 中段两步态的起点：由页面层持有，面板与快捷键共用同一份状态 */
  pendingStart: number | null;
  /** 更新中段起点；null 表示取消或已消费 */
  onPendingStart: (start: number | null) => void;
  /** 播放器创建/销毁时回调，供播放页读取精确播放位置 */
  onPlayerApi?: (api: PlayerSkipApi | null) => void;
  /** 快捷键（Shift+I/O/S/E）记录片段时回调，由父级做校验与写入 */
  onRecordSegment?: (segment: SkipSegment) => void;
  /** 剧集标识 `${source}:${vodId}:${episodeIndex}`（片段缓存按集淘汰的分组键） */
  episodeKey?: string;
  /** 下一集 m3u8 地址：当前集预取完成后预热下一集前 7 分钟 */
  nextUrl?: string;
  nextEpisodeKey?: string;
  /** 进度恢复：优先 URL position，其次查询该回调（返回 0 表示无记录） */
  getRestorePosition?: () => number | Promise<number>;
  onTimeUpdate?: (position: number, duration: number) => void;
  onEnded?: () => void;
  onPause?: (position: number, duration: number) => void;
  /** Checked before autoplay and on native media events so iOS background throttling cannot resume an expired timer. */
  canPlay?: () => boolean;
  timerStopped?: boolean;
  onResumeFromTimer?: () => void;
  /** 当前装载媒体的真实解码尺寸，不使用历史最高值或清单声明。 */
  onResolution?: (resolution: PlaybackResolution | null, sourceUrl: string, identity: string) => void;
  onPlaybackInfo?: (info: PlaybackInfo | null, sourceUrl: string, identity: string) => void;
  /** 恢复策略判源不可用（重试耗尽/格式硬失败）时回调：父级弹出换源面板 */
  onRequestSwitchSource?: (reason: string) => void;
  /** 控制条上的上一集 / 下一集：不在播放器里也能切集，省得回到页面按钮 */
  onPrevEpisode?: () => void;
  onNextEpisode?: () => void;
  hasPrevEpisode?: boolean;
  hasNextEpisode?: boolean;
}

export function PlayerShell({
  url,
  title,
  adFilter,
  autoplayNext,
  skipMark,
  autoSkipSegments,
  pendingStart,
  onPendingStart,
  onPlayerApi,
  onRecordSegment,
  episodeKey,
  nextUrl,
  nextEpisodeKey,
  getRestorePosition,
  onTimeUpdate,
  onEnded,
  onPause,
  canPlay,
  timerStopped,
  onResumeFromTimer,
  onResolution,
  onPlaybackInfo,
  onRequestSwitchSource,
  onPrevEpisode,
  onNextEpisode,
  hasPrevEpisode,
  hasNextEpisode,
}: PlayerShellProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const artRef = useRef<any>(null);
  const hlsRef = useRef<Hls | null>(null);
  const [error, setError] = useState('');
  const [hint, setHint] = useState('');
  // 起播前的品牌占位图（沿用旧版 nomedia 素材），实际开始播放后隐藏
  const [showPoster, setShowPoster] = useState(true);
  const [needsPlayGesture, setNeedsPlayGesture] = useState(false);
  const [playInterrupted, setPlayInterrupted] = useState(false);
  const [adScanning, setAdScanning] = useState(false);
  const adSessionRef = useRef<HlsPtsFilterSession | null>(null);
  const adSpliceRef = useRef<HlsSpliceContinuitySession | null>(null);
  const adAbortRef = useRef<AbortController | null>(null);
  const nativeAdCleanupRef = useRef<(() => void) | null>(null);
  const adTimelineRef = useRef<HlsAdTimeline | null>(null);
  const adNoticeRef = useRef(false);
  const hintTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // 始终持有最新 props/回调，避免重建播放器
  const propsRef = useRef({
    url, title, adFilter, autoplayNext, skipMark, autoSkipSegments,
    pendingStart, onPendingStart, onPlayerApi, onRecordSegment,
    episodeKey, nextUrl, nextEpisodeKey,
    getRestorePosition, onTimeUpdate, onEnded, onPause, canPlay, onResumeFromTimer, onResolution, onPlaybackInfo, onRequestSwitchSource,
    onPrevEpisode, onNextEpisode, hasPrevEpisode, hasNextEpisode,
  });
  propsRef.current = {
    url, title, adFilter, autoplayNext, skipMark, autoSkipSegments,
    pendingStart, onPendingStart, onPlayerApi, onRecordSegment,
    episodeKey, nextUrl, nextEpisodeKey,
    getRestorePosition, onTimeUpdate, onEnded, onPause, canPlay, onResumeFromTimer, onResolution, onPlaybackInfo, onRequestSwitchSource,
    onPrevEpisode, onNextEpisode, hasPrevEpisode, hasNextEpisode,
  };

  // 跨集共享、每次换集重置的播放链路状态
  // 媒体健康度：音频轨可播不代表视频轨正常（「黑屏但有声」的假死态）。
  // 仅当有分片真正进入 MSE buffer 后才视为恢复，错误遮罩才能被清除。
  const mediaHealthyRef = useRef(true);
  const playbackStartedRef = useRef(false);
  const progressGateRef = useRef(new PlaybackProgressGate());
  // 起播阶段的 video 元素级错误允许自愈重试一次（重建 hls/MSE）
  const videoErrorRetryUsedRef = useRef(false);
  // 进度恢复每集只执行一次（MANIFEST_PARSED 可能因代理回退再次触发）
  const restoredRef = useRef(false);
  // 某些 HLS 源在 MANIFEST_PARSED 时 duration 仍未就绪，延迟到媒体元数据可用后恢复
  const restoreCleanupRef = useRef<(() => void) | null>(null);
  const telemetryRef = useRef<ReturnType<typeof createPlaybackTelemetry> | null>(null);
  // timeupdate 续跑预取的游标：必须按集清零，否则会沿用上一集的时间戳推迟首次续跑
  const lastPrefetchEnsureRef = useRef(0);
  // setupMedia 可能改走代理形式，video:error 重试要用最近一次的地址
  const currentMediaUrlRef = useRef(url);
  // 本集的恢复策略实例：跨直连/代理两级重建共享计数
  const recoveryRef = useRef<PlaybackRecovery | null>(null);
  // Incremented for every media load so a slow IndexedDB read cannot seek a later episode.
  const mediaLoadIdRef = useRef(0);
  const loadedMediaRef = useRef<{ url: string; identity: string } | null>(null);
  const playRequestIdRef = useRef(0);
  const playPendingRef = useRef(false);
  const nativeProxyFallbackRef = useRef(false);
  // Render may already contain the next episode's props while the old media still emits events.
  const progressCallbacksRef = useRef({ onTimeUpdate, onPause, onEnded });
  const loadedEpisodeIdentityRef = useRef(episodeKey ?? url);
  if (loadedEpisodeIdentityRef.current === (episodeKey ?? url)) {
    // Keep settings such as autoplayNext current without assigning old-media events to a new episode.
    progressCallbacksRef.current = { onTimeUpdate, onPause, onEnded };
  }
  // 自然播完标记，卸载时不回写进度（避免覆盖「已看完」记录）
  const endedRef = useRef(false);
  // 跳过片段：每集已处理的片段（按 type:start 去重），换集时重置（见 loadEpisode）
  const handledSegmentsRef = useRef<Set<string>>(new Set());
  // 被「撤销」过的片段：本集不再自动跳（否则撤回到片段内会被立刻再跳走），但仍保留提示按钮
  const suppressedAutoRef = useRef<Set<string>>(new Set());
  // 上一次 timeupdate 的位置：用于区分「连续播放越过片尾」与「拖动进度条」
  const lastSampleRef = useRef(0);
  // 跳过按钮提示；用 ref 比较，避免 timeupdate 每 250ms 触发重渲染
  const [skipPrompt, setSkipPrompt] = useState<ResolvedSegment | null>(null);
  const skipPromptRef = useRef<ResolvedSegment | null>(null);
  // 刚跳过的片段：给一个撤销窗口，误标导致跳掉正片时不必手动拖回去
  const [undoSkip, setUndoSkip] = useState<{ from: number; segment: ResolvedSegment } | null>(null);
  const undoTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const showHint = (text: string) => {
    setHint(text);
    if (hintTimerRef.current) clearTimeout(hintTimerRef.current);
    hintTimerRef.current = setTimeout(() => setHint(''), 2500);
  };

  const requestPlay = (video: HTMLVideoElement) => {
    if (propsRef.current.canPlay?.() === false) return;
    const loadId = mediaLoadIdRef.current;
    const requestId = ++playRequestIdRef.current;
    playPendingRef.current = true;
    setNeedsPlayGesture(false);
    setPlayInterrupted(false);
    requestVideoPlayback(video, {
      isCurrent: () => loadId === mediaLoadIdRef.current && requestId === playRequestIdRef.current,
      onStarted: () => { playPendingRef.current = false; setNeedsPlayGesture(false); setPlayInterrupted(false); },
      onBlocked: () => { playPendingRef.current = false; setNeedsPlayGesture(true); },
      onInterrupted: () => {
        playPendingRef.current = false;
        // An explicit pause must stay paused. Offer recovery instead of leaving
        // an interrupted current request on an endless loading screen.
        if (video.paused) setPlayInterrupted(true);
      },
      onError: () => {
        playPendingRef.current = false;
        setError('播放未能开始，请重新加载或切换资源');
      },
    });
  };

  // Save progress and user marks on the source clock across native auto-seek,
  // MSE playlist filtering, retries and toggling the global filter.
  const sourceTime = () => filteredToSourceTime(artRef.current?.currentTime ?? 0, adTimelineRef.current);
  const sourceDuration = () => adTimelineRef.current?.originalDuration ?? artRef.current?.duration ?? 0;
  const emitWatchedProgress = (kind: 'onTimeUpdate' | 'onPause') => {
    const snapshot = progressGateRef.current.take();
    if (snapshot) progressCallbacksRef.current[kind]?.(snapshot.position, snapshot.duration);
  };

  // 片段缓存开启时调大 hls.js 自身缓冲，缓冲之外的空窗由预取器补齐
  const buildHlsConfig = (): Partial<HlsConfig> => {
    const p = propsRef.current;
    const loadId = mediaLoadIdRef.current;
    const cacheEnabled = !IS_STANDALONE && !p.adFilter && loadCacheSettings().enabled && !!p.episodeKey;
    return {
      debug: false,
      enableWorker: true,
      backBufferLength: 90,
      maxBufferLength: cacheEnabled ? 120 : 30,
      maxMaxBufferLength: cacheEnabled ? 600 : 60,
      maxBufferSize: (cacheEnabled ? 90 : 30) * 1000 * 1000,
      maxBufferHole: 0.5,
      fragLoadingMaxRetry: 6,
      fragLoadingRetryDelay: 1000,
      manifestLoadingMaxRetry: 3,
      manifestLoadingRetryDelay: 1000,
      startLevel: -1,
      abrEwmaDefaultEstimate: 500_000,
      appendErrorMaxRetry: 5,
      // 组合 loader：广告过滤（blockAd 随设置）+ 片段缓存命中（cacheEnabled）
      loader: createHlsLoader(Hls, {
        blockAd: p.adFilter,
        ptsSession: adSessionRef.current ?? undefined,
        spliceSession: adSpliceRef.current ?? undefined,
        onAdScan: () => {
          if (loadId === mediaLoadIdRef.current && !playbackStartedRef.current) setAdScanning(true);
        },
        onAdFilterResult: (result, originalContent) => {
          if (loadId !== mediaLoadIdRef.current) return;
          setAdScanning(false);
          // Master/audio playlists must not clear the active video timeline.
          if (result.totalGroups > 0) {
            adTimelineRef.current = createHlsAdTimeline(originalContent, result.removedGroups);
          }
          if (result.removedGroups.length && !adNoticeRef.current) {
            adNoticeRef.current = true;
            showHint(`已过滤 ${result.removedGroups.length} 组插播片段`);
          }
        },
        cacheSegments: !IS_STANDALONE,
      }) as unknown as HlsConfig['loader'],
    };
  };

  // 当前集预取（episodeKey 缺省 = 关闭，见 ensure 内部 settings.enabled 判断）
  const ensurePrefetch = (mediaUrl: string, currentTime: number, horizonSeconds?: number) => {
    // A second inspector can time out differently and build a different timeline.
    // Keep normal player buffering while filtered playback owns its playlist.
    if (IS_STANDALONE || propsRef.current.adFilter) return;
    const p = propsRef.current;
    // Native HLS owns its segment buffer; do not fetch a duplicate copy in JavaScript.
    if (!p.episodeKey || !hlsRef.current || isFileMedia(mediaUrl)) return;
    getVideoPrefetcher().ensure({
      m3u8Url: mediaUrl,
      currentTime,
      episodeKey: p.episodeKey,
      horizonSeconds,
      adFilter: false,
      onProgress: (stats) => {
        // 当前集预取完成且存在下一集：用独立预取器预热下一集前 7 分钟
        if (stats.state === 'done' && p.nextUrl && p.nextEpisodeKey) {
          getNextEpisodePrefetcher().ensure({
            m3u8Url: p.nextUrl,
            currentTime: 0,
            episodeKey: p.nextEpisodeKey,
            horizonSeconds: 420,
            adFilter: false,
          });
        }
      },
    });
  };

  /** 切换提示状态；值相同直接返回，避免 timeupdate 高频 setState */
  const updateSkipPrompt = (next: ResolvedSegment | null) => {
    const prev = skipPromptRef.current;
    const same =
      prev === next ||
      (prev !== null &&
        next !== null &&
        prev.type === next.type &&
        prev.start === next.start &&
        prev.end === next.end);
    if (same) return;
    skipPromptRef.current = next;
    setSkipPrompt(next);
  };

  /** 片段去重键：按类型 + 起点，同一集内每段只处理一次 */
  const segmentKey = (s: ResolvedSegment) => `${s.type}:${s.start}`;

  /** 进度条区间可视化：在进度条轨道叠加半透明色带（颜色与面板图例共用 SEGMENT_COLORS） */
  const renderSkipMarks = () => {
    const art = artRef.current;
    const progress = art?.template.$progress;
    if (!progress) return;
    progress.querySelectorAll('[data-skip-segment]').forEach((el: Element) => el.remove());
    const duration = art.duration;
    if (!Number.isFinite(duration) || duration <= 0) return;
    const segments = resolveSegments(propsRef.current.skipMark, sourceDuration());
    for (const seg of segments) {
      const el = document.createElement('div');
      el.dataset.skipSegment = '1';
      el.title = `跳过${SEGMENT_LABELS[seg.type]}`;
      const start = sourceToFilteredTime(seg.start, adTimelineRef.current);
      const end = sourceToFilteredTime(seg.end, adTimelineRef.current);
      const left = (start / duration) * 100;
      const width = Math.max(0.4, ((end - start) / duration) * 100);
      el.style.cssText = `position:absolute;left:${left}%;width:${width}%;top:0;bottom:0;background:${SEGMENT_COLORS[seg.type]};pointer-events:none;`;
      progress.appendChild(el);
    }
  };

  /**
   * 跳到片段末尾并续跑预取；同步 lastSampleRef，避免下一拍被误判为「连续越过片尾」。
   * 返回是否成功：媒体未就绪导致赋值失败时返回 false，调用方不置已处理标记，
   * 下一次 timeupdate 会重新判定（保证「可重试」）。
   */
  const skipTo = (seconds: number): boolean => {
    const art = artRef.current;
    if (!art || !Number.isFinite(seconds) || seconds < 0) return false;
    try {
      art.currentTime = sourceToFilteredTime(seconds, adTimelineRef.current);
    } catch {
      return false;
    }
    lastSampleRef.current = seconds;
    ensurePrefetch(currentMediaUrlRef.current, seconds);
    return true;
  };

  /** 记录一次跳过（跳转前的位置）：给 12s 撤销窗口，误标导致跳掉正片时不用手动拖回去 */
  const rememberSkip = (from: number, segment: ResolvedSegment) => {
    setUndoSkip({ from, segment });
    if (undoTimerRef.current) clearTimeout(undoTimerRef.current);
    undoTimerRef.current = setTimeout(() => setUndoSkip(null), 12_000);
  };

  const undoLastSkip = () => {
    const last = undoSkip;
    if (!last) return;
    if (undoTimerRef.current) {
      clearTimeout(undoTimerRef.current);
      undoTimerRef.current = null;
    }
    // 撤销后把片段从「已处理」移除（按钮会重新出现），同时本集不再自动跳它：
    // 否则回到片段内会被下一次 timeupdate 立刻再跳走，形成"撤销→又被跳过"的死循环
    handledSegmentsRef.current.delete(segmentKey(last.segment));
    suppressedAutoRef.current.add(segmentKey(last.segment));
    skipTo(last.from);
    setUndoSkip(null);
    showHint('已撤回跳过');
  };

  /**
   * 跳过片尾：与自然播完共用 onEnded 链路（清进度 + 依 autoplayNext 连播下一集）。
   * endedRef 置 true 同时阻止 video:ended 重复回调，也避免卸载时把片尾进度回写。
   */
  const finishBySkip = (ending?: ResolvedSegment) => {
    const art = artRef.current;
    if (ending) handledSegmentsRef.current.add(segmentKey(ending));
    endedRef.current = true;
    updateSkipPrompt(null);
    setUndoSkip(null);
    try {
      art?.pause();
    } catch {
      /* 忽略 */
    }
    showHint('已跳过片尾');
    progressCallbacksRef.current.onEnded?.();
  };

  /**
   * 初始化/切换媒体：iOS 原生 HLS、MP4 直放，其余浏览器复用 hls.js。
   * allowProxyFallback：直连致命网络错误（CORS/防盗链/分片被拒）时，
   * 自动改走同源 cookie 鉴权的 /api/proxy 重试一次。
   * 注意：不销毁 ArtPlayer，只销毁并重建 hls，从而保留网页全屏等播放器状态。
   */
  const setupMedia = (video: HTMLVideoElement, mediaUrl: string, allowProxyFallback: boolean) => {
    if (IS_STANDALONE) {
      try { mediaUrl = standaloneMediaUrl(mediaUrl); }
      catch (reason) {
        setError(reason instanceof Error ? reason.message : '请使用可直接播放的 HTTPS 视频链接');
        setNeedsPlayGesture(false);
        return;
      }
    }
    video.setAttribute('playsinline', '');
    video.setAttribute('webkit-playsinline', '');
    const loadId = ++mediaLoadIdRef.current;
    playPendingRef.current = false;
    const hasResumePosition = playbackStartedRef.current;
    const resumePosition = hasResumePosition
      ? filteredToSourceTime(video.currentTime, adTimelineRef.current) : 0;
    const keepPaused = playbackStartedRef.current && video.paused;
    // A transport rebuild/restoration must wait for a new real playing event.
    progressGateRef.current.pause(sourceTime(), sourceDuration());
    const readRestorePosition = propsRef.current.getRestorePosition;
    telemetryRef.current?.dispose();
    telemetryRef.current = null;
    restoreCleanupRef.current?.();
    restoreCleanupRef.current = null;
    restoredRef.current = false;
    hlsRef.current?.destroy();
    hlsRef.current = null;
    adAbortRef.current?.abort();
    nativeAdCleanupRef.current?.();
    nativeAdCleanupRef.current = null;
    adSessionRef.current?.destroy();
    adSpliceRef.current?.destroy();
    adSpliceRef.current = null;
    adTimelineRef.current = null;
    adNoticeRef.current = false;
    setAdScanning(false);
    const adAbort = new AbortController();
    adAbortRef.current = adAbort;
    adSessionRef.current = propsRef.current.adFilter
      ? createHlsPtsFilterSession({ concurrency: 16, timeoutMs: 15_000 }) : null;
    if (propsRef.current.adFilter) {
      getVideoPrefetcher().stop();
      getNextEpisodePrefetcher().stop();
    }
    currentMediaUrlRef.current = mediaUrl;
    nativeProxyFallbackRef.current = !IS_STANDALONE && allowProxyFallback && !mediaUrl.startsWith('/api/proxy');
    setNeedsPlayGesture(false);
    setPlayInterrupted(false);
    const transport = selectMediaTransport(mediaUrl, {
      hlsJs: Hls.isSupported(),
      nativeHls: !!video.canPlayType('application/vnd.apple.mpegurl'),
      appleMobile: isAppleMobile(navigator.userAgent, navigator.platform, navigator.maxTouchPoints),
    });
    if (transport === 'hls' && propsRef.current.adFilter) {
      adSpliceRef.current = createHlsSpliceContinuitySession();
    }
    const logicalUrl = propsRef.current.url;
    const identity = propsRef.current.episodeKey ?? logicalUrl;
    loadedMediaRef.current = { url: logicalUrl, identity };
    const isCurrentMedia = () => loadId === mediaLoadIdRef.current && propsRef.current.url === logicalUrl
      && (propsRef.current.episodeKey ?? propsRef.current.url) === identity;
    const resolutionCallback = propsRef.current.onResolution;
    const infoCallback = propsRef.current.onPlaybackInfo;
    const telemetry = createPlaybackTelemetry(video, {
      nativeSourceUrl: transport === 'native' ? new URL(mediaUrl, window.location.href).href : undefined,
      isCurrent: isCurrentMedia,
      onResolution: (resolution) => resolutionCallback?.(resolution, logicalUrl, identity),
      onInfo: (info) => infoCallback?.(info, logicalUrl, identity),
    });
    telemetryRef.current = telemetry;

    let restoreInFlight = false;
    const restoreAndStart = async () => {
      if (!isCurrentMedia() || restoredRef.current || restoreInFlight) return;

      // MANIFEST_PARSED 早于 loadedmetadata 的 HLS 源很常见；没有有效时长时
      // 先不消费 restoredRef，等 loadedmetadata/durationchange 后再重试。
      const duration = artRef.current?.duration || video.duration || 0;
      if (!Number.isFinite(duration) || duration <= 0) return;

      restoreInFlight = true;
      try {
        // Storage failure must not prevent playback or leave restore listeners active forever.
        const saved = hasResumePosition
          ? resumePosition
          : await Promise.resolve().then(() => readRestorePosition?.() ?? 0).catch(() => 0);
        if (!isCurrentMedia()) return;
        const currentDuration = artRef.current?.duration || video.duration || duration;
        let prefetchAnchor = video.currentTime;
        const target = sourceToFilteredTime(saved, adTimelineRef.current);
        if (Number.isFinite(target) && target > 0 && Number.isFinite(currentDuration) && target < currentDuration - 2) {
          video.currentTime = target;
          prefetchAnchor = target;
          showHint(`已从 ${formatTime(saved)} 继续播放`);
        }
        restoredRef.current = true;
        restoreCleanupRef.current?.();
        restoreCleanupRef.current = null;
        ensurePrefetch(mediaUrl, prefetchAnchor);
        if (propsRef.current.canPlay?.() === false) {
          video.pause();
          return;
        }
        if (keepPaused) {
          video.pause();
          setNeedsPlayGesture(false);
          return;
        }
        // An episode tap may already have a pending play() that will start once
        // data arrives. Do not replace that trusted request with a second one.
        if (video.paused && !playPendingRef.current) requestPlay(video);
      } catch {
        // IndexedDB 读取失败时不阻塞播放，后续事件仍可再次尝试恢复。
      } finally {
        restoreInFlight = false;
      }
    };

    const restoreEvents = ['loadedmetadata', 'durationchange', 'canplay'] as const;
    const onRestoreEvent = () => { void restoreAndStart(); };
    restoreEvents.forEach((event) => video.addEventListener(event, onRestoreEvent));
    restoreCleanupRef.current = () => {
      restoreEvents.forEach((event) => video.removeEventListener(event, onRestoreEvent));
    };

    if (transport === 'native') {
      // crossorigin=anonymous rejects otherwise playable non-CORS MP4/native HLS streams.
      // Native media can play cross-origin without exposing its pixels to JavaScript.
      video.removeAttribute('crossorigin');
      video.src = mediaUrl;
      video.load();
      const session = adSessionRef.current;
      if (session && !isFileMedia(mediaUrl)) {
        // Inspect in the background without replacing the native source, so
        // native fullscreen/PiP/AirPlay keep their original reachable URL.
        void prepareNativePtsAds(mediaUrl, { session, signal: adAbort.signal }).then((plan) => {
          if (!isCurrentMedia() || adAbort.signal.aborted || plan.status !== 'ready') return;
          nativeAdCleanupRef.current = attachNativePtsAdSkips(video, {
            plan, isCurrent: isCurrentMedia,
            isEnabled: () => propsRef.current.adFilter,
            onSkip: () => showHint('已跳过识别出的插播片段'),
          });
        }).catch(() => { /* Optional inspection must not fail native playback. */ });
      }
      return;
    }

    const hls = new Hls(buildHlsConfig());
    hlsRef.current = hls;
    telemetry.attachHls(hls);
    hls.loadSource(mediaUrl);
    hls.attachMedia(video);

    hls.on(Hls.Events.MANIFEST_PARSED, () => {
      recoveryRef.current?.markHealthy();
      // 进度恢复改由 restoreAndStart 处理：duration 未就绪时不消费标记，挂事件重试
      void restoreAndStart();
    });
    // 播放链路恢复（FRAG_LOADED / MANIFEST_PARSED）：静默窗外清零连续失败计数
    hls.on(Hls.Events.FRAG_LOADED, () => recoveryRef.current?.markHealthy());
    // 分片真正进入 MSE buffer 才算媒体恢复：此时视频轨可渲染，错误态可解除
    hls.on(Hls.Events.FRAG_BUFFERED, () => {
      mediaHealthyRef.current = true;
    });

    hls.on(Hls.Events.ERROR, (_evt, data) => {
      if (!data.fatal) return;
      const recovery = recoveryRef.current;
      if (!recovery) return;
      const decision = recovery.onFatal(data.type, data.details);
      switch (decision.action) {
        case 'ignore':
          break;
        case 'retry': {
          // 前两次重试保留直连；达到退避阈值或清单级错误时升级为代理形式
          // （同源 cookie 鉴权，规避 CORS/防盗链/分片被拒）
          if (
            !IS_STANDALONE && allowProxyFallback &&
            !mediaUrl.startsWith('/api/proxy') &&
            (decision.attempt >= 2 || data.details === 'manifestLoadError')
          ) {
            showHint('直连失败，改用代理重试...');
            setupMedia(video, `/api/proxy?url=${encodeURIComponent(mediaUrl)}`, false);
            return;
          }
          showHint(`${decision.reason}（第 ${decision.attempt} 次）...`);
          recovery.schedule(decision.delayMs, () => hls.startLoad());
          break;
        }
        case 'recover-media': {
          showHint(`${decision.reason}（第 ${decision.attempt} 次）...`);
          if (decision.swapAudio) hls.swapAudioCodec?.();
          hls.recoverMediaError();
          break;
        }
        case 'switch-source': {
          // 覆盖播放开始后的场景：起播失败走 setError 遮罩；
          // 播放中失败走回调弹换源面板（父级未提供回调时同样 setError）
          const message = `${describeHlsError(data.type, data.details)}：${decision.reason}`;
          if (playbackStartedRef.current) {
            showHint(message);
            propsRef.current.onRequestSwitchSource?.(decision.reason);
          } else {
            setError(`视频加载失败，${message}，请尝试其他视频源`);
          }
          break;
        }
      }
    });
  };

  /** 换集：保存旧集进度并切换媒体，不重建 ArtPlayer。 */
  const loadEpisode = (targetUrl: string) => {
    if (!targetUrl) return;
    const previousArt = artRef.current;
    if (previousArt && restoredRef.current && !endedRef.current) {
      progressGateRef.current.pause(sourceTime(), sourceDuration());
      emitWatchedProgress('onPause');
    }
    progressGateRef.current.reset();
    restoredRef.current = false;
    loadedEpisodeIdentityRef.current = propsRef.current.episodeKey ?? targetUrl;
    progressCallbacksRef.current = {
      onTimeUpdate: propsRef.current.onTimeUpdate,
      onPause: propsRef.current.onPause,
      onEnded: propsRef.current.onEnded,
    };
    recoveryRef.current?.dispose();
    mediaHealthyRef.current = true;
    playbackStartedRef.current = false;
    videoErrorRetryUsedRef.current = false;
    lastPrefetchEnsureRef.current = 0;
    // 跳过片段按集重置：上一集已处理过不意味新一集也处理过
    handledSegmentsRef.current.clear();
    suppressedAutoRef.current.clear();
    lastSampleRef.current = 0;
    endedRef.current = false;
    updateSkipPrompt(null);
    setUndoSkip(null);
    recoveryRef.current = new PlaybackRecovery();
    // 换集时清掉上一集的预取窗口，避免带宽被旧集占用
    getVideoPrefetcher().stop();
    setError('');
    setShowPoster(true);
    const art = artRef.current;
    if (!art) return;
    setupMedia(art.video, targetUrl, true);
  };

  // —— 创建播放器（仅一次，挂载即创建） ——
  useEffect(() => {
    if (!containerRef.current || !propsRef.current.url) return;
    const initialUrl = propsRef.current.url;
    const progressGate = progressGateRef.current;
    // 不再把触屏常驻时间写入共享 static。控件由下方实例级控制器管理，
    // 兼容华为等「桌面 UA + 实际触屏」，并保护暂停、拖动、设置及键盘焦点。
    const touchPointer = prefersTouchPointer();
    Artplayer.CONTROL_HIDE_TIME = ART_DEFAULT_CONTROL_HIDE_MS;

    // 初始化每集状态
    mediaHealthyRef.current = true;
    playbackStartedRef.current = false;
    progressGateRef.current.reset();
    videoErrorRetryUsedRef.current = false;
    restoredRef.current = false;
    recoveryRef.current = new PlaybackRecovery();
    endedRef.current = false;
    handledSegmentsRef.current.clear();
    suppressedAutoRef.current.clear();
    lastSampleRef.current = 0;

    let lastSave = 0;

    const art = new Artplayer({
      container: containerRef.current,
      url: initialUrl,
      type: 'm3u8',
      volume: 0.8,
      // Restoring a stored position may cross Safari's user-activation boundary.
      // Start explicitly below and show a touch target if iOS requires another gesture.
      autoplay: false,
      pip: true,
      autoMini: true,
      screenshot: true,
      setting: true,
      playbackRate: true,
      aspectRatio: true,
      fullscreen: true,
      fullscreenWeb: true,
      miniProgressBar: true,
      mutex: true,
      backdrop: true,
      playsInline: true,
      airplay: true,
      hotkey: false,
      theme: '#2563eb',
      lang: navigator.language.toLowerCase().startsWith('zh') ? 'zh-cn' : 'en',
      moreVideoAttr: { playsInline: true, preload: 'metadata' },
      // 上/下集放在播放键右侧：换集是看剧最高频的动作，不该让用户滚回页面下方找按钮
      controls: [
        {
          name: 'prev-episode',
          index: 11,
          position: 'left',
          html: '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24"><path fill="currentColor" d="M6 6h2v12H6V6zm3.5 6l8.5 6V6l-8.5 6z"/></svg>',
          tooltip: '上一集 (Alt+←)',
          click: () => {
            if (propsRef.current.hasPrevEpisode) propsRef.current.onPrevEpisode?.();
          },
        },
        {
          name: 'next-episode',
          index: 12,
          position: 'left',
          html: '<svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24"><path fill="currentColor" d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/></svg>',
          tooltip: '下一集 (Alt+→)',
          click: () => {
            if (propsRef.current.hasNextEpisode) propsRef.current.onNextEpisode?.();
          },
        },
      ],
      customType: {
        m3u8: (video: HTMLVideoElement, mediaUrl: string) => {
          setupMedia(video, mediaUrl, true);
        },
      },
    });
    artRef.current = art;

    // 进度条区间可视化：初始渲染一次，换集 duration 变化时重绘
    renderSkipMarks();
    art.on('video:durationchange', renderSkipMarks);
    // 全屏切换 / 播放器尺寸变化会重建控件，色带随之被清掉，这里补一次重绘
    art.on('fullscreen', renderSkipMarks);
    art.on('fullscreenWeb', renderSkipMarks);
    art.on('resize', renderSkipMarks);

    // 播放页「记录当前」需要精确时间：不能依赖 5s 节流的 onTimeUpdate
    propsRef.current.onPlayerApi?.({
      getCurrentTime: () => {
        const current = sourceTime();
        return typeof current === 'number' && Number.isFinite(current) ? current : 0;
      },
      getDuration: () => {
        const duration = sourceDuration();
        return typeof duration === 'number' && Number.isFinite(duration) ? duration : 0;
      },
      seek: (seconds) => {
        if (!Number.isFinite(seconds) || seconds < 0) return;
        try {
          artRef.current.currentTime = sourceToFilteredTime(seconds, adTimelineRef.current);
        } catch {
          /* 忽略 */
        }
      },
      pause: () => {
        try {
          artRef.current?.pause();
        } catch {
          /* 忽略 */
        }
      },
      isPaused: () => artRef.current?.video?.paused ?? true,
      play: () => {
        const p = propsRef.current;
        const loaded = loadedMediaRef.current;
        if (!loaded || loaded.url !== p.url || loaded.identity !== (p.episodeKey ?? p.url)) loadEpisode(p.url);
        const video = artRef.current?.video as HTMLVideoElement | undefined;
        if (video) requestPlay(video);
      },
    });

    art.on('video:loadedmetadata', () => {
      // ArtPlayer 运行时支持 title 选项（类型定义未覆盖），用于界面标题展示
      try {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        (art as any).title = propsRef.current.title;
      } catch { /* 忽略 */ }
    });

    const enforcePlaybackGuard = () => {
      if (propsRef.current.canPlay?.() === false) {
        art.video.pause();
        return false;
      }
      return true;
    };
    art.video.addEventListener('play', enforcePlaybackGuard);
    const checkOnReturn = () => { enforcePlaybackGuard(); };
    document.addEventListener('visibilitychange', checkOnReturn);
    window.addEventListener('pageshow', checkOnReturn);
    window.addEventListener('focus', checkOnReturn);
    art.on('video:playing', () => {
      if (!enforcePlaybackGuard()) return;
      playbackStartedRef.current = true;
      progressGateRef.current.start(sourceTime());
      setNeedsPlayGesture(false);
      setPlayInterrupted(false);
      setShowPoster(false);
      if (!hlsRef.current) mediaHealthyRef.current = true;
      // 仅在媒体真正恢复（有分片进入 buffer）后清错误遮罩：
      // 否则「视频轨挂了、音频轨先播出来」时会清掉遮罩，留下黑屏假死态
      if (mediaHealthyRef.current) setError('');
    });
    art.on('video:error', () => {
      mediaHealthyRef.current = false;
      if (!hlsRef.current) {
        if (nativeProxyFallbackRef.current) {
          showHint('直连失败，改用代理重试...');
          setupMedia(art.video, `/api/proxy?url=${encodeURIComponent(currentMediaUrlRef.current)}`, false);
          return;
        }
        setError(IS_STANDALONE
          ? '此线路暂时无法在当前设备直接播放，请尝试其他 HTTPS 链接或兼容格式'
          : '视频播放失败：线路不可达或当前设备不支持此格式，请切换资源');
        propsRef.current.onRequestSwitchSource?.('原生播放器无法播放此资源');
        return;
      }
      // 起播阶段的 video 元素级错误（MSE/解码偶发失败）：重建一次播放链路自愈，
      // 而不是直接钉死错误遮罩——重建后视频轨重新 append，黑屏有声即可解除
      if (!playbackStartedRef.current && !videoErrorRetryUsedRef.current) {
        videoErrorRetryUsedRef.current = true;
        showHint('播放异常，正在重试...');
        setupMedia(art.video, currentMediaUrlRef.current, true);
        return;
      }
      setError('视频播放失败，请尝试其他视频源');
    });
    art.on('video:timeupdate', () => {
      if (!enforcePlaybackGuard()) return;
      const now = Date.now();
      if (restoredRef.current) progressGateRef.current.observe(sourceTime(), sourceDuration());
      if (restoredRef.current && now - lastSave > 5000) {
        lastSave = now;
        emitWatchedProgress('onTimeUpdate');
      }
      // 每 30s 续跑一次前向预取窗口（ensure 幂等，窗口未覆盖足够余量才会重建）
      if (now - lastPrefetchEnsureRef.current > 30_000) {
        lastPrefetchEnsureRef.current = now;
        // 用 currentMediaUrlRef（代理回退后的实际地址）：否则预取的 key 与
        // loader 读取的 key 不一致，缓存永不命中且直连 fetch 白耗流量
        ensurePrefetch(currentMediaUrlRef.current, art.currentTime);
      }

      // —— 跳过片段判定 ——
      const p = propsRef.current;
      const current = sourceTime();
      const duration = sourceDuration();
      const previous = lastSampleRef.current;
      lastSampleRef.current = current;
      const segments = resolveSegments(p.skipMark, duration);

      // 结尾片段：只认连续播放越过起点；拖动进度条、刚写入标记、进度恢复造成的大跳变
      // 都不自动结束，只显示按钮由用户决定。是否结束由合并后的 autoSkipSegments 控制
      // （片头/中段跳段，片尾结束本集，是否连播下一集仍看 autoplayNext）。
      if (
        p.autoSkipSegments &&
        restoredRef.current &&
        playbackStartedRef.current &&
        findCrossedEnding(segments, previous, current)
      ) {
        const ending = segments.find(
          (s) => s.type === 'ending' && previous < s.start && current >= s.start
        );
        finishBySkip(ending);
        return;
      }

      // 片头/中段片段：命中则自动跳到末尾（同一类操作，共用 autoSkipSegments 开关）；
      // 已处理过的片段本集不再反复拉扯。
      const active = findActiveSegment(segments, current);
      if (
        active &&
        active.type !== 'ending' &&
        p.autoSkipSegments &&
        !handledSegmentsRef.current.has(segmentKey(active)) &&
        !suppressedAutoRef.current.has(segmentKey(active)) &&
        restoredRef.current &&
        playbackStartedRef.current
      ) {
        if (skipTo(active.end)) {
          handledSegmentsRef.current.add(segmentKey(active));
          rememberSkip(current, active);
          showHint(active.type === 'opening' ? '已跳过片头' : '已跳过中段');
        }
      }

      // 按钮提示：当前落在某个未处理片段内（结尾片段显示「跳过片尾」）
      const prompt =
        active && !handledSegmentsRef.current.has(segmentKey(active)) ? active : null;
      updateSkipPrompt(prompt);
    });
    art.on('video:seeking', () => { progressGateRef.current.seekStart(); });
    art.on('video:seeked', () => {
      progressGateRef.current.seekEnd(sourceTime());
      ensurePrefetch(currentMediaUrlRef.current, art.currentTime);
      // seek 是用户主动行为：拉平采样基准，避免下一拍被误判为「连续越过片尾」。
      // 暂停中 seek 不会触发 timeupdate，这里也同步刷新按钮的显隐。
      const current = sourceTime();
      lastSampleRef.current = current;
      const segments = resolveSegments(propsRef.current.skipMark, sourceDuration());
      const active = findActiveSegment(segments, current);
      const prompt =
        active && !handledSegmentsRef.current.has(segmentKey(active)) ? active : null;
      updateSkipPrompt(prompt);
    });
    art.on('video:pause', () => {
      // 跳过片尾会主动 pause：此时已按「看完」处理，不能再把片尾位置写回进度
      if (restoredRef.current && !endedRef.current) {
        progressGateRef.current.pause(sourceTime(), sourceDuration());
        emitWatchedProgress('onPause');
      }
      // 暂停 = 预取黄金窗口：解除限速并无限铺满整集（用户主动行为，带宽占用可接受）
      // waiting 触发的限速在此解除，否则黄金窗口会被 500ms 轮询冻结
      getVideoPrefetcher().setThrottled(false);
      ensurePrefetch(currentMediaUrlRef.current, art.currentTime, 0);
    });
    art.on('video:waiting', () => {
      // 卡顿：预取临时让出带宽给播放
      getVideoPrefetcher().setThrottled(true);
    });
    art.on('video:playing', () => {
      getVideoPrefetcher().setThrottled(false);
    });
    art.on('video:ended', () => {
      // finishBySkip 已经手动走过结束链路：这里不能重复触发 onEnded
      if (!restoredRef.current || endedRef.current) return;
      progressGateRef.current.observe(sourceTime(), sourceDuration());
      emitWatchedProgress('onPause');
      progressGateRef.current.reset();
      endedRef.current = true;
      updateSkipPrompt(null);
      progressCallbacksRef.current.onEnded?.();
    });

    // —— 键盘快捷键（旧版 hotkey:false + 自定义逻辑的移植） ——
    const shortcuts = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      // 输入框或按钮获得焦点时不劫持按键：否则空格会吞掉按钮的默认激活
      if (e.defaultPrevented || target.isContentEditable || target.closest('input, textarea, select, button, a, [role="dialog"]')) return;
      const current = artRef.current;
      if (!current) return;
      if (e.altKey && e.key === 'ArrowLeft') { e.preventDefault(); return; } // 由父层处理集数切换
      if (e.altKey && e.key === 'ArrowRight') { e.preventDefault(); return; }
      switch (e.key) {
        case 'ArrowLeft':
          if (current.currentTime > 5) { current.currentTime -= 5; showHint('快退 5s'); e.preventDefault(); }
          break;
        case 'ArrowRight':
          if (current.duration - current.currentTime > 5) { current.currentTime += 5; showHint('快进 5s'); e.preventDefault(); }
          break;
        case 'ArrowUp':
          if (current.volume < 1) { current.volume = Math.min(1, current.volume + 0.1); showHint(`音量 ${Math.round(current.volume * 100)}%`); e.preventDefault(); }
          break;
        case 'ArrowDown':
          if (current.volume > 0) { current.volume = Math.max(0, current.volume - 0.1); showHint(`音量 ${Math.round(current.volume * 100)}%`); e.preventDefault(); }
          break;
        case ' ':
          current.toggle(); showHint('播放/暂停'); e.preventDefault();
          break;
        case 'f': case 'F':
          current.fullscreen = !current.fullscreen; e.preventDefault();
          break;
        // 标记类快捷键一律要求 Shift：这几键会直接写盘并影响整部剧，
        // 单键太容易误触（误记片头 = 之后每集都被跳过一大段）
        case 'i': case 'I':
          if (!e.shiftKey) break;
          propsRef.current.onRecordSegment?.({
            type: 'opening',
            start: 0,
            end: round1(sourceTime()),
          });
          e.preventDefault();
          break;
        case 'o': case 'O':
          if (!e.shiftKey) break;
          propsRef.current.onRecordSegment?.({
            type: 'ending',
            start: round1(sourceTime()),
            end: -1,
          });
          e.preventDefault();
          break;
        case 's': case 'S':
          if (!e.shiftKey) break;
          propsRef.current.onPendingStart(round1(sourceTime()));
          showHint('片段起点已记录，播放到终点后按 Shift+E');
          e.preventDefault();
          break;
        case 'e': case 'E': {
          if (!e.shiftKey) break;
          const start = propsRef.current.pendingStart;
          if (start === null) {
            showHint('请先按 Shift+S 记录片段起点');
          } else {
            const end = round1(sourceTime());
            propsRef.current.onPendingStart(null);
            propsRef.current.onRecordSegment?.({ type: 'middle', start, end });
          }
          e.preventDefault();
          break;
        }
      }
    };
    document.addEventListener('keydown', shortcuts);

    // —— 移动端长按 3 倍速 ——
    let longPressTimer: ReturnType<typeof setTimeout> | null = null;
    let isLongPress = false;
    let originalRate = 1.0;
    const el = containerRef.current;

    const detachControlVisibility = attachPlayerControlVisibility(art, el, touchPointer);

    const onTouchStart = (e: TouchEvent) => {
      if (art.video?.paused) return;
      // 已有触控在处理时忽略新手指：否则第二指会把 originalRate 捕获成 3.0，
      // 松手后倍速永久卡在 3x；旧定时器句柄也会被覆盖成无法清除的幽灵触发
      if (isLongPress || longPressTimer || e.touches.length !== 1) return;
      // 控制栏 / 设置面板上的长按不触发倍速（按住进度条拖动、长按倍速菜单项会误触）
      if ((e.target as HTMLElement).closest?.('.art-controls, .art-settings')) return;
      originalRate = art.video.playbackRate;
      longPressTimer = setTimeout(() => {
        if (art.video?.paused) return;
        art.video.playbackRate = 3.0;
        isLongPress = true;
        showHint('3 倍速');
      }, SURFACE_LONG_PRESS_MS);
    };
    const onTouchEnd = () => {
      if (longPressTimer) { clearTimeout(longPressTimer); longPressTimer = null; }
      if (isLongPress) {
        art.video.playbackRate = originalRate;
        isLongPress = false;
        showHint(`${originalRate} 倍速`);
      }
    };
    const onTouchMove = (e: TouchEvent) => {
      if (isLongPress) e.preventDefault();
    };
    // ArtPlayer 的 contextmenu 组件只在桌面端初始化（移动端构造函数里跳过 init），
    // 长按倍速因而会连带呼出系统原生菜单/气泡。播放器表面没有可用的原生菜单，统一抑制
    const onContextMenu = (e: Event) => e.preventDefault();
    el?.addEventListener('touchstart', onTouchStart, { passive: false });
    el?.addEventListener('touchend', onTouchEnd);
    el?.addEventListener('touchcancel', onTouchEnd);
    el?.addEventListener('touchmove', onTouchMove, { passive: false });
    el?.addEventListener('contextmenu', onContextMenu);

    // 卸载与页面隐藏时保存进度
    const saveOnHide = () => {
      if (document.visibilityState === 'hidden' && restoredRef.current && !endedRef.current) {
        progressGateRef.current.observe(sourceTime(), sourceDuration());
        emitWatchedProgress('onPause');
      }
    };
    const saveOnPageHide = () => {
      if (restoredRef.current && !endedRef.current) {
        progressGateRef.current.observe(sourceTime(), sourceDuration());
        emitWatchedProgress('onPause');
      }
    };
    document.addEventListener('visibilitychange', saveOnHide);
    window.addEventListener('pagehide', saveOnPageHide);

    return () => {
      // 卸载前刷一次最终进度，避免丢失最后几秒。
      // 已自然播完的集数不回写，避免覆盖 onEnded 里清除的「已看完」记录
      if (restoredRef.current && !endedRef.current) {
        try {
          progressGate.pause(sourceTime(), sourceDuration());
          emitWatchedProgress('onPause');
        } catch { /* 忽略 */ }
      }
      document.removeEventListener('keydown', shortcuts);
      document.removeEventListener('visibilitychange', saveOnHide);
      window.removeEventListener('pagehide', saveOnPageHide);
      mediaLoadIdRef.current += 1;
      if (hintTimerRef.current) clearTimeout(hintTimerRef.current);
      if (undoTimerRef.current) clearTimeout(undoTimerRef.current);
      el?.removeEventListener('touchstart', onTouchStart);
      el?.removeEventListener('touchend', onTouchEnd);
      el?.removeEventListener('touchcancel', onTouchEnd);
      el?.removeEventListener('touchmove', onTouchMove);
      el?.removeEventListener('contextmenu', onContextMenu);
      art.video?.removeEventListener('play', enforcePlaybackGuard);
      document.removeEventListener('visibilitychange', checkOnReturn);
      window.removeEventListener('pageshow', checkOnReturn);
      window.removeEventListener('focus', checkOnReturn);
      detachControlVisibility();
      if (longPressTimer) clearTimeout(longPressTimer);
      if (isLongPress) art.video.playbackRate = originalRate;
      restoreCleanupRef.current?.();
      restoreCleanupRef.current = null;
      telemetryRef.current?.dispose();
      telemetryRef.current = null;
      Artplayer.CONTROL_HIDE_TIME = ART_DEFAULT_CONTROL_HIDE_MS;
      hlsRef.current?.destroy();
      hlsRef.current = null;
      adAbortRef.current?.abort();
      nativeAdCleanupRef.current?.();
      nativeAdCleanupRef.current = null;
      adSessionRef.current?.destroy();
      adSessionRef.current = null;
      adSpliceRef.current?.destroy();
      adSpliceRef.current = null;
      recoveryRef.current?.dispose();
      getVideoPrefetcher().stop();
      // 播放页可能仍持有读取接口：销毁前显式置空，避免「记录当前」读到已销毁实例
      propsRef.current.onPlayerApi?.(null);
      art.destroy();
      artRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // —— 上/下集禁用态：走 ArtPlayer 的 controls API 更新样式，不直接改 DOM ——
  // 直接 querySelector 改 style 在控件重建（切全屏/播放器重绘）后不会恢复，且依赖内部 class 名。
  useEffect(() => {
    const controls = artRef.current?.controls;
    if (!controls) return;
    controls.update({
      name: 'prev-episode',
      style: { opacity: hasPrevEpisode ? '1' : '0.4', pointerEvents: hasPrevEpisode ? 'auto' : 'none' },
    });
    controls.update({
      name: 'next-episode',
      style: { opacity: hasNextEpisode ? '1' : '0.4', pointerEvents: hasNextEpisode ? 'auto' : 'none' },
    });
  }, [hasPrevEpisode, hasNextEpisode, url]);

  // —— 标记变化：重置采样基准并立即刷新提示 ——
  // 刚写入片段时当前时间可能恰好等于新边界，若沿用上一拍采样会被判成
  // 「连续越过」而当场触发；把基准拉平后本集只保留手动按钮，下一集才自动。
  // 顺带覆盖暂停中修改标记的场景（没有 timeupdate 也要让按钮即时出现/消失）。
  useEffect(() => {
    const art = artRef.current;
    if (!art) return;
    const current = sourceTime();
    lastSampleRef.current = Number.isFinite(current) ? current : 0;
    const segments = resolveSegments(skipMark, sourceDuration());
    const active = findActiveSegment(segments, current);
    const prompt =
      active && !handledSegmentsRef.current.has(segmentKey(active)) ? active : null;
    updateSkipPrompt(prompt);
    renderSkipMarks();
    // Helpers read the latest refs without re-running this effect on every render.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [skipMark]);

  // —— 换集：仅切换 HLS 源，不重建播放器（保留网页全屏等状态） ——
  useEffect(() => {
    const loaded = loadedMediaRef.current;
    if (!loaded || loaded.url !== url || loaded.identity !== (episodeKey ?? url)) loadEpisode(url);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [url, episodeKey]);

  // —— 广告过滤开关变化：重建 HLS loader（无需重建整个播放器） ——
  const firstAdFilterRef = useRef(true);
  useEffect(() => {
    if (firstAdFilterRef.current) { firstAdFilterRef.current = false; return; }
    if (artRef.current) {
      // 用当前实际媒体地址：代理回退生效时切广告过滤不应跳回直连形式
      getVideoPrefetcher().stop();
      getNextEpisodePrefetcher().stop();
      setupMedia(artRef.current.video, currentMediaUrlRef.current || propsRef.current.url, true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [adFilter]);

  return (
    <div className="libretv-player relative w-full h-full">
      <div ref={containerRef} className="w-full h-full" style={{ WebkitTouchCallout: 'none' }} />
      {showPoster && !error && (
        <div
          className="absolute inset-0 bg-black pointer-events-none"
          style={{
            backgroundImage: `url(${appPath('/player-poster.png')})`,
            backgroundSize: 'contain',
            backgroundPosition: 'center',
            backgroundRepeat: 'no-repeat',
          }}
        />
      )}
      {timerStopped && !error && (
        <div className="absolute inset-0 z-20 flex flex-col items-center justify-center gap-4 bg-black/65 text-white">
          <p className="text-sm">定时播放已结束</p>
          <button
            type="button"
            className="min-h-12 rounded-full bg-white px-6 text-sm font-medium text-black"
            onClick={() => {
              propsRef.current.onResumeFromTimer?.();
              endedRef.current = false;
              const video = artRef.current?.video as HTMLVideoElement | undefined;
              if (propsRef.current.canPlay?.() !== false) {
                if (video) requestPlay(video);
              }
            }}
          >继续播放</button>
        </div>
      )}
      {showPoster && !needsPlayGesture && !playInterrupted && !error && !timerStopped && (
        <div role="status" className="absolute inset-0 z-10 pointer-events-none flex items-center justify-center bg-black/20 text-white">
          <span className="rounded-full bg-black/75 px-6 py-3 text-sm">{adScanning ? '正在识别插播片段…' : '正在加载视频…'}</span>
        </div>
      )}
      {(needsPlayGesture || playInterrupted) && !error && !timerStopped && (
        <button
          type="button"
          className="absolute inset-0 z-10 flex items-center justify-center bg-black/30 text-white"
          aria-label={playInterrupted ? '重试播放视频' : '点击播放视频'}
          onClick={() => {
            // Call play directly in the click stack; awaiting storage here loses iOS activation.
            const video = artRef.current?.video as HTMLVideoElement | undefined;
            if (video) requestPlay(video);
          }}
        >
          <span className="rounded-full bg-black/75 px-6 py-3 text-sm">{playInterrupted ? '重试播放' : '点击播放'}</span>
        </button>
      )}
      {!error && skipPrompt && (
        <button
          type="button"
          className="absolute bottom-16 left-1/2 -translate-x-1/2 z-10 rounded-full bg-black/70 px-4 py-2 text-sm text-white transition-colors hover:bg-black/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
          onClick={() => {
            if (skipPrompt.type === 'ending') {
              finishBySkip(skipPrompt);
              return;
            }
            const from = sourceTime();
            if (skipTo(skipPrompt.end)) {
              handledSegmentsRef.current.add(segmentKey(skipPrompt));
              rememberSkip(from, skipPrompt);
              updateSkipPrompt(null);
              showHint(skipPrompt.type === 'opening' ? '已跳过片头' : '已跳过中段');
            }
          }}
        >
          {skipPrompt.type === 'ending'
            ? '跳过片尾'
            : skipPrompt.type === 'opening'
              ? '跳过片头'
              : '跳过中段'}
        </button>
      )}
      {error && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-black/80">
          <p className="text-danger text-sm">{error}</p>
          <button className="btn-ghost text-xs" onClick={() => location.reload()}>
            重新加载
          </button>
        </div>
      )}
      {(hint || undoSkip) && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-10 flex items-center gap-2 rounded-full bg-black/70 px-3 py-1.5 text-sm text-white animate-fade-in">
          {/* 撤销窗口比普通提示长：hint 已淡出时仍要让用户知道刚才跳过了什么 */}
          <span className="pointer-events-none">
            {hint || (undoSkip ? `已跳过${SEGMENT_LABELS[undoSkip.segment.type]}` : '')}
          </span>
          {undoSkip && (
            <button
              type="button"
              className="pointer-events-auto shrink-0 rounded-full bg-white/20 px-2 py-0.5 text-xs font-medium transition-colors hover:bg-white/30 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent"
              onClick={undoLastSkip}
            >
              撤销
            </button>
          )}
        </div>
      )}
    </div>
  );
}
