'use client';

import type { HomeResumeItem } from '@/lib/home-resume';
import type { SearchResultItem } from '@/lib/types';
import { resolveSource, useAppStore } from '@/lib/store';
import { DIRECT_MEDIA_SOURCE } from '@/lib/standalone-media';
import { buildWatchUrl } from '@/lib/utils';
import { HomeSpotlight } from './home-spotlight';
import { ContinueWatching } from './continue-watching';
import { useHomeResume } from './use-home-resume';

export interface HomeResumeTarget {
  item: HomeResumeItem;
  href: string;
  detail?: SearchResultItem;
  sourceName?: string;
}

/** Hero and rail share a single read and selection, so the same work cannot appear twice. */
export function HomeViewing({ onPick, onDetail }: {
  onPick: (title: string) => void; onDetail: (item: SearchResultItem) => void;
}) {
  const selection = useHomeResume();
  const customAPIs = useAppStore((state) => state.customAPIs);
  const envSources = useAppStore((state) => state.envSources);
  const target = (item: HomeResumeItem): HomeResumeTarget => {
    const source = resolveSource({ customAPIs, envSources }, item.sourceKey, { url: item.sourceUrl });
    const direct = item.sourceKey === DIRECT_MEDIA_SOURCE;
    return {
      item,
      href: buildWatchUrl({ sourceKey: item.sourceKey, vodId: item.vodId, index: item.episodeIndex,
        title: item.title, sourceUrl: source?.url, detail: source?.detail,
        position: item.playbackPosition, episodeUrl: direct ? item.vodId : undefined }),
      sourceName: direct ? '视频链接' : source?.name,
      detail: !direct && source ? { sourceKey: item.sourceKey, sourceName: source.name,
        sourceUrl: source.url, vodId: item.vodId, name: item.title, pic: item.pic } : undefined,
    };
  };
  return <>
    <span hidden data-home-viewing-ready={selection.ready} />
    <HomeSpotlight recent={selection.hero ? target(selection.hero) : null} ready={selection.ready}
      onPick={onPick} onDetail={onDetail} />
    <ContinueWatching items={selection.others.map(target)} />
  </>;
}
