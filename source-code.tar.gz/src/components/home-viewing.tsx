'use client';

import { useQueries, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/client-api';
import { HOME_RESUME_OTHER_LIMIT, hasHomeNextEpisode, selectHomeResume, type HomeResumeItem } from '@/lib/home-resume';
import type { SearchResultItem } from '@/lib/types';
import { resolveSource, useAppStore } from '@/lib/store';
import { DIRECT_MEDIA_SOURCE } from '@/lib/standalone-media';
import { buildWatchUrl } from '@/lib/utils';
import { HomeSpotlight } from './home-spotlight';
import { ContinueWatching } from './continue-watching';
import { useHomeResume } from './use-home-resume';
import { useAuth } from './auth';

export interface HomeResumeTarget {
  item: HomeResumeItem;
  href: string;
  detail?: SearchResultItem;
  sourceName?: string;
}

/** Hero and rail share a single read and selection, so the same work cannot appear twice. */
export function HomeViewing({ onPick, onDetail }: {
  onPick: (title: string) => void; onDetail: (item: SearchResultItem) => void;
}) {
  const { candidates, ready } = useHomeResume();
  const { verified } = useAuth();
  const queryClient = useQueryClient();
  const customAPIs = useAppStore((state) => state.customAPIs);
  const envSources = useAppStore((state) => state.envSources);
  const sourceStore = { customAPIs, envSources };
  const checks = verified ? candidates
    .filter((candidate) => !candidate.complete || candidate.nextEpisodeIndex !== undefined)
    .slice(0, HOME_RESUME_OTHER_LIMIT + 1)
    .flatMap((candidate) => {
      const { item, nextEpisodeIndex } = candidate;
      if (nextEpisodeIndex === undefined || !item.sourceUrl) return [];
      const source = resolveSource(sourceStore, item.sourceKey);
      if (!source || source.url !== item.sourceUrl) return [];
      return [{ candidate, source, nextEpisodeIndex }];
    }) : [];
  const results = useQueries({
    queries: checks.map(({ candidate: { item }, source, nextEpisodeIndex }) => ({
      queryKey: ['home-next-episode', source.key, item.vodId, source.url, source.detail, nextEpisodeIndex, item.watchedAt],
      queryFn: async ({ signal }) => {
        const detail = await api.detail(item.vodId, source, signal, undefined, true);
        if (!signal.aborted) queryClient.setQueryData(['detail', source.key, item.vodId, source.url], detail);
        return hasHomeNextEpisode(detail.episodes, nextEpisodeIndex);
      },
      staleTime: 30_000,
      retry: false,
      refetchOnWindowFocus: true,
    })),
  });
  const confirmedNext = new Set(checks.filter((_, index) => results[index].isSuccess && results[index].data === true)
    .map(({ candidate }) => candidate));
  const selection = selectHomeResume(candidates, confirmedNext);
  const target = (item: HomeResumeItem): HomeResumeTarget => {
    const source = resolveSource(sourceStore, item.sourceKey, { url: item.sourceUrl });
    const direct = item.sourceKey === DIRECT_MEDIA_SOURCE;
    return {
      item,
      href: buildWatchUrl({ sourceKey: item.sourceKey, vodId: item.vodId, index: item.nextEpisodeIndex ?? item.episodeIndex,
        title: item.title, sourceUrl: source?.url, detail: source?.detail,
        position: item.nextEpisodeIndex === undefined ? item.playbackPosition : undefined,
        episodeUrl: direct ? item.vodId : undefined }),
      sourceName: direct ? '视频链接' : source?.name,
      detail: !direct && source ? { sourceKey: item.sourceKey, sourceName: source.name,
        sourceUrl: source.url, vodId: item.vodId, name: item.title, pic: item.pic } : undefined,
    };
  };
  return <>
    <span hidden data-home-viewing-ready={ready && !results.some((result) => result.isLoading)} />
    <HomeSpotlight recent={selection.hero ? target(selection.hero) : null} ready={ready}
      onPick={onPick} onDetail={onDetail} />
    <ContinueWatching items={selection.others.map(target)} />
  </>;
}
