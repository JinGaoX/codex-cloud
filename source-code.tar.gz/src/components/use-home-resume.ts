'use client';

import { useLiveQuery } from 'dexie-react-hooks';
import { db, MAX_HISTORY } from '@/lib/db';
import { HOME_RESUME_OTHER_LIMIT, selectHomeResume, type HomeResumeSelection } from '@/lib/home-resume';

const EMPTY: HomeResumeSelection = { hero: null, others: [], total: 0 };

/** One shared, reactive read for the hero and its deduplicated continuation rail. */
export function useHomeResume(otherLimit = HOME_RESUME_OTHER_LIMIT): HomeResumeSelection & { ready: boolean; unavailable: boolean } {
  const result = useLiveQuery(async () => {
    try {
      return await db.transaction('r', db.history, db.progress, async () => {
        const history = await db.history.orderBy('timestamp').reverse().limit(MAX_HISTORY).toArray();
        // Existing primary-key ranges avoid reading orphaned progress for films
        // no longer in history, without adding an index or changing the schema.
        const prefixes = [...new Set(history.filter((entry) => typeof entry.sourceKey === 'string' && typeof entry.vodId === 'string')
          .map((entry) => `${entry.sourceKey}_${entry.vodId}_`))];
        const progress = prefixes.length ? await db.progress.where('key').startsWithAnyOf(prefixes).toArray() : [];
        return { ...selectHomeResume(history, progress, otherLimit), unavailable: false };
      });
    } catch {
      // IndexedDB being unavailable must not replace the existing featured
      // fallback with a broken or invented viewing record.
      return { ...EMPTY, unavailable: true };
    }
  }, [otherLimit]);
  return { ...(result ?? EMPTY), ready: result !== undefined, unavailable: result?.unavailable ?? false };
}
