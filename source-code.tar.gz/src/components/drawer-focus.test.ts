import { describe, expect, it, vi } from 'vitest';
import { createDrawerFocusReturn, drawerMayRestoreFocus } from './drawer-focus';

const target = (isConnected = true) => ({ isConnected, focus: vi.fn() });

describe('drawer focus return', () => {
  it('keeps the original trigger through a nested non-modal phase and restores it once', () => {
    const session = createDrawerFocusReturn();
    const trigger = target();
    const detail = target();
    session.open(true, trigger);
    session.open(false, detail);
    session.open(true, detail);
    expect(trigger.focus).not.toHaveBeenCalled();
    session.close();
    session.close();
    expect(trigger.focus).toHaveBeenCalledTimes(1);
    expect(detail.focus).not.toHaveBeenCalled();
  });

  it('discards playback navigation focus and captures a fresh origin next time', () => {
    const session = createDrawerFocusReturn();
    const oldPage = target();
    const nextTrigger = target();
    session.open(true, oldPage);
    session.close(false);
    expect(oldPage.focus).not.toHaveBeenCalled();
    session.open(true, nextTrigger);
    session.close();
    expect(nextTrigger.focus).toHaveBeenCalledTimes(1);
  });

  it('does not focus a removed page or steal focus for an originally non-modal drawer', () => {
    const session = createDrawerFocusReturn();
    const removed = target(false);
    session.open(true, removed);
    session.close();
    expect(removed.focus).not.toHaveBeenCalled();
    const background = target();
    session.open(false, background);
    session.close();
    expect(background.focus).not.toHaveBeenCalled();
  });

  it('leaves a newly opened history panel focused when the old drawer finishes exiting', () => {
    const session = createDrawerFocusReturn();
    const trigger = target();
    const oldCloseButton = {} as Element;
    const historyInput = {} as Element;
    const body = {} as Element;
    const panel = { contains: (node: Node | null) => node === oldCloseButton };
    session.open(true, trigger);
    expect(drawerMayRestoreFocus(panel, oldCloseButton, [body])).toBe(true);
    expect(drawerMayRestoreFocus(panel, body, [body])).toBe(true);
    // History opens and focuses its input before the old 200ms exit completes.
    session.close(drawerMayRestoreFocus(panel, historyInput, [body]));
    expect(trigger.focus).not.toHaveBeenCalled();
  });
});
