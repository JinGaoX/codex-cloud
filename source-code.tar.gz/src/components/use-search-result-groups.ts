'use client';

import { useMemo, useState } from 'react';
import { aggregateResults, reconcileSearchGroups } from '@/lib/search-result-groups';
import type { SearchResultItem } from '@/lib/types';

export function useSearchResultGroups(items: SearchResultItem[], requestKey: string) {
  const current = useMemo(() => aggregateResults(items), [items]);
  const [snapshot, setSnapshot] = useState(() => ({ requestKey, current, groups: current }));
  if (snapshot.requestKey !== requestKey || snapshot.current !== current) {
    const groups = snapshot.requestKey === requestKey ? reconcileSearchGroups(snapshot.groups, current) : current;
    setSnapshot({ requestKey, current, groups });
    return groups;
  }
  return snapshot.groups;
}
