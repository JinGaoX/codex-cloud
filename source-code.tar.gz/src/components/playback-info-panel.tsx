'use client';

import type { PlaybackInfo } from '@/lib/playback-info';

const UNKNOWN = '暂未读取';

function positive(value?: number): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value > 0;
}

/** 只显示编码家族，不把播放器补充的 profile / level 当成媒体实测信息。 */
function videoCodecLabel(codec?: string): string | undefined {
  const value = codec?.trim().toLowerCase();
  if (!value) return undefined;
  if (/^(avc1|avc3|h\.?264)(?:[.\s-]|$)/.test(value)) return 'H.264';
  if (/^(hvc1|hev1|hevc|h\.?265)(?:[.\s-]|$)/.test(value)) return 'HEVC / H.265';
  if (/^(av01|av1)(?:[.\s-]|$)/.test(value)) return 'AV1';
  if (/^(vp09|vp9)(?:[.\s-]|$)/.test(value)) return 'VP9';
  if (/^(vp08|vp8)(?:[.\s-]|$)/.test(value)) return 'VP8';
  return undefined;
}

function audioCodecLabel(codec?: string): string | undefined {
  const value = codec?.trim().toLowerCase();
  if (!value) return undefined;
  if (/^(aac|mp4a\.40\.(?:2|5|29))(?:[.\s-]|$)/.test(value)) return 'AAC';
  if (/^(ac-3|ac3)(?:[.\s-]|$)/.test(value)) return 'AC-3';
  if (/^(ec-3|eac3|e-ac-3)(?:[.\s-]|$)/.test(value)) return 'E-AC-3';
  if (/^opus(?:[.\s-]|$)/.test(value)) return 'Opus';
  if (/^flac(?:[.\s-]|$)/.test(value)) return 'FLAC';
  if (/^(mp3|mp4a\.40\.34|mp4a\.6b)(?:[.\s-]|$)/.test(value)) return 'MP3';
  return undefined;
}

function InfoItem({ label, value, note }: { label: string; value: string; note?: string }) {
  return (
    <div className="min-w-0 rounded-lg bg-chip/60 px-3 py-2.5">
      <dt className="text-[11px] text-muted">{label}</dt>
      <dd className="mt-1 break-words text-sm font-medium text-content tabular-nums">{value}</dd>
      {note && <dd className="mt-1 text-[11px] leading-relaxed text-faint">{note}</dd>}
    </div>
  );
}

export function PlaybackInfoPanel({
  resolution,
  info,
  id = 'playback-info-panel',
}: {
  resolution: { width: number; height: number } | null;
  info: PlaybackInfo | null;
  id?: string;
}) {
  const hasResolution = resolution && positive(resolution.width) && positive(resolution.height);
  const hasMeasuredFrameRate = positive(info?.frameRate);
  const hasDeclaredFrameRate = positive(info?.declaredFrameRate);
  const frameRate = hasMeasuredFrameRate ? info?.frameRate : hasDeclaredFrameRate ? info?.declaredFrameRate : undefined;
  const hasBitrateSamples = Boolean(
    info && Number.isInteger(info.bitrateSampleCount) && info.bitrateSampleCount > 0 && positive(info.bitrateSampleSeconds)
  );
  const hasBitrate = positive(info?.bitrate) && hasBitrateSamples;
  const hasDroppedFrames = typeof info?.droppedFrames === 'number' && Number.isInteger(info.droppedFrames) && info.droppedFrames >= 0;
  const hasTotalFrames = typeof info?.totalFrames === 'number' && Number.isInteger(info.totalFrames) && info.totalFrames >= 0;

  return (
    <section id={id} aria-label="当前画质信息" className="mt-3 rounded-xl border border-line bg-surface-raised p-3 sm:p-4">
      <div className="mb-3">
        <h2 className="text-sm font-semibold text-content">当前画质信息</h2>
        <p className="mt-1 text-xs leading-relaxed text-muted">随当前片源更新；还未取得的数据会显示“暂未读取”。</p>
      </div>
      <dl className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        <InfoItem
          label="当前解码尺寸"
          value={hasResolution ? `${resolution.width}×${resolution.height}` : UNKNOWN}
          note="包含视频文件内自带的黑边"
        />
        <InfoItem label="视频编码" value={videoCodecLabel(info?.videoCodec) ?? UNKNOWN} />
        <InfoItem
          label="参考码率"
          value={hasBitrate ? `≈ ${(info!.bitrate! / 1_000_000).toFixed(2)} Mbps` : UNKNOWN}
          note={hasBitrateSamples ? `样本：${info!.bitrateSampleCount} 个完整主分片 · ${info!.bitrateSampleSeconds.toFixed(1)} 秒` : '当前播放方式或片源可能不提供分片统计'}
        />
        <InfoItem
          label={hasMeasuredFrameRate ? '分片平均帧率' : hasDeclaredFrameRate ? '帧率（源站声明上限）' : '分片平均帧率'}
          value={frameRate ? `${frameRate.toFixed(2)} fps` : UNKNOWN}
          note={hasMeasuredFrameRate ? '按播放器收到的视频样本数与媒体时长计算' : hasDeclaredFrameRate ? '仅为源站声明上限，尚未从媒体样本计算' : undefined}
        />
        <InfoItem label="音频编码" value={audioCodecLabel(info?.audioCodec) ?? UNKNOWN} />
        <InfoItem
          label="播放器丢帧"
          value={hasDroppedFrames
            ? hasTotalFrames ? `${info!.droppedFrames!.toLocaleString('zh-CN')} / ${info!.totalFrames!.toLocaleString('zh-CN')} 帧` : `${info!.droppedFrames!.toLocaleString('zh-CN')} 帧`
            : UNKNOWN}
          note={hasDroppedFrames && hasTotalFrames ? '丢帧数 / 总帧数' : undefined}
        />
      </dl>
      <div className="mt-3 space-y-2 border-t border-line pt-3 text-xs leading-relaxed text-muted">
        <p>参考码率按当前播放附近若干完整主分片的字节数与媒体时长估算，可能包含音频和封装开销。它不是网速、全片平均码率或画质评分。</p>
        <p>同为 1080 只代表像素尺寸接近。源片质量、压缩码率、编码方式和再次转码都会影响细节；不同编码不能只比较码率，也无法据此确认原生 1080 或 4K。</p>
      </div>
    </section>
  );
}
