'use client';

import { useCallback, useEffect, useMemo, useRef } from 'react';
import { describeEpisode } from '@/lib/episode-labels';
import { episodeGridLabel } from '@/lib/episode-grid-labels';
import { Icon } from './icon';
import { EmptyState, LoadingState } from './states';
import './episode-grid.css';

export interface EpisodeGridProps {
  episodes: readonly string[];
  titles?: readonly string[];
  currentIndex: number;
  reversed: boolean;
  onReverse: () => void;
  onSelect: (index: number) => void;
  loading?: boolean;
  error?: boolean;
}

/** Source labels and playback indexes stay paired even when display order changes. */
export function EpisodeGrid({ episodes, titles, currentIndex, reversed, onReverse, onSelect, loading, error }: EpisodeGridProps) {
  const grid = useRef<HTMLDivElement>(null);
  const buttons = useRef(new Map<number, HTMLButtonElement>());
  const labels = useMemo(() => episodes.map((_, index) => {
    const episode = describeEpisode(index, titles?.[index]);
    return { index, episode, display: episodeGridLabel(episode) };
  }), [episodes, titles]);
  const titled = labels.some(({ episode }) => Boolean(episode.title));
  const ordered = reversed ? [...labels].reverse() : labels;

  const locateCurrent = useCallback(() => {
    const container = grid.current, button = buttons.current.get(currentIndex);
    if (!container || !button) return;
    const bounds = container.getBoundingClientRect(), item = button.getBoundingClientRect();
    // Do not scroll ancestors: changing an episode must keep the player in view.
    if (item.top < bounds.top + 4) container.scrollTop += item.top - bounds.top - 4;
    else if (item.bottom > bounds.bottom - 4) container.scrollTop += item.bottom - bounds.bottom + 4;
  }, [currentIndex]);

  useEffect(() => {
    locateCurrent();
    const container = grid.current;
    if (!container || typeof ResizeObserver === 'undefined') return;
    const observer = new ResizeObserver(locateCurrent);
    observer.observe(container);
    return () => observer.disconnect();
  }, [locateCurrent, reversed, labels, titled]);

  return (
    <section className="watch-episode-panel" aria-labelledby="watch-episode-title">
      <div className="watch-episode-heading">
        <h2 id="watch-episode-title">剧集列表{episodes.length > 0 && `（${episodes.length}）`}</h2>
        <div className="watch-episode-tools">
          <button type="button" onClick={locateCurrent} disabled={!labels[currentIndex]} aria-label="定位当前播放集">
            定位当前集
          </button>
          {episodes.length > 1 && <button type="button" onClick={onReverse}
            aria-label={reversed ? '切换为正序排列' : '切换为倒序排列'}>
            <Icon name="arrowDown" className={reversed ? 'rotate-180' : undefined} />
            {reversed ? '正序排列' : '倒序排列'}
          </button>}
        </div>
      </div>
      {labels.length === 0 ? (
        loading ? <LoadingState label="正在加载剧集" />
          : <EmptyState variant="plain" title={error ? '获取剧集失败' : '暂无剧集信息'} />
      ) : (
        <div ref={grid} className="watch-episode-grid" data-titled={titled || undefined} aria-label="选集">
          {ordered.map(({ index, episode, display }) => (
            <button key={index} type="button" className="watch-episode-item"
              data-dated={display.dated || undefined}
              ref={(button) => { if (button) buttons.current.set(index, button); else buttons.current.delete(index); }}
              aria-label={episode.label} aria-current={index === currentIndex ? 'true' : undefined}
              title={episode.label} onClick={() => onSelect(index)}>
              {titled && <span className="watch-episode-number" aria-hidden="true">{episode.number}</span>}
              <span className="watch-episode-copy" aria-hidden="true">
                <span className="watch-episode-name">{display.primary}</span>
                {display.secondary && <span className="watch-episode-version">{display.secondary}</span>}
              </span>
              {index === currentIndex && <span className="sr-only">当前播放</span>}
            </button>
          ))}
        </div>
      )}
      <p className="watch-episode-help">快捷键：空格 播放/暂停 · ←/→ 快退/快进 · F 全屏 · Alt+←/→ 切换集数</p>
    </section>
  );
}
