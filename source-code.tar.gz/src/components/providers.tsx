'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useEffect, useState, type ReactNode } from 'react';
import { ToastProvider } from './toast';
import { AuthProvider } from './auth';
import { ThemeProvider } from './theme';
import { GlobalDownloadManager } from './download-manager';
import { useAppStore, hydrateLiveProbeResults } from '@/lib/store';
import { api, STATUS_QUERY_KEY } from '@/lib/client-api';
import { applyEnvPresets } from '@/lib/subscription-sync';
import { IS_ANDROID_NATIVE, IS_STANDALONE } from '@/lib/runtime-mode';
import { PersonalAccountProvider } from './personal-account-provider';
import { AndroidRuntime } from './android-runtime';
import { ACTIVE_ACCOUNT_SCOPE, setActiveAccountScope } from '@/lib/account-scope';

export function Providers({ children }: { children: ReactNode }) {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: { retry: 1, refetchOnWindowFocus: false, staleTime: 60_000 },
        },
      })
  );
  const [settingsStatus, setSettingsStatus] = useState<'loading' | 'ready' | 'error'>('loading');
  const [settingsAttempt, setSettingsAttempt] = useState(0);
  const [scopeError, setScopeError] = useState(false);

  // store 配置了 skipHydration：等挂载后再读 localStorage，
  // 保证 hydration 阶段客户端与服务端渲染结果一致。
  useEffect(() => {
    // 先等持久化状态恢复，再拉服务端下发数据：
    // 避免 setEnvSources/setLiveEnvSources 的勾选合并发生在 rehydrate 之前被覆盖
    let active = true;
    const deadline = setTimeout(() => {
      active = false;
      setSettingsStatus('error');
    }, 15_000);
    void Promise.resolve()
      .then(() => useAppStore.persist.rehydrate())
      .then(() => {
        if (!active) return;
        clearTimeout(deadline);
        if (!useAppStore.persist.hasHydrated()) {
          setSettingsStatus('error');
          return;
        }
        setSettingsStatus('ready');
        // 测活缓存从 IndexedDB 恢复（并顺带搬迁旧 localStorage 快照里的存量），
        // 与下方 /api/status 拉取互不依赖，失败静默
        void hydrateLiveProbeResults();
        // 拉取部署者通过 DEFAULT_SOURCES / DEFAULT_LIVE_SOURCES 预置的源（失败时静默忽略）
        // 与 AuthProvider 共用同一 query key，/api/status 全站只发一次
        return queryClient.fetchQuery({ queryKey: STATUS_QUERY_KEY, queryFn: () => api.status() });
      })
      .then((d) => {
        // 预置数据（DEFAULT_SOURCES / DEFAULT_LIVE_SOURCES / DEFAULT_SUBSCRIPTIONS）
        // 预置订阅要经鉴权接口拉取，首屏这次可能发生在登录之前而 401 静默失败；
        // 登录成功后由 AuthProvider 再调一次 applyEnvPresets 补齐（函数幂等）
        if (d) return applyEnvPresets(d);
      })
      .catch(() => {
        clearTimeout(deadline);
        if (active && !useAppStore.persist.hasHydrated()) setSettingsStatus('error');
      });
    return () => { active = false; clearTimeout(deadline); };
  }, [queryClient, settingsAttempt]);

  if (settingsStatus !== 'ready') {
    if (settingsStatus === 'loading') return <div role="status" className="flex min-h-screen items-center justify-center text-sm text-muted">正在准备应用…</div>;
    return <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center gap-4 px-6 text-content">
      <h1 className="text-xl font-semibold">暂时无法读取本机设置</h1>
      <p role="status" className="text-sm leading-relaxed text-muted">原有资料已保留。可以重新读取设置。</p>
      <button type="button" className="btn-primary min-h-11" onClick={() => {
        setScopeError(false);
        setSettingsStatus('loading');
        setSettingsAttempt((attempt) => attempt + 1);
      }}>重试读取设置</button>
      {ACTIVE_ACCOUNT_SCOPE && <button type="button" className="btn-ghost min-h-11" onClick={() => {
        try {
          setActiveAccountScope(null);
          window.location.reload();
        } catch { setScopeError(true); }
      }}>返回本机模式，保留账号资料</button>}
      {scopeError && <p role="alert" className="text-sm text-muted">暂时无法切换资料空间，请重试。</p>}
    </main>;
  }

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <ToastProvider>
          {/* 全站常驻：下载事件监听（enqueueDownload）依赖它存在——
              挂在 Header 里会让 /watch 等不渲染 Header 的页面派发的事件凭空丢失 */}
          <AuthProvider>
            <PersonalAccountProvider>
              {IS_ANDROID_NATIVE && <AndroidRuntime />}
              {!IS_STANDALONE && <GlobalDownloadManager />}
              {children}
            </PersonalAccountProvider>
          </AuthProvider>
        </ToastProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}
