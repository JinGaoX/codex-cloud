'use client';

import Link from 'next/link';
import { useEffect, useMemo, useRef, useState, type RefObject } from 'react';
import { flushSync } from 'react-dom';
import { useRouter, useSearchParams } from 'next/navigation';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/client-api';
import { partitionSearchResults } from '@/lib/manual-search';
import { isInDisabledSubscription, isSourceDisabled, resolveSource, useAppStore } from '@/lib/store';
import type { SearchResponse, SearchResultItem, SourceConfig, SourceSearchOutcome } from '@/lib/types';
import { validateSourceUrl } from '@/lib/utils';
import { DetailModal } from './detail-modal';
import { Drawer } from './drawer';
import { HistoryPanel } from './history-panel';
import { Icon } from './icon';
import { RelatedSearch } from './related-search';
import { SearchHistoryDropdown, useSearchHistory } from './search-history';
import { AggregatedCard, aggregateResults } from './video-card';
import './watch-navigation.css';

/** Watch tools do not navigate or pause the current media until a result is chosen. */
export function WatchNavigation({ title, subtitle }: { title: string; subtitle: string }) {
  const router = useRouter();
  const params = useSearchParams();
  const mediaScope = JSON.stringify([params.get('source'), params.get('id')]);
  const [input, setInput] = useState('');
  const [query, setQuery] = useState('');
  const [expanded, setExpanded] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [detailItem, setDetailItem] = useState<SearchResultItem | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const toggleRef = useRef<HTMLButtonElement>(null);
  const returnFocusRef = useRef<HTMLElement | null>(null);
  const returnFocusTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const closeSearch = (restoreFocus = true) => {
    setSearchOpen(false);
    if (returnFocusTimer.current) clearTimeout(returnFocusTimer.current);
    if (restoreFocus) {
      // Return after Drawer has completed its 200ms exit and own focus cleanup.
      returnFocusTimer.current = setTimeout(() => {
        if (returnFocusRef.current?.isConnected) returnFocusRef.current.focus();
        returnFocusTimer.current = null;
      }, 220);
    }
  };
  useEffect(() => () => {
    if (returnFocusTimer.current) clearTimeout(returnFocusTimer.current);
  }, []);

  useEffect(() => {
    if (returnFocusTimer.current) clearTimeout(returnFocusTimer.current);
    setSearchOpen(false);
    setHistoryOpen(false);
    setDetailItem(null);
  }, [mediaScope]);

  const search = (text: string) => {
    const next = text.trim().slice(0, 100);
    if (!next) { inputRef.current?.focus(); return; }
    if (!searchOpen) returnFocusRef.current = window.matchMedia('(max-width:899px)').matches
      ? toggleRef.current : document.activeElement instanceof HTMLElement ? document.activeElement : inputRef.current;
    setInput(next);
    setQuery(next);
    setHistoryOpen(false);
    setSearchOpen(true);
  };
  const toggleSearch = () => {
    if (expanded) {
      setExpanded(false);
      toggleRef.current?.focus();
    } else {
      // The input must be visible and focused in the original iPhone tap.
      flushSync(() => setExpanded(true));
      inputRef.current?.focus();
    }
  };

  return <>
    <header className="watch-navigation" data-search-expanded={expanded || undefined}>
      <div className="watch-nav-inner">
        <div className="watch-nav-identity">
          <button type="button" className="watch-nav-icon" aria-label="返回" onClick={() => {
            if (window.history.length > 1) router.back(); else router.push('/');
          }}><Icon name="chevronDown" className="rotate-90" /></button>
          <Link href="/" className="watch-nav-icon" aria-label="回首页" title="回首页"><Icon name="home" /></Link>
          <div className="watch-nav-title"><h1 title={title}>{title}</h1><p title={subtitle}>{subtitle}</p></div>
        </div>
        <div className="watch-nav-search" id="watch-navigation-search">
          <WatchSearchForm id="watch-navigation-input" inputRef={inputRef} value={input} onChange={setInput} onSearch={search}
            onEscape={() => { setExpanded(false); toggleRef.current?.focus(); }} />
        </div>
        <nav className="watch-nav-tools" aria-label="播放页快捷功能">
          <button ref={toggleRef} type="button" className="watch-nav-icon watch-nav-search-toggle" aria-label={expanded ? '收起搜索' : '展开搜索'}
            aria-expanded={expanded} aria-controls="watch-navigation-search" onClick={toggleSearch}><Icon name={expanded ? 'close' : 'search'} /></button>
          <button type="button" className="watch-nav-history" onClick={() => { setSearchOpen(false); setHistoryOpen(true); }} aria-label="观看历史">
            <Icon name="clock" /><span>历史</span>
          </button>
        </nav>
      </div>
    </header>
    <WatchSearchDrawer open={searchOpen} query={query} input={input} onInput={setInput} onSearch={search}
      onClose={() => closeSearch()} detailOpen={!!detailItem} onOpen={setDetailItem} />
    <HistoryPanel open={historyOpen} onClose={() => setHistoryOpen(false)} />
    <DetailModal item={detailItem} onClose={() => setDetailItem(null)} onPlay={() => { setDetailItem(null); closeSearch(false); }} />
  </>;
}

function WatchSearchForm({ id, value, inputRef, onChange, onSearch, onEscape }: {
  id: string; value: string; inputRef?: RefObject<HTMLInputElement | null>;
  onChange: (value: string) => void; onSearch: (value: string) => void; onEscape?: () => void;
}) {
  const history = useSearchHistory(value);
  const submit = (text: string) => {
    const next = text.trim().slice(0, 100);
    if (!next) return;
    history.close();
    history.record(next);
    onSearch(next);
  };
  return <div ref={history.containerRef} className="watch-search-form-wrap">
    <form className="watch-search-form" autoComplete="off" onSubmit={(event) => { event.preventDefault(); submit(value); }}>
      <label htmlFor={id} className="sr-only">搜索电影、电视剧、动漫</label>
      <Icon name="search" />
      <input ref={inputRef} id={id} value={value} maxLength={100} placeholder="搜索电影、电视剧、动漫…" type="search"
        autoComplete="off" autoCorrect="off" autoCapitalize="none" spellCheck={false} enterKeyHint="search"
        onChange={(event) => { onChange(event.target.value); history.resetActive(); }} onFocus={history.onFocus}
        onKeyDown={(event) => {
          if (event.key === 'Escape') {
            event.stopPropagation();
            if (history.visible) history.close(); else onEscape?.();
            return;
          }
          history.onKeyDown(event, submit);
        }} role="combobox" aria-expanded={history.visible} aria-controls={`${id}-history`} aria-autocomplete="list"
        aria-activedescendant={history.visible && history.activeIndex >= 0 ? `${id}-history-${history.activeIndex}` : undefined} />
      <button type="submit">搜索</button>
    </form>
    {history.visible && <SearchHistoryDropdown id={`${id}-history`} matches={history.matches} activeIndex={history.activeIndex}
      totalCount={history.totalCount} expanded={history.expanded} onToggleExpand={history.toggleExpanded}
      onPick={submit} onRemove={history.remove} onClearAll={history.clearAll} />}
  </div>;
}

function WatchSearchDrawer({ open, query, input, onInput, onSearch, onClose, onOpen, detailOpen }: {
  open: boolean; query: string; input: string; onInput: (value: string) => void; onSearch: (query: string) => void;
  onClose: () => void; onOpen: (item: SearchResultItem) => void; detailOpen: boolean;
}) {
  const queryClient = useQueryClient();
  const customAPIs = useAppStore((state) => state.customAPIs);
  const envSources = useAppStore((state) => state.envSources);
  const selectedKeys = useAppStore((state) => state.selectedKeys);
  const sourceHealth = useAppStore((state) => state.sourceHealth);
  const subscriptions = useAppStore((state) => state.subscriptions);
  const filterAdult = useAppStore((state) => state.yellowFilter);
  const configured = useMemo(() => selectedKeys.map((key) => resolveSource({ customAPIs, envSources }, key)), [selectedKeys, customAPIs, envSources]);
  const sources = useMemo(() => {
    const seen = new Set<string>();
    return configured.filter((source): source is SourceConfig => {
      if (!source || !validateSourceUrl(source.url) || seen.has(source.key)) return false;
      seen.add(source.key);
      return !isSourceDisabled({ sourceHealth }, source.key) && !isInDisabledSubscription({ subscriptions }, source.key);
    });
  }, [configured, sourceHealth, subscriptions]);
  const queryKey = useMemo(() => ['watch-search', query, selectedKeys, filterAdult, configured], [query, selectedKeys, filterAdult, configured]);
  const requestKey = JSON.stringify(queryKey);
  const [stream, setStream] = useState<{ key: string; outcomes: SourceSearchOutcome[] }>({ key: '', outcomes: [] });
  const [visibleCount, setVisibleCount] = useState(24);
  useEffect(() => setVisibleCount(24), [requestKey]);
  useEffect(() => {
    if (!open) void queryClient.cancelQueries({ queryKey, exact: true });
  }, [open, queryClient, queryKey]);
  const search = useQuery({
    queryKey,
    queryFn: async ({ signal }) => {
      const previous = queryClient.getQueryData<SearchResponse>(queryKey);
      setStream({ key: requestKey, outcomes: [] });
      const result = await api.search(query, sources, filterAdult, { signal, onSource: (outcome) => {
        if (signal.aborted) return;
        setStream((value) => value.key === requestKey ? { key: requestKey, outcomes: [...value.outcomes, outcome] } : value);
        useAppStore.getState().recordSourceHealth([outcome]);
      } });
      if (result.partial && previous) {
        const items = new Map(previous.list.map((item) => [JSON.stringify([item.sourceKey, item.vodId]), item]));
        for (const item of result.list) items.set(JSON.stringify([item.sourceKey, item.vodId]), item);
        return { ...result, list: [...items.values()] };
      }
      return result;
    },
    enabled: open && !!query && sources.length > 0,
    staleTime: 300_000,
    retry: false,
  });
  const streamed = useMemo(() => stream.key === requestKey ? stream.outcomes : [], [stream, requestKey]);
  const list = useMemo(() => search.data?.list ?? streamed.flatMap((outcome) => outcome.list), [search.data, streamed]);
  const sections = useMemo(() => partitionSearchResults(list, query), [list, query]);
  const groups = useMemo(() => aggregateResults(sections.main), [sections.main]);
  const extraGroups = useMemo(() => aggregateResults(sections.supplementary), [sections.supplementary]);
  const failures = search.data?.failures ?? streamed.filter((outcome) => !outcome.ok).map((outcome) => ({ sourceKey: outcome.sourceKey, error: outcome.error || '请求失败' }));
  const sourceIncomplete = !search.isFetching && list.length === 0 && failures.length > 0;
  const warning = search.error instanceof Error ? search.error.message : search.data?.error
    || (sourceIncomplete ? '本次搜索暂未全部完成，请重试或查看片源失败原因。' : undefined);
  const ready = Boolean(search.data) && !search.isFetching;
  const available = !search.error && (list.length > 0 || failures.length === 0 || streamed.some((outcome) => outcome.ok) || failures.length < sources.length);

  return <Drawer open={open} onClose={onClose} title="搜索影视" width="max-w-4xl" modal={!detailOpen} resetScrollKey={requestKey}
    subheader={<WatchSearchForm id="watch-drawer-search-input" value={input} onChange={onInput} onSearch={onSearch} onEscape={onClose} />}>
    <div className="watch-search-content">
      <div className="watch-search-heading"><h2>“{query}”的搜索结果</h2><span>{sources.length} 个可用片源</span></div>
      {sources.length === 0 ? <div className="watch-search-empty"><p>当前没有可参与搜索的片源。</p>
        <p>请在首页的片源管理中添加、勾选或恢复点播源。</p><Link className="btn-primary" href="/">返回首页管理片源</Link></div> : <>
        {search.isFetching && <p className="watch-search-status" role="status">正在搜索，找到的结果会陆续显示…</p>}
        {warning && <div className="watch-search-warning" role="status"><span>{warning}</span><button className="btn-ghost" type="button" disabled={search.isFetching} onClick={() => void search.refetch()}>重试搜索</button></div>}
        {failures.length > 0 && <details className="watch-search-failures"><summary>查看 {failures.length} 个片源的失败原因</summary><ul>
          {failures.map((failure) => <li key={failure.sourceKey}>{configured.find((source) => source?.key === failure.sourceKey)?.name ?? failure.sourceKey}：{failure.error}</li>)}
        </ul></details>}
        {groups.length > 0 && <><p className="watch-search-result-count">原词找到 {groups.length} 部影片</p><div className="watch-search-results">
          {groups.slice(0, visibleCount).map((group) => <AggregatedCard key={group.key} group={group} sources={sources} onOpen={onOpen} />)}
        </div>{groups.length > visibleCount && <button className="btn-ghost" type="button" onClick={() => setVisibleCount((count) => count + 24)}>加载更多影片</button>}</>}
        {extraGroups.length > 0 && <section className="watch-search-supplementary"><h3>解说、预告与花絮</h3><div className="watch-search-results">
          {extraGroups.slice(0, visibleCount).map((group) => <AggregatedCard key={group.key} group={group} sources={sources} onOpen={onOpen} />)}
        </div></section>}
        {ready && list.length === 0 && !warning && <p className="watch-search-status">原词暂未找到资源，可以查看下面的相近片名，或换个关键词。</p>}
        {open && <RelatedSearch query={query} requestKey={requestKey} ready={ready} available={available} originalItems={list} sources={sources} filterAdult={filterAdult} onOpen={onOpen} />}
      </>}
      <Link className="watch-search-full-link" href={`/?s=${encodeURIComponent(query)}`}>打开完整搜索页</Link>
    </div>
  </Drawer>;
}
