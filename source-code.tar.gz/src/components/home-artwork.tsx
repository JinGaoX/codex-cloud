'use client';

import { useCallback, useEffect, useRef, useState, type SyntheticEvent } from 'react';
import { appPath } from '@/lib/app-path';
import { homeArtworkCandidates, homeArtworkShape, type HomeArtworkCandidate, type HomeArtworkShape } from '@/lib/home-artwork';
import { PLATFORM_CATALOG } from '@/lib/platform-catalog';
import { HOME_WIDE_ARTWORK } from './home-featured';
import { SmartImage } from './smart-image';

interface HomeArtworkProps {
  title: string;
  pic?: string;
  variant: 'hero' | 'card';
  eager?: boolean;
}

/** A changed record/source starts a fresh image sequence, including cached failures. */
export function HomeArtwork({ title, pic, variant, eager = false }: HomeArtworkProps) {
  const candidates = homeArtworkCandidates(title, pic, HOME_WIDE_ARTWORK, PLATFORM_CATALOG);
  return <ArtworkSequence key={JSON.stringify([title, pic, variant, candidates])}
    candidates={candidates} variant={variant} eager={eager} />;
}

function ArtworkSequence({ candidates, variant, eager }: {
  candidates: readonly HomeArtworkCandidate[]; variant: HomeArtworkProps['variant']; eager: boolean;
}) {
  const [index, setIndex] = useState(0);
  // A late error/exhaustion callback from the previous image must not skip a fallback.
  const advance = useCallback(() => setIndex((current) => current === index ? current + 1 : current), [index]);
  const candidate = candidates[index];
  return <ArtworkFrame key={index} candidate={candidate} variant={variant} eager={eager} onFailed={advance} />;
}

interface LoadedArtwork {
  src: string;
  shape: HomeArtworkShape;
  width: number;
  height: number;
}

/** Each candidate has isolated load state; a replacement never borrows the old poster. */
function ArtworkFrame({ candidate, variant, eager, onFailed }: {
  candidate?: HomeArtworkCandidate; variant: HomeArtworkProps['variant']; eager: boolean; onFailed: () => void;
}) {
  const container = useRef<HTMLDivElement>(null);
  const [loaded, setLoaded] = useState<LoadedArtwork | null>(null);
  const acceptImage = useCallback((image: HTMLImageElement) => {
    if (!image.classList.contains('home-artwork-image')) return;
    const shape = homeArtworkShape(image.naturalWidth, image.naturalHeight);
    if (!shape) return;
    const next = { src: image.currentSrc || image.src, shape, width: image.naturalWidth, height: image.naturalHeight };
    setLoaded((previous) => previous?.src === next.src && previous.shape === next.shape
      && previous.width === next.width && previous.height === next.height ? previous : next);
  }, []);
  const onLoad = (event: SyntheticEvent<HTMLDivElement>) => {
    if (event.target instanceof HTMLImageElement) acceptImage(event.target);
  };
  useEffect(() => {
    // A hot HTTP/SW cache may have completed before hydration attaches onLoad.
    const image = container.current?.querySelector<HTMLImageElement>('.home-artwork-image');
    if (image?.complete) acceptImage(image);
  }, [acceptImage]);
  return <div ref={container} className={`home-artwork home-artwork-${variant}`}
    data-shape={loaded?.shape} data-loaded={loaded ? true : undefined}
    data-empty={!candidate || undefined} data-artwork-source={candidate?.source}
    data-image-width={loaded?.width} data-image-height={loaded?.height}
    onLoadCapture={onLoad} onErrorCapture={(event) => {
      if (event.target instanceof HTMLImageElement && event.target.classList.contains('home-artwork-image')) setLoaded(null);
    }} aria-hidden="true">
    {candidate?.kind === 'bundled' ? (
      // File names come from the existing reviewed catalog, never a guessed title URL.
      // eslint-disable-next-line @next/next/no-img-element
      <img src={appPath(candidate.url)} alt="" width="1920" height="1080"
        className="home-artwork-image" loading={eager ? 'eager' : 'lazy'} decoding="async"
        fetchPriority={eager ? 'high' : 'auto'} onError={onFailed} />
    ) : candidate ? <SmartImage url={candidate.url} mode="direct" alt="" className="home-artwork-image"
      loading={eager ? 'eager' : 'lazy'} onExhausted={onFailed} /> : null}
    {loaded?.shape === 'poster' && (
      // Both hero and card reuse the resolved source URL, including SmartImage fallbacks.
      // eslint-disable-next-line @next/next/no-img-element
      <img src={loaded.src} alt="" className="home-artwork-poster" data-artwork-layer="poster"
        width={loaded.width} height={loaded.height} decoding="async" referrerPolicy="no-referrer" onError={onFailed} />
    )}
  </div>;
}
