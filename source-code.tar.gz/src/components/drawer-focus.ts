type FocusReturnTarget = { readonly isConnected: boolean; focus: () => void };

/** An exiting drawer must not take focus back from a newly opened panel. */
export function drawerMayRestoreFocus(
  panel: Pick<HTMLElement, 'contains'> | null,
  activeElement: Element | null,
  idleElements: readonly Element[],
) {
  return !activeElement || idleElements.includes(activeElement) || Boolean(panel?.contains(activeElement));
}

/** One focus origin per open session, including temporary non-modal nested dialogs. */
export function createDrawerFocusReturn() {
  let active = false;
  let origin: FocusReturnTarget | null = null;
  return {
    open(modal: boolean, target: FocusReturnTarget | null) {
      if (active) return;
      active = true;
      origin = modal ? target : null;
    },
    close(restoreFocus = true) {
      const target = origin;
      active = false;
      origin = null;
      if (restoreFocus && target?.isConnected) target.focus();
    },
  };
}
