import { describe, expect, it } from 'vitest';
import { discoveryHref, libraryLists, readLibraryView } from './library-browser-state';
import { homeCategoryView } from './home-navigation-state';

const parse = (query: string) => readLibraryView(new URLSearchParams(query));

describe('home category navigation', () => {
  it('changes the real browse type while retaining allowed filters and resetting the window', () => {
    const next = homeCategoryView(parse('type=movie&sort=S&country=韩国&genre=剧情&minRating=8&size=21&offset=42&page=3'), 'tv');
    expect(next).toMatchObject({ type: 'tv', mode: 'browse', sort: 'S', country: '韩国', genre: '剧情', minRating: 8, size: 21, offset: 0, page: 1 });
    expect(discoveryHref(next)).toMatch(/^\/\?type=tv&mode=browse/);
    expect(discoveryHref(next)).toContain('#home-discovery');
  });

  it('keeps ranking mode but selects a supported ranking for the chosen category', () => {
    const next = homeCategoryView(parse('type=movie&mode=ranking&list=top250&size=24&offset=48'), 'tv');
    expect(next).toMatchObject({ type: 'tv', mode: 'ranking', list: libraryLists('tv')[0].id, page: 1, size: 24, offset: 0 });
    expect(homeCategoryView(next, 'movie')).toMatchObject({ type: 'movie', mode: 'ranking', list: 'top250', offset: 0 });
  });

  it('respects variety ranking and animation categories without carrying a foreign list', () => {
    const variety = homeCategoryView(parse('type=tv&mode=browse&size=20&offset=60'), 'show');
    expect(variety).toMatchObject({ type: 'show', mode: 'ranking', offset: 0 });
    expect(libraryLists('show').some((entry) => entry.id === variety.list)).toBe(true);
    expect(homeCategoryView(variety, 'animation')).toMatchObject({ type: 'animation', mode: 'ranking', list: 'douban_movie_animation', offset: 0 });
  });

  it('does not carry search or private source parameters to discovery', () => {
    const view = parse('type=tv&s=private-search&sourceUrl=https://private.invalid&size=21&offset=21');
    expect(discoveryHref(homeCategoryView(view, 'movie'))).not.toMatch(/private|sourceUrl|[?&]s=/);
  });
});
