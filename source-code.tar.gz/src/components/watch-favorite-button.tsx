'use client';

import { useEffect, useRef, useState } from 'react';
import { useLiveQuery } from 'dexie-react-hooks';
import { addFavorite, db, favoriteKeyOf, removeFavorite } from '@/lib/db';
import type { SearchResultItem } from '@/lib/types';
import { Icon } from './icon';
import { useToast } from './toast';

/** Shared by CMS playback and direct videos; no separate playback favorite store. */
export function WatchFavoriteButton({ item }: { item: SearchResultItem }) {
  const { toast } = useToast();
  const [readAttempt, setReadAttempt] = useState(0);
  const [saving, setSaving] = useState(false);
  const savingRef = useRef(false);
  const mountedRef = useRef(true);
  const key = favoriteKeyOf(item.sourceKey, item.vodId);
  const result = useLiveQuery(async () => {
    try { return { entry: await db.favorites.get(key), error: false }; }
    catch { return { entry: undefined, error: true }; }
  }, [key, readAttempt]);

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  const toggle = async () => {
    if (savingRef.current || !result) return;
    if (result.error) {
      setReadAttempt((attempt) => attempt + 1);
      return;
    }
    savingRef.current = true;
    setSaving(true);
    try {
      // Read inside the same transaction as the write so a detail sheet or
      // another tab's latest change is respected even before the live query updates.
      const removed = await db.transaction('rw', db.favorites, async () => {
        const existing = await db.favorites.get(key);
        if (existing) await removeFavorite(item.sourceKey, item.vodId);
        else await addFavorite(item);
        return Boolean(existing);
      });
      if (mountedRef.current) toast(removed ? '已取消收藏' : '已加入收藏', 'success');
    } catch {
      if (mountedRef.current) toast('收藏保存失败，请检查浏览器存储空间后重试', 'error');
    } finally {
      savingRef.current = false;
      if (mountedRef.current) setSaving(false);
    }
  };

  const favorite = Boolean(result?.entry);
  const label = !result ? '正在读取收藏状态'
    : result.error ? '重试读取收藏状态'
    : saving ? '正在保存收藏'
    : `${favorite ? '取消收藏' : '收藏'} ${item.name}`;
  return <button type="button" className="btn-ghost btn-sm min-h-11 shrink-0"
    aria-label={label} aria-pressed={favorite} aria-busy={!result || saving}
    title={result?.error ? '无法读取本机收藏，点击重试' : label}
    disabled={!result || saving} onClick={() => void toggle()}>
    <Icon name={result?.error ? 'refresh' : 'heart'} className="w-4 h-4" />
    {!result ? '读取中' : result.error ? '重试收藏' : saving ? '保存中' : favorite ? '已收藏' : '收藏'}
  </button>;
}
