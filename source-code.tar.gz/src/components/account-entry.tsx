'use client';

import { accountEntryPresentation } from '@/lib/account-entry-state';
import { usePersonalAccount } from './personal-account-provider';
import './account-entry.css';

/** A compact shortcut to the existing account panel, without exposing an email in navigation. */
export function AccountEntry({ onOpen, active }: { onOpen: () => void; active: boolean }) {
  const account = usePersonalAccount();
  const view = accountEntryPresentation(account);
  return <button type="button" className="account-entry" onClick={onOpen}
    aria-label={view.description} title={view.description} aria-haspopup="dialog" aria-expanded={active}
    data-state={view.indicator}>
    <span className="account-entry-icon"><AccountGlyph />{view.indicator !== 'none' && <span className="account-entry-indicator" aria-hidden="true" />}</span>
    <span className="account-entry-label">{view.label}</span>
  </button>;
}

export function AccountGlyph() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <circle cx="12" cy="8" r="3.5" /><path d="M4.5 21v-2a7.5 7.5 0 0 1 15 0v2" />
  </svg>;
}
