import type { LibraryType } from '@/lib/library-discovery';
import { libraryHref, libraryLists, readLibraryView, type LibraryView } from './library-browser-state';

/** Follow the gallery's category rules; a different category always starts at its first item. */
export function homeCategoryView(view: LibraryView, type: LibraryType): LibraryView {
  const next: LibraryView = {
    ...view,
    type,
    list: type === 'movie' ? 'top250' : libraryLists(type)[0]?.id ?? 'douban_movie_weekly',
    page: 1,
    offset: 0,
  };
  return readLibraryView(new URLSearchParams(libraryHref(next).split('?')[1]));
}
