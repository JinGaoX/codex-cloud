'use client';

import Link from 'next/link';
import { useEffect, useRef, type ReactNode } from 'react';
import { APP_BRAND } from '@/lib/app-brand';
import type { AppPanel } from '@/lib/app-navigation';
import { Icon } from './icon';
import { IS_STANDALONE, SUPPORTS_LIVE_TV } from '@/lib/runtime-mode';
import { InstallAppButton } from './pwa-runtime';
import type { LibraryType } from '@/lib/library-discovery';
import { HomeSidebar } from './home-sidebar';
import { AccountEntry, AccountGlyph } from './account-entry';

/** Shared cinema navigation. Header continues to own panels and search behavior. */
export function HomeNavigation({ onPanel, onHome, onDiscover, discoveryActive = false, discoveryType = 'movie', onDownload, activePanel, search, persistentSearch = false, searchOpen, onSearchOpen, onSearchClose, isHome = false, isLive, heading, skipTarget = 'app-main' }: {
  onPanel: (panel: AppPanel) => void;
  onHome: () => void;
  onDiscover: (type?: LibraryType) => void;
  discoveryActive?: boolean;
  discoveryType?: LibraryType;
  onDownload: () => void;
  activePanel?: AppPanel;
  search?: ReactNode;
  persistentSearch?: boolean;
  searchOpen: boolean;
  onSearchOpen: (trigger: HTMLElement) => void;
  onSearchClose: (restoreFocus?: boolean) => void;
  isHome?: boolean;
  isLive: boolean;
  heading?: string;
  skipTarget?: string;
}) {
  const menu = useRef<HTMLDetailsElement>(null);
  useEffect(() => {
    const dismiss = (event: PointerEvent) => {
      if (event.target instanceof Node && !menu.current?.contains(event.target)) menu.current?.removeAttribute('open');
    };
    document.addEventListener('pointerdown', dismiss);
    return () => document.removeEventListener('pointerdown', dismiss);
  }, []);
  const selectPanel = (panel: AppPanel) => {
    onSearchClose();
    menu.current?.removeAttribute('open');
    menu.current?.querySelector('summary')?.focus();
    onPanel(panel);
  };
  const showPanel = (panel: AppPanel) => { onSearchClose(); menu.current?.removeAttribute('open'); onPanel(panel); };
  const toggleSearch = (trigger: HTMLElement) => {
    if (searchOpen) onSearchClose(true);
    else {
      menu.current?.removeAttribute('open');
      onSearchOpen(trigger);
    }
  };
  return <>
    <a className="home-skip-link" href={`#${skipTarget}`}>跳到主要内容</a>
    <HomeSidebar onHome={() => { onSearchClose(); menu.current?.removeAttribute('open'); onHome(); }}
      onDiscover={(type) => { onSearchClose(); menu.current?.removeAttribute('open'); onDiscover(type); }}
      onPanel={selectPanel} isHome={isHome} isLive={isLive} discoveryActive={discoveryActive} activeType={discoveryType} activePanel={activePanel} />
    <header className="home-topbar" data-search-open={searchOpen || undefined} data-search-persistent={persistentSearch || undefined}>
      <div className="home-topbar-inner">
        <Link href="/" className="home-brand" aria-label={`${APP_BRAND.name} 首页`} onClick={() => onSearchClose()}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={APP_BRAND.icons.large} width="34" height="34" alt="" />
          <span>{APP_BRAND.shortName}</span>
        </Link>
        {heading && <h1 className="sr-only">{heading}</h1>}
        <nav className="home-primary-nav" aria-label="主导航">
          <button type="button" onClick={() => { onSearchClose(); onHome(); }} aria-current={isHome && !discoveryActive && !activePanel ? 'page' : undefined}>首页</button>
          <button type="button" aria-current={discoveryActive && !activePanel ? 'location' : undefined} onClick={() => { onSearchClose(); onDiscover(); }}>发现</button>
          {SUPPORTS_LIVE_TV && <Link href="/live" aria-current={isLive ? 'page' : undefined}><Icon name="bolt" />直播</Link>}
          <button type="button" aria-label="我的收藏" aria-pressed={activePanel === 'favorites'} onClick={() => showPanel('favorites')}><Icon name="heart" /><span>收藏</span></button>
          <button type="button" aria-label="观看历史" aria-pressed={activePanel === 'history'} onClick={() => showPanel('history')}><Icon name="clock" /><span>历史</span></button>
        </nav>
        {search && <div className="home-header-search" id="home-header-search" onKeyDown={(event) => {
          if (event.key === 'Escape' && searchOpen) {
            onSearchClose(true);
          }
        }}>{search}</div>}
        <div className="home-topbar-tools">
          {search && !persistentSearch && <button type="button" className="home-search-toggle" aria-label={searchOpen ? '收起搜索' : '搜索'}
            aria-expanded={searchOpen} aria-controls="home-header-search" onClick={(event) => toggleSearch(event.currentTarget)}><Icon name={searchOpen ? 'close' : 'search'} /></button>}
          <AccountEntry active={activePanel === 'account'} onOpen={() => showPanel('account')} />
          <button type="button" className="home-desktop-settings" aria-label="设置" onClick={() => showPanel('settings')}><Icon name="gear" /></button>
          <details className="home-more" ref={menu} onToggle={(event) => {
            if (event.currentTarget.open) onSearchClose();
          }} onBlurCapture={(event) => {
            if (event.relatedTarget instanceof Node && !event.currentTarget.contains(event.relatedTarget)) event.currentTarget.open = false;
          }} onKeyDown={(event) => {
            if (event.key === 'Escape') { menu.current?.removeAttribute('open'); menu.current?.querySelector('summary')?.focus(); }
          }}>
            <summary aria-label="更多功能"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="5" cy="12" r="1.8"/><circle cx="12" cy="12" r="1.8"/><circle cx="19" cy="12" r="1.8"/></svg></summary>
            <nav className="home-more-panel" aria-label="更多观影功能">
              <button type="button" onClick={() => selectPanel('account')}><AccountGlyph />账号与同步</button>
              <button type="button" onClick={() => selectPanel('sources')}><Icon name="link" />片源管理</button>
              <button type="button" onClick={() => selectPanel('settings')}><Icon name="gear" />设置</button>
              {!IS_STANDALONE && <button type="button" onClick={() => { menu.current?.removeAttribute('open'); menu.current?.querySelector('summary')?.focus(); onDownload(); }}><Icon name="download" />下载管理</button>}
              <InstallAppButton />
            </nav>
          </details>
        </div>
      </div>
    </header>
  </>;
}
