'use client';

import Link from 'next/link';
import { useCallback, useEffect, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import { usePathname, useRouter } from 'next/navigation';
import { ThemeToggle } from './theme';
import { SourceManagerDrawer } from './source-manager';
import { HistoryPanel } from './history-panel';
import { FavoritesPanel } from './favorites-panel';
import { InstallAppButton } from './pwa-runtime';
import { APP_BRAND } from '@/lib/app-brand';
import { requestShowDownloadManager } from './download-manager';
import { Icon } from './icon';
import { SearchHistoryDropdown, useSearchHistory } from './search-history';
import { cn } from '@/lib/utils';
import { IS_STANDALONE, SUPPORTS_LIVE_TV } from '@/lib/runtime-mode';
import { APP_PANEL_EVENT, type AppPanel } from '@/lib/app-navigation';
import { appPath } from '@/lib/app-path';
import { observeSoftwareKeyboard } from '@/lib/mobile-keyboard';
import { HomeNavigation } from './home-navigation';
import { DISCOVERY_NAVIGATION_EVENT, discoveryHref, hasLibraryView, readLastLibraryView, readLibraryView } from './library-browser-state';
import { homeCategoryView } from './home-navigation-state';
import type { LibraryType } from '@/lib/library-discovery';
import type { ReactNode } from 'react';

/** One cinema shell for home, search and secondary pages; panel behavior is shared. */
export function Header({ showSearch = false, variant = 'default', homeSearch, isHome = false, heading, skipTarget = 'app-main' }: {
  showSearch?: boolean;
  variant?: 'default' | 'cinema-home' | 'legacy';
  homeSearch?: ReactNode;
  isHome?: boolean;
  heading?: string;
  skipTarget?: string;
}) {
  const router = useRouter();
  const pathname = usePathname();
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [settingsTab, setSettingsTab] = useState<'sources' | 'live-sources' | 'account' | undefined>();
  const [historyOpen, setHistoryOpen] = useState(false);
  const [favoritesOpen, setFavoritesOpen] = useState(false);
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const searchTrigger = useRef<HTMLElement | null>(null);
  const searchInputId = homeSearch ? 'home-search-input' : 'header-search-input';
  const [query, setQuery] = useState('');
  const [discoveryActive, setDiscoveryActive] = useState(false);
  const [discoveryType, setDiscoveryType] = useState<LibraryType>('movie');
  useEffect(() => {
    const sync = () => {
      const params = new URLSearchParams(window.location.search);
      setDiscoveryActive(pathname === '/' && window.location.hash === '#home-discovery' && !params.has('s'));
      setDiscoveryType((hasLibraryView(params) ? readLibraryView(params) : readLastLibraryView() ?? readLibraryView(params)).type);
    };
    sync();
    window.addEventListener('hashchange', sync);
    window.addEventListener('popstate', sync);
    window.addEventListener(DISCOVERY_NAVIGATION_EVENT, sync);
    return () => {
      window.removeEventListener('hashchange', sync);
      window.removeEventListener('popstate', sync);
      window.removeEventListener(DISCOVERY_NAVIGATION_EVENT, sync);
    };
  }, [pathname, isHome]);
  // 与首页搜索框共用同一套「最近搜索」下拉逻辑
  const searchHistory = useSearchHistory(query);

  const closeSearch = useCallback((restoreFocus = false) => {
    const active = document.activeElement;
    // Explicitly dismiss the field before hiding its container. Closing the
    // keyboard itself leaves search open and does not force a focus change.
    if (active instanceof HTMLElement && document.getElementById('home-header-search')?.contains(active)) active.blur();
    if (restoreFocus) {
      // The original trigger may be in the hidden tab bar; reveal it before focus.
      flushSync(() => { setSearchOpen(false); setKeyboardVisible(false); });
      searchTrigger.current?.focus({ preventScroll: true });
    } else setSearchOpen(false);
  }, []);

  const openPanel = useCallback((panel: AppPanel) => {
    closeSearch();
    const tab = panel === 'sources' || panel === 'live-sources' || panel === 'account' ? panel : undefined;
    setSettingsOpen(panel === 'settings' || tab !== undefined);
    setSettingsTab(tab);
    setHistoryOpen(panel === 'history');
    setFavoritesOpen(panel === 'favorites');
  }, [closeSearch]);

  const openSearch = (trigger: HTMLElement) => {
    searchTrigger.current = trigger;
    // Reveal and focus within the tap itself so iOS can open its keyboard.
    flushSync(() => setSearchOpen(true));
    document.getElementById(searchInputId)?.focus();
  };

  useEffect(() => {
    const onOpenPanel = (event: Event) => {
      const panel = (event as CustomEvent<unknown>).detail;
      if (panel === 'settings' || panel === 'sources' || panel === 'live-sources' || panel === 'account' || panel === 'history' || panel === 'favorites') openPanel(panel);
    };
    window.addEventListener(APP_PANEL_EVENT, onOpenPanel);
    return () => window.removeEventListener(APP_PANEL_EVENT, onOpenPanel);
  }, [openPanel]);

  // Recheck after a sheet unmounts too: removing a focused field need not blur.
  useEffect(() => observeSoftwareKeyboard(setKeyboardVisible), [settingsOpen, historyOpen, favoritesOpen, searchOpen]);

  const submitSearch = (text: string) => {
    const q = text.trim().slice(0, 100);
    if (!q) return;
    searchHistory.close();
    router.push(`/?s=${encodeURIComponent(q)}`, { scroll: false });
    // 顶栏搜索一并写入最近搜索（此前只有首页会记录）
    searchHistory.record(q);
  };

  const pickHistory = (text: string) => {
    setQuery(text);
    submitSearch(text);
  };

  const goHome = () => {
    closeSearch();
    setDiscoveryActive(false);
    setSettingsOpen(false);
    setHistoryOpen(false);
    setFavoritesOpen(false);
    if (IS_STANDALONE && pathname === '/') window.history.pushState(null, '', appPath('/'));
    else router.push('/');
    window.scrollTo({ top: 0, behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
  };

  const goDiscover = (type?: LibraryType) => {
    closeSearch();
    setSettingsOpen(false); setHistoryOpen(false); setFavoritesOpen(false);
    setDiscoveryActive(true);
    const params = new URLSearchParams(window.location.search);
    const currentView = pathname === '/' && hasLibraryView(params) ? readLibraryView(params) : readLastLibraryView() ?? readLibraryView(new URLSearchParams());
    const view = type ? homeCategoryView(currentView, type) : currentView;
    setDiscoveryType(view.type);
    const href = discoveryHref(view);
    if (IS_STANDALONE && pathname === '/') {
      window.history.pushState(null, '', appPath(href));
      window.dispatchEvent(new Event(DISCOVERY_NAVIGATION_EVENT));
    }
    else router.push(href, { scroll: false });
    // If already on home, no remount or hash-change event is needed to reach the same section.
    document.getElementById('home-discovery')?.scrollIntoView({ block: 'start', behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'instant' : 'smooth' });
  };

  // Secondary pages use the same real search handlers and history dropdown.
  // The home route supplies its own URL-driven form, so only one form is mounted.
  const headerSearch = (
    <section aria-label="搜索影视" className="home-search-area">
      <div ref={searchHistory.containerRef} className="home-search-box relative w-full z-20">
        <form className="w-full" autoComplete="off" onSubmit={(event) => { event.preventDefault(); submitSearch(query); }}>
          <div className="flex items-stretch min-h-11">
            <label htmlFor="header-search-input" className="home-search-label"><Icon name="search" /><span>找片</span></label>
            <input
              id="header-search-input"
              className="flex-1 min-w-0 pr-2 bg-transparent text-base text-content placeholder:text-faint focus:outline-none"
              aria-label="搜索影片"
              placeholder="搜索电影、电视剧、动漫…"
              enterKeyHint="search"
              autoCapitalize="none"
              autoCorrect="off"
              autoComplete="off"
              spellCheck={false}
              value={query}
              maxLength={100}
              onChange={(event) => { setQuery(event.target.value); searchHistory.resetActive(); }}
              onFocus={searchHistory.onFocus}
              onKeyDown={(event) => searchHistory.onKeyDown(event, pickHistory)}
              role="combobox"
              aria-expanded={searchHistory.visible}
              aria-controls="header-search-history"
              aria-autocomplete="list"
              aria-activedescendant={searchHistory.visible && searchHistory.activeIndex >= 0 ? `header-search-history-${searchHistory.activeIndex}` : undefined}
            />
            <button type="submit" className="btn-primary shrink-0">搜索</button>
          </div>
        </form>
        {searchHistory.visible && <SearchHistoryDropdown
          id="header-search-history"
          matches={searchHistory.matches}
          activeIndex={searchHistory.activeIndex}
          totalCount={searchHistory.totalCount}
          expanded={searchHistory.expanded}
          onToggleExpand={searchHistory.toggleExpanded}
          onPick={pickHistory}
          onRemove={searchHistory.remove}
          onClearAll={searchHistory.clearAll}
        />}
      </div>
    </section>
  );

  return (
    <>
      {variant !== 'legacy' ? <HomeNavigation onPanel={openPanel} onHome={goHome} onDiscover={goDiscover} discoveryActive={discoveryActive} discoveryType={discoveryType} onDownload={requestShowDownloadManager} search={homeSearch ?? headerSearch}
        isHome={isHome} isLive={pathname === '/live'} heading={heading} skipTarget={skipTarget}
        searchOpen={searchOpen} onSearchOpen={openSearch} onSearchClose={closeSearch}
        activePanel={settingsOpen ? settingsTab ?? 'settings' : historyOpen ? 'history' : favoritesOpen ? 'favorites' : undefined} /> : <header className="vip-header sticky top-0 z-40 bg-surface/90 backdrop-blur-xl border-b border-line">
        <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 flex items-center gap-2 sm:gap-3 h-16">
          <Link href="/" aria-label={`${APP_BRAND.name} 首页`} className="flex items-center shrink-0 gap-2.5 min-h-11">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={APP_BRAND.icons.large} alt={APP_BRAND.name} className="w-9 h-9 rounded-xl" />
            <span className="leading-tight"><span className="block text-lg font-semibold tracking-wide text-content">{APP_BRAND.shortName}</span><span className="block mt-0.5 text-[9px] tracking-[0.12em] text-faint">电影 · 电视剧 · 综艺</span></span>
          </Link>

          {showSearch && (
            <form
              className="flex-1 min-w-0 max-w-xl hidden sm:block"
              autoComplete="off"
              onSubmit={(e) => {
                e.preventDefault();
                submitSearch(query);
              }}
            >
              <div ref={searchHistory.containerRef} className="relative">
                <input
                  className={cn(
                    'input w-full h-9',
                    // 展开时：上圆角与外框沿用聚焦样式，底边改为内部分隔线，与下拉拼成同一面板
                    searchHistory.visible &&
                      'rounded-b-none border-accent border-b-line bg-surface-raised focus-visible:ring-0'
                  )}
                  aria-label="搜索影片"
                  placeholder="搜索影片..."
                  value={query}
                  maxLength={100}
                  autoComplete="off"
                  spellCheck={false}
                  onChange={(e) => {
                    setQuery(e.target.value);
                    searchHistory.resetActive();
                  }}
                  onFocus={searchHistory.onFocus}
                  onKeyDown={(e) => searchHistory.onKeyDown(e, pickHistory)}
                  role="combobox"
                  aria-expanded={searchHistory.visible}
                  aria-controls="header-search-history"
                  aria-autocomplete="list"
                  aria-activedescendant={
                    searchHistory.visible && searchHistory.activeIndex >= 0
                      ? `header-search-history-${searchHistory.activeIndex}`
                      : undefined
                  }
                />
                {searchHistory.visible && (
                  <SearchHistoryDropdown
                    id="header-search-history"
                    matches={searchHistory.matches}
                    activeIndex={searchHistory.activeIndex}
                    totalCount={searchHistory.totalCount}
                    expanded={searchHistory.expanded}
                    onToggleExpand={searchHistory.toggleExpanded}
                    onPick={pickHistory}
                    onRemove={searchHistory.remove}
                    onClearAll={searchHistory.clearAll}
                  />
                )}
              </div>
            </form>
          )}

          <div className="flex-1 sm:hidden" />

          <nav aria-label="应用工具" className="flex items-center ml-auto md:hidden [&_button]:min-h-11 [&_button]:min-w-11 [&_button]:inline-flex [&_button]:items-center [&_button]:justify-center">
              <ThemeToggle />
          </nav>

          <nav aria-label="观影工具" className="hidden md:flex items-center shrink-0 gap-0.5 lg:gap-1 ml-auto">
            <HeaderLink href="/" active={pathname === '/'}>首页</HeaderLink>
            {SUPPORTS_LIVE_TV && <HeaderLink href="/live" active={pathname === '/live'}>
              直播
            </HeaderLink>}
            <ThemeToggle />
            <InstallAppButton />
            <IconButton label="我的收藏" onClick={() => openPanel('favorites')}>
              <Icon name="heart" />
            </IconButton>
            <IconButton label="观看历史" onClick={() => openPanel('history')}>
              <Icon name="clock" />
            </IconButton>
            <IconButton label="管理片源" onClick={() => openPanel('sources')}>
              <Icon name="link" />
            </IconButton>
            {!IS_STANDALONE && <span className="hidden sm:contents"><IconButton label="下载管理" onClick={requestShowDownloadManager}>
              <Icon name="download" />
            </IconButton></span>}
            <IconButton label="设置" onClick={() => openPanel('settings')}>
              <Icon name="gear" />
            </IconButton>
          </nav>
        </div>
      </header>}

        <nav
          aria-label="主要导航"
          data-mobile-tab-bar
          className={cn('vip-bottom-nav fixed inset-x-0 bottom-0 z-40 grid border-t border-line bg-surface/95 backdrop-blur-xl md:hidden', SUPPORTS_LIVE_TV ? 'grid-cols-5' : 'grid-cols-4')}
          style={{ display: keyboardVisible ? 'none' : undefined, paddingBottom: 'env(safe-area-inset-bottom)', paddingLeft: 'max(12px, env(safe-area-inset-left))', paddingRight: 'max(12px, env(safe-area-inset-right))' }}
        >
          <MobileNavItem label="首页" active={isHome && !discoveryActive && !searchOpen && !settingsOpen && !historyOpen && !favoritesOpen} page onClick={goHome}><Icon name="home" /></MobileNavItem>
          <MobileNavItem label="搜索" active={searchOpen} expanded={searchOpen} controls="home-header-search" onClick={openSearch}><Icon name="search" /></MobileNavItem>
          {SUPPORTS_LIVE_TV && <MobileNavItem label="直播" active={pathname === '/live' && !searchOpen && !settingsOpen && !historyOpen && !favoritesOpen} href="/live"><Icon name="bolt" /></MobileNavItem>}
          <MobileNavItem label="收藏" ariaLabel="我的收藏" active={favoritesOpen} onClick={() => openPanel('favorites')}><Icon name="heart" /></MobileNavItem>
          <MobileNavItem label="历史" ariaLabel="观看历史" active={historyOpen} onClick={() => openPanel('history')}><Icon name="clock" /></MobileNavItem>
        </nav>

      <SourceManagerDrawer open={settingsOpen} initialTab={settingsTab} onClose={() => setSettingsOpen(false)} />
      <HistoryPanel open={historyOpen} onClose={() => setHistoryOpen(false)} />
      <FavoritesPanel open={favoritesOpen} onClose={() => setFavoritesOpen(false)} />
    </>
  );
}

function MobileNavItem({ label, ariaLabel, active, page = false, href, expanded, controls, onClick, children }: {
  label: string;
  ariaLabel?: string;
  active: boolean;
  page?: boolean;
  href?: string;
  expanded?: boolean;
  controls?: string;
  onClick?: (trigger: HTMLButtonElement) => void;
  children: React.ReactNode;
}) {
  const className = cn('relative h-16 min-w-11 flex flex-col items-center justify-center gap-1 rounded-xl text-[10px] font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent', active ? 'text-accent' : 'text-faint active:bg-hover');
  const content = <>
    <span className={cn('flex h-7 w-12 items-center justify-center rounded-xl transition-colors [&_svg]:w-[21px] [&_svg]:h-[21px]', active && 'bg-accent/10')}>{children}</span>
    <span>{label}</span>
  </>;
  if (href) return <Link href={href} aria-current={active ? 'page' : undefined} className={className}>{content}</Link>;
  return (
    <button
      type="button"
      aria-label={ariaLabel || label}
      aria-current={page && active ? 'page' : undefined}
      aria-pressed={page || expanded !== undefined ? undefined : active}
      aria-expanded={expanded}
      aria-controls={controls}
      onClick={(event) => onClick?.(event.currentTarget)}
      className={className}
    >
      {content}
    </button>
  );
}

function HeaderLink({ href, active, children }: { href: string; active: boolean; children: React.ReactNode }) {
  return (
    <Link
      href={href}
      className={cn(
        'min-h-11 inline-flex items-center px-2 lg:px-2.5 py-1.5 rounded-xl text-sm transition-colors',
        active ? 'text-content bg-hover' : 'text-muted hover:text-content'
      )}
    >
      {children}
    </Link>
  );
}

function IconButton({ label, onClick, children }: { label: string; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      className="min-w-11 min-h-11 px-2.5 rounded-xl inline-flex items-center justify-center gap-2 text-muted hover:text-content hover:bg-hover transition-colors"
      title={label}
      aria-label={label}
      onClick={onClick}
    >
      {children}
      <span className="hidden lg:inline text-xs whitespace-nowrap">{label.replace(/^我的|^观看|^管理/, '')}</span>
    </button>
  );
}
