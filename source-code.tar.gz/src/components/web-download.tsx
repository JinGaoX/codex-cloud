'use client';

import { useEffect, useRef, useState } from 'react';
import { enqueueWebDownloads, showWebDownloads, webDownloadErrorMessage, type WebDownloadEntry } from '@/lib/web-download-queue';
import type { WebVideoDownloadOptions, WebVideoDownloadVariant } from '@/lib/web-video-download';
import { Drawer } from './drawer';
import { Icon } from './icon';

type Episode = { url: string; title: string; label: string };
type DownloadSubject = WebDownloadEntry & { resolution: { width: number; height: number } | null };
type Inspection = { subject: DownloadSubject } & (
  | { phase: 'loading' }
  | { phase: 'error'; message: string }
  | { phase: 'ready'; options: WebVideoDownloadOptions }
);

function qualityLabel(
  variant: WebVideoDownloadVariant, options: WebVideoDownloadOptions, subject: DownloadSubject, index: number,
): string {
  const resolution = variant.width && variant.height
    ? { width: variant.width, height: variant.height }
    : options.kind === 'mp4' ? subject.resolution : null;
  if (resolution) {
    const highest = index === 0 && options.variants.length > 1 && options.variants.every((entry) => entry.width && entry.height);
    return `${resolution.width}×${resolution.height}${highest ? ' · 最高画质' : ''}`;
  }
  const bitrate = variant.bandwidth && variant.bandwidth > 0 ? ` · ${(variant.bandwidth / 1_000_000).toFixed(2)} Mbps` : '';
  return `画质未确认${bitrate}`;
}

export function WebDownloadControl({
  url, title, sourceName, resolution, episodes,
}: DownloadSubject & { episodes: readonly Episode[] }) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<'single' | 'batch' | null>(null);
  const [check, setCheck] = useState<Inspection | null>(null);
  const [quality, setQuality] = useState(0);
  const [batch, setBatch] = useState<{ sourceName: string; episodes: readonly Episode[] } | null>(null);
  const [selected, setSelected] = useState<number[]>([]);
  const trigger = useRef<HTMLButtonElement>(null);
  const batchTrigger = useRef<HTMLButtonElement>(null);
  const inspection = useRef<AbortController | null>(null);

  useEffect(() => () => inspection.current?.abort(), []);

  function inspect(subject: DownloadSubject) {
    inspection.current?.abort();
    const controller = new AbortController();
    inspection.current = controller;
    setQuality(0);
    setCheck({ subject, phase: 'loading' });
    void import('@/lib/web-video-download').then(async ({ inspectWebVideoDownload }) => {
      if (controller.signal.aborted) return;
      const options = await inspectWebVideoDownload(subject.url, controller.signal);
      if (controller.signal.aborted) return;
      if (!options.variants.length) throw new Error('当前片源没有可下载的画质。');
      setCheck({ subject, phase: 'ready', options });
    }).catch((error: unknown) => {
      if (!controller.signal.aborted) setCheck({ subject, phase: 'error',
        message: webDownloadErrorMessage(error, '无法读取下载信息，请重试。') });
    });
  }

  function close() {
    inspection.current?.abort();
    setOpen(false);
  }

  function addToQueue(entries: readonly WebDownloadEntry[]) {
    if (!entries.length) return;
    // Unmount this drawer before the download manager takes over the scroll lock.
    (mode === 'batch' ? batchTrigger : trigger).current?.focus({ preventScroll: true });
    setOpen(false);
    setMode(null);
    enqueueWebDownloads(entries);
  }

  const variant = check?.phase === 'ready' ? check.options.variants[quality] : undefined;
  const batchButton = (
    <button type="button" className="btn-primary min-h-11 w-full" disabled={!selected.length} onClick={() => {
      if (batch) addToQueue(batch.episodes.flatMap((episode, index) => selected.includes(index)
        ? [{ url: episode.url, title: episode.title, sourceName: batch.sourceName }] : []));
    }}>下载所选{selected.length > 0 ? `（${selected.length} 集）` : ''}</button>
  );
  const singleButton = check?.phase === 'ready' && variant && (
    <button type="button" className="btn-primary min-h-11 w-full" disabled={Boolean(variant.unsupported)} onClick={() => {
      addToQueue([{ url: check.subject.url, title: check.subject.title, sourceName: check.subject.sourceName,
        selection: { kind: check.options.kind, variant } }]);
    }}>加入下载队列</button>
  );

  return <>
    <div className="ml-auto flex max-w-full flex-wrap justify-end gap-2">
      <button ref={trigger} type="button" className="btn-ghost btn-sm inline-flex min-h-11 items-center gap-1.5"
        aria-haspopup="dialog" aria-expanded={open && mode === 'single'} disabled={!url} onClick={() => {
          setMode('single');
          setOpen(true);
          inspect({ url, title, sourceName, resolution });
        }}><Icon name="download" className="size-4" />下载本集</button>
      {episodes.length > 1 && <button ref={batchTrigger} type="button" className="btn-ghost btn-sm min-h-11"
        aria-haspopup="dialog" aria-expanded={open && mode === 'batch'} onClick={() => {
          setBatch({ sourceName, episodes: episodes.filter((episode) => episode.url) });
          setSelected([]);
          setMode('batch');
          setOpen(true);
        }}>批量下载</button>}
      <button type="button" className="btn-ghost btn-sm min-h-11" aria-haspopup="dialog"
        onClick={showWebDownloads}>下载管理</button>
    </div>
    {mode && <Drawer open={open} onClose={close} title={mode === 'batch' ? '批量下载' : '下载本集'} width="max-w-lg"
      mobileSheet returnFocusRef={mode === 'batch' ? batchTrigger : trigger}
      resetScrollKey={mode} footer={mode === 'batch' ? batchButton : singleButton || undefined}>
      {mode === 'batch' && batch && <div className="space-y-3">
        <p className="break-words text-sm text-muted">{batch.sourceName} · 每集按片源可识别的最高画质依次下载。</p>
        <div className="flex gap-2">
          <button type="button" className="btn-ghost btn-sm min-h-10" onClick={() => setSelected(batch.episodes.map((_, index) => index))}>全选</button>
          <button type="button" className="btn-ghost btn-sm min-h-10" disabled={!selected.length} onClick={() => setSelected([])}>清空选择</button>
        </div>
        <fieldset className="grid grid-cols-1 gap-2 min-[400px]:grid-cols-2">
          <legend className="sr-only">选择要下载的剧集</legend>
          {batch.episodes.map((episode, index) => <label key={index}
            className="flex min-h-11 cursor-pointer items-center gap-2 rounded-lg border border-line bg-surface px-2.5 py-2 text-sm text-content">
            <input type="checkbox" className="size-4 shrink-0" checked={selected.includes(index)} onChange={(event) => {
              const checked = event.target.checked;
              setSelected((previous) => checked ? [...previous, index] : previous.filter((item) => item !== index));
            }} />
            <span className="min-w-0 break-words">{episode.label}</span>
          </label>)}
        </fieldset>
      </div>}
      {mode === 'single' && check && <div className="space-y-4">
        <div>
          <p className="break-words font-medium leading-relaxed text-content">{check.subject.title}</p>
          <p className="mt-1 break-words text-sm text-muted">片源 · {check.subject.sourceName}</p>
        </div>
        {check.phase === 'loading' && <p role="status" className="text-sm text-muted">正在检查可下载画质…</p>}
        {check.phase === 'error' && <>
          <p role="alert" className="text-sm leading-relaxed text-danger">{check.message}</p>
          <button type="button" className="btn-ghost min-h-11" onClick={() => inspect(check.subject)}>重新检查</button>
        </>}
        {check.phase === 'ready' && variant && <>
          {check.options.variants.length > 1
            ? <label className="block space-y-2 text-sm text-content">
              <span>下载清晰度</span>
              <select className="input min-h-11 w-full" value={quality} onChange={(event) => setQuality(Number(event.target.value))}>
                {check.options.variants.map((option, index) => <option key={index} value={index}>
                  {qualityLabel(option, check.options, check.subject, index)}{option.unsupported ? ' · 暂不支持' : ''}
                </option>)}
              </select>
            </label>
            : <p className="text-sm text-muted">{qualityLabel(variant, check.options, check.subject, quality)}</p>}
          {variant.unsupported && <p role="alert" className="text-sm leading-relaxed text-danger">{variant.unsupported}</p>}
        </>}
      </div>}
    </Drawer>}
  </>;
}
