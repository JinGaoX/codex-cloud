'use client';

import { useEffect, useRef, useState } from 'react';
import { UserCancelledError } from '@/lib/download-saver';
import type { PreparedWebDownload } from '@/lib/web-download-file-target';
import type { WebVideoDownloadOptions, WebVideoDownloadVariant } from '@/lib/web-video-download';
import { Drawer } from './drawer';
import { Icon } from './icon';

type DownloadEngine = typeof import('@/lib/web-video-download');

type DownloadSubject = {
  url: string;
  title: string;
  sourceName: string;
  resolution: { width: number; height: number } | null;
};

type Inspection = { subject: DownloadSubject } & (
  | { phase: 'loading' }
  | { phase: 'error'; message: string }
  | { phase: 'ready'; options: WebVideoDownloadOptions; engine: DownloadEngine }
);

type DownloadJob =
  | { phase: 'running'; percentage?: number }
  | { phase: 'cancelling' | 'cancelled' | 'saved' | 'browser' }
  | { phase: 'error'; message: string }
  | { phase: 'prepared'; file: PreparedWebDownload };

function errorMessage(error: unknown, fallback: string): string {
  const message = error instanceof Error ? error.message.trim() : '';
  return message.length <= 240 && /[\u3400-\u9fff]/.test(message) && !/(?:https?:\/\/|\?|(?:token|key|signature)=)/i.test(message)
    ? message
    : fallback;
}

function qualityLabel(
  variant: WebVideoDownloadVariant, options: WebVideoDownloadOptions, subject: DownloadSubject, index: number,
): string {
  const resolution = variant.width && variant.height
    ? { width: variant.width, height: variant.height }
    : options.kind === 'mp4' ? subject.resolution : null;
  if (resolution) {
    const highest = index === 0 && (options.variants.length === 1 || options.variants.every((entry) => entry.width && entry.height));
    return `${resolution.width}×${resolution.height}${highest && options.variants.length > 1 ? ' · 最高画质' : ''}`;
  }
  const bitrate = variant.bandwidth && variant.bandwidth > 0
    ? ` · ${(variant.bandwidth / 1_000_000).toFixed(2)} Mbps`
    : '';
  return `画质未确认${bitrate}`;
}

/** One foreground download belongs to the episode selected when the drawer opened. */
export function WebDownloadControl(subject: DownloadSubject) {
  const [open, setOpen] = useState(false);
  const [check, setCheck] = useState<Inspection | null>(null);
  const [selected, setSelected] = useState(0);
  const [job, setJob] = useState<DownloadJob | null>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const inspection = useRef<AbortController | null>(null);
  const activeJob = useRef<AbortController | null>(null);
  const prepared = useRef<{ file: PreparedWebDownload; saveRequested: boolean } | null>(null);

  useEffect(() => () => {
    inspection.current?.abort();
    const running = activeJob.current;
    activeJob.current = null;
    running?.abort();
    const latest = prepared.current;
    prepared.current = null;
    latest?.file.dispose(latest.saveRequested);
  }, []);

  const releasePrepared = () => {
    const latest = prepared.current;
    prepared.current = null;
    latest?.file.dispose(latest.saveRequested);
  };

  const inspect = (target: DownloadSubject) => {
    inspection.current?.abort();
    const controller = new AbortController();
    inspection.current = controller;
    releasePrepared();
    setSelected(0);
    setJob(null);
    setCheck({ subject: target, phase: 'loading' });
    void import('@/lib/web-video-download').then(async (engine) => {
      if (controller.signal.aborted) return;
      const options = await engine.inspectWebVideoDownload(target.url, controller.signal);
      if (controller.signal.aborted) return;
      if (!options.variants.length) throw new Error('当前片源没有可下载的画质。');
      setCheck({ subject: target, phase: 'ready', engine, options });
    }).catch((error: unknown) => {
      if (!controller.signal.aborted) setCheck({ subject: target, phase: 'error',
        message: errorMessage(error, '无法读取下载信息，请重试。') });
    }).finally(() => {
      if (inspection.current === controller) inspection.current = null;
    });
  };

  const busy = job?.phase === 'running' || job?.phase === 'cancelling';
  const pendingSave = job?.phase === 'prepared';
  const openDownloads = () => {
    setOpen(true);
    if (busy || pendingSave || !subject.url) return;
    if (!check || check.subject.url !== subject.url || check.subject.title !== subject.title) inspect(subject);
  };

  const startDownload = () => {
    if (activeJob.current || check?.phase !== 'ready') return;
    const variant = check.options.variants[selected];
    if (!variant) return;
    const controller = new AbortController();
    activeJob.current = controller;
    releasePrepared();
    setJob({ phase: 'running' });
    // Call in this gesture so browsers can open their save picker.
    void check.engine.downloadWebVideo({
      kind: check.options.kind, variant, title: check.subject.title, signal: controller.signal,
      onProgress: ({ percentage }) => {
        if (activeJob.current === controller && !controller.signal.aborted) setJob({ phase: 'running', percentage });
      },
    }).then((result) => {
      if (activeJob.current !== controller || controller.signal.aborted) {
        if (typeof result === 'object') result.dispose();
        if (activeJob.current === controller) setJob({ phase: 'cancelled' });
        return;
      }
      if (typeof result === 'object') {
        prepared.current = { file: result, saveRequested: false };
        setJob({ phase: 'prepared', file: result });
      } else setJob({ phase: result });
    }).catch((error: unknown) => {
      if (activeJob.current !== controller) return;
      if (controller.signal.aborted || error instanceof UserCancelledError
        || (error instanceof DOMException && error.name === 'AbortError')) setJob({ phase: 'cancelled' });
      else setJob({ phase: 'error', message: errorMessage(error, '保存失败，请重试或选择其他画质。') });
    }).finally(() => {
      if (activeJob.current === controller) activeJob.current = null;
    });
  };

  const option = check?.phase === 'ready' ? check.options.variants[selected] : undefined;
  const labels = check?.subject.url === subject.url && check.subject.title === subject.title ? subject : check?.subject;
  const footer = busy
    ? <button type="button" className="btn-ghost min-h-11 w-full" disabled={job.phase === 'cancelling'} onClick={() => {
        activeJob.current?.abort();
        setJob({ phase: 'cancelling' });
      }}>{job.phase === 'cancelling' ? '正在取消…' : '取消下载'}</button>
    : pendingSave
      ? <div className="flex items-center gap-2">
          <button type="button" className="btn-ghost min-h-11" onClick={() => { releasePrepared(); setJob(null); }}>
            清除待保存文件
          </button>
          <a className="btn-primary min-h-11 flex-1" href={job.file.url} download={job.file.filename} onClick={() => {
            if (prepared.current) prepared.current.saveRequested = true;
          }}>保存到设备</a>
        </div>
      : option && <button type="button" className="btn-primary min-h-11 w-full" disabled={Boolean(option.unsupported)}
          onClick={startDownload}>保存到设备</button>;

  return <>
    <button ref={trigger} type="button" className="btn-ghost btn-sm ml-auto inline-flex min-h-11 shrink-0 items-center gap-1.5"
      aria-haspopup="dialog" aria-expanded={open} disabled={!subject.url && !busy && !pendingSave} onClick={openDownloads}>
      <Icon name="download" className="size-4" />
      {busy || pendingSave ? '查看下载' : '下载本集'}
    </button>
    <Drawer open={open} onClose={() => setOpen(false)} title="下载本集" mobileSheet returnFocusRef={trigger}
      footer={footer || undefined}>
      {check && <div className="space-y-4">
        <div>
          <p className="break-words font-medium leading-relaxed text-content">{check.subject.title}</p>
          <p className="mt-1 break-words text-sm text-muted">片源 · {check.subject.sourceName}</p>
        </div>
        {check.phase === 'loading' && <p role="status" className="text-sm text-muted">正在检查可下载画质…</p>}
        {check.phase === 'error' && <div className="space-y-3">
          <p role="alert" className="text-sm leading-relaxed text-danger">{check.message}</p>
          <button type="button" className="btn-ghost min-h-11" onClick={() => inspect(check.subject)}>重新检查</button>
        </div>}
        {check.phase === 'ready' && option && labels && <>
          {check.options.variants.length > 1
            ? <label className="block space-y-2 text-sm text-content">
                <span>下载清晰度</span>
                <select className="input min-h-11 w-full" value={selected} disabled={busy} onChange={(event) => {
                  releasePrepared();
                  setJob(null);
                  setSelected(Number(event.target.value));
                }}>
                  {check.options.variants.map((variant, index) => <option key={index} value={index}>
                    {qualityLabel(variant, check.options, labels, index)}
                  </option>)}
                </select>
              </label>
            : <p className="text-sm text-content">下载画质 · {qualityLabel(option, check.options, labels, selected)}</p>}
          {check.options.kind === 'hls' && check.options.variants.some((variant) => variant.width && variant.height) &&
            <p className="text-xs text-muted">分辨率来自片源播放清单。</p>}
          <p className="text-sm leading-relaxed text-muted">
            保存片源原始画质，可能包含片源自带广告。下载完成前请保持此播放页打开。
          </p>
          {option.unsupported && <p role="status" className="text-sm leading-relaxed text-danger">{option.unsupported}</p>}
        </>}
        {job?.phase === 'running' && <div className="space-y-2">
          <p role="status" className="text-sm text-content">正在下载<span aria-hidden="true">{job.percentage === undefined ? '…' : ` · ${Math.floor(job.percentage)}%`}</span></p>
          <progress aria-label="下载进度" className="h-2 w-full" max={100} value={job.percentage} />
        </div>}
        {job?.phase === 'cancelling' && <p role="status" className="text-sm text-muted">正在取消下载…</p>}
        {job?.phase === 'cancelled' && <p role="status" className="text-sm text-muted">已取消下载。</p>}
        {job?.phase === 'error' && <div className="space-y-2">
          <p role="alert" className="text-sm leading-relaxed text-danger">{job.message}</p>
          <button type="button" className="btn-ghost min-h-11" onClick={() => inspect(check.subject)}>重新检查画质</button>
        </div>}
        {job?.phase === 'prepared' && <p role="status" className="text-sm text-content">视频已准备好。点击下方按钮保存。</p>}
        {job?.phase === 'saved' && <p role="status" className="text-sm text-content">视频已保存。</p>}
        {job?.phase === 'browser' && <p role="status" className="text-sm text-content">已交给浏览器，请查看系统下载记录。</p>}
      </div>}
    </Drawer>
  </>;
}
