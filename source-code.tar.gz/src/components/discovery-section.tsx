'use client';

import { useAppStore } from '@/lib/store';
import { LibraryBrowser } from './library-browser';
import './library.css';

/** One full catalogue browser, shared by home and legacy library bookmarks. */
export function DiscoverySection({ onPick }: { onPick: (title: string) => void }) {
  const enabled = useAppStore((state) => state.standaloneDiscoveryEnabled);
  return enabled ? <LibraryBrowser embedded onPick={onPick} /> : null;
}
