'use client';

import { useEffect, useRef, useState } from 'react';
import { useInfiniteQuery, useQuery, useQueryClient, type InfiniteData } from '@tanstack/react-query';
import { DISCOVERY_LISTS, DISCOVERY_REFRESH_MS, DOUBAN_BROWSE_TAGS, DOUBAN_DISCOVERY_MAX_PAGES, DOUBAN_DISCOVERY_PAGE_SIZE, discoveryRequestKey, fetchDiscoveryRequest, fetchDoubanDiscovery, filterDiscoveryItems, mergeDoubanDiscoveryPages, nextDoubanDiscoveryPage, type DiscoveryFilter, type DiscoveryItem, type DiscoveryRequest, type DiscoveryResponse } from '@/lib/discovery';
import { readDiscoveryCache, writeDiscoveryCache } from '@/lib/discovery-cache';
import { DEFAULT_DISCOVERY_VIEW, readDiscoverySession, writeDiscoverySession, type DiscoveryMode, type DiscoveryType, type DiscoveryView } from '@/lib/discovery-session';
import { PLATFORM_CHOICES, getPlatformItems } from '@/lib/platform-catalog';
import { useAppStore } from '@/lib/store';
import { cn } from '@/lib/utils';
import { SmartImage } from './smart-image';
import { Icon } from './icon';

const MODES: { id: DiscoveryMode; label: string }[] = [
  { id: 'ranking', label: '榜单' }, { id: 'browse', label: '豆瓣找片' }, { id: 'catalog', label: '固定精选' },
];
const TYPES: { id: DiscoveryType; label: string; lists: readonly (typeof DISCOVERY_LISTS)[number]['id'][] }[] = [
  { id: 'movie', label: '电影', lists: ['douban_movie_weekly'] },
  { id: 'tv', label: '电视剧', lists: ['douban_tv_chinese', 'douban_tv_global', 'baidu_teleplay'] },
  { id: 'show', label: '综艺', lists: ['douban_show_chinese', 'douban_show_global'] },
];
const FILTERS: { id: DiscoveryFilter; label: string }[] = [
  { id: 'all', label: '全部' },
  { id: 'high-rated', label: '8分以上' },
  { id: 'comedy', label: '喜剧' },
];

/** Public, real metadata only. Browsing stays independent of search and playback. */
export function DiscoverySection({ onPick }: { onPick: (title: string) => void }) {
  const enabled = useAppStore((state) => state.standaloneDiscoveryEnabled);
  return enabled ? <DiscoveryContent onPick={onPick} /> : null;
}

function DiscoveryContent({ onPick }: { onPick: (title: string) => void }) {
  const queryClient = useQueryClient();
  const [view, setView] = useState<DiscoveryView>(DEFAULT_DISCOVERY_VIEW);
  const { type, listId, mode, platform, tag, filter } = view;
  const [initialized, setInitialized] = useState(false);
  const [preparedKey, setPreparedKey] = useState('');
  const viewRef = useRef(view);
  viewRef.current = view;
  const restoreScrollRef = useRef<number | null>(null);
  const lastScrollRef = useRef(0);

  useEffect(() => {
    const saved = readDiscoverySession();
    if (saved) {
      const { scrollY, ...savedView } = saved;
      setView(savedView);
      restoreScrollRef.current = scrollY;
      lastScrollRef.current = scrollY;
    }
    setInitialized(true);
  }, []);

  const changeView = (patch: Partial<DiscoveryView>) => {
    restoreScrollRef.current = null;
    setView((previous) => ({ ...previous, ...patch }));
  };

  // The discovery section is unmounted during search. Keep only this tab's view
  // and position; search terms and private viewing/source data are not included.
  useEffect(() => {
    if (!initialized) return;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const save = () => {
      if (timer) clearTimeout(timer);
      timer = undefined;
      writeDiscoverySession({ ...viewRef.current, scrollY: lastScrollRef.current });
    };
    const onScroll = () => {
      if (restoreScrollRef.current !== null) return;
      lastScrollRef.current = window.scrollY;
      if (!timer) timer = setTimeout(save, 150);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('pagehide', save);
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('pagehide', save);
      save();
    };
  }, [initialized]);
  useEffect(() => {
    if (initialized) writeDiscoverySession({ ...view, scrollY: lastScrollRef.current });
  }, [view, initialized]);
  const selectedType = TYPES.find((entry) => entry.id === type)!;
  const selected = DISCOVERY_LISTS.find((entry) => entry.id === listId && selectedType.lists.includes(entry.id))
    ?? DISCOVERY_LISTS.find((entry) => entry.id === selectedType.lists[0])!;
  const selectedPlatform = PLATFORM_CHOICES.find((entry) => entry.id === platform)!;
  const browseType = type === 'movie' ? 'movie' : 'tv';
  const request: DiscoveryRequest = mode === 'browse' ? { kind: 'douban', type: browseType, tag } : { kind: 'list', id: selected.id };
  const cacheKey = discoveryRequestKey(request);
  const source = mode === 'catalog'
    ? `${selectedPlatform.label} · ${type === 'movie' ? '电影' : '电视剧'}固定精选`
    : mode === 'browse' ? `豆瓣 · ${tag}${type === 'movie' ? '电影' : '电视剧'}` : selected.source;

  // Hydrate public metadata after mounting, before enabling its network query.
  // Existing source settings and user records never enter this cache.
  useEffect(() => {
    if (!initialized) return;
    const cached = readDiscoveryCache(cacheKey);
    if (mode === 'browse') {
      const key = ['public-douban-pages-v1', cacheKey];
      const existing = queryClient.getQueryData<InfiniteData<DiscoveryResponse, number>>(key);
      if (cached && !existing) {
        // Legacy first-page caches predate pagination. A manual next request can
        // still find out whether a full page of fifty has more results.
        const firstPage = cached.items.length === DOUBAN_DISCOVERY_PAGE_SIZE ? { ...cached, nextPageStart: DOUBAN_DISCOVERY_PAGE_SIZE } : cached;
        queryClient.setQueryData(key, { pages: [firstPage], pageParams: [0] }, { updatedAt: cached.retrievedAt });
      }
    } else {
      const key = ['standalone-discovery-v2', cacheKey];
      const existing = queryClient.getQueryData<DiscoveryResponse>(key);
      if (cached && (!existing || cached.retrievedAt > existing.retrievedAt)) {
        queryClient.setQueryData(key, cached, { updatedAt: cached.retrievedAt });
      }
    }
    setPreparedKey(cacheKey);
  }, [cacheKey, mode, initialized, queryClient]);

  const query = useQuery({
    queryKey: ['standalone-discovery-v2', cacheKey],
    queryFn: async ({ signal }) => {
      const data = await fetchDiscoveryRequest(request, signal);
      writeDiscoveryCache(cacheKey, data);
      return data;
    },
    staleTime: DISCOVERY_REFRESH_MS,
    gcTime: 60 * 60_000,
    refetchInterval: DISCOVERY_REFRESH_MS,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
    retry: false,
    enabled: initialized && mode === 'ranking' && preparedKey === cacheKey,
  });
  const browseQuery = useInfiniteQuery({
    queryKey: ['public-douban-pages-v1', cacheKey],
    initialPageParam: 0,
    queryFn: async ({ signal, pageParam }) => {
      const data = await fetchDoubanDiscovery(browseType, tag, signal, pageParam);
      // Additional pages stay in bounded query memory. Persistent public cache
      // remains at twelve first pages / 256 KiB, separate from private records.
      if (pageParam === 0) writeDiscoveryCache(cacheKey, data);
      return data;
    },
    getNextPageParam: (_lastPage, pages) => nextDoubanDiscoveryPage(pages),
    maxPages: DOUBAN_DISCOVERY_MAX_PAGES,
    staleTime: DISCOVERY_REFRESH_MS,
    gcTime: 60 * 60_000,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    retry: false,
    enabled: initialized && mode === 'browse' && preparedKey === cacheKey,
  });
  const activeQuery = mode === 'browse' ? browseQuery : query;
  const response = mode === 'browse' ? browseQuery.data?.pages[0] : query.data;
  const items = mode === 'catalog' && type !== 'show'
    ? getPlatformItems(platform, type)
    : mode === 'ranking' ? filterDiscoveryItems(query.data?.items ?? [], filter) : mergeDoubanDiscoveryPages(browseQuery.data?.pages ?? []);
  const landscapeGrid = items.length > 0 && items.every((item) => item.coverShape === 'landscape');

  // Wait for actual cards, rather than restoring into the short loading skeleton.
  // Native history restoration may also run; the extra frame keeps the final
  // position after React has committed the returned page. User input cancels it.
  useEffect(() => {
    if (!initialized || restoreScrollRef.current === null || mode !== 'catalog' && activeQuery.isPending) return;
    const target = restoreScrollRef.current;
    let frame = 0;
    let attempts = 0;
    const cancel = () => { restoreScrollRef.current = null; cancelAnimationFrame(frame); };
    const restore = () => {
      const maxScroll = Math.max(0, document.documentElement.scrollHeight - window.innerHeight);
      const position = Math.min(target, maxScroll);
      window.scrollTo({ top: position, behavior: 'instant' });
      lastScrollRef.current = position;
      if (++attempts < 2) frame = requestAnimationFrame(restore);
      else restoreScrollRef.current = null;
    };
    frame = requestAnimationFrame(restore);
    window.addEventListener('pointerdown', cancel, { once: true });
    window.addEventListener('wheel', cancel, { once: true });
    window.addEventListener('keydown', cancel, { once: true });
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener('pointerdown', cancel);
      window.removeEventListener('wheel', cancel);
      window.removeEventListener('keydown', cancel);
    };
  }, [initialized, mode, activeQuery.isPending]);

  const pick = (title: string) => {
    lastScrollRef.current = window.scrollY;
    writeDiscoverySession({ ...viewRef.current, scrollY: window.scrollY });
    onPick(title);
  };

  if (!initialized) return <DiscoverySkeleton />;

  return (
    <section aria-label="发现影视" className="vip-discovery mt-5 mb-8 min-w-0">
      <div className="flex items-center justify-between gap-2 mb-2">
        <div role="group" aria-label="选择影视类型" className="flex items-center gap-5 sm:gap-7">
          {TYPES.map((entry) => (
            <button key={entry.id} type="button" aria-pressed={entry.id === type}
              className={cn('vip-category min-h-11 min-w-11 relative text-lg sm:text-xl font-semibold transition-colors', entry.id === type ? 'text-content' : 'text-faint hover:text-content')}
              onClick={() => {
                changeView({ type: entry.id, listId: entry.lists[0], filter: 'all', tag: '热门',
                  ...(entry.id === 'show' ? { mode: 'ranking' as const } : {}) });
              }}>
              {entry.label}
              {entry.id === type && <span aria-hidden="true" className="absolute bottom-0 left-0 w-5 h-0.5 rounded-full bg-accent" />}
            </button>
          ))}
        </div>
        {mode !== 'catalog' && <button type="button" className="w-11 h-11 shrink-0 flex items-center justify-center rounded-full text-muted hover:bg-chip hover:text-content disabled:opacity-40"
          aria-label={mode === 'ranking' ? '刷新榜单' : '刷新豆瓣分类'} disabled={activeQuery.isFetching || preparedKey !== cacheKey} onClick={() => void activeQuery.refetch()}>
          <Icon name="refresh" className={cn('w-4 h-4', activeQuery.isFetching && 'animate-spin')} />
        </button>}
      </div>

      <div className="flex flex-wrap items-center gap-1 mb-1" role="group" aria-label="选择发现方式">
        {MODES.filter((entry) => type !== 'show' || entry.id === 'ranking').map((entry) => <button key={entry.id} type="button" aria-pressed={mode === entry.id}
          className={cn('min-h-11 px-3.5 rounded-full text-xs sm:text-sm transition-colors', mode === entry.id ? 'bg-accent/10 text-accent font-medium' : 'text-muted hover:bg-chip hover:text-content')}
          onClick={() => changeView({ mode: entry.id, filter: 'all' })}>{entry.label}</button>)}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-x-4 gap-y-1 mb-2">
        <div className="flex min-w-0 gap-1 overflow-x-auto max-w-full sm:flex-wrap" role="group" aria-label="选择影视分类">
          {mode === 'ranking' && selectedType.lists.map((id) => {
            const list = DISCOVERY_LISTS.find((entry) => entry.id === id)!;
            return <button key={id} type="button" aria-pressed={id === selected.id}
              className={cn('min-h-11 shrink-0 px-3 rounded-full text-xs transition-colors', id === selected.id ? 'text-content font-semibold' : 'text-muted hover:bg-chip hover:text-content')}
              onClick={() => changeView({ listId: id, filter: 'all' })}>{list.label}</button>;
          })}
          {mode === 'browse' && DOUBAN_BROWSE_TAGS[browseType].map((entry) => <button key={entry} type="button" aria-pressed={tag === entry}
            className={cn('min-h-11 shrink-0 px-3 rounded-full text-xs transition-colors', tag === entry ? 'bg-chip text-content font-semibold' : 'text-muted hover:bg-chip hover:text-content')}
            onClick={() => changeView({ tag: entry })}>{entry}</button>)}
          {mode === 'catalog' && PLATFORM_CHOICES.map((entry) => <button key={entry.id} type="button" aria-pressed={entry.id === platform}
            className={cn('min-h-11 shrink-0 px-3 rounded-full text-xs transition-colors', entry.id === platform ? 'text-content font-semibold' : 'text-muted hover:bg-chip hover:text-content')}
            onClick={() => changeView({ platform: entry.id })}>{entry.label}</button>)}
        </div>
        {mode === 'ranking' && selected.filterable && <div className="flex gap-1" role="group" aria-label="筛选当前榜单">
          {FILTERS.map((entry) => (
            <button key={entry.id} type="button" aria-pressed={filter === entry.id}
              className={cn('min-h-11 px-3 rounded-full text-xs transition-colors', filter === entry.id ? 'text-content font-semibold' : 'text-faint hover:text-content')}
              onClick={() => changeView({ filter: entry.id })}>{entry.label}</button>
          ))}
        </div>}
      </div>

      <p className="mb-3 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] leading-relaxed text-faint">
        <span>{source}</span>
        {mode === 'catalog' ? <span>{items.length} 部 · 随版本更新</span> : <>
          {response && <span>本机获取 {new Date(response.retrievedAt).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>}
          {mode === 'browse' ? <span>已加载 {items.length} 部 · 按需加载更多</span> : filter !== 'all' && <span>仅筛选当前榜单</span>}
        </>}
      </p>

      {mode !== 'catalog' && activeQuery.isError && !(mode === 'browse' && browseQuery.isFetchNextPageError) && <div role="status" className="rounded-xl border border-line bg-card px-4 py-3 mb-3 flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs text-muted">{response ? '更新暂未成功，保留上次内容' : mode === 'ranking' ? '榜单暂时没加载出来' : '豆瓣分类暂时没加载出来'}</p>
        <button type="button" className="min-h-11 px-3 text-sm text-accent" disabled={activeQuery.isFetching} onClick={() => void activeQuery.refetch()}>
          {activeQuery.isFetching ? '正在重试…' : '重试'}
        </button>
        {!response && type !== 'show' && <button type="button" className="min-h-11 px-3 text-xs text-accent" onClick={() => changeView({ mode: 'catalog' })}>查看固定精选</button>}
      </div>}

      {mode !== 'catalog' && activeQuery.isPending ? <DiscoverySkeleton /> : items.length > 0 ?
        <div className={cn('vip-poster-grid grid gap-x-3 gap-y-4 sm:gap-x-4', landscapeGrid ? 'grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6' : 'grid-cols-3 min-[480px]:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8')} aria-label={source}>
          {items.map((item) => <PosterCard key={item.id} item={item} onPick={pick} />)}
        </div>
      : mode === 'catalog' || response ? <p className="text-sm text-muted py-8 text-center">
        {mode === 'catalog' ? '这个分类暂时没有内容。' : filter === 'comedy' ? '这个榜单里暂时没有喜剧，换个榜单看看。' : filter === 'high-rated' ? '这个榜单里暂时没有8分以上的作品。' : '暂时还没有内容，稍后再来看看。'}
      </p> : null}
      {mode === 'browse' && response && <div className="mt-5 flex flex-col items-center gap-2">
        {browseQuery.isFetchNextPageError && <p role="status" className="text-xs text-muted">这一页暂时没加载出来，已保留前面的影片。</p>}
        {browseQuery.hasNextPage ? <button type="button" className="btn-ghost min-h-11 px-5"
          disabled={browseQuery.isFetching} onClick={() => void browseQuery.fetchNextPage()}>
          {browseQuery.isFetchingNextPage ? '正在加载…' : browseQuery.isFetchNextPageError ? '重试加载更多' : '加载更多'}
        </button> : <p className="text-xs text-faint">{(browseQuery.data?.pages.length ?? 0) >= DOUBAN_DISCOVERY_MAX_PAGES
          ? '已到本次加载上限，可切换分类继续找片。'
          : '暂时没有更多可读取的影片了。'}</p>}
      </div>}
    </section>
  );
}

function FilmCover({ item, className, eager = false }: { item: DiscoveryItem; className: string; eager?: boolean }) {
  const [failed, setFailed] = useState(false);
  const [bundledFailed, setBundledFailed] = useState(false);
  const fallbackKey = JSON.stringify(item.coverFallbacks ?? []);
  useEffect(() => { setFailed(false); setBundledFailed(false); }, [item.id, item.bundledCover, item.cover, fallbackKey]);
  if (item.bundledCover && !bundledFailed) {
    // This path comes from the bundled, reviewed catalog, not a user's API data.
    // eslint-disable-next-line @next/next/no-img-element
    return <img src={item.bundledCover} alt="" className={className} loading={eager ? 'eager' : 'lazy'}
      onError={() => setBundledFailed(true)} />;
  }
  return item.cover && !failed ? <SmartImage url={item.cover} fallbackUrls={item.coverFallbacks} mode="direct" alt="" className={className}
    loading={eager ? 'eager' : 'lazy'} onExhausted={() => setFailed(true)} /> : <div className={cn(className, 'vip-cover-empty flex items-center justify-center')}>
    <svg aria-hidden="true" className="w-10 h-10 text-accent/40" viewBox="0 0 48 48" fill="none"><rect x="8" y="8" width="32" height="32" rx="8" stroke="currentColor" strokeWidth="1.5"/><path d="m21 17 11 7-11 7V17Z" fill="currentColor"/></svg>
  </div>;
}

function PosterCard({ item, onPick }: { item: DiscoveryItem; onPick: (title: string) => void }) {
  return <button type="button" onClick={() => onPick(item.title)} aria-label={`搜索 ${item.title}`}
    className="text-left min-w-0 group focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/60 rounded-xl">
    <div className={cn('relative overflow-hidden rounded-xl bg-chip shadow-sm', item.coverShape === 'landscape' ? 'aspect-video' : 'aspect-[2/3]')}>
      <FilmCover item={item} className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-[1.04]" />
      <div aria-hidden="true" className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/65 to-transparent" />
      {item.rank !== undefined && <span aria-label={`原榜第${item.rank}名`} className="absolute top-2 left-2 text-white text-xs font-semibold tabular-nums drop-shadow-md">{String(item.rank).padStart(2, '0')}</span>}
      {item.rating && <span className="absolute bottom-2 right-2 text-[10px] sm:text-[11px] font-medium text-[#f1d39e]">豆瓣 {item.rating}</span>}
    </div>
    <h3 className="text-xs sm:text-sm font-medium text-content mt-2.5 line-clamp-2 leading-relaxed">{item.title}</h3>
  </button>;
}

function DiscoverySkeleton() {
  return <div aria-label="正在加载公开影视数据" className="grid grid-cols-3 min-[480px]:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-3">
    {Array.from({ length: 8 }, (_, index) => <div key={index} className="aspect-[2/3] rounded-xl bg-chip animate-pulse" />)}
  </div>;
}
