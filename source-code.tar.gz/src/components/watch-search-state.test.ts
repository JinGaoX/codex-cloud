import { describe, expect, it } from 'vitest';
import { WATCH_SEARCH_PAGE_SIZE, watchSearchWindow } from './watch-search-state';

describe('watch search result pages', () => {
  it('offers more when only commentary and trailers exceed the first page', () => {
    const main = ['film'];
    const supplementary = Array.from({ length: 31 }, (_, index) => `extra-${index}`);
    const first = watchSearchWindow(main, supplementary, WATCH_SEARCH_PAGE_SIZE);
    expect(first.main).toEqual(main);
    expect(first.supplementary).toHaveLength(24);
    expect(first.hasMore).toBe(true);
    const next = watchSearchWindow(main, supplementary, WATCH_SEARCH_PAGE_SIZE * 2);
    expect(next.main).toEqual(main);
    expect(next.supplementary).toEqual(supplementary);
    expect(next.hasMore).toBe(false);
  });

  it('keeps a shared next page while either section still has hidden films', () => {
    const main = Array.from({ length: 50 }, (_, index) => index);
    const supplementary = Array.from({ length: 25 }, (_, index) => index);
    const next = watchSearchWindow(main, supplementary, WATCH_SEARCH_PAGE_SIZE * 2);
    expect(next.main).toEqual(main.slice(0, 48));
    expect(next.supplementary).toEqual(supplementary);
    expect(next.hasMore).toBe(true);
    expect(watchSearchWindow(main, supplementary, WATCH_SEARCH_PAGE_SIZE * 3).hasMore).toBe(false);
  });
});
