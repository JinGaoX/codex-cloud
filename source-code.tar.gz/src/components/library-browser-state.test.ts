import { describe, expect, it } from 'vitest';
import { discoveryHref, hasLibraryView, libraryHref, libraryWindowStart, withLibraryWindow, readDiscoveryReturnPosition, readLastLibraryView, readLibraryPosition, readLibraryView, writeLastLibraryView, writeLibraryPosition, trackLibraryPage, type PositionStorage } from './library-browser-state';

const parse = (query: string) => readLibraryView(new URLSearchParams(query));
function memoryStorage() {
  const values = new Map<string, string>([['libretv-settings', 'private-settings-fixture']]);
  return { values, getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => { values.set(key, value); } };
}

describe('public library navigation', () => {
  it('preserves legacy native-batch positions while adapting to complete display rows', () => {
    const legacy = parse('mode=ranking&list=top250&page=2');
    expect(libraryWindowStart(legacy)).toBe(25);
    expect(libraryWindowStart(withLibraryWindow(legacy, 21))).toBe(25);
    expect(libraryWindowStart(parse('page=2'))).toBe(20);
  });

  it('round-trips explicit sizes and absolute offsets without rotating into another range', () => {
    const desktop = parse('type=movie&size=21&offset=42&page=3');
    const tablet = withLibraryWindow(desktop, 24);
    expect(tablet).toMatchObject({ size: 24, offset: 42, page: 2 });
    expect(parse(libraryHref(tablet).split('?')[1])).toEqual(tablet);
    expect(withLibraryWindow(tablet, 21)).toEqual(desktop);
    expect(parse('size=999&offset=9999')).not.toHaveProperty('size');
    expect(parse('size=21&offset=9999').offset).toBe(4999);
    expect(hasLibraryView(new URLSearchParams('size=21&offset=42'))).toBe(true);
  });
  it('maps legacy catalogue links into the one home discovery section without leaking search parameters', () => {
    const view = parse('type=tv&mode=ranking&list=douban_tv_global&page=2&s=private-query&sourceUrl=private-source');
    expect(discoveryHref(view)).toBe('/?type=tv&mode=ranking&list=douban_tv_global&page=2#home-discovery');
    expect(readLibraryView(new URLSearchParams(discoveryHref(view).split('?')[1].split('#')[0]))).toEqual(view);
    expect(hasLibraryView(new URLSearchParams('s=some-film'))).toBe(false);
    expect(hasLibraryView(new URLSearchParams('country=韩国'))).toBe(true);
  });

  it('remembers only normalized public criteria, independently from private settings and prior scroll positions', () => {
    const store = memoryStorage();
    const view = { ...parse('type=tv&mode=browse&country=韩国&minRating=8&page=3'), privateApi: 'secret', history: ['private'] };
    writeLastLibraryView(view, store);
    expect(readLastLibraryView(store)).toEqual(parse('type=tv&mode=browse&country=韩国&minRating=8&page=3'));
    expect(store.values.get('libretv-settings')).toBe('private-settings-fixture');
    expect(store.values.get('libretv-library-view-v1')).not.toMatch(/secret|history|private/);
    store.values.set('libretv-library-view-v1', 'https://foreign.invalid/?s=private');
    expect(readLastLibraryView(store)).toBeUndefined();
  });

  it('restores only the matching history entry and rejects malformed or another page return coordinates', () => {
    const view = parse('type=tv&page=2');
    const state = { ppsDiscoveryReturn: { key: libraryHref(view), scrollY: 1469 } };
    expect(readDiscoveryReturnPosition(view, state)).toBe(1469);
    expect(readDiscoveryReturnPosition(parse('type=movie&page=2'), state)).toBeUndefined();
    expect(readDiscoveryReturnPosition(view, { ppsDiscoveryReturn: { key: libraryHref(view), scrollY: Infinity } })).toBeUndefined();
    expect(readDiscoveryReturnPosition(view, null)).toBeUndefined();
  });
  it('stops repeated offset responses, isolates filters and keeps the page fingerprint window bounded', () => {
    const pages = new Map<string, readonly string[]>();
    expect(trackLibraryPage(pages, 'movie', 1, ['a', 'b'])).toBe(false);
    expect(trackLibraryPage(pages, 'movie', 1, ['a', 'b'])).toBe(false);
    expect(trackLibraryPage(pages, 'movie', 2, ['a', 'b'])).toBe(true);
    expect(trackLibraryPage(pages, 'movie', 1, ['a', 'b'])).toBe(false);
    expect(trackLibraryPage(pages, 'tv', 2, ['a', 'b'])).toBe(false);
    expect(trackLibraryPage(pages, 'movie', 3, ['b', 'c'])).toBe(false);
    for (let page = 4; page < 40; page++) trackLibraryPage(pages, 'movie', page, [`id-${page}`]);
    expect(pages.size).toBe(16);
  });
  it('round-trips filters and deep pages without inventing a total or dropping real criteria', () => {
    const selected = parse('type=movie&mode=browse&genre=悬疑&country=韩国&year=2010s&minRating=8&sort=S&page=51');
    expect(selected).toMatchObject({ type: 'movie', mode: 'browse', genre: '悬疑', country: '韩国', year: '2010s', minRating: 8, sort: 'S', page: 51 });
    expect(readLibraryView(new URLSearchParams(libraryHref(selected).split('?')[1]))).toEqual(selected);
  });

  it('does not accept a foreign list, private destination or impossible page from a URL', () => {
    const selected = parse('type=tv&mode=ranking&list=top250&page=999&genre=not-a-genre&country=https://private.invalid&minRating=NaN&sort=bad');
    expect(selected).toMatchObject({ type: 'tv', list: 'douban_tv_chinese', page: 2, genre: '', country: '', minRating: 0, sort: 'U' });
    expect(libraryHref(selected)).not.toMatch(/private|bad|NaN/);
    expect(parse('page=-5').page).toBe(1);
    expect(parse('page=1.2').page).toBe(1);
    expect(parse('page=250').page).toBe(250);
    expect(parse('mode=ranking&list=top250&page=250').page).toBe(10);
  });

  it('keeps variety shows on their verified weekly lists rather than treating a loose tag as a complete catalog', () => {
    expect(parse('type=show&mode=browse')).toMatchObject({ type: 'show', mode: 'ranking', list: 'douban_show_chinese' });
    expect(parse('type=show&mode=ranking&list=douban_show_global')).toMatchObject({ list: 'douban_show_global' });
  });

  it('stores bounded public positions without modifying guest settings or retaining arbitrary fields', () => {
    const store = memoryStorage();
    for (let page = 1; page <= 20; page++) {
      const view = { ...parse(`page=${page}`), sourceUrl: 'https://private.invalid', history: ['private'] };
      writeLibraryPosition(view, page * 100.25, store);
    }
    expect(store.values.get('libretv-settings')).toBe('private-settings-fixture');
    const saved = [...store.values.entries()].find(([key]) => key !== 'libretv-settings')![1];
    expect(Object.keys(JSON.parse(saved))).toHaveLength(12);
    expect(saved).not.toMatch(/private|sourceUrl|history/);
    expect(readLibraryPosition(libraryHref(parse('page=20')), store)).toBe(2005);
    expect(readLibraryPosition(libraryHref(parse('page=1')), store)).toBe(0);
  });

  it('rejects foreign coordinate keys, corrupt data and non-finite positions', () => {
    const store = memoryStorage();
    writeLibraryPosition(parse(''), Infinity, store);
    expect(store.values.size).toBe(1);
    store.values.set('libretv-library-navigation-v1', JSON.stringify({ 'https://foreign.invalid': 999, '/library?type=movie&mode=browse': -1 }));
    expect(readLibraryPosition('https://foreign.invalid', store)).toBe(0);
    expect(readLibraryPosition(libraryHref(parse('')), store)).toBe(0);
    store.values.set('libretv-library-navigation-v1', '{broken');
    expect(readLibraryPosition(libraryHref(parse('')), store)).toBe(0);
  });

  it('continues if session storage is unavailable', () => {
    const unavailable: PositionStorage = { getItem: () => { throw new Error('blocked'); }, setItem: () => { throw new Error('blocked'); } };
    expect(() => writeLibraryPosition(parse(''), 300, unavailable)).not.toThrow();
    expect(readLibraryPosition(libraryHref(parse('')), unavailable)).toBe(0);
  });
});
