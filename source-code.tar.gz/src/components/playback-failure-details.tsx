import type { PlaybackFailure } from '@/lib/playback-failure';

export function PlaybackFailureDetails({ failure }: { failure: PlaybackFailure }) {
  return (
    <details className="mx-auto w-fit max-w-full text-center text-sm">
      <summary className="mx-auto min-h-11 w-fit cursor-pointer rounded-lg px-3 py-3 text-white/90 underline underline-offset-4">
        查看原因
      </summary>
      <div className="space-y-1 rounded-lg bg-white/10 px-3 py-2 text-left text-xs leading-relaxed text-white/90">
        <p className="font-medium">{failure.stage}{failure.status !== undefined && ` · HTTP ${failure.status}`}</p>
        <p>{failure.reason}</p>
      </div>
    </details>
  );
}
