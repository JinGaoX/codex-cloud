'use client';

import Link from 'next/link';
import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { DISCOVERY_REFRESH_MS, fetchDiscoveryList } from '@/lib/discovery';
import { readDiscoveryCache, writeDiscoveryCache } from '@/lib/discovery-cache';
import { useAppStore } from '@/lib/store';
import { formatTime } from '@/lib/utils';
import type { SearchResultItem } from '@/lib/types';
import { selectDynamicHomeFeatures } from './home-featured';
import { HomeArtwork } from './home-artwork';
import type { HomeResumeTarget } from './home-viewing';

export function HomeSpotlight({ recent, ready, onPick, onDetail }: {
  recent: HomeResumeTarget | null; ready: boolean;
  onPick: (title: string) => void; onDetail: (item: SearchResultItem) => void;
}) {
  const enabled = useAppStore((state) => state.standaloneDiscoveryEnabled);
  if (!ready) return <section className="home-spotlight home-spotlight-loading" aria-label="正在读取本机观看记录" aria-busy="true" />;
  if (recent) return <ResumeSpotlight target={recent} onDetail={onDetail} />;
  return enabled ? <DynamicSpotlight onPick={onPick} /> : null;
}

/** A live weekly selection replaces the former bundled recommendations. */
function DynamicSpotlight({ onPick }: { onPick: (title: string) => void }) {
  const [activeId, setActiveId] = useState<string | null>(null);
  const cacheKey = 'list:douban_movie_weekly';
  const query = useQuery({
    queryKey: ['standalone-discovery-v2', cacheKey],
    queryFn: async ({ signal }) => {
      const data = await fetchDiscoveryList('douban_movie_weekly', signal);
      writeDiscoveryCache(cacheKey, data);
      return data;
    },
    initialData: () => readDiscoveryCache(cacheKey),
    initialDataUpdatedAt: () => readDiscoveryCache(cacheKey)?.retrievedAt,
    staleTime: DISCOVERY_REFRESH_MS,
    gcTime: 60 * 60_000,
    refetchInterval: DISCOVERY_REFRESH_MS,
    refetchIntervalInBackground: false,
    refetchOnWindowFocus: true,
    refetchOnReconnect: true,
    retry: false,
  });
  const features = selectDynamicHomeFeatures(query.data?.items ?? []);
  const item = features.find((entry) => entry.id === activeId) ?? features[0];
  if (!item) {
    if (query.isPending) return <section className="home-spotlight home-spotlight-loading" aria-label="正在加载动态影视推荐" aria-busy="true" />;
    return <section className="home-continue" aria-label="动态影视推荐">
      <div className="home-media-section-heading">
        <p className="text-sm text-muted" role="status">{query.isError ? '动态推荐暂时没有加载出来' : '暂时没有可展示的推荐封面'}</p>
        <button type="button" className="home-history-link" disabled={query.isFetching} onClick={() => void query.refetch()}>
          {query.isFetching ? '正在重试…' : '重试'}
        </button>
        <Link href="#home-discovery" className="home-history-link">浏览影片<span aria-hidden="true">›</span></Link>
      </div>
    </section>;
  }
  return <section className="home-spotlight" data-mode="featured" aria-labelledby="home-spotlight-title">
    <div className="home-spotlight-backdrop"><HomeArtwork key={`${item.id}:${item.cover}`} title={item.title} pic={item.cover} variant="hero" eager /></div>
    <div className="home-spotlight-copy">
      <p className="home-spotlight-eyebrow">豆瓣电影周榜{query.isError && <span> · 更新暂未成功，显示上次内容</span>}</p>
      <h2 id="home-spotlight-title">{item.title}</h2>
      {(item.rating || item.genres.length > 0) && <p className="home-spotlight-metadata">{[
        item.rating && `豆瓣 ${item.rating}`, ...item.genres.slice(0, 2),
      ].filter(Boolean).join(' · ')}</p>}
      <div className="home-spotlight-actions">
        <button type="button" className="home-spotlight-primary" onClick={() => onPick(item.title)} aria-label={`搜索 ${item.title} 的播放片源`}>
          <PlayIcon />观看选项
        </button>
        <Link href="#home-discovery" className="home-spotlight-secondary">浏览影片<span aria-hidden="true">›</span></Link>
      </div>
    </div>
    {features.length > 1 && <div className="home-spotlight-switcher" role="group" aria-label="切换动态推荐影片">
      {features.map((entry) => <button key={entry.id} type="button" className="home-spotlight-dot"
        aria-label={`查看推荐 ${entry.title}`} aria-pressed={entry.id === item.id} onClick={() => setActiveId(entry.id)}><span aria-hidden="true" /></button>)}
    </div>}
  </section>;
}

function ResumeSpotlight({ target, onDetail }: { target: HomeResumeTarget; onDetail: (item: SearchResultItem) => void }) {
  const { item } = target;
  const position = formatTime(item.playbackPosition);
  return <section className="home-spotlight" data-mode="resume" data-history-id={item.id} aria-labelledby="home-spotlight-title">
    <div className="home-spotlight-backdrop"><HomeArtwork key={`${item.title}:${item.pic}`} title={item.title} pic={item.pic} variant="hero" eager /></div>
    <div className="home-spotlight-copy">
      <p className="home-spotlight-eyebrow">最近观看{target.sourceName && <span> · {target.sourceName}</span>}</p>
      <h2 id="home-spotlight-title">{item.title}</h2>
      <p className="home-spotlight-metadata">{item.hasEpisodeContext ? `上次第 ${item.episodeIndex + 1} 集` : '接着上次观看'}</p>
      <div className="home-spotlight-progress">
        <p>{item.duration > 0 ? `${position} / ${formatTime(item.duration)}` : `已观看 ${position}`}
          {item.percent !== null && <span>已看 {item.percent}%</span>}</p>
        {item.percent !== null && <div className="home-hero-progress-track" role="progressbar" aria-label="已观看进度"
          aria-valuemin={0} aria-valuemax={100} aria-valuenow={item.percent}><div style={{ width: `${item.percent}%` }} /></div>}
      </div>
      <div className="home-spotlight-actions">
        <Link href={target.href} className="home-spotlight-primary" aria-label={`继续播放 ${item.title}`}><PlayIcon />继续播放</Link>
        {target.detail && <button type="button" className="home-spotlight-secondary" onClick={() => onDetail(target.detail!)}>
          {item.hasEpisodeContext ? '选集' : '查看详情'}<span aria-hidden="true">›</span>
        </button>}
      </div>
    </div>
  </section>;
}

function PlayIcon() {
  return <svg aria-hidden="true" width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><path d="m4 2 10 6-10 6V2Z" /></svg>;
}
