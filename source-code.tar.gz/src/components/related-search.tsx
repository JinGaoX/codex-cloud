'use client';

import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/client-api';
import { getManualSearchPolicy, partitionSearchResults } from '@/lib/manual-search';
import { runSearchExpansion, type SearchExpansionOutcome } from '@/lib/search-expansion-runner';
import type { SearchResultItem, SourceConfig } from '@/lib/types';
import { AggregatedCard, aggregateResults } from './video-card';
import './related-search.css';

/** Opt-in user discovery only. Automatic source switching keeps api.search's strict contract. */
export function RelatedSearch({ query, requestKey, ready, available, originalItems, sources, filterAdult, onOpen }: {
  query: string;
  requestKey: string;
  ready: boolean;
  available: boolean;
  originalItems: SearchResultItem[];
  sources: SourceConfig[];
  filterAdult: boolean;
  onOpen: (item: SearchResultItem) => void;
}) {
  const policy = useMemo(() => getManualSearchPolicy(query, originalItems), [query, originalItems]);
  const [requested, setRequested] = useState<{ key: string; kind: 'series' | 'alternative' } | null>(null);
  const mode = policy.automatic ? 'automatic' : requested?.key === requestKey ? requested.kind : null;
  const candidates = useMemo(() => mode === 'automatic' ? policy.automaticCandidates : mode === 'series' ? policy.series
    : mode === 'alternative' ? policy.alternatives : [], [mode, policy]);
  const active = ready && available && sources.length > 0 && candidates.length > 0;
  const [progress, setProgress] = useState<{ key: string; outcomes: SearchExpansionOutcome[] }>({ key: '', outcomes: [] });
  const key = JSON.stringify([requestKey, candidates, originalItems.map((item) => [item.sourceKey, item.vodId]), sources]);
  const supplemental = useQuery({
    queryKey: ['manual-related-search-v2', key],
    queryFn: ({ signal }) => {
      setProgress({ key, outcomes: [] });
      return runSearchExpansion({ candidates, excludedItems: originalItems, signal,
        search: (candidate, requestSignal) => api.search(candidate.query, sources, filterAdult, {
          signal: requestSignal,
          // Stream transport keeps already received results if a source connection ends early.
          // Supplement requests deliberately do not count as repeated source-health failures.
          onSource: () => {},
        }),
        onResult: (outcome) => { if (!signal.aborted) setProgress((previous) => previous.key === key
          ? { key, outcomes: [...previous.outcomes, outcome] } : previous); },
      });
    },
    enabled: active, staleTime: 300_000, retry: false,
  });
  const outcomes = supplemental.data ?? (progress.key === key ? progress.outcomes : []);
  const sections = outcomes.map((outcome) => ({ outcome, ...partitionSearchResults(outcome.list, query) }));
  const hasResults = outcomes.some((item) => item.list.length > 0);
  const hasMain = sections.some((section) => section.main.length > 0);
  const incomplete = Boolean(supplemental.error) || outcomes.some((item) => item.partial || item.error || item.failures.length > 0);

  if (!ready || !available || sources.length === 0) return null;
  const actions = !policy.automatic && (policy.series.length > 0 || policy.alternatives.length > 0) && <div className="related-search-invitation">
    <span>也可以继续查找</span>
    {policy.series.length > 0 && <button type="button" className="btn-ghost" aria-pressed={mode === 'series'} onClick={() => setRequested({ key: requestKey, kind: 'series' })}>查找同系列</button>}
    {policy.alternatives.length > 0 && <button type="button" className="btn-ghost" aria-pressed={mode === 'alternative'} onClick={() => setRequested({ key: requestKey, kind: 'alternative' })}>搜索其他写法</button>}
  </div>;
  if (candidates.length === 0) return actions || null;

  return <section className="related-search" aria-label="相关搜索结果">
    <div className="related-search-heading">
      <div><h2>{mode === 'series' ? '同系列其他作品' : '试试相关片名'}</h2>
        <p>{policy.automatic ? originalItems.length === 0
          ? `原片名“${query}”暂未找到匹配资源，以下按相近片名或系列名补充查找。`
          : '原词目前只找到带解说、预告或花絮标识的内容，继续查找其他片名写法或同系列。'
          : '保留实际片名、季数和年份，选择你想看的版本。'}</p></div>
      <button type="button" className="btn-ghost" disabled={supplemental.isFetching} onClick={() => void supplemental.refetch()}>重新查找</button>
    </div>
    <p className="related-search-status" role="status" aria-atomic="true">{supplemental.isFetching
      ? `正在补搜${candidates.map((item) => `“${item.query}”`).join('、')}…`
      : incomplete ? '部分补搜未完成，已保留找到的结果。可重试或检查片源。'
        : !hasResults ? '这些相关关键词也暂未找到资源，可以换个关键词或片源。' : !hasMain
          ? '暂时仍只找到解说、预告或花絮等相关内容，已保留在下面。' : '已找到以下相关资源。'}</p>
    {sections.filter((section) => section.main.length > 0).map(({ outcome, main }) => <RelatedResults key={`main:${outcome.candidate.kind}:${outcome.candidate.query}`}
      outcome={outcome} items={main} sources={sources} onOpen={onOpen} />)}
    {sections.filter((section) => section.supplementary.length > 0).map(({ outcome, supplementary }) => <RelatedResults key={`supplementary:${outcome.candidate.kind}:${outcome.candidate.query}`}
      outcome={outcome} items={supplementary} supplementary sources={sources} onOpen={onOpen} />)}
    {actions}
  </section>;
}

function RelatedResults({ outcome, items, supplementary = false, sources, onOpen }: { outcome: SearchExpansionOutcome; items: SearchResultItem[]; supplementary?: boolean; sources: SourceConfig[]; onOpen: (item: SearchResultItem) => void }) {
  const groups = useMemo(() => aggregateResults(items), [items]);
  const [count, setCount] = useState(60);
  return <div className={`related-search-group${supplementary ? ' related-search-secondary' : ''}`}>
    <h3>{supplementary ? '解说、预告与花絮 · ' : outcome.candidate.kind === 'series' ? '同系列 · ' : '相近片名 · '}{outcome.candidate.query}<span>{groups.length} 部</span></h3>
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 items-start">
      {groups.slice(0, count).map((group) => <AggregatedCard key={group.key} group={group} sources={sources} onOpen={onOpen} />)}
    </div>
    {groups.length > count && <button className="btn-ghost related-search-more" type="button" onClick={() => setCount((value) => value + 60)}>加载更多相关结果（还有 {groups.length - count} 部）</button>}
  </div>;
}
