'use client';

import { useId, useState, type FormEvent } from 'react';
import { usePersonalAccount } from './personal-account-provider';
import { ConfirmDialog } from './confirm-dialog';
import { Icon } from './icon';
import { personalAccountLabel } from '@/lib/personal-login';

type Account = ReturnType<typeof usePersonalAccount>;
type Confirmation = 'import' | 'logout' | 'local' | 'cloud' | null;

function readableError(value: unknown): string {
  const message = value instanceof Error ? value.message : typeof value === 'string' ? value : '';
  if (/invalid.*(credentials|password)/i.test(message)) return '账号或密码不正确，请重新输入。';
  if (/email.*not.*confirmed/i.test(message)) return '请先完成邮箱验证，再登录。';
  if (/rate.*limit|too many/i.test(message)) return '操作较频繁，请稍后再试。';
  return /[\u3400-\u9fff]/.test(message) ? message : '操作未完成，请检查网络后重试。';
}

const STATUS_LABELS: Record<Account['status'], string> = {
  local: '本机模式', idle: '同步已就绪', syncing: '正在同步', offline: '离线，等待联网',
  error: '同步暂未完成', conflict: '有不同版本需要处理', 'auth-required': '需要重新登录',
};

/** Shared account panel; shortcuts and settings reuse the same local-first flow. */
export function AccountSyncPanel() {
  const account = usePersonalAccount();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [confirmation, setConfirmation] = useState<Confirmation>(null);
  const run = async (action: () => Promise<unknown>, success?: string) => {
    if (busy) return;
    setBusy(true); setError(''); setNotice('');
    try { await action(); if (success) setNotice(success); }
    catch (failure) { setError(readableError(failure)); }
    finally { setBusy(false); }
  };
  const confirm = () => {
    const pending = confirmation;
    setConfirmation(null);
    if (pending === 'import') void run(() => account.importGuest(), '本机资料已合并到当前账号，原本机资料仍保留。');
    if (pending === 'logout') void run(() => account.logout(true));
    if (pending === 'local' || pending === 'cloud') void run(() => account.resolveConflicts(pending));
  };

  if (!account.ready) return <div role="status" className="py-4 text-sm text-muted">正在读取账号状态…</div>;

  return (
    <section aria-labelledby="account-sync-heading" className="space-y-5">
      <div>
        <h3 id="account-sync-heading" className="text-base font-semibold text-content">账号与同步</h3>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          不登录时只使用本机资料。登录自己的账号后，手机、平板和电脑可同步点播与直播片源、影片与频道收藏、观看历史、逐集进度和直播最近观看。
        </p>
      </div>
      {account.scopeActive ? (
        <AccountDetails account={account} busy={busy} run={run} requestConfirmation={setConfirmation} />
      ) : account.configured ? <AccountForm account={account} /> : (
        <div role="status" className="rounded-lg bg-chip p-4 text-sm leading-relaxed text-muted">
          同步服务尚未配置，暂时不能登录或跨设备同步。你仍可正常使用本机片源、收藏和观看记录，现有资料不会上传。
        </div>
      )}
      {(error || account.error) && <p role="alert" className="text-sm leading-relaxed text-danger">{error || readableError(account.error)}</p>}
      {notice && <p role="status" className="text-sm leading-relaxed text-content">{notice}</p>}
      <ConfirmDialog
        open={confirmation !== null}
        danger={confirmation !== 'import'}
        title={confirmation === 'import' ? '合并本设备的游客资料？' : confirmation === 'logout' ? '仍有未同步资料，确认退出？' : '如何处理不同版本？'}
        message={confirmation === 'import'
          ? '将本设备游客模式中账号尚未保存的点播与直播片源、影片与频道收藏、观看历史、逐集进度和直播最近观看补充到当前账号，并同步至账号服务。账号已有的对应资料优先保留，原本机资料不会删除。'
          : confirmation === 'logout'
            ? '退出会清除本设备的账号缓存，尚未同步的修改将丢失；已同步的账号资料和原本机游客资料仍然保留。建议取消后先完成同步。'
            : confirmation === 'local'
              ? '将当前待处理项目的本机版本同步到账号，替换其他设备上传的对应版本。其他项目不受影响。'
              : '采用账号中的对应版本，放弃这些待处理项目尚未同步的本机修改。其他项目不受影响。'}
        confirmLabel={confirmation === 'import' ? '合并到我的账号' : confirmation === 'logout' ? '放弃未同步修改并退出' : confirmation === 'local' ? '保留本机版本' : '采用云端版本'}
        onCancel={() => setConfirmation(null)} onConfirm={confirm}
      />
    </section>
  );
}

function AccountDetails({ account, busy, run, requestConfirmation }: {
  account: Account; busy: boolean;
  run: (action: () => Promise<unknown>, success?: string) => Promise<void>;
  requestConfirmation: (confirmation: Confirmation) => void;
}) {
  const syncing = busy || account.status === 'syncing';
  const lastSync = account.lastSyncedAt ? new Date(account.lastSyncedAt).toLocaleString('zh-CN', { hour12: false }) : null;
  return (
    <div className="space-y-4">
      <div className="border-b border-line pb-4">
        <p className="break-all font-medium text-content">{account.user?.email ? personalAccountLabel(account.user.email) : '当前个人账号'}</p>
        <div role="status" aria-live="polite" className="mt-2 space-y-1 text-sm text-muted">
          <p>{STATUS_LABELS[account.status]}{account.pendingCount > 0 ? ` · ${account.pendingCount} 项待同步` : ''}</p>
          {lastSync && <p className="text-xs text-faint">上次同步：{lastSync}</p>}
        </div>
      </div>
      {account.status === 'auth-required' && <div className="space-y-3">
        <p className="text-sm leading-relaxed text-muted">登录状态需要重新确认。可先返回本机模式再登录同一账号；未同步的账号资料仍独立保存在本设备。</p>
        <button type="button" className="btn-ghost min-h-11 text-sm" disabled={busy} onClick={account.returnToLocal}>返回本机模式，保留账号资料</button>
      </div>}
      {(account.conflictCount > 0 || account.status === 'conflict') && (
        <div className="space-y-3 rounded-lg bg-chip p-4">
          <h4 className="text-sm font-medium text-content">{account.conflictCount || '部分'} 项资料在其他设备也有更新</h4>
          <p className="text-sm leading-relaxed text-muted">同步已暂停，先选择这些项目要保留的版本。正在播放的视频不会被远程跳转。</p>
          <div className="flex flex-wrap gap-2">
            <button type="button" className="btn-ghost min-h-11 text-sm" disabled={syncing} onClick={() => requestConfirmation('local')}>保留本机版本</button>
            <button type="button" className="btn-ghost min-h-11 text-sm" disabled={syncing} onClick={() => requestConfirmation('cloud')}>采用云端版本</button>
          </div>
        </div>
      )}
      <div className="flex flex-wrap gap-2">
        <button type="button" className="btn-primary min-h-11 gap-2 text-sm" disabled={syncing || !account.configured || account.status === 'auth-required'} onClick={() => void run(() => account.syncNow())}>
          <Icon name="refresh" className="h-4 w-4" />{syncing ? '正在处理…' : '立即同步'}
        </button>
        <button type="button" className="btn-ghost min-h-11 text-sm" disabled={syncing || !account.user || !account.configured} onClick={() => requestConfirmation('import')}>合并本机游客资料</button>
      </div>
      <p className="text-xs leading-relaxed text-faint">离线时先保存到本机账号空间，联网后再同步。下载文件、缓存和设备偏好不会上传。</p>
      <button type="button" className="btn-ghost min-h-11 text-sm" disabled={syncing} onClick={() => void run(async () => { if (!await account.logout()) requestConfirmation('logout'); })}>退出账号，返回本机模式</button>
    </div>
  );
}

function AccountForm({ account }: { account: Account }) {
  const id = useId();
  const [registering, setRegistering] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false);
  const [confirmation, setConfirmation] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (busy) return;
    if (registering && password !== confirmation) { setError('两次输入的密码不一致。'); return; }
    const submittedPassword = password;
    setPasswordVisible(false);
    setPassword(''); setConfirmation(''); setError(''); setNotice(''); setBusy(true);
    try {
      if (registering) {
        const result = await account.register(email.trim(), submittedPassword);
        setNotice(result.confirmationRequired ? '请查看邮箱中的验证邮件，完成验证后回来登录。' : '账号已创建。');
      } else await account.login(email.trim(), submittedPassword);
    } catch (failure) { setError(readableError(failure)); }
    finally { setBusy(false); }
  };
  return (
    <form onSubmit={(event) => void submit(event)} className="space-y-4" aria-label={registering ? '创建个人账号' : '登录个人账号'}>
      {!account.allowSignup && <p className="text-sm leading-relaxed text-muted">账号由管理员统一创建。使用分配给你的家庭账号登录；没有账号或忘记密码时，请联系管理员。</p>}
      <div>
        <label htmlFor={`${id}-email`} className="mb-2 block text-sm text-content">{registering ? '邮箱' : '账号或邮箱'}</label>
        <input id={`${id}-email`} className="input min-h-11 w-full" type={registering ? 'email' : 'text'} name="username" autoComplete="username" inputMode={registering ? 'email' : 'text'} autoCapitalize="none" spellCheck={false} required maxLength={254} placeholder={registering ? undefined : '例如 001'} aria-describedby={registering ? undefined : `${id}-login-hint`} value={email} onChange={(event) => setEmail(event.target.value)} disabled={busy} />
        {!registering && <p id={`${id}-login-hint`} className="mt-2 text-xs leading-relaxed text-faint">家庭账号直接填写编号，如 001；也支持完整邮箱。</p>}
      </div>
      <div>
        <label htmlFor={`${id}-password`} className="mb-2 block text-sm text-content">密码{registering ? '（至少 8 位）' : ''}</label>
        <div className="relative">
          <input id={`${id}-password`} className="input min-h-11 w-full pr-20" type={passwordVisible ? 'text' : 'password'} autoComplete={registering ? 'new-password' : 'current-password'} autoCapitalize="none" spellCheck={false} required minLength={registering ? 8 : undefined} maxLength={256} value={password} onChange={(event) => setPassword(event.target.value)} disabled={busy} />
          <button type="button" className="absolute inset-y-0 right-0 min-w-16 min-h-11 rounded-lg px-3 text-xs text-muted hover:text-content" aria-label={passwordVisible ? '隐藏密码' : '显示密码'} aria-pressed={passwordVisible} aria-controls={`${id}-password`} disabled={busy} onClick={() => setPasswordVisible((visible) => !visible)}>{passwordVisible ? '隐藏' : '显示'}</button>
        </div>
      </div>
      {registering && <div>
        <label htmlFor={`${id}-confirmation`} className="mb-2 block text-sm text-content">再次输入密码</label>
        <input id={`${id}-confirmation`} className="input min-h-11 w-full" type={passwordVisible ? 'text' : 'password'} autoComplete="new-password" required minLength={8} maxLength={256} value={confirmation} onChange={(event) => setConfirmation(event.target.value)} disabled={busy} />
      </div>}
      {error && <p role="alert" className="text-sm leading-relaxed text-danger">{error}</p>}
      {notice && <p role="status" className="text-sm leading-relaxed text-content">{notice}</p>}
      <button type="submit" className="btn-primary min-h-11 w-full text-sm" disabled={busy}>{busy ? '正在处理…' : registering ? '创建我的账号' : '登录我的账号'}</button>
      {account.allowSignup && <div className="flex flex-wrap items-center justify-between gap-x-3">
        <button type="button" className="min-h-11 text-sm text-muted hover:text-content focus-visible:outline focus-visible:outline-2 focus-visible:outline-accent" disabled={busy} onClick={() => { setRegistering(!registering); setPassword(''); setPasswordVisible(false); setConfirmation(''); setError(''); setNotice(''); }}>{registering ? '已有账号，返回登录' : '创建个人账号'}</button>
      </div>}
      <p className="text-xs leading-relaxed text-faint">每位家人使用自己的账号。登录不会自动合并或上传本机原有资料。</p>
    </form>
  );
}
