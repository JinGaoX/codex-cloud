import type { DiscoveryItem } from '@/lib/discovery';

/** Artwork lookup only: these titles are never used as a recommendation source. */
export const HOME_WIDE_ARTWORK: readonly { title: string; image: string }[] = [
  { title: '狂飙', image: 'feature-knockout.webp' },
  { title: '星际穿越', image: 'feature-interstellar.webp' },
  { title: '白夜破晓', image: 'feature-daybreak.webp' },
  { title: '浪浪山小妖怪', image: 'feature-nobody.webp' },
];

/** Preserve the live provider order; the hero needs an actual image to showcase. */
export function selectDynamicHomeFeatures(items: readonly DiscoveryItem[]): DiscoveryItem[] {
  const seen = new Set<string>();
  return items.filter((item) => {
    if (!item.cover || seen.has(item.id)) return false;
    seen.add(item.id);
    return true;
  }).slice(0, 6);
}
