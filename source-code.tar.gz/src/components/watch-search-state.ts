export const WATCH_SEARCH_PAGE_SIZE = 24;

/** Both result sections share a page size, so either can offer the next page. */
export function watchSearchWindow<T>(main: readonly T[], supplementary: readonly T[], visibleCount: number) {
  return {
    main: main.slice(0, visibleCount),
    supplementary: supplementary.slice(0, visibleCount),
    hasMore: main.length > visibleCount || supplementary.length > visibleCount,
  };
}
