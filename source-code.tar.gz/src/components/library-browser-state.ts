import { DISCOVERY_LISTS, type DiscoveryListId } from '@/lib/discovery';
import { cleanLibraryFilters, type LibraryFilters } from '@/lib/library-discovery';

export type LibraryMode = 'browse' | 'ranking';
/** Native pushState does not emit hashchange; notify the lightweight shared header. */
export const DISCOVERY_NAVIGATION_EVENT = 'libretv:discovery-navigation';
export interface LibraryView extends LibraryFilters {
  mode: LibraryMode;
  list: DiscoveryListId | 'top250';
  page: number;
  /** Omitted by legacy links. Offset preserves the first item when a device rotates. */
  size?: 20 | 21 | 24;
  offset?: number;
}

export function libraryLists(type: LibraryFilters['type']) {
  return DISCOVERY_LISTS.filter((entry) => type === 'show' ? entry.id.startsWith('douban_show_')
    : type === 'tv' ? entry.id.startsWith('douban_tv_') || entry.id === 'baidu_teleplay'
    : type === 'animation' ? entry.id === 'douban_movie_animation' : !entry.isTv);
}

export function readLibraryView(params: Pick<URLSearchParams, 'get'>): LibraryView {
  const filters = cleanLibraryFilters({
    type: params.get('type'), sort: params.get('sort'), genre: params.get('genre'),
    country: params.get('country'), year: params.get('year'), minRating: Number(params.get('minRating') ?? 0),
  });
  const mode = filters.type === 'show' || params.get('mode') === 'ranking' ? 'ranking' : 'browse';
  const lists = libraryLists(filters.type);
  const defaultList = filters.type === 'movie' ? 'top250' : lists[0]?.id ?? 'douban_movie_weekly';
  const requestedList = params.get('list');
  const list = requestedList === 'top250' && filters.type === 'movie' ? 'top250'
    : lists.find((entry) => entry.id === requestedList)?.id ?? defaultList;
  const rawPage = params.get('page') ?? '1';
  const page = /^\d{1,3}$/.test(rawPage) ? Math.min(250, Math.max(1, Number(rawPage))) : 1;
  const sizeValue = Number(params.get('size'));
  const size = [20, 21, 24].includes(sizeValue) ? sizeValue as 20 | 21 | 24 : undefined;
  const limit = mode === 'ranking' ? list === 'top250' ? 250 : 50 : 5000;
  if (size) {
    const rawOffset = params.get('offset');
    const offset = rawOffset !== null && /^\d{1,4}$/.test(rawOffset)
      ? Math.min(limit - 1, Number(rawOffset)) : Math.min(limit - 1, (page - 1) * size);
    return { ...filters, mode, list, size, offset, page: Math.floor(offset / size) + 1 };
  }
  return { ...filters, mode, list, page: mode === 'ranking' ? Math.min(list === 'top250' ? 10 : 2, page) : page };
}

export function libraryWindowStart(view: LibraryView): number {
  return view.offset ?? (view.page - 1) * (view.size ?? (view.mode === 'ranking' ? 25 : 20));
}

export function withLibraryWindow(view: LibraryView, size: 20 | 21 | 24): LibraryView {
  const offset = libraryWindowStart(view);
  return { ...view, size, offset, page: Math.floor(offset / size) + 1 };
}

export function libraryHref(view: LibraryView): string {
  const params = new URLSearchParams({ type: view.type, mode: view.mode });
  if (view.mode === 'ranking') params.set('list', view.list);
  else {
    if (view.sort !== 'U') params.set('sort', view.sort);
    if (view.genre) params.set('genre', view.genre);
    if (view.country) params.set('country', view.country);
    if (view.year) params.set('year', view.year);
    if (view.minRating) params.set('minRating', String(view.minRating));
  }
  if (view.page > 1) params.set('page', String(view.page));
  if (view.size) { params.set('size', String(view.size)); params.set('offset', String(libraryWindowStart(view))); }
  return `/library?${params.toString()}`;
}

/** The full browser now lives under the home hero; legacy library URLs stay readable. */
export function discoveryHref(view: LibraryView): string {
  return `${libraryHref(view).replace('/library?', '/?')}#home-discovery`;
}

export function hasLibraryView(params: Pick<URLSearchParams, 'get'>): boolean {
  return ['type', 'mode', 'list', 'sort', 'genre', 'country', 'year', 'minRating', 'page', 'size', 'offset'].some((key) => params.get(key) !== null);
}

/** Stop a source that ignores page offsets, without keeping full metadata pages. */
export function trackLibraryPage(pages: Map<string, readonly string[]>, scope: string, page: number, ids: readonly string[]): boolean {
  const key = `${scope}:${page}`;
  const current = new Set(ids);
  const repeated = current.size > 0 && [...pages].some(([otherKey, otherIds]) => otherKey.startsWith(`${scope}:`)
    && Number(otherKey.slice(scope.length + 1)) < page && otherIds.length > 0 && [...current].every((id) => otherIds.includes(id)));
  pages.delete(key);
  pages.set(key, [...current]);
  while (pages.size > 16) pages.delete(pages.keys().next().value!);
  return repeated;
}

const POSITION_KEY = 'libretv-library-navigation-v1';
const LAST_VIEW_KEY = 'libretv-library-view-v1';
const MAX_POSITIONS = 12;
export interface PositionStorage { getItem(key: string): string | null; setItem(key: string, value: string): void }

function storage(): PositionStorage | undefined {
  try { return typeof window === 'undefined' ? undefined : window.sessionStorage; } catch { return undefined; }
}

export function readLastLibraryView(store = storage()): LibraryView | undefined {
  if (!store) return undefined;
  try {
    const raw = store.getItem(LAST_VIEW_KEY);
    if (!raw || raw.length > 1024 || !raw.startsWith('/library?')) return undefined;
    return readLibraryView(new URLSearchParams(raw.split('?')[1]));
  } catch { return undefined; }
}

/** Only public catalogue criteria; no search terms, private API or viewing data. */
export function writeLastLibraryView(view: LibraryView, store = storage()): void {
  if (!store) return;
  try { store.setItem(LAST_VIEW_KEY, libraryHref(readLibraryView(new URLSearchParams(libraryHref(view).split('?')[1])))); } catch { /* Optional session preference. */ }
}

export function readDiscoveryReturnPosition(view: LibraryView, state: unknown): number | undefined {
  if (!state || typeof state !== 'object') return undefined;
  const entry = (state as Record<string, unknown>).ppsDiscoveryReturn;
  if (!entry || typeof entry !== 'object') return undefined;
  const { key, scrollY } = entry as Record<string, unknown>;
  return key === libraryHref(view) && typeof scrollY === 'number' && Number.isFinite(scrollY) && scrollY >= 0 && scrollY <= 1_000_000 ? scrollY : undefined;
}

function positions(store: PositionStorage): Record<string, number> {
  const raw = store.getItem(POSITION_KEY);
  if (!raw || raw.length > 16_384) return {};
  const parsed: unknown = JSON.parse(raw);
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
  return Object.fromEntries(Object.entries(parsed).slice(-MAX_POSITIONS).filter(([key, value]) =>
    /^\/library\?/.test(key) && key.length < 1024 && typeof value === 'number' && Number.isFinite(value) && value >= 0 && value <= 1_000_000));
}

export function readLibraryPosition(key: string, store = storage()): number {
  if (!store) return 0;
  try { return positions(store)[key] ?? 0; } catch { return 0; }
}

/** Public navigation coordinates only; never stores sources, records or search terms. */
export function writeLibraryPosition(view: LibraryView, scrollY: number, store = storage()): void {
  if (!store || !Number.isFinite(scrollY) || scrollY < 0 || scrollY > 1_000_000) return;
  try {
    const key = libraryHref(view);
    const saved = positions(store);
    delete saved[key];
    saved[key] = Math.round(scrollY);
    store.setItem(POSITION_KEY, JSON.stringify(Object.fromEntries(Object.entries(saved).slice(-MAX_POSITIONS))));
  } catch { /* Navigation continues if storage is blocked. */ }
}
