'use client';

import { useSyncExternalStore } from 'react';
import {
  cancelWebDownload,
  getWebDownloads,
  getWebDownloadsServerSnapshot,
  hideWebDownloads,
  markWebDownloadSaveRequested,
  removeWebDownload,
  retryWebDownload,
  showWebDownloads,
  subscribeWebDownloads,
  type WebDownloadTask,
} from '@/lib/web-download-queue';
import { Drawer } from './drawer';
import { Icon } from './icon';

function statusLabel(task: WebDownloadTask): string {
  switch (task.status) {
    case 'queued': return '排队中';
    case 'checking': return '正在检查画质…';
    case 'downloading': return task.progress?.percentage === undefined ? '下载中…' : `下载中 ${task.progress.percentage}%`;
    case 'cancelling': return '正在取消…';
    case 'cancelled': return '已取消';
    case 'error': return '下载失败';
    case 'ready':
      if (task.handedToBrowser) return '已交给浏览器';
      return task.file.kind === 'attachment' ? '可交给浏览器下载' : '待保存';
  }
}

function DownloadRow({ task }: { task: WebDownloadTask }) {
  const variant = task.selection?.variant;
  const resolution = variant?.width && variant.height ? `${variant.width}×${variant.height}` : '';
  const percentage = task.status === 'downloading' ? task.progress?.percentage : undefined;
  const canCancel = task.status === 'queued' || task.status === 'checking' || task.status === 'downloading';
  const canRetry = task.status === 'error' || task.status === 'cancelled';
  return (
    <li className="space-y-2 rounded-lg border border-line bg-surface px-3 py-3">
      <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
        <p className="min-w-0 break-words text-sm font-medium text-content">{task.title}</p>
        <p className="shrink-0 text-xs text-muted">{statusLabel(task)}</p>
      </div>
      <p className="break-words text-xs text-muted">{[task.sourceName, resolution].filter(Boolean).join(' · ')}</p>
      {percentage !== undefined && <progress className="h-1.5 w-full accent-current" value={percentage} max={100} aria-label={`${task.title}下载进度`} />}
      {task.status === 'error' && <p className="break-words text-sm text-danger">{task.reason}</p>}
      {task.status === 'ready' && <p className="break-all text-xs text-muted">{task.file.filename}</p>}
      {(canCancel || canRetry || task.status === 'ready') && <div className="flex flex-wrap justify-end gap-2">
        {canCancel && <button type="button" className="btn-ghost btn-sm min-h-10" onClick={() => cancelWebDownload(task.id)}>取消下载</button>}
        {canRetry && <button type="button" className="btn-ghost btn-sm min-h-10" onClick={() => retryWebDownload(task.id)}>重试</button>}
        {(canRetry || task.status === 'ready') && <button type="button" className="btn-ghost btn-sm min-h-10" onClick={() => removeWebDownload(task.id)}>移除任务</button>}
        {task.status === 'ready' && <a
          className="btn-primary btn-sm min-h-10"
          href={task.file.url}
          download={task.file.filename}
          target={task.file.kind === 'attachment' ? '_blank' : undefined}
          rel={task.file.kind === 'attachment' ? 'noopener noreferrer' : undefined}
          onClick={() => markWebDownloadSaveRequested(task.id)}
        >{task.handedToBrowser ? '重新保存' : task.file.kind === 'attachment' ? '浏览器下载' : '保存到设备'}</a>}
      </div>}
    </li>
  );
}

export function WebDownloadCenter() {
  const { tasks, open } = useSyncExternalStore(subscribeWebDownloads, getWebDownloads, getWebDownloadsServerSnapshot);
  const active = tasks.find((task) => task.status === 'checking' || task.status === 'downloading' || task.status === 'cancelling');
  const waiting = tasks.filter((task) => task.status === 'ready' && !task.handedToBrowser).length;
  const failed = tasks.filter((task) => task.status === 'error').length;
  const pending = waiting ? `${waiting} 项待保存` : failed ? `${failed} 项失败` : undefined;
  const indicator = active && pending ? `${statusLabel(active)} · ${pending}`
    : active ? statusLabel(active) : pending;

  return <>
    {indicator && <button
      type="button"
      className="btn-ghost fixed bottom-[calc(5rem+env(safe-area-inset-bottom))] right-3 z-40 inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface-raised px-4 text-sm shadow-lg lg:bottom-5 lg:right-5"
      aria-haspopup="dialog"
      aria-label={`下载管理 · ${indicator}`}
      aria-expanded={open}
      onClick={showWebDownloads}
    ><Icon name="download" className="size-4" />{indicator}</button>}
    <Drawer open={open} onClose={hideWebDownloads} title="下载管理" width="max-w-xl" mobileSheet>
      <div className="space-y-3">
        <p className="text-sm leading-relaxed text-muted">在 PPS 内切换页面时会继续下载。准备期间请保持 PPS 打开，刷新或关闭会结束当前队列。</p>
        <p className="text-sm leading-relaxed text-muted">准备好后点「保存到设备」或「浏览器下载」。可在浏览器的下载记录找文件，iPhone 和 iPad 可在「文件」App 的「下载」文件夹查看。</p>
        {tasks.length === 0
          ? <p className="py-5 text-center text-sm text-muted">暂无下载任务。在播放页可下载本集或批量下载。</p>
          : <ul className="space-y-2">{tasks.map((task) => <DownloadRow key={task.id} task={task} />)}</ul>}
      </div>
    </Drawer>
  </>;
}
