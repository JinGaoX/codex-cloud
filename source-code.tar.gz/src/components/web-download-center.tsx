'use client';

import { useEffect, useSyncExternalStore } from 'react';
import { cn } from '@/lib/utils';
import {
  canPauseWebDownload,
  cancelWebDownload,
  getWebDownloads,
  getWebDownloadsServerSnapshot,
  handleWebDownloadVisibilityChange,
  hideWebDownloads,
  initializeWebDownloads,
  markWebDownloadSaveRequested,
  pauseWebDownload,
  removeWebDownload,
  resumeWebDownload,
  retryWebDownload,
  showWebDownloads,
  subscribeWebDownloads,
  type WebDownloadTask,
} from '@/lib/web-download-queue';
import { Drawer } from './drawer';
import { Icon } from './icon';

function progressLabel(label: string, percentage?: number) {
  return percentage === undefined ? label : `${label} ${percentage}%`;
}

function statusLabel(task: WebDownloadTask): string {
  switch (task.status) {
    case 'queued': return '排队中';
    case 'checking': return '正在检查画质…';
    case 'downloading': return task.progress?.percentage === undefined ? '下载中…' : `下载中 ${task.progress.percentage}%`;
    case 'pausing': return progressLabel('暂停中', task.progress?.percentage);
    case 'paused': return progressLabel('已暂停', task.progress?.percentage);
    case 'restoring': return progressLabel('正在恢复…', task.progress?.percentage);
    case 'cancelling': return '正在取消…';
    case 'cancelled': return '已取消';
    case 'error': return task.progress?.current ? progressLabel('下载失败 · 已保留', task.progress.percentage) : '下载失败';
    case 'ready':
      if (task.handedToBrowser) return '已交给浏览器';
      return task.file.kind === 'attachment' ? '可交给浏览器下载' : '待保存';
  }
}

function DownloadRow({ task }: { task: WebDownloadTask }) {
  const variant = task.selection?.variant;
  const resolution = variant?.width && variant.height ? `${variant.width}×${variant.height}` : '';
  const transferring = task.status === 'downloading' || task.status === 'pausing' || task.status === 'paused' || task.status === 'restoring';
  const progress = transferring || task.status === 'error' ? task.progress : undefined;
  const percentage = progress?.percentage;
  const canPause = canPauseWebDownload(task);
  const canCancel = task.status === 'queued' || task.status === 'checking' || transferring;
  const canRetry = task.status === 'error' || task.status === 'cancelled';
  const pauseAction = task.status === 'paused' ? resumeWebDownload : canPause ? pauseWebDownload : null;
  const pauseLabel = task.status === 'pausing' ? '正在暂停…' : task.status === 'paused' ? '继续下载' : '暂停下载';
  return (
    <li className="space-y-2 rounded-lg border border-line bg-surface px-3 py-3">
      <div className="flex flex-wrap items-baseline justify-between gap-x-3 gap-y-1">
        <p className="min-w-0 break-words text-sm font-medium text-content">{task.title}</p>
        <p className="shrink-0 text-xs text-muted">{statusLabel(task)}</p>
      </div>
      <p className="break-words text-xs text-muted">{[task.sourceName, resolution].filter(Boolean).join(' · ')}</p>
      {percentage !== undefined && <progress className="h-1.5 w-full accent-current" value={percentage} max={100} aria-label={`${task.title}下载进度`} />}
      {task.status === 'error' && <p className="break-words text-sm text-danger">{task.reason}</p>}
      {task.status === 'ready' && <p className="break-all text-xs text-muted">{task.file.filename}</p>}
      {(canCancel || canRetry || task.status === 'ready') && <div className="flex flex-wrap justify-end gap-2">
        {canCancel && <button type="button" className="btn-ghost btn-sm min-h-10" onClick={() => cancelWebDownload(task.id)}>取消下载</button>}
        {(pauseAction || task.status === 'pausing') && <button
          type="button"
          className="btn-primary btn-sm min-h-10 aria-disabled:cursor-default aria-disabled:opacity-60"
          aria-disabled={task.status === 'pausing' || undefined}
          onClick={pauseAction ? () => pauseAction(task.id) : undefined}
        >{pauseLabel}</button>}
        {canRetry && <button type="button" className="btn-ghost btn-sm min-h-10" onClick={() => retryWebDownload(task.id)}>重试</button>}
        {(canRetry || task.status === 'ready') && <button type="button" className="btn-ghost btn-sm min-h-10" onClick={() => removeWebDownload(task.id)}>移除任务</button>}
        {task.status === 'ready' && <a
          className="btn-primary btn-sm min-h-10"
          href={task.file.url}
          download={task.file.filename}
          target={task.file.kind === 'attachment' ? '_blank' : undefined}
          rel={task.file.kind === 'attachment' ? 'noopener noreferrer' : undefined}
          onClick={() => markWebDownloadSaveRequested(task.id)}
        >{task.handedToBrowser ? '重新保存' : task.file.kind === 'attachment' ? '浏览器下载' : '保存到设备'}</a>}
      </div>}
    </li>
  );
}

export function WebDownloadCenter() {
  const { tasks, open } = useSyncExternalStore(subscribeWebDownloads, getWebDownloads, getWebDownloadsServerSnapshot);
  const active = tasks.find((task) => task.status === 'checking' || task.status === 'downloading'
    || task.status === 'pausing' || task.status === 'restoring' || task.status === 'cancelling')
    ?? tasks.find((task) => task.status === 'paused');
  const waiting = tasks.filter((task) => task.status === 'ready' && !task.handedToBrowser).length;
  const failed = tasks.filter((task) => task.status === 'error').length;
  const pending = waiting ? `${waiting} 项待保存` : failed ? `${failed} 项失败` : undefined;
  const queued = tasks.filter((task) => task.status === 'queued').length;
  const indicator = [active && statusLabel(active), pending].filter(Boolean).join(' · ')
    || (queued > 0 ? `${queued} 项排队中` : `${tasks.length} 项任务`);

  useEffect(() => {
    const onVisibilityChange = () => { void handleWebDownloadVisibilityChange(); };
    document.addEventListener('visibilitychange', onVisibilityChange);
    void initializeWebDownloads();
    return () => document.removeEventListener('visibilitychange', onVisibilityChange);
  }, []);

  return <>
    {tasks.length > 0 && <button
      type="button"
      className={cn('btn-ghost fixed bottom-[calc(5rem+env(safe-area-inset-bottom))] right-3 z-40 inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface-raised px-4 text-sm shadow-lg lg:bottom-5 lg:right-5',
        open && 'pointer-events-none opacity-0')}
      aria-haspopup="dialog"
      aria-label={`下载管理 · ${indicator}`}
      aria-expanded={open}
      tabIndex={open ? -1 : undefined}
      onClick={(event) => {
        event.currentTarget.focus({ preventScroll: true });
        showWebDownloads();
      }}
    ><Icon name="download" className="size-4 shrink-0" />{indicator}</button>}
    <Drawer open={open} onClose={hideWebDownloads} title="下载管理" width="max-w-xl" mobileSheet>
      <div className="space-y-3">
        {tasks.length === 0
          ? <p className="py-5 text-center text-sm text-muted">暂无下载任务。在播放页可下载本集或批量下载。</p>
          : <ul className="space-y-2">{tasks.map((task) => <DownloadRow key={task.id} task={task} />)}</ul>}
        <details className="rounded-lg border border-line bg-surface px-3">
          <summary tabIndex={0} className="min-h-10 cursor-pointer py-2.5 text-sm text-content">文件保存在哪</summary>
          <p className="pb-3 text-sm leading-relaxed text-muted">准备好后点「保存到设备」或「浏览器下载」。可在浏览器的下载记录找文件，iPhone 和 iPad 可在「文件」App 的「下载」文件夹查看。</p>
        </details>
        {tasks.length > 0 && <p className="text-xs leading-relaxed text-muted">HLS 下载切到后台会暂停。回到 PPS 可点「继续下载」。支持本机暂存时，关闭后重开也能找回进度；整文件 MP4 重试可能从头开始。</p>}
      </div>
    </Drawer>
  </>;
}
