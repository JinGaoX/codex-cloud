'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { APP_BRAND } from '@/lib/app-brand';
import type { AppPanel } from '@/lib/app-navigation';
import { LIBRARY_TYPES, type LibraryType } from '@/lib/library-discovery';
import { IS_ANDROID_NATIVE, SUPPORTS_LIVE_TV } from '@/lib/runtime-mode';
import { Icon } from './icon';
import './home-sidebar.css';

const TABLET_RAIL = '(min-width: 1000px) and (max-width: 1399px) and (orientation: landscape)';

/** Navigation only: Header owns routes and sheets, and the gallery owns its real filters. */
export function HomeSidebar({ onHome, onDiscover, onPanel, isHome, isLive, discoveryActive, activeType, activePanel }: {
  onHome: () => void;
  onDiscover: (type?: LibraryType) => void;
  onPanel: (panel: AppPanel) => void;
  isHome: boolean;
  isLive: boolean;
  discoveryActive: boolean;
  activeType: LibraryType;
  activePanel?: AppPanel;
}) {
  const [collapsed, setCollapsed] = useState(false);
  const [overlayOpen, setOverlayOpen] = useState(false);
  const [tabletRail, setTabletRail] = useState(false);
  const sidebar = useRef<HTMLElement>(null);
  const toggle = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (IS_ANDROID_NATIVE) return;
    const media = window.matchMedia(TABLET_RAIL);
    const sync = () => {
      setTabletRail(media.matches);
      if (!media.matches) setOverlayOpen(false);
    };
    sync();
    media.addEventListener('change', sync);
    return () => media.removeEventListener('change', sync);
  }, []);

  useEffect(() => {
    if (!overlayOpen || !tabletRail) return;
    const close = () => { setOverlayOpen(false); toggle.current?.focus({ preventScroll: true }); };
    const escape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { event.preventDefault(); close(); }
    };
    const outside = (event: PointerEvent) => {
      if (event.target instanceof Node && !sidebar.current?.contains(event.target)) close();
    };
    document.addEventListener('keydown', escape);
    document.addEventListener('pointerdown', outside);
    return () => {
      document.removeEventListener('keydown', escape);
      document.removeEventListener('pointerdown', outside);
    };
  }, [overlayOpen, tabletRail]);

  const select = (action: () => void) => { setOverlayOpen(false); action(); };
  const expanded = tabletRail ? overlayOpen : !collapsed;
  return <>
    {tabletRail && overlayOpen && <div className="home-sidebar-scrim" aria-hidden="true" />}
    <aside ref={sidebar} className="home-sidebar" aria-label="影视导航" data-collapsed={collapsed || undefined}
      data-overlay-open={overlayOpen || undefined} onBlurCapture={(event) => {
        if (tabletRail && event.relatedTarget instanceof Node && !event.currentTarget.contains(event.relatedTarget)) setOverlayOpen(false);
      }}>
      <div className="home-sidebar-brand-row">
        <button type="button" className="home-sidebar-brand" aria-label={`${APP_BRAND.name} 首页`} onClick={() => select(onHome)} title={APP_BRAND.shortName}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={APP_BRAND.icons.large} alt="" width="32" height="32" />
          <span className="home-sidebar-label">{APP_BRAND.shortName}</span>
        </button>
      </div>
      {!IS_ANDROID_NATIVE && <button ref={toggle} type="button" className="home-sidebar-toggle" aria-label={expanded ? '收起导航' : '展开导航'}
        aria-expanded={expanded} aria-controls="home-sidebar-navigation" onClick={() => {
          if (tabletRail) setOverlayOpen((open) => !open);
          else setCollapsed((value) => !value);
        }}>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
          <rect x="3.5" y="4.5" width="17" height="15" rx="2" /><path d="M9 4.5v15" />
          <path d={expanded ? 'm15.5 9-3 3 3 3' : 'm13 9 3 3-3 3'} />
        </svg>
        <span className="home-sidebar-label">{expanded ? '收起导航' : '展开导航'}</span>
      </button>}
      <div id="home-sidebar-navigation" className="home-sidebar-navigation">
        <nav aria-label="主要影视导航" className="home-sidebar-main">
          <button type="button" aria-label="首页" title="首页" aria-current={isHome && !discoveryActive && !activePanel ? 'page' : undefined} onClick={() => select(onHome)}><Icon name="home" /><span className="home-sidebar-label">首页</span></button>
          <button type="button" aria-label="发现影视" title="发现影视" aria-current={discoveryActive && !activePanel ? 'location' : undefined} onClick={() => select(() => onDiscover())}><Icon name="search" /><span className="home-sidebar-label">发现</span></button>
          {SUPPORTS_LIVE_TV && <Link href="/live" title="直播" aria-label="直播" aria-current={isLive ? 'page' : undefined} onClick={() => setOverlayOpen(false)}><Icon name="bolt" /><span className="home-sidebar-label">直播</span></Link>}
          <button type="button" aria-label="我的收藏" title="我的收藏" aria-pressed={activePanel === 'favorites'} onClick={() => select(() => onPanel('favorites'))}><Icon name="heart" /><span className="home-sidebar-label">收藏</span></button>
          <button type="button" aria-label="观看历史" title="观看历史" aria-pressed={activePanel === 'history'} onClick={() => select(() => onPanel('history'))}><Icon name="clock" /><span className="home-sidebar-label">历史</span></button>
        </nav>
        <nav aria-label="发现影视分类" className="home-sidebar-categories">
          <span className="home-sidebar-group-label">影视分类</span>
          {LIBRARY_TYPES.map((entry) => <button key={entry.value} type="button" title={entry.label} aria-label={`发现${entry.label}`}
            aria-current={discoveryActive && activeType === entry.value && !activePanel ? 'location' : undefined}
            onClick={() => select(() => onDiscover(entry.value))}>
            <MediaIcon type={entry.value} /><span className="home-sidebar-label">{entry.label}</span>
          </button>)}
        </nav>
      </div>
    </aside>
  </>;
}

function MediaIcon({ type }: { type: LibraryType }) {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {type === 'movie' ? <><rect x="3.5" y="4" width="17" height="16" rx="2" /><path d="M8 4v16M16 4v16M3.5 9h4M3.5 15h4M16.5 9h4M16.5 15h4" /></>
      : type === 'tv' ? <><rect x="3" y="7" width="18" height="13" rx="2" /><path d="m8 3 4 4 4-4M7 16h5" /></>
        : type === 'animation' ? <><path d="m8 7-2-3-3 5v6a6 6 0 0 0 6 6h6a6 6 0 0 0 6-6V9l-3-5-2 3Z" /><path d="M8 12h.01M16 12h.01M9 16c2 1.5 4 1.5 6 0" /></>
          : <><rect x="3.5" y="5" width="17" height="15" rx="3" /><path d="m8 2 4 3 4-3m-4 5 1.1 3.2h3.4l-2.7 2 1 3.2-2.8-2-2.8 2 1-3.2-2.7-2h3.4Z" /></>}
  </svg>;
}
