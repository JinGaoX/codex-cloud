'use client';

import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { flushSync } from 'react-dom';
import dynamic from 'next/dynamic';
import { useRouter, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/client-api';
// 播放器（artplayer + hls.js）按需加载：拆出独立 chunk，不占首屏 First Load JS
const PlayerShell = dynamic(() => import('@/components/player-shell').then((m) => m.PlayerShell), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full flex items-center justify-center">
      <Spinner size="lg" />
    </div>
  ),
});
import { EmptyState, LoadingState, Spinner } from '@/components/states';
import { SwitchSourceModal } from '@/components/switch-source';
import { SkipMarkPanel } from '@/components/skip-mark-panel';
import { skipMarkKey, validateSegment, type SkipSegment } from '@/lib/skip-marks';
import type { PlayerSkipApi } from '@/components/player-shell';
import { useToast } from '@/components/toast';
import { enqueueDownload } from '@/components/download-manager';
import { Icon } from '@/components/icon';
import { PlaybackInfoPanel } from '@/components/playback-info-panel';
import { WatchFavoriteButton } from '@/components/watch-favorite-button';
import { useAuth } from '@/components/auth';
import { resolveSource, useAppStore } from '@/lib/store';
import { qualityKey } from '@/lib/quality';
import type { PlaybackInfo } from '@/lib/playback-info';
import type { PlaybackResolution } from '@/lib/playback-telemetry';
import {
  clearProgress,
  progressKeyOf,
  saveProgress,
  upsertHistory,
  db,
} from '@/lib/db';
import { cn } from '@/lib/utils';
import { IS_STANDALONE } from '@/lib/runtime-mode';
import { DIRECT_MEDIA_SOURCE } from '@/lib/standalone-media';
import { getSleepTimer } from '@/lib/sleep-timer';
import { SleepTimerControl, useSleepTimer } from '@/components/sleep-timer-control';
import { describeEpisode, hasEpisodeTitles, type EpisodeLabel } from '@/lib/episode-labels';
import { watchFavoriteItem } from '@/lib/watch-favorite';

/**
 * 播放页（唯一入口，替代旧版 watch.html → player.html 跳转链）。
 * 状态全部由 URL 驱动：/watch?source=xx&id=..&index=..&title=..
 * 集数列表由服务端详情接口获取；进度与历史走 IndexedDB。
 */
export default function WatchPage() {
  return (
    <Suspense>
      <WatchContent />
    </Suspense>
  );
}

function WatchContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const store = useAppStore();
  const { verified } = useAuth();
  const { toast } = useToast();

  const sourceKey = searchParams.get('source') || '';
  const vodId = searchParams.get('id') || '';
  const directUrl = searchParams.get('url') || '';
  const titleParam = searchParams.get('title') || '';
  const indexParam = parseInt(searchParams.get('index') || '0', 10) || 0;

  const [measuredResolution, setMeasuredResolution] = useState<(PlaybackResolution & { url: string; identity: string }) | null>(null);
  const [measuredPlaybackInfo, setMeasuredPlaybackInfo] = useState<{ url: string; identity: string; info: PlaybackInfo } | null>(null);
  const [expandedPlaybackIdentity, setExpandedPlaybackIdentity] = useState<string | null>(null);
  const [reversed, setReversed] = useState(false);
  const [switchOpen, setSwitchOpen] = useState(false);
  const [skipPanelOpen, setSkipPanelOpen] = useState(false);
  // 播放器对外暴露的精确时间读取接口（「记录当前」用），随播放器卸载置空
  const playerApiRef = useRef<PlayerSkipApi | null>(null);
  const autoNextTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const sleepTimer = useSleepTimer();
  const checkTimerCanPlay = useCallback(() => {
    if (getSleepTimer().canPlay()) return true;
    if (autoNextTimer.current) {
      clearTimeout(autoNextTimer.current);
      autoNextTimer.current = null;
    }
    playerApiRef.current?.pause();
    return false;
  }, []);
  useEffect(() => {
    if (sleepTimer.mode === 'stopped') checkTimerCanPlay();
  }, [sleepTimer, checkTimerCanPlay]);
  // 播放框：小屏「跳过标记」抽屉要按它的底边算剩余高度，避免压住画面
  const playerFrameRef = useRef<HTMLDivElement | null>(null);
  const [sheetMaxHeight, setSheetMaxHeight] = useState<number | undefined>(undefined);

  useEffect(() => {
    if (!skipPanelOpen) return;
    const measure = () => {
      // 桌面端抽屉贴右侧、整屏高，不受播放器位置影响
      if (window.matchMedia('(min-width: 1024px)').matches) {
        setSheetMaxHeight(undefined);
        return;
      }
      const box = playerFrameRef.current?.getBoundingClientRect();
      if (!box) {
        setSheetMaxHeight(undefined);
        return;
      }
      const viewport = window.visualViewport?.height ?? window.innerHeight;
      const room = viewport - box.bottom - 12;
      // 不超过视口 60%；矮窗下最多压到 160px，再小就没法用了
      setSheetMaxHeight(Math.round(Math.max(160, Math.min(viewport * 0.6, room))));
    };
    measure();
    // 只在打开与尺寸变化时测：跟着滚动实时改高度会让抽屉边滚边长，很晃
    window.addEventListener('resize', measure);
    window.visualViewport?.addEventListener('resize', measure);
    return () => {
      window.removeEventListener('resize', measure);
      window.visualViewport?.removeEventListener('resize', measure);
    };
  }, [skipPanelOpen]);

  const isDirectMedia = sourceKey === DIRECT_MEDIA_SOURCE && Boolean(directUrl);
  const source = isDirectMedia ? { key: DIRECT_MEDIA_SOURCE, name: '视频链接', url: '' } : resolveSource(store, sourceKey, {
    url: searchParams.get('sourceUrl') || undefined,
    detail: searchParams.get('detail') || undefined,
  });

  // 详情查询：无 id（纯直连链接分享）时跳过
  const detailQuery = useQuery({
    queryKey: ['detail', sourceKey, vodId, source?.url],
    queryFn: ({ signal }) => api.detail(vodId, source!, signal, titleParam),
    enabled: Boolean(!isDirectMedia && source && vodId && verified),
    staleTime: 5 * 60_000,
  });

  const episodes = useMemo(() => detailQuery.data?.episodes ?? [], [detailQuery.data]);
  const videoTitle = titleParam || detailQuery.data?.videoInfo?.title || '未知视频';
  const favoriteItem = watchFavoriteItem(source, vodId, videoTitle, detailQuery.data?.videoInfo);

  // Commit the selected media in the tap stack; the URL can acknowledge it later.
  // A late URL for an earlier tap must not replace a newer selection.
  const selectionScope = JSON.stringify([sourceKey, vodId, source?.url ?? '']);
  const [pendingEpisode, setPendingEpisode] = useState<{ scope: string; index: number; url: string; params: string } | null>(null);
  const selectedEpisode = pendingEpisode?.scope === selectionScope ? pendingEpisode : null;
  useEffect(() => {
    if (pendingEpisode && (pendingEpisode.scope !== selectionScope || pendingEpisode.params === searchParams.toString())) {
      setPendingEpisode(null);
    }
  }, [pendingEpisode, selectionScope, searchParams]);
  useEffect(() => {
    const onPopState = () => setPendingEpisode(null);
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
  }, []);

  // 当前播放地址：优先取剧集列表中的当前集，其次直连 URL 参数
  const currentUrl = useMemo(() => {
    if (selectedEpisode) return selectedEpisode.url;
    if (episodes.length > 0) {
      const idx = Math.min(Math.max(indexParam, 0), episodes.length - 1);
      return episodes[idx] || directUrl;
    }
    return directUrl;
  }, [selectedEpisode, episodes, indexParam, directUrl]);

  const currentIndex = useMemo(() => {
    if (selectedEpisode) return selectedEpisode.index;
    if (episodes.length > 0) return Math.min(Math.max(indexParam, 0), episodes.length - 1);
    return indexParam;
  }, [selectedEpisode, episodes, indexParam]);

  const episodeIdentity = `${sourceKey}:${vodId}:${currentIndex}`;
  const playbackIdentity = `${episodeIdentity}:${currentUrl}`;
  const currentMediaRef = useRef({ url: currentUrl, identity: episodeIdentity });
  currentMediaRef.current = { url: currentUrl, identity: episodeIdentity };
  const currentResolution = measuredResolution?.url === currentUrl && measuredResolution.identity === episodeIdentity
    ? measuredResolution : null;
  const currentPlaybackInfo = measuredPlaybackInfo?.url === currentUrl && measuredPlaybackInfo.identity === episodeIdentity
    ? measuredPlaybackInfo.info : null;
  const playbackInfoOpen = expandedPlaybackIdentity === playbackIdentity;
  const handleResolution = useCallback((resolution: PlaybackResolution | null, mediaUrl: string, identity: string) => {
    if (mediaUrl !== currentMediaRef.current.url || identity !== currentMediaRef.current.identity) return;
    setMeasuredResolution((previous) => {
      if (!resolution) return null;
      if (previous?.url === mediaUrl && previous.identity === identity
        && previous.width === resolution.width && previous.height === resolution.height) return previous;
      return { ...resolution, url: mediaUrl, identity };
    });
  }, []);
  const handlePlaybackInfo = useCallback((info: PlaybackInfo | null, mediaUrl: string, identity: string) => {
    if (mediaUrl !== currentMediaRef.current.url || identity !== currentMediaRef.current.identity) return;
    setMeasuredPlaybackInfo(info ? { url: mediaUrl, identity, info } : null);
  }, []);
  useEffect(() => setExpandedPlaybackIdentity(null), [playbackIdentity]);
  useEffect(() => {
    if (!currentResolution || !sourceKey || !vodId) return;
    useAppStore.getState().setQuality({
      [qualityKey(sourceKey, vodId)]: {
        width: currentResolution.width, height: currentResolution.height, from: 'play', timestamp: Date.now(),
      },
    });
  }, [currentResolution, sourceKey, vodId]);

  const currentEpisode = describeEpisode(currentIndex, detailQuery.data?.episodeTitles?.[currentIndex]);
  const titledEpisodes = hasEpisodeTitles(detailQuery.data?.episodeTitles, episodes.length);
  const playerTitle = episodes.length > 0 ? `${videoTitle} · ${currentEpisode.label}` : videoTitle;

  // 跳过片段按剧名记忆：换集不变，换源到同名资源也能命中。
  // 标题缺失（直连链接）时退回 source:vodId，至少保证本源本片可用。
  const skipMarkFallback = `${sourceKey}:${vodId || currentUrl}`;
  const markKey = useMemo(
    () => skipMarkKey(videoTitle, skipMarkFallback),
    [videoTitle, skipMarkFallback]
  );
  const skipMark = store.skipMarks[markKey];
  const markedCount = skipMark?.segments.length ?? 0;

  // 中段两步态的起点：页面层持有，面板按钮与 Shift+S/E 共用同一份状态
  const [pendingStart, setPendingStart] = useState<number | null>(null);
  // 换集清空中段两步态：起点属于上一集，不能和新集的位置拼成区间
  useEffect(() => setPendingStart(null), [sourceKey, vodId, currentIndex]);

  const goEpisode = useCallback(
    (index: number) => {
      if (autoNextTimer.current) {
        clearTimeout(autoNextTimer.current);
        autoNextTimer.current = null;
      }
      if (!Number.isInteger(index) || index < 0 || index >= episodes.length || !checkTimerCanPlay()) return;
      const targetUrl = episodes[index];
      if (!targetUrl) return;
      if (index === currentIndex && targetUrl === currentUrl) {
        playerApiRef.current?.play();
        return;
      }
      const sp = new URLSearchParams(searchParams.toString());
      sp.set('index', String(index));
      sp.set('url', targetUrl);
      sp.delete('position');
      const params = sp.toString();
      flushSync(() => setPendingEpisode({ scope: selectionScope, index, url: targetUrl, params }));
      // No await, route navigation or storage access before this play request.
      playerApiRef.current?.play();
      router.replace(`/watch?${params}`, { scroll: false });
    },
    [router, searchParams, episodes, currentIndex, currentUrl, selectionScope, checkTimerCanPlay]
  );

  // 进度恢复优先级：URL position 参数 > IndexedDB 记录
  const getRestorePosition = useCallback(async () => {
    const urlPos = selectedEpisode ? 0 : parseInt(searchParams.get('position') || '0', 10) || 0;
    if (urlPos > 0) return urlPos;
    if (!vodId) return 0;
    const entry = await db.progress.get(progressKeyOf(sourceKey, vodId, currentIndex));
    return entry?.position ?? 0;
  }, [selectedEpisode, searchParams, sourceKey, vodId, currentIndex]);

  // PlayerShell only emits actual advanced playback. Commit identity, artwork and
  // episode progress atomically; merely entering a page cannot reorder history.
  const handleProgress = useCallback(
    (position: number, duration: number) => {
      if (!verified || !sourceKey || !vodId || !Number.isFinite(position) || position < 1
        || !Number.isFinite(duration) || duration <= 0) return;
      void db.transaction('rw', db.history, db.progress, async () => {
        const id = `${sourceKey}_${vodId}`;
        const existing = await db.history.get(id);
        await upsertHistory({
          sourceKey, sourceUrl: source?.url, vodId,
          title: titleParam || detailQuery.data?.videoInfo?.title || existing?.title || videoTitle,
          pic: detailQuery.data?.videoInfo?.cover || existing?.pic,
          episodeIndex: currentIndex, totalEpisodes: episodes.length || existing?.totalEpisodes || 0,
          playbackPosition: position, duration, timestamp: Date.now(),
        });
        // upsertHistory preserves old small positions for legacy callers. Here
        // this snapshot is real playback and must belong to the current episode.
        await db.history.update(id, { playbackPosition: position, duration });
        await saveProgress(sourceKey, vodId, currentIndex, position, duration);
      }).catch(() => {});
    },
    [verified, sourceKey, source?.url, vodId, currentIndex, titleParam, videoTitle, detailQuery.data, episodes.length]
  );

  // 自动连播的 800ms 延迟切集要在卸载时取消，避免离开页面后跳转
  useEffect(() => () => {
    if (autoNextTimer.current) clearTimeout(autoNextTimer.current);
  }, []);

  const handleEnded = useCallback(() => {
    if (autoNextTimer.current) clearTimeout(autoNextTimer.current);
    autoNextTimer.current = null;
    if (vodId) clearProgress(sourceKey, vodId, currentIndex).catch(() => {});
    getSleepTimer().finishEpisode();
    if (!checkTimerCanPlay()) return;
    if (store.autoplayNext && currentIndex < episodes.length - 1) {
      autoNextTimer.current = setTimeout(() => {
        autoNextTimer.current = null;
        // The user may choose “after this episode” during the hand-off delay.
        getSleepTimer().finishEpisode();
        if (checkTimerCanPlay()) goEpisode(currentIndex + 1);
      }, 800);
    }
  }, [store.autoplayNext, currentIndex, episodes.length, goEpisode, sourceKey, vodId, checkTimerCanPlay]);

  // 快捷键（Shift+I/O/S/E）记录片段：校验后写入
  const handleRecordSegment = useCallback(
    (segment: SkipSegment) => {
      const duration = playerApiRef.current?.getDuration() ?? 0;
      const existing = useAppStore.getState().skipMarks[markKey]?.segments ?? [];
      const error = validateSegment(segment, duration, existing);
      if (error) {
        toast(error, 'error');
        return;
      }
      useAppStore.getState().setSkipMark(markKey, [...existing, segment]);
      const label =
        segment.type === 'opening' ? '片头结束' : segment.type === 'ending' ? '片尾开始' : '中段片段';
      // 中段命中时的表现取决于全局「自动跳过片段」，记完就说清楚，避免"标了却没反应"
      const hint =
        segment.type === 'middle'
          ? useAppStore.getState().autoSkipSegments
            ? '，命中时将自动跳过'
            : '，命中时显示跳过按钮'
          : '';
      toast(`已记录${label}${hint}`, 'success');
    },
    [markKey, toast]
  );

  // Alt+←/→ 集数切换快捷键
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!e.altKey) return;
      if (e.key === 'ArrowLeft' && currentIndex > 0) {
        e.preventDefault();
        goEpisode(currentIndex - 1);
      } else if (e.key === 'ArrowRight' && currentIndex < episodes.length - 1) {
        e.preventDefault();
        goEpisode(currentIndex + 1);
      }
    };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [currentIndex, episodes.length, goEpisode]);

  const orderedEpisodes = reversed ? [...episodes].map((_, i) => episodes.length - 1 - i) : episodes.map((_, i) => i);

  if (!verified) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-faint text-sm">等待访问验证...</p>
      </div>
    );
  }

  if (!source) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <h1 className="text-content font-medium mb-2">点播源不存在</h1>
          <p className="text-sm text-muted mb-4">
            该视频来自点播源「{sourceKey}」，但它可能已被删除。请在设置中重新添加后重试。
          </p>
          <Link href="/" className="btn-primary">返回首页</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-40 bg-surface/90 backdrop-blur border-b border-line">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center gap-3">
          <BackButton />
          <HomeButton />
          <div className="min-w-0">
            <h1 className="text-sm font-medium text-content truncate">{videoTitle}</h1>
            <p className="text-xs text-faint">
              {source.name}
              {episodes.length > 0 && ` · 第 ${currentIndex + 1}/${episodes.length} 集`}
            </p>
          </div>
          <div className="ml-auto flex items-center gap-2">
            {!IS_STANDALONE && <button
              className="btn-ghost btn-sm"
              onClick={() => {
                if (!currentUrl) return;
                enqueueDownload({
                  url: currentUrl,
                  // 多集才带集数后缀；单集影片（含电影）文件名就是纯标题
                  title: `${videoTitle}${episodes.length > 1 ? ` 第${currentIndex + 1}集` : ''}`,
                  format: 'MP4',
                });
                // 「已加入下载队列」由 DownloadManager 在真正入队后提示：
                // 这里先提示的话，用户随后取消保存位置会出现「已加入→已取消」的矛盾
              }}
            >
              下载本集
            </button>}
            {!isDirectMedia && <button className="btn-ghost btn-sm" onClick={() => setSwitchOpen(true)}>
              切换资源
            </button>}
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-4">
        <div className={cn('grid grid-cols-1 gap-4', !isDirectMedia && 'lg:grid-cols-[1fr_300px]')}>
          <div>
            <div ref={playerFrameRef} className="aspect-video bg-black rounded-lg overflow-hidden">
              {currentUrl ? (
                <PlayerShell
                  url={currentUrl}
                  title={playerTitle}
                  adFilter={store.adFilter}
                  autoplayNext={!isDirectMedia && store.autoplayNext && sleepTimer.mode !== 'episode' && sleepTimer.mode !== 'stopped'}
                  canPlay={checkTimerCanPlay}
                  timerStopped={sleepTimer.mode === 'stopped'}
                  onResumeFromTimer={() => getSleepTimer().cancel()}
                  skipMark={skipMark}
                  autoSkipSegments={store.autoSkipSegments}
                  pendingStart={pendingStart}
                  onPendingStart={setPendingStart}
                  onPlayerApi={(api) => { playerApiRef.current = api; }}
                  onRecordSegment={handleRecordSegment}
                  episodeKey={episodeIdentity}
                  nextUrl={currentIndex + 1 < episodes.length ? episodes[currentIndex + 1] : undefined}
                  nextEpisodeKey={currentIndex + 1 < episodes.length ? `${sourceKey}:${vodId}:${currentIndex + 1}` : undefined}
                  getRestorePosition={getRestorePosition}
                  onTimeUpdate={handleProgress}
                  onPause={handleProgress}
                  onEnded={handleEnded}
                  onRequestSwitchSource={isDirectMedia ? undefined : () => setSwitchOpen(true)}
                  hasPrevEpisode={currentIndex > 0}
                  hasNextEpisode={episodes.length > 0 && currentIndex < episodes.length - 1}
                  onPrevEpisode={() => goEpisode(currentIndex - 1)}
                  onNextEpisode={() => goEpisode(currentIndex + 1)}
                  onResolution={handleResolution}
                  onPlaybackInfo={handlePlaybackInfo}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  {detailQuery.isLoading ? (
                    <Spinner size="lg" />
                  ) : (
                    <p className="text-faint text-sm">
                      {detailQuery.isError ? '视频加载失败，请尝试其他资源' : '无可用播放地址'}
                    </p>
                  )}
                </div>
              )}
            </div>

            {episodes.length > 0 && <p aria-label="当前剧集" className="mt-3 text-sm leading-6 text-content whitespace-normal break-words [overflow-wrap:anywhere]">正在播放 · {currentEpisode.label}</p>}
            <div className="flex flex-wrap items-center justify-between gap-2 mt-3">
              <button
                type="button"
                aria-expanded={playbackInfoOpen}
                aria-controls="playback-info-panel"
                className="inline-flex min-h-11 items-center gap-1.5 rounded-lg border border-line bg-chip px-3 py-2 text-xs text-muted tabular-nums transition-colors hover:bg-hover hover:text-content focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/40"
                title="点击查看当前画质信息"
                onClick={() => setExpandedPlaybackIdentity((identity) => identity === playbackIdentity ? null : playbackIdentity)}
              >
                <span role="status" aria-live="polite" className="inline-flex items-center gap-1.5">
                  当前分辨率
                  <span className="font-medium text-content">
                    {currentResolution ? `${currentResolution.width}×${currentResolution.height}` : '暂未读取'}
                  </span>
                </span>
                <Icon name="chevronDown" className={cn('h-3 w-3 shrink-0 transition-transform', playbackInfoOpen && 'rotate-180')} />
              </button>
              <div className="flex flex-wrap items-center gap-2">
                {favoriteItem && <WatchFavoriteButton key={JSON.stringify([sourceKey, vodId])} item={favoriteItem} />}
                <SleepTimerControl state={sleepTimer} />
              </div>
            </div>
            {playbackInfoOpen && <PlaybackInfoPanel resolution={currentResolution} info={currentPlaybackInfo} />}

            {/* 操作栏 */}
            {!isDirectMedia && <div className="flex flex-wrap items-center gap-2 mt-3">
              <button
                className="btn-ghost btn-sm"
                disabled={currentIndex <= 0}
                onClick={() => goEpisode(currentIndex - 1)}
              >
                上一集
              </button>
              <button
                className="btn-ghost btn-sm"
                disabled={episodes.length === 0 || currentIndex >= episodes.length - 1}
                onClick={() => goEpisode(currentIndex + 1)}
              >
                下一集
              </button>
              <button
                className={cn('btn-ghost btn-sm', skipPanelOpen && 'bg-chip text-content')}
                aria-expanded={skipPanelOpen}
                aria-haspopup="dialog"
                onClick={() => setSkipPanelOpen((v) => !v)}
                title={
                  markedCount > 0
                    ? `本剧已标记 ${markedCount} 段${skipMark?.enabled === false ? '（本剧跳过已关闭）' : ''}`
                    : '标记片头 / 中段 / 片尾，供本剧各集自动跳过'
                }
              >
                跳过标记{markedCount > 0 ? ` (${markedCount})` : ''}
                {markedCount > 0 && skipMark?.enabled === false && (
                  <span className="ml-1 inline-block size-1.5 rounded-full bg-faint" aria-label="本剧跳过已关闭" />
                )}
              </button>
              <label className="flex items-center gap-1.5 text-xs text-muted ml-auto cursor-pointer">
                <input
                  type="checkbox"
                  className="h-3.5 w-3.5 accent-[#2563eb]"
                  checked={store.autoplayNext}
                  onChange={(e) => store.updateSettings({ autoplayNext: e.target.checked })}
                />
                自动连播
              </label>
            </div>}

            {!isDirectMedia && <SkipMarkPanel
              open={skipPanelOpen}
              onClose={() => setSkipPanelOpen(false)}
              markKey={markKey}
              pendingStart={pendingStart}
              onPendingStart={setPendingStart}
              mobileMaxHeight={sheetMaxHeight}
              getPlayerClock={() => {
                const api = playerApiRef.current;
                if (!api) return null;
                return {
                  currentTime: api.getCurrentTime(),
                  duration: api.getDuration(),
                  seek: (s) => api.seek(s),
                  pause: () => api.pause(),
                  isPaused: () => api.isPaused(),
                };
              }}
            />}
          </div>

          {/* 剧集侧栏 */}
          {!isDirectMedia && <aside className="bg-surface-raised rounded-lg p-3 h-fit">
            <div className="flex items-center justify-between gap-2 mb-2.5">
              <h2 className="text-sm font-semibold text-content">
                剧集列表{episodes.length > 0 && `（${episodes.length}）`}
              </h2>
              {/* 排列开关紧贴它所作用的列表：放在这里才看得出它管的是这一栏的顺序 */}
              {episodes.length > 1 && (
                <button
                  className="btn-ghost btn-sm shrink-0"
                  onClick={() => setReversed((v) => !v)}
                  aria-label={reversed ? '切换为正序排列' : '切换为倒序排列'}
                  title="调整剧集列表的排列顺序"
                >
                  <Icon
                    name="arrowDown"
                    className={cn('w-3.5 h-3.5 transition-transform', reversed && 'rotate-180')}
                  />
                  {reversed ? '正序排列' : '倒序排列'}
                </button>
              )}
            </div>
            {episodes.length === 0 ? (
              detailQuery.isLoading ? (
                <LoadingState />
              ) : (
                <EmptyState variant="plain" title={detailQuery.isError ? '获取剧集失败' : '暂无剧集信息'} />
              )
            ) : (
              <div className={cn('grid gap-1.5 max-h-[65vh] overflow-y-auto scrollbar-thin pr-1', titledEpisodes ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-1' : 'grid-cols-5 lg:grid-cols-4')}>
                {orderedEpisodes.map((realIndex) => (
                  <EpisodeButton
                    key={realIndex}
                    episode={describeEpisode(realIndex, detailQuery.data?.episodeTitles?.[realIndex])}
                    titled={titledEpisodes}
                    active={realIndex === currentIndex}
                    onClick={() => goEpisode(realIndex)}
                  />
                ))}
              </div>
            )}
            <p className="hidden md:block text-[10px] text-faint mt-3 leading-relaxed">
              快捷键：空格 播放/暂停 · ←/→ 快退/快进 5s · ↑/↓ 音量 · F 全屏 · Alt+←/→ 切换集数
            </p>
          </aside>}
        </div>
      </main>

      {switchOpen && (
        <SwitchSourceModal
          currentTitle={videoTitle}
          currentSourceKey={sourceKey}
          currentVodId={vodId}
          currentIndex={currentIndex}
          getCurrentPosition={() => playerApiRef.current?.getCurrentTime() ?? 0}
          onClose={() => setSwitchOpen(false)}
        />
      )}
    </div>
  );
}

/** 集数按钮：激活时自动滚动进可视区（长剧列表） */
function EpisodeButton({ episode, titled, active, onClick }: { episode: EpisodeLabel; titled: boolean; active: boolean; onClick: () => void }) {
  const ref = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (active) ref.current?.scrollIntoView({ block: 'nearest' });
  }, [active]);

  return (
    <button
      ref={ref}
      className={cn('btn min-h-11 min-w-0', titled ? '!justify-start !px-3 py-3 text-left' : 'btn-sm !px-1', active ? 'episode-active' : 'btn-ghost')}
      aria-label={episode.label}
      aria-current={active ? 'true' : undefined}
      onClick={onClick}
    >
      {episode.title ? <><span aria-hidden="true" className="shrink-0 text-xs tabular-nums opacity-70">{episode.number}</span><span className="min-w-0 whitespace-normal break-words [overflow-wrap:anywhere] text-sm leading-6">{episode.title}</span></> : episode.number}
    </button>
  );
}

function BackButton() {
  const router = useRouter();
  return (
    <button
      className="p-2 -ml-2 rounded-md text-muted hover:text-content hover:bg-hover transition-colors"
      onClick={() => {
        if (window.history.length > 1) router.back();
        else router.push('/');
      }}
      aria-label="返回"
    >
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
      </svg>
    </button>
  );
}

/** 首页按钮：直达首页，避免从外链进入时逐级 back */
function HomeButton() {
  return (
    <Link
      href="/"
      className="p-2 rounded-md text-muted hover:text-content hover:bg-hover transition-colors"
      aria-label="回首页"
      title="回首页"
    >
      <Icon name="home" className="w-5 h-5" />
    </Link>
  );
}
