'use client';

import { Suspense, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { discoveryHref, readLibraryView } from '@/components/library-browser-state';

/** Keep previously shared/bookmarked URLs, without maintaining a second discovery screen. */
function LibraryRedirect() {
  const router = useRouter();
  const params = useSearchParams();
  useEffect(() => { router.replace(discoveryHref(readLibraryView(params)), { scroll: false }); }, [params, router]);
  return <main id="app-main" className="p-6"><h1 className="text-xl">正在打开首页发现影视…</h1></main>;
}

export default function LibraryPage() {
  return <Suspense><LibraryRedirect /></Suspense>;
}
