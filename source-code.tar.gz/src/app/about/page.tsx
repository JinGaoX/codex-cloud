'use client';

import { Header } from '@/components/header';
import { SiteFooter } from '@/components/site-footer';
import { SourceArchiveLink } from '@/components/source-archive-link';
import { APP_BRAND } from '@/lib/app-brand';
import { IS_STANDALONE } from '@/lib/runtime-mode';
import { useAuth } from '@/components/auth';

export default function AboutPage() {
  const { version } = useAuth();
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main id="app-main" tabIndex={-1} className="flex-1 max-w-2xl w-full mx-auto px-5 py-8 sm:py-12 space-y-8">
        <section className="flex items-center gap-4">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={APP_BRAND.icons.large} alt="" className="w-20 h-20 rounded-[22px]" />
          <div>
            <h1 className="text-2xl font-semibold tracking-wide text-content">关于 {APP_BRAND.shortName}</h1>
            {version && <p className="text-xs text-faint mt-2">版本 {version}</p>}
          </div>
        </section>
        <section className="rounded-2xl border border-line bg-surface-raised p-5">
          <h2 className="text-base font-semibold text-content mb-3">应用功能</h2>
          <p className="text-sm text-muted leading-7">{APP_BRAND.shortName} 基于你添加的片源提供搜索、选集和播放，并保存本机收藏与进度。</p>
          <p className="text-sm text-muted leading-7 mt-2">手机、平板和电脑共用相同的找片与观看功能，根据屏幕调整布局和操作。未登录时使用本机资料，登录后使用该账号的独立资料。</p>
          <p className="text-sm text-muted leading-7 mt-2">播放页可设置定时停止，或者在本集结束后停止。倒计时以实际经过的时间计算；手机系统可能限制后台执行，回到应用时会重新检查截止时间。</p>
        </section>
        <section>
          <h2 className="text-base font-semibold text-content mb-3">你的记录与账号</h2>
          <p className="text-sm text-muted leading-7">不登录时，片源、收藏和观看记录保存在当前设备，不会自动上传。选择登录后，该账号的点播片源、收藏、历史和逐集进度会同步至所配置的账号服务；游客资料须主动确认才合并。可在设置中导出备份，清除网站数据或卸载可能移除本机资料。</p>
          <p className="text-sm text-muted leading-7 mt-2">{IS_STANDALONE
            ? '搜索和视频由设备直接访问你选择的来源。来源会收到正常网络请求；独立版不提供视频下载或整集后台缓存。'
            : '搜索由你部署的服务处理。来源会收到正常网络请求；启用缓存或下载时，视频会保存在你当前的设备上。'}</p>
        </section>
        <details className="rounded-2xl border border-line px-5 py-1">
          <summary className="min-h-12 cursor-pointer text-sm font-medium text-content">榜单与影片信息</summary>
          <p className="text-sm text-muted leading-7 pb-4">首页榜单通过 <a className="text-accent" href="https://github.com/vikiboss/60s" target="_blank" rel="noopener noreferrer">60s API</a> 读取豆瓣周榜和百度热播剧榜。评分和排名按来源显示；影视库的地区、年代、类型和最低评分由来源联合查询，并非只过滤眼前这一页。推荐条目用于搜索你的片源，实际收录、播放及清晰度以片源为准。</p>
          <p className="text-sm text-muted leading-7 pb-4">影视库通过<a className="text-accent" href="https://movie.douban.cmliussss.net/" target="_blank" rel="noopener noreferrer">公开元数据镜像</a>动态读取影片，支持来源提供的类型、地区、年代、评分条件和排序；每次只展示一页，不把整个目录预先下载。综艺暂使用口碑周榜，避免来源标签混类造成误导。</p>
          <p className="text-sm text-muted leading-7 pb-4">Top250及分类高分榜保留来源的真实排名，已有周榜不为凑数量添加条目。标注的获取时间是本机成功请求时间，不代表豆瓣刚刚更新；来源更新频率和服务可用性由提供方决定。获取失败会提示重试或展示上次缓存，不再回退固定36部片单。</p>
          <p className="text-sm text-muted leading-7 pb-4">目录收录不等于你的片源提供播放。点击作品仍搜索你配置的API，不会为了浏览目录批量检查视频，也不会把第三方影片标签当作实测画质。海报与影片信息权利归各权利人所有。</p>
        </details>
        <section className="rounded-2xl border border-line bg-surface-raised p-5">
          <h2 className="text-base font-semibold text-content mb-3">看懂画质信息</h2>
          <p className="text-sm text-muted leading-7">选片时的尺寸来自预览抽样或曾经播放的记录；播放页显示当前解码宽高，可能包含视频内自带的黑边。点击分辨率可展开编码、参考码率、帧率和丢帧，设备或片源不提供的信息会显示“暂未读取”。</p>
          <p className="text-sm text-muted leading-7 mt-2">参考码率来自当前播放附近的分片，不是网速或全片平均值。同样的分辨率也会因源片、编码和压缩产生不同的清晰度，尺寸和码率都不能单独作为画质评分。</p>
        </section>
        <section>
          <h2 className="text-base font-semibold text-content mb-3">开源与版权</h2>
          <p className="text-sm text-muted leading-7">本项目基于 <a className="text-accent" href="https://github.com/LibreSpark/LibreTV" target="_blank" rel="noopener noreferrer">LibreTV</a> 修改，保留原作者版权声明，遵循 AGPL-3.0-or-later。<SourceArchiveLink className="text-accent">取得本修改版对应源码</SourceArchiveLink>。当前图标由用户提供，相关名称与图像权利归各权利人所有。</p>
          <p className="text-sm text-muted leading-7 mt-2">请使用合法可用的影视来源。本应用仅提供播放器与搜索工具。</p>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
