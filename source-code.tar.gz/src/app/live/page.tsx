'use client';

import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useQueries, type UseQueryResult } from '@tanstack/react-query';
import { api } from '@/lib/client-api';
import { requestAppPanel } from '@/lib/app-navigation';
import { copyToClipboard } from '@/lib/clipboard';
import { Header } from '@/components/header';
// 播放器（artplayer + hls.js）按需加载：拆出独立 chunk，不占首屏 First Load JS
import dynamic from 'next/dynamic';
const LivePlayer = dynamic(() => import('@/components/live-player').then((m) => m.LivePlayer), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full flex items-center justify-center bg-black">
      <Spinner size="lg" />
    </div>
  ),
});
import { LiveChannelList, type LiveChannelItem } from '@/components/live-channel-list';
import { LiveEpgPanel } from '@/components/live-epg-panel';
import { Spinner } from '@/components/states';
import { useAuth } from '@/components/auth';
import { allLiveSources, useAppStore } from '@/lib/store';
import { cn } from '@/lib/utils';
import { SmartImage } from '@/components/smart-image';
import { IS_STANDALONE, SUPPORTS_LIVE_TV } from '@/lib/runtime-mode';
import { standaloneMediaUrl } from '@/lib/standalone-media';
import type { LivePlaylistResponse } from '@/lib/types';
import { keepLiveChannelOrder } from '@/lib/live-channel-filter';
import Link from 'next/link';

/**
 * 直播页：左侧播放器 + 频道信息 + 节目单；右侧频道侧栏。
 * 状态由 URL 驱动（?url=&name=&group=&tvgId=&epg=），支持频道深链与刷新保持。
 * 换台路径：侧栏点击、全局 ↑↓ 键盘、播放器控制条上一台/下一台（全屏可用）。
 * 移动端从播放器下方打开频道抽屉，选中频道后自动收起。
 */
export default function LivePage() {
  if (!SUPPORTS_LIVE_TV) return (
    <div className="min-h-screen flex flex-col"><Header /><main id="app-main" tabIndex={-1} className="max-w-lg mx-auto px-4 py-12 text-center">
      <h1 className="text-lg font-semibold text-content mb-3">直播暂不可用</h1>
      <p className="text-sm text-muted mb-5">此版本支持点播搜索及可直接访问的视频链接。</p>
      <Link href="/" className="btn-primary">返回首页</Link>
    </main></div>
  );
  return (
    <Suspense>
      <LiveContent />
    </Suspense>
  );
}

function readChannelUrl(url: string): string {
  if (!IS_STANDALONE || !url) return url;
  try {
    return standaloneMediaUrl(url);
  } catch {
    return '';
  }
}

function LiveContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  // 精确订阅所需字段：任何其他 store 变化（如测活写回）不应触发本组件重渲染
  const liveSelectedUrls = useAppStore((s) => s.liveSelectedUrls);
  const liveEnvSources = useAppStore((s) => s.liveEnvSources);
  const liveSubscriptions = useAppStore((s) => s.liveSubscriptions);
  const liveFavorites = useAppStore((s) => s.liveFavorites);
  const lastPlayedUrl = useAppStore((s) => s.lastPlayedLiveUrl);
  const imageProxyMode = useAppStore((s) => s.imageProxyMode);
  const customImageProxy = useAppStore((s) => s.customImageProxy);
  const { verified } = useAuth();
  const [copied, setCopied] = useState(false);
  // 移动端频道抽屉开合
  const [listOpen, setListOpen] = useState(false);
  const listButtonRef = useRef<HTMLButtonElement>(null);
  const closeListButtonRef = useRef<HTMLButtonElement>(null);
  const [logoFailed, setLogoFailed] = useState(false);
  /** 侧栏上报的筛选排序结果（键盘换台沿此列表顺序）；ref 存储，不触发重渲染 */
  const filteredRef = useRef<LiveChannelItem[]>([]);
  /** 当前频道镜像：selectChannel 内读取最近一次播放的频道，用于记录"上一个频道" */
  const currentChannelRef = useRef<LiveChannelItem | undefined>(undefined);
  /** 上一个频道：退格键/按钮一键切回（电视遥控器 back 键习惯） */
  const lastChannelRef = useRef<LiveChannelItem | null>(null);

  // 仅聚合已启用的直播源（设置 → 直播源中的勾选状态）
  const sources = useMemo(() => {
    const selected = new Set(liveSelectedUrls);
    return allLiveSources({ liveEnvSources, liveSubscriptions }).filter((s) => selected.delete(s.url));
  }, [liveSelectedUrls, liveEnvSources, liveSubscriptions]);

  const combinePlaylists = useCallback((results: UseQueryResult<LivePlaylistResponse>[]) => {
    const list: LiveChannelItem[] = [];
    const retryFailed: Array<UseQueryResult<LivePlaylistResponse>['refetch']> = [];
    let loadingCount = 0;
    results.forEach((result, index) => {
      const source = sources[index];
      if (result.isFetching) loadingCount++;
      else if (result.isError) retryFailed.push(result.refetch);
      for (const c of result.data?.channels ?? []) {
        list.push({ ...c, epg: source.epg, sourceUrl: source.url });
      }
    });
    return { incoming: list, loadingCount, retryFailed };
  }, [sources]);

  // Fetch and cache each subscription independently so a slow source cannot block the list.
  const { incoming, loadingCount, retryFailed } = useQueries({
    queries: sources.map((source) => ({
      queryKey: ['livePlaylist', source.url],
      queryFn: ({ signal }) => api.livePlaylist(source.url, false, signal),
      enabled: verified,
      staleTime: 10 * 60_000,
      retry: false,
    })),
    combine: combinePlaylists,
  });
  const [playlist, setPlaylist] = useState(() => ({ incoming, channels: keepLiveChannelOrder([], incoming) }));
  let channels = playlist.channels;
  if (playlist.incoming !== incoming) {
    channels = keepLiveChannelOrder(channels, incoming);
    setPlaylist({ incoming, channels });
  }
  const groups = useMemo(() => [...new Set(channels.map((channel) => channel.group).filter((group): group is string => Boolean(group)))]
    .sort((a, b) => a.localeCompare(b, 'zh')), [channels]);

  // 当前频道：优先取列表内完整对象（含台标），否则由 URL 参数重建
  const requestedUrl = searchParams.get('url') || '';
  const currentUrl = readChannelUrl(requestedUrl);
  const resumeChannel = !requestedUrl && lastPlayedUrl
    ? channels.find((channel) => channel.url === lastPlayedUrl)
    : undefined;
  const currentChannel = useMemo(() => {
    const found = channels.find((c) => c.url === currentUrl);
    if (found) return found;
    if (!currentUrl) return undefined;
    return {
      id: searchParams.get('tvgId') || currentUrl,
      url: currentUrl,
      name: searchParams.get('name') || '未知频道',
      group: searchParams.get('group') || undefined,
      tvgId: searchParams.get('tvgId') || undefined,
      epg: searchParams.get('epg') || undefined,
    } as LiveChannelItem;
  }, [channels, currentUrl, searchParams]);

  const rememberPlayback = useCallback((url: string) => {
    const selectedUrl = new URLSearchParams(window.location.search).get('url') || '';
    if (readChannelUrl(selectedUrl) !== url) return;
    useAppStore.getState().rememberLivePlayback(url);
  }, []);

  useEffect(() => {
    setLogoFailed(false);
  }, [currentChannel?.url]);
  useEffect(() => {
    currentChannelRef.current = currentChannel;
  }, [currentChannel]);

  const selectChannel = useCallback(
    (c: LiveChannelItem) => {
      const cur = currentChannelRef.current;
      if (cur && cur.url !== c.url) lastChannelRef.current = cur;
      const sp = new URLSearchParams({ url: c.url, name: c.name });
      if (c.group) sp.set('group', c.group);
      if (c.tvgId) sp.set('tvgId', c.tvgId);
      if (IS_STANDALONE) {
        window.history.replaceState(null, '', `${window.location.pathname}?${sp.toString()}`);
      } else {
        if (c.epg) sp.set('epg', c.epg);
        router.replace(`/live?${sp.toString()}`, { scroll: false });
      }
      useAppStore.getState().addLiveRecent({
        url: c.url,
        name: c.name,
        logo: c.logo,
        group: c.group,
        tvgId: c.tvgId,
        epg: c.epg,
        sourceUrl: c.sourceUrl,
      });
    },
    [router]
  );

  const handleFilteredChange = useCallback((list: LiveChannelItem[]) => {
    filteredRef.current = list;
  }, []);

  /** 沿侧栏当前筛选排序的列表顺序切上一台/下一台（循环） */
  const switchChannelByOffset = useCallback(
    (delta: 1 | -1) => {
      const list = filteredRef.current;
      if (list.length === 0) return;
      const nowUrl = readChannelUrl(new URLSearchParams(window.location.search).get('url') || '');
      const idx = list.findIndex((c) => c.url === nowUrl);
      const next =
        idx === -1 ? (delta === 1 ? 0 : list.length - 1) : (idx + delta + list.length) % list.length;
      selectChannel(list[next]);
    },
    [selectChannel]
  );

  const goPrevChannel = useCallback(() => switchChannelByOffset(-1), [switchChannelByOffset]);
  const goNextChannel = useCallback(() => switchChannelByOffset(1), [switchChannelByOffset]);

  /** 切回上一个频道（Backspace / 信息条按钮） */
  const backToPrevChannel = useCallback(() => {
    const prev = lastChannelRef.current;
    if (!prev) return;
    lastChannelRef.current = null;
    selectChannel(prev);
  }, [selectChannel]);

  const closeChannelList = useCallback(() => {
    setListOpen(false);
    listButtonRef.current?.focus({ preventScroll: true });
  }, []);

  useEffect(() => {
    if (listOpen) closeListButtonRef.current?.focus({ preventScroll: true });
  }, [listOpen]);

  // 全局键盘：↑↓ 直接切台，Backspace 切回上一个频道。
  // 输入框/列表光标导航场景让位（列表聚焦时由列表内 ↑↓ 管理光标）
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && listOpen) {
        closeChannelList();
        return;
      }
      const isChannelKey = e.key === 'ArrowDown' || e.key === 'ArrowUp' || e.key === 'Backspace';
      if (!isChannelKey) return;
      if (e.repeat || e.altKey || e.ctrlKey || e.metaKey) return;
      const target = e.target as HTMLElement | null;
      if (target) {
        if (target.isContentEditable) return;
        const tag = target.tagName;
        if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
        if (target.closest('[data-channel-list]')) return;
      }
      e.preventDefault();
      if (e.key === 'Backspace') backToPrevChannel();
      else switchChannelByOffset(e.key === 'ArrowDown' ? 1 : -1);
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [switchChannelByOffset, backToPrevChannel, listOpen, closeChannelList]);

  const handleSelect = useCallback(
    (c: LiveChannelItem) => {
      selectChannel(c);
      // 移动端抽屉：选中即收起
      if (listOpen) closeChannelList();
    },
    [selectChannel, listOpen, closeChannelList]
  );

  if (!verified) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main id="app-main" tabIndex={-1} className="flex-1 flex items-center justify-center">
          <p className="text-faint text-sm">等待访问验证...</p>
        </main>
      </div>
    );
  }

  const logo = currentChannel?.logo;
  const isFavorite = currentChannel ? liveFavorites.includes(currentChannel.url) : false;
  const hasConfiguredSources = liveEnvSources.length + liveSubscriptions.length > 0;
  const failedCount = retryFailed.length;
  const isLoadingChannels = loadingCount > 0 && channels.length === 0;
  const allSourcesFailed = channels.length === 0 && sources.length > 0 && failedCount === sources.length;
  let channelStatus: string | undefined;
  if (requestedUrl && !currentUrl) {
    channelStatus = '此频道链接无法播放，请选择支持 HTTPS 的频道。';
  } else if (sources.length === 0) {
    channelStatus = hasConfiguredSources
      ? '所有直播源均已停用，请勾选需要启用的订阅。'
      : IS_STANDALONE
        ? '添加允许浏览器跨域访问的 HTTPS M3U 订阅，即可选台观看。'
        : '添加 M3U 直播订阅，即可选台观看。';
  } else if (isLoadingChannels) {
    channelStatus = '频道列表加载中…';
  } else if (allSourcesFailed) {
    channelStatus = IS_STANDALONE
      ? '直播订阅读取失败，请检查网络、HTTPS 和跨域访问设置。'
      : '直播订阅读取失败，请检查订阅地址后重试。';
  } else if (channels.length === 0) {
    channelStatus = '当前订阅没有可用频道，请检查直播源。';
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header showSearch />
      <main id="app-main" tabIndex={-1} className="flex-1 max-w-7xl w-full mx-auto px-4 py-4">
        <h1 className="sr-only">直播</h1>
        <div className="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_320px] gap-4">
          {/* 主栏：播放器 + 信息条 + 节目单 */}
          <div className="min-w-0">
            <div className="aspect-video bg-black rounded-lg overflow-hidden">
              {currentUrl ? (
                <LivePlayer
                  url={currentUrl}
                  title={currentChannel?.name || '直播'}
                  onPrevChannel={goPrevChannel}
                  onNextChannel={goNextChannel}
                  onPlaybackStarted={rememberPlayback}
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center gap-2 bg-black p-4 text-center">
                  <span className="live-dot" />
                  <p className="text-white/70 text-sm" aria-live="polite">
                    {channelStatus ?? <>
                      <span className="lg:hidden">打开频道列表选择频道</span>
                      <span className="hidden lg:inline">从右侧选择一个频道开始观看</span>
                    </>}
                  </p>
                  {resumeChannel && (
                    <button
                      type="button"
                      className="btn-primary max-w-full min-h-11"
                      onClick={() => selectChannel(resumeChannel)}
                    >
                      <span className="truncate">继续看 {resumeChannel.name}</span>
                    </button>
                  )}
                  {channels.length === 0 && !isLoadingChannels && (
                    <div className="flex flex-wrap justify-center gap-2 mt-1">
                      <button
                        type="button"
                        className="btn-primary min-h-11"
                        onClick={() => requestAppPanel('live-sources')}
                      >
                        管理直播源
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {channels.length > 0 && (
              <button
                ref={listButtonRef}
                type="button"
                className="btn-ghost mt-3 min-h-11 w-full lg:hidden"
                aria-expanded={listOpen}
                aria-controls="live-channel-list"
                onClick={() => setListOpen(true)}
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
                频道列表（{channels.length}）
              </button>
            )}

            {(failedCount > 0 || (loadingCount > 0 && channels.length > 0)) && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-x-3 rounded-lg border border-line bg-surface-raised px-3 py-1 text-xs text-muted">
                <p aria-live="polite" className="py-2">
                  {loadingCount > 0 && `正在加载 ${loadingCount} 个直播订阅`}
                  {loadingCount > 0 && failedCount > 0 && ' · '}
                  {failedCount > 0 && `${failedCount} 个订阅拉取失败`}
                </p>
                {failedCount > 0 && (
                  <button type="button" className="btn-ghost min-h-11" onClick={() => {
                    for (const refetch of retryFailed) void refetch({ cancelRefetch: false });
                  }}>
                    重试失败订阅
                  </button>
                )}
              </div>
            )}

            {/* 频道信息条 */}
            {currentChannel && (
              <div className="bg-surface-raised border border-line rounded-lg p-3 mt-3 flex items-center gap-3">
                <div className="w-10 h-10 shrink-0 rounded bg-chip flex items-center justify-center overflow-hidden">
                  {logo && !logoFailed ? (
                    <SmartImage
                      url={logo}
                      mode={imageProxyMode}
                      customProxy={customImageProxy}
                      alt=""
                      className="w-full h-full object-contain"
                      onExhausted={() => setLogoFailed(true)}
                    />
                  ) : (
                    <span className="text-xs text-faint">{currentChannel.name.slice(0, 1)}</span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="live-dot shrink-0" />
                    <h2 className="text-sm font-semibold text-content truncate">{currentChannel.name}</h2>
                    {currentChannel.group && (
                      <span className="tag block bg-chip text-faint shrink-0 max-w-[45%] truncate">{currentChannel.group}</span>
                    )}
                  </div>
                  <p className="text-xs text-faint truncate mt-0.5">{currentChannel.url}</p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    className={cn(
                      'rounded-md p-2 transition-colors',
                      lastChannelRef.current
                        ? 'text-muted hover:text-accent hover:bg-hover'
                        : 'text-faint/40 cursor-default'
                    )}
                    aria-label="上一个频道"
                    title={lastChannelRef.current ? `上一个频道：${lastChannelRef.current.name}（Backspace）` : '暂无上一个频道'}
                    onClick={backToPrevChannel}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M9 15L4 10l5-5m-5 5h10.5a5.5 5.5 0 015.5 5.5V17"
                      />
                    </svg>
                  </button>
                  <button
                    className="rounded-md p-2 text-muted hover:text-accent hover:bg-hover transition-colors"
                    aria-label="上一台"
                    title="上一台（↑）"
                    onClick={goPrevChannel}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M11 19l-7-7 7-7m8 14l-7-7 7-7"
                      />
                    </svg>
                  </button>
                  <button
                    className="rounded-md p-2 text-muted hover:text-accent hover:bg-hover transition-colors"
                    aria-label="下一台"
                    title="下一台（↓）"
                    onClick={goNextChannel}
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M13 5l7 7-7 7M5 5l7 7-7 7"
                      />
                    </svg>
                  </button>
                  <button
                    className={cn(
                      'rounded-md p-2 transition-colors',
                      isFavorite ? 'text-warning' : 'text-muted hover:text-warning hover:bg-hover'
                    )}
                    aria-label={isFavorite ? '取消收藏' : '收藏'}
                    title={isFavorite ? '取消收藏' : '收藏'}
                    onClick={() => useAppStore.getState().toggleLiveFavorite(currentChannel.url)}
                  >
                    <svg
                      className="w-4 h-4"
                      fill={isFavorite ? 'currentColor' : 'none'}
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.196-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.783-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"
                      />
                    </svg>
                  </button>
                  <button
                    className="rounded-md p-2 text-muted hover:text-accent hover:bg-hover transition-colors"
                    aria-label="复制播放地址"
                    title="复制播放地址"
                    onClick={async () => {
                      const ok = await copyToClipboard(currentChannel.url);
                      if (ok) {
                        setCopied(true);
                        setTimeout(() => setCopied(false), 1500);
                      }
                    }}
                  >
                    {copied ? (
                      <span className="text-[10px] text-success">已复制</span>
                    ) : (
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h8a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3"
                        />
                      </svg>
                    )}
                  </button>
                </div>
              </div>
            )}

            {/* 节目单 */}
            {!IS_STANDALONE && currentChannel && (
              <section className="bg-surface-raised border border-line rounded-lg p-3 mt-3">
                <h2 className="text-sm font-semibold text-content mb-2.5">节目单</h2>
                <LiveEpgPanel epgUrl={currentChannel.epg} tvgId={currentChannel.tvgId} />
              </section>
            )}
          </div>

          {/* 移动端抽屉遮罩 */}
          {listOpen && (
            <div
              className="fixed inset-0 z-[54] bg-black/50 lg:hidden"
              aria-hidden="true"
              onClick={closeChannelList}
            />
          )}

          {/* 侧栏：桌面常驻 sticky；移动端底部抽屉 */}
          <aside
            id="live-channel-list"
            aria-label="频道列表"
            className={cn(
              'bg-surface-raised border border-line flex-col overflow-hidden',
              'fixed inset-x-0 bottom-0 z-[55] h-[75dvh] pb-[env(safe-area-inset-bottom)] rounded-t-2xl shadow-2xl',
              listOpen ? 'flex' : 'hidden',
              'lg:sticky lg:top-20 lg:z-auto lg:flex lg:h-[calc(100vh-6.5rem)] lg:rounded-xl lg:pb-0 lg:shadow-none'
            )}
          >
            {/* 抽屉把手栏（仅移动端） */}
            <div className="flex items-center justify-between px-3 pt-3 pb-1 shrink-0 lg:hidden">
              <span className="text-sm font-semibold text-content">频道列表</span>
              <button
                ref={closeListButtonRef}
                type="button"
                className="grid h-11 w-11 place-items-center rounded-md text-muted hover:text-content hover:bg-hover transition-colors"
                aria-label="关闭频道列表"
                onClick={closeChannelList}
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            <div className="flex-1 min-h-0 flex flex-col">
              {isLoadingChannels ? (
                <div className="flex-1 flex items-center justify-center">
                  <Spinner size="lg" />
                </div>
              ) : (
                <LiveChannelList
                  channels={channels}
                  groups={groups}
                  currentUrl={currentUrl}
                  onSelect={handleSelect}
                  onFilteredChange={handleFilteredChange}
                />
              )}
              {sources.length === 0 && (
                <p className="text-[10px] text-faint px-3 py-1.5 border-t border-line shrink-0">
                  {hasConfiguredSources
                    ? '所有直播源均已停用，请在设置中勾选启用'
                    : '暂无直播源，请在设置 → 直播源中添加'}
                </p>
              )}
            </div>
          </aside>
        </div>
      </main>
    </div>
  );
}
