'use client';

import { Suspense, useEffect, useMemo, useRef, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Header } from '@/components/header';
import { DiscoverySection } from '@/components/discovery-section';
import { DetailModal } from '@/components/detail-modal';
import { AggregatedCard } from '@/components/video-card';
import { useSearchResultGroups } from '@/components/use-search-result-groups';
import { useAppStore, resolveSource, isInDisabledSubscription, isSourceDisabled } from '@/lib/store';
import { api } from '@/lib/client-api';
import type { SearchResponse, SearchResultItem, SourceSearchOutcome } from '@/lib/types';
import { SearchHistoryDropdown, useSearchHistory } from '@/components/search-history';
import { cn, formatDisableTtl, validateSourceUrl } from '@/lib/utils';
import { useToast } from '@/components/toast';
import { EmptyState } from '@/components/states';
import { Icon } from '@/components/icon';
import { SiteFooter } from '@/components/site-footer';
import { APP_BRAND } from '@/lib/app-brand';
import { IS_STANDALONE } from '@/lib/runtime-mode';
import { appPath } from '@/lib/app-path';
import { requestAppPanel } from '@/lib/app-navigation';
import { HomeViewing } from '@/components/home-viewing';
import { RelatedSearch } from '@/components/related-search';
import { getSearchExpansionPlan } from '@/lib/search-expansion';
import { partitionSearchResults } from '@/lib/manual-search';
import './home.css';
import '@/components/home-media.css';

/**
 * 首页：搜索（URL ?s= 驱动，可后退/分享）+ 豆瓣推荐。
 * 搜索状态由 React Query 管理，失败源在结果区顶部以非阻塞方式展示。
 */
/** 搜索结果分批渲染的批大小：一次挂载上千张卡片会明显掉帧 */
const RESULT_PAGE_SIZE = 60;

export default function HomePage() {
  return (
    <Suspense>
      <HomeContent />
    </Suspense>
  );
}

function HomeContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const urlQuery = searchParams.get('s') || '';
  // 精确订阅所需字段（对齐 live 页的做法）：搜索流式期间逐源写健康度、
  // 打开设置抽屉/历史面板等无关 store 变化，都不应触发首页整树重渲染
  const customAPIs = useAppStore((s) => s.customAPIs);
  const envSources = useAppStore((s) => s.envSources);
  const selectedKeys = useAppStore((s) => s.selectedKeys);
  const yellowFilter = useAppStore((s) => s.yellowFilter);
  const sourceHealth = useAppStore((s) => s.sourceHealth);
  const subscriptions = useAppStore((s) => s.subscriptions);
  const [input, setInput] = useState(urlQuery);
  const [detailItem, setDetailItem] = useState<SearchResultItem | null>(null);
  /** 流式搜索中已结算的源（data 就绪前用于增量渲染） */
  const [streamedSearch, setStreamedSearch] = useState<{ key: string; outcomes: SourceSearchOutcome[] }>({ key: '', outcomes: [] });
  const inputRef = useRef<HTMLInputElement>(null);

  // URL 驱动搜索：?s= 变化时回填输入框
  useEffect(() => {
    if (urlQuery) setInput(urlQuery);
  }, [urlQuery]);

  // 源名回显：失败/停用提示里显示友好名称而非裸 key
  const sourceName = (key: string) =>
    customAPIs.find((a) => a.key === key)?.name ??
    envSources.find((a) => a.key === key)?.name ??
    key;

  const selectedSources = useMemo(() => {
    // selectedKeys 可能含历史残留的重复 key：按 key 去重，避免同源重复搜索
    const seen = new Set<string>();
    return selectedKeys
      .map((key) => resolveSource({ customAPIs, envSources }, key))
      .filter((s): s is NonNullable<typeof s> => {
        if (!s || !validateSourceUrl(s.url) || seen.has(s.key)) return false;
        seen.add(s.key);
        return true;
      })
      // 自动停用期内的源不参与搜索（到期自动恢复）
      .filter((s) => !isSourceDisabled({ sourceHealth }, s.key))
      // 所属订阅被整体停用的源同样跳过（无损：各源勾选状态保留，重新启用即恢复）
      .filter((s) => !isInDisabledSubscription({ subscriptions }, s.key));
  }, [customAPIs, envSources, selectedKeys, sourceHealth, subscriptions]);
  const disabledSources = useMemo(
    () => selectedKeys.filter((key) => isSourceDisabled({ sourceHealth }, key)),
    [selectedKeys, sourceHealth]
  );
  // 来自已关闭订阅的源：勾选状态还在，但本次搜索用不到，必须明确告知
  const offSubscriptionSources = useMemo(
    () =>
      selectedKeys.filter(
        (key) => !isSourceDisabled({ sourceHealth }, key) && isInDisabledSubscription({ subscriptions }, key)
      ),
    [selectedKeys, sourceHealth, subscriptions]
  );

  // 同一 key 的 API 地址/名称编辑后也应重新搜索，避免沿用 5 分钟前的旧源结果。
  const searchQueryKey = ['search', urlQuery, selectedKeys, yellowFilter,
    selectedKeys.map((key) => resolveSource({ customAPIs, envSources }, key))];
  const searchRequestKey = JSON.stringify(searchQueryKey);
  const streamedOutcomes = useMemo(
    () => streamedSearch.key === searchRequestKey ? streamedSearch.outcomes : [],
    [streamedSearch, searchRequestKey]
  );
  const searchQuery = useQuery({
    queryKey: searchQueryKey,
    // 与 runSearch 的截断规则保持一致：顶栏搜索 / 手动构造长链接不会绕过上限
    queryFn: async ({ signal }) => {
      const previous = queryClient.getQueryData<SearchResponse>(searchQueryKey);
      setStreamedSearch({ key: searchRequestKey, outcomes: [] });
      const result = await api.search(urlQuery.slice(0, 100), selectedSources, yellowFilter, {
        signal,
        // 逐源结算即更新：结果边搜边渲染，同时滚动健康度
        onSource: (outcome) => {
          if (signal.aborted) return;
          setStreamedSearch((prev) => prev.key === searchRequestKey
            ? { key: searchRequestKey, outcomes: [...prev.outcomes, outcome] }
            : prev);
          for (const ev of useAppStore.getState().recordSourceHealth([outcome])) {
            if (!IS_STANDALONE) toast(
              ev.permanent
                ? `「${sourceName(ev.key)}」多次失败，已停止参与搜索，可在设置中恢复`
                : `「${sourceName(ev.key)}」连续超时/失败，已停用 ${formatDisableTtl(ev.ttlMs ?? 0)}`,
              'warning'
            );
          }
        },
      });
      // 对同一搜索重试时，传输中断不能抹掉上次已经展示的影片。
      if (result.partial && previous) {
        const items = new Map(previous.list.map((item) => [JSON.stringify([item.sourceKey, item.vodId]), item]));
        for (const item of result.list) items.set(JSON.stringify([item.sourceKey, item.vodId]), item);
        return { ...result, list: [...items.values()] };
      }
      return result;
    },
    enabled: Boolean(urlQuery) && selectedSources.length > 0,
    // 5 分钟内从播放页返回时直接使用缓存，不重新搜索（服务端另有 60s 结果缓存兜底）
    staleTime: 300_000,
    retry: false,
  });

  // 最近搜索改为搜索框下拉（聚焦展开、按输入过滤），不再常驻首屏
  const searchHistory = useSearchHistory(input);

  const runSearch = (q: string) => {
    const query = q.trim().slice(0, 100);
    if (!query) {
      toast('请输入搜索内容', 'info');
      inputRef.current?.focus();
      return;
    }
    if (selectedSources.length === 0) {
      toast('请先在设置中添加并勾选点播源', 'warning');
      return;
    }
    searchHistory.close();
    inputRef.current?.blur();
    const href = `/?s=${encodeURIComponent(query)}`;
    if (IS_STANDALONE) {
      // Search data comes from external sources; native history keeps useSearchParams
      // in sync without asking a static host for an unnecessary RSC navigation.
      window.history.pushState(null, '', appPath(href));
    } else {
      router.push(href, { scroll: false });
    }
    searchHistory.record(query);
  };

  const pickHistory = (text: string) => {
    setInput(text);
    searchHistory.close();
    runSearch(text);
  };

  const isSearching = Boolean(urlQuery) && searchQuery.isFetching && !searchQuery.data;
  // 聚合数据未就绪时，用已结算源的结果增量渲染（健康源不再等坏源超时）
  const streamedList = useMemo(
    () => streamedOutcomes.flatMap((o) => o.list),
    [streamedOutcomes]
  );
  const list = useMemo(
    () => searchQuery.data?.list ?? streamedList,
    [searchQuery.data, streamedList]
  );
  const searchWarning = searchQuery.error instanceof Error
    ? searchQuery.error.message
    : searchQuery.data?.error;
  const failures =
    searchQuery.data?.failures ??
    streamedOutcomes
      .filter((o) => !o.ok)
      .map((o) => ({ sourceKey: o.sourceKey, error: o.error || '请求失败', timedOut: o.timedOut }));
  const sourceSearchIncomplete = !isSearching && list.length === 0 && failures.length > 0;
  const standaloneSourceFailure = IS_STANDALONE && sourceSearchIncomplete;
  const primaryReady = Boolean(searchQuery.data) && !searchQuery.isFetching;
  const primaryAvailable = Boolean(searchQuery.data) && !searchQuery.error &&
    (list.length > 0 || failures.length === 0 || streamedOutcomes.some((outcome) => outcome.ok) || failures.length < selectedSources.length);
  const canExpandEmpty = primaryReady && primaryAvailable && getSearchExpansionPlan(urlQuery).candidates.length > 0;
  // Explicit commentary/trailer labels remain available without outranking full-work results.
  const partitioned = useMemo(() => partitionSearchResults(list, urlQuery), [list, urlQuery]);
  // 跨源同名聚合：同名影片合并为一张卡片，展开后可选择具体来源
  const groups = useSearchResultGroups(partitioned.main, searchRequestKey);
  const secondaryGroups = useSearchResultGroups(partitioned.supplementary, searchRequestKey);

  // 只在搜索条件改变时回到首批，逐源返回时保留已加载的卡片。
  const [visibleCount, setVisibleCount] = useState(RESULT_PAGE_SIZE);
  const visibleGroups = useMemo(() => groups.slice(0, visibleCount), [groups, visibleCount]);
  useEffect(() => setVisibleCount(RESULT_PAGE_SIZE), [searchRequestKey]);
  const [secondaryCount, setSecondaryCount] = useState(RESULT_PAGE_SIZE);
  useEffect(() => setSecondaryCount(RESULT_PAGE_SIZE), [searchRequestKey]);

  const searchSection = (
        <section aria-label="搜索影视" className="home-search-area">
          {/* 定位容器比胶囊宽一圈：浮层按它的宽度对齐，接缝处不会与胶囊边框错位 1px */}
          <div ref={searchHistory.containerRef} className="home-search-box relative w-full z-20">
            <form
              className="w-full"
              autoComplete="off"
              onSubmit={(e) => {
                e.preventDefault();
                runSearch(input);
              }}
            >
              {/* 输入框与搜索按钮合并为一个胶囊：内部无边框，焦点态由容器统一表达；
                  下拉展开时改为「上圆下直」并隐去底边，与下方浮层拼成同一个面板 */}
              <div
                className={cn(
                  // 12px 圆角矩形（非胶囊）：收起态与展开态共用同一组上圆角，
                  // 展开时输入框这部分形状完全不发生变化，上下圆角也与下拉保持一致；
                  // 右侧与上下不留内边距，由搜索按钮拉伸填满、与搜索框边缘贴合
                  'flex items-stretch pl-4 border',
                  'min-h-14 shadow-sm',
                  'transition-[background-color,border-color,border-radius] duration-200',
                  searchHistory.visible
                    ? // 展开时：外框（含上圆角）沿用输入框的聚焦样式不变，只把底边改为内部分隔线，
                      // 使输入区在展开状态下仍是边界清晰的独立输入框，而非与列表糊成一片
                      'rounded-t-2xl rounded-b-none border-accent/60 border-b-line bg-surface-raised'
                    : 'rounded-2xl border-line bg-card focus-within:border-accent/60 focus-within:ring-1 focus-within:ring-accent/20'
                )}
              >
                <label htmlFor="home-search-input" className="home-search-label"><Icon name="search" className="w-5 h-5" /><span>找片</span></label>
                <input
                  id="home-search-input"
                  ref={inputRef}
                  className="flex-1 min-w-0 pr-2 bg-transparent text-base sm:text-sm text-content placeholder:text-faint focus:outline-none"
                  placeholder={urlQuery ? '搜索电影、电视剧、综艺' : '搜索电影、电视剧、动漫…'}
                  enterKeyHint="search"
                  autoCapitalize="none"
                  autoCorrect="off"
                  autoComplete="off"
                  spellCheck={false}
                  value={input}
                  maxLength={100}
                  onChange={(e) => {
                    setInput(e.target.value);
                    searchHistory.resetActive();
                  }}
                  onFocus={searchHistory.onFocus}
                  onKeyDown={(e) => searchHistory.onKeyDown(e, pickHistory)}
                  role="combobox"
                  aria-label="搜索影片"
                  aria-expanded={searchHistory.visible}
                  aria-controls="home-search-history"
                  aria-autocomplete="list"
                  aria-activedescendant={
                    searchHistory.visible && searchHistory.activeIndex >= 0
                      ? `home-search-history-${searchHistory.activeIndex}`
                      : undefined
                  }
                />
                {input && (
                  <button
                    type="button"
                    className="shrink-0 self-center mr-1 min-w-11 min-h-11 inline-flex items-center justify-center rounded-full text-faint hover:text-content hover:bg-hover transition-colors"
                    onClick={() => {
                      setInput('');
                      searchHistory.resetActive();
                      inputRef.current?.focus();
                    }}
                    aria-label="清空"
                  >
                    <Icon name="close" className="w-4 h-4" />
                  </button>
                )}
                {/* 主操作按钮：贴合搜索框右端——右侧圆角跟随容器、左侧直角，展开时右下角
                    跟着容器一起改直角；按压改用亮度反馈（缩放会让贴合边缘露出缝隙） */}
                <button
                  type="submit"
                  className={cn(
                    'btn-primary shrink-0 min-h-11 px-4 font-medium transition-[background-color,filter] active:brightness-90',
                    '!rounded-xl self-center mr-1.5'
                  )}
                >
                  <Icon name="search" className="w-4 h-4" />
                  搜索
                </button>
              </div>
            </form>

            {/* 最近搜索：与输入框无缝拼接；浮层不占文档流，出现/消失不会顶动下方内容 */}
            {searchHistory.visible && (
              <SearchHistoryDropdown
                id="home-search-history"
                matches={searchHistory.matches}
                activeIndex={searchHistory.activeIndex}
                totalCount={searchHistory.totalCount}
                expanded={searchHistory.expanded}
                onToggleExpand={searchHistory.toggleExpanded}
                onPick={pickHistory}
                onRemove={searchHistory.remove}
                onClearAll={searchHistory.clearAll}
              />
            )}
          </div>
          <div className="home-source-meta flex items-center justify-between gap-3 min-h-11 pt-1 text-xs text-faint">
            <span className="min-w-0 truncate"><span className="home-source-dot" aria-hidden="true" />已启用 {selectedSources.length} 个片源</span>
            <button type="button" className="shrink-0 min-h-11 inline-flex items-center gap-1.5 text-muted hover:text-accent focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent rounded-lg px-1"
              onClick={() => requestAppPanel('sources')}>
              <Icon name="link" className="w-3.5 h-3.5" />管理片源
            </button>
          </div>
        </section>
  );

  return (
    <div className={cn('min-h-screen flex flex-col', urlQuery ? 'cinema-results' : 'cinema-home')}>
      <Header homeSearch={searchSection} isHome={!urlQuery} heading={!urlQuery ? '首页' : undefined} skipTarget="home-main" />

      <main id="home-main" tabIndex={-1} className={cn('vip-home relative flex-1 w-full mx-auto', urlQuery ? 'cinema-results-main' : 'cinema-main')}>
        {urlQuery && <h1 className="sr-only">{APP_BRAND.name} 视频搜索</h1>}

        {/* 搜索结果 */}
        {urlQuery && (
          <section aria-label="搜索结果" className="mb-10">
            <div className="cinema-results-heading flex flex-wrap items-center justify-between gap-x-4 gap-y-2 mb-5">
              <h2 className="text-sm text-muted">
                “<span className="text-content">{urlQuery}</span>” 的搜索结果
                {isSearching ? (
                  <span className="text-faint">
                    （已就绪 {streamedOutcomes.length}/{selectedSources.length} 个源…）
                  </span>
                ) : (
                  searchQuery.data && (
                    <span className="text-faint">
                      （原词 {groups.length + secondaryGroups.length} 部影片 · {list.length} 条结果{!IS_STANDALONE && failures.length > 0 && `，${failures.length} 个源失败`}）
                    </span>
                  )
                )}
              </h2>
              <button type="button" className="cinema-results-sources min-h-11 inline-flex items-center gap-2 text-xs text-muted hover:text-content"
                onClick={() => requestAppPanel('sources')}>
                <Icon name="link" className="w-4 h-4" />{selectedSources.length} 个片源 · 管理
              </button>
            </div>

            {(searchWarning || standaloneSourceFailure) && selectedSources.length > 0 && (!IS_STANDALONE || list.length === 0) && (
              <div role="status" className="mb-3 text-sm bg-chip rounded-lg px-3 py-2 flex flex-wrap items-center gap-2">
                <span className="flex-1 text-muted break-words">{IS_STANDALONE
                  ? searchWarning || failures[0]?.error || '搜索暂时没有完成，请稍后重试。'
                  : searchWarning}</span>
                <button className="btn-ghost btn-sm min-h-11" disabled={searchQuery.isFetching}
                  onClick={() => void searchQuery.refetch()}>
                  {searchQuery.isFetching ? '正在重试…' : '重试搜索'}
                </button>
              </div>
            )}

            {IS_STANDALONE && failures.length > 0 && (
              <details className="mb-3 text-xs bg-chip rounded-lg px-3 py-2 text-muted">
                <summary className="min-h-11 flex items-center cursor-pointer">查看 {failures.length} 个片源的失败原因</summary>
                <ul className="space-y-2 pb-2">
                  {failures.map((failure) => (
                    <li key={failure.sourceKey} className="break-words leading-relaxed">
                      <span className="text-content">{sourceName(failure.sourceKey)}</span>：{failure.error}
                    </li>
                  ))}
                </ul>
              </details>
            )}

            {!IS_STANDALONE && failures.length > 0 && (
              <div className="mb-3 text-xs bg-chip rounded-lg px-3 py-2 flex flex-wrap gap-x-3 gap-y-1">
                <span className="text-faint">{isSearching ? '以下源暂时无响应：' : '部分点播源请求失败：'}</span>
                {failures.map((f) => (
                  <span key={f.sourceKey} className={f.timedOut ? 'text-warning' : 'text-faint'}>
                    {f.timedOut ? '⏱' : '✗'} {sourceName(f.sourceKey)}
                    {f.timedOut ? ' 超时' : ''}
                    {IS_STANDALONE && f.error && `：${f.error}`}
                  </span>
                ))}
                {!searchWarning && (
                  <button className="text-accent underline" disabled={searchQuery.isFetching}
                    onClick={() => void searchQuery.refetch()}>
                    {searchQuery.isFetching ? '正在重试…' : '重试搜索'}
                  </button>
                )}
              </div>
            )}

            {!IS_STANDALONE && disabledSources.length > 0 && (
              <div className="mb-3 text-xs text-faint bg-chip rounded-lg px-3 py-2">
                {disabledSources.length} 个源因连续超时/失败已暂停参与搜索（临时停用的到期自动恢复，
                长期停用的需在设置中手动恢复）：{disabledSources.map((key) => sourceName(key)).join('、')}
              </div>
            )}

            {!IS_STANDALONE && offSubscriptionSources.length > 0 && (
              <div className="mb-3 text-xs text-faint bg-chip rounded-lg px-3 py-2">
                {offSubscriptionSources.length} 个源所属的订阅已停用，未参与本次搜索（在设置 → 数据源订阅中可重新启用）：
                {offSubscriptionSources.map((key) => sourceName(key)).join('、')}
              </div>
            )}

            {selectedSources.length === 0 ? (
              <NoSourceGuide hasSources={customAPIs.length > 0 || envSources.length > 0} />
            ) : groups.length > 0 ? (
              <>
                <div key={searchRequestKey} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 items-start">
                  {visibleGroups.map((group) => (
                    <AggregatedCard
                      key={group.key}
                      group={group}
                      sources={selectedSources}
                      onOpen={(item) => setDetailItem(item)}
                    />
                  ))}
                </div>
                {groups.length > visibleCount && (
                  <div className="flex justify-center mt-4">
                    <button
                      className="btn-ghost btn-sm"
                      onClick={() => setVisibleCount((v) => v + RESULT_PAGE_SIZE)}
                    >
                      加载更多（还有 {groups.length - visibleCount} 部）
                    </button>
                  </div>
                )}
              </>
            ) : list.length > 0 ? null : isSearching ? (
              <ResultsSkeleton />
            ) : canExpandEmpty ? null : (
              <EmptyState
                icon="search"
                title={searchWarning || sourceSearchIncomplete ? '搜索暂未完成' : '没有找到匹配的结果'}
                description={searchWarning || sourceSearchIncomplete ? '请重试搜索，或在设置中检查点播源' : '请尝试其他关键词或更换点播源'}
                className="!py-16"
              />
            )}
            <RelatedSearch key={`related:${searchRequestKey}`} query={urlQuery} requestKey={searchRequestKey} ready={primaryReady} available={primaryAvailable}
              originalItems={list} sources={selectedSources} filterAdult={yellowFilter} onOpen={setDetailItem} />
            {secondaryGroups.length > 0 && <section key={`secondary:${searchRequestKey}`} className="related-search search-original-secondary" aria-label="原词找到的解说、预告与花絮">
              <div className="related-search-heading"><div><h2>解说、预告与花絮</h2>
                <p>原词找到的其他相关内容，按片源明确标识区分，仍可打开查看。</p></div></div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 items-start mt-4">
                {secondaryGroups.slice(0, secondaryCount).map((group) => <AggregatedCard key={group.key} group={group} sources={selectedSources} onOpen={setDetailItem} />)}
              </div>
              {secondaryGroups.length > secondaryCount && <button type="button" className="btn-ghost related-search-more" onClick={() => setSecondaryCount((count) => count + RESULT_PAGE_SIZE)}>加载更多相关内容（还有 {secondaryGroups.length - secondaryCount} 部）</button>}
            </section>}
          </section>
        )}

        {!urlQuery && (
          <>
            <HomeViewing onPick={(title) => { setInput(title); runSearch(title); }} onDetail={setDetailItem} />
            <DiscoverySection onPick={(title) => { setInput(title); runSearch(title); }} />
            {selectedSources.length === 0 && <NoSourceGuide hasSources={customAPIs.length > 0 || envSources.length > 0} />}
          </>
        )}

      </main>

      {!IS_STANDALONE && <SiteFooter />}

      <DetailModal item={detailItem} onClose={() => setDetailItem(null)} />
    </div>
  );
}

function ResultsSkeleton() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
      {Array.from({ length: 6 }).map((_, i) => (
        // 结构对齐真实结果卡（左侧缩略图 + 右侧文字块），避免占位与真实卡片形状不符
        <div key={i} className="card flex h-28 overflow-hidden">
          <div className="w-[105px] sm:w-[120px] shrink-0 bg-chip animate-pulse" />
          <div className="flex-1 p-2.5 space-y-2">
            <div className="h-4 w-3/4 rounded bg-chip animate-pulse" />
            <div className="h-3 w-1/2 rounded bg-chip animate-pulse" />
            <div className="h-3 w-full rounded bg-chip animate-pulse" />
          </div>
        </div>
      ))}
    </div>
  );
}

/** 无点播源 / 未勾选点播源时的引导（替代旧版首屏静默空白） */
function NoSourceGuide({ hasSources = false }: { hasSources?: boolean }) {
    return (
      <section className="home-source-guide w-full mx-auto mb-5 rounded-2xl border border-line bg-card p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-5" aria-label="连接片源">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-accent/10 text-accent flex items-center justify-center shrink-0"><Icon name="link" /></div>
          <div className="min-w-0 flex-1">
            <h2 className="text-base font-semibold text-content">{hasSources ? '选择要搜索的片源' : '连接你的片库'}</h2>
            <p className="text-sm text-muted leading-6 mt-1">{hasSources ? '勾选至少一个片源，就可以开始搜索。' : '添加你自己的影视片源，就能搜索和播放。'}</p>
          </div>
        </div>
        <button type="button" className="btn-primary min-h-11 w-full sm:w-auto shrink-0 px-5" onClick={() => requestAppPanel('sources')}>
          <Icon name={hasSources ? 'link' : 'plus'} className="w-4 h-4" />{hasSources ? '管理片源' : '添加片源'}
        </button>
      </section>
    );
}
