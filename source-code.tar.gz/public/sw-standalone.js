/* Generated for the static iPhone app. No API, proxy or media response is stored. */
const BUILD = '__LIBRETV_STANDALONE_BUILD__';
const APP_VERSION = '__LIBRETV_STANDALONE_VERSION__';
const BASE_PATH = /*__LIBRETV_APP_BASE_PATH__*/ '';
const PRECACHE = /*__LIBRETV_STANDALONE_PRECACHE__*/ [];
const ROUTES = /*__LIBRETV_STANDALONE_ROUTES__*/ {};
// Project sites share an origin; activating one app must not evict another app's cache.
const CACHE_PREFIX = 'libretv-standalone-shell-' + (BASE_PATH ? encodeURIComponent(BASE_PATH) + '-' : '');
const CACHE_NAME = `${CACHE_PREFIX}${BUILD}`;
const FILES = new Set(PRECACHE.map((entry) => entry.url));
const RESOURCE_TIMEOUT_MS = 12_000;
const INSTALL_TIMEOUT_MS = 60_000;

async function saveResource(cache, entry, installSignal) {
  const controller = new AbortController();
  const abort = () => controller.abort();
  installSignal.addEventListener('abort', abort, { once: true });
  let timer;
  try {
    await Promise.race([(async () => {
      if (installSignal.aborted) throw new Error('App installation timed out');
      const response = await fetch(entry.url, { cache: 'reload', credentials: 'same-origin', redirect: 'follow', signal: controller.signal });
      // Verification includes the body read, so a stalled body is bounded too.
      if (!(await hasExpectedBytes(response, entry.sha256))) throw new Error(`App resource is unavailable: ${entry.url}`);
      if (controller.signal.aborted || installSignal.aborted) throw new Error('App installation was cancelled');
      const resource = response.redirected
        ? new Response(response.body, { status: response.status, statusText: response.statusText, headers: response.headers })
        : response;
      await cache.put(entry.url, resource);
    })(), new Promise((_, reject) => {
      timer = setTimeout(() => { controller.abort(); reject(new Error(`App resource timed out: ${entry.url}`)); }, RESOURCE_TIMEOUT_MS);
    })]);
  } finally {
    clearTimeout(timer);
    installSignal.removeEventListener('abort', abort);
  }
}

async function hasExpectedBytes(response, expected) {
  if (!response.ok || response.type === 'opaque') return false;
  // Static hosts can canonicalize /index.html -> / and /watch.html -> /watch.
  // Follow that normalization, but never accept an off-site response or a login page.
  try {
    const target = new URL(response.url);
    if (target.origin !== self.location.origin || scopedPath(target.pathname) === null) return false;
  } catch { return false; }
  const bytes = await response.clone().arrayBuffer();
  const digest = await crypto.subtle.digest('SHA-256', bytes);
  const actual = [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, '0')).join('');
  return actual === expected;
}

self.addEventListener('install', (event) => {
  // A partially downloaded app must never replace a complete older version.
  event.waitUntil((async () => {
    if (PRECACHE.length === 0 || !ROUTES['/']) throw new Error('Standalone build has not been prepared');
    const controller = new AbortController();
    let timer;
    try {
      await Promise.race([(async () => {
        const cache = await caches.open(CACHE_NAME);
        let next = 0;
      // A small pool avoids a long serial install on mobile without saturating
      // the connection. All files still need verified bytes before activation.
        const tasks = Array.from({ length: Math.min(4, PRECACHE.length) }, async () => {
          while (next < PRECACHE.length && !controller.signal.aborted) await saveResource(cache, PRECACHE[next++], controller.signal);
        });
        await Promise.all(tasks);
      })(), new Promise((_, reject) => {
        timer = setTimeout(() => { controller.abort(); reject(new Error('App installation timed out')); }, INSTALL_TIMEOUT_MS);
      })]);
    } catch (error) {
      controller.abort();
      await caches.delete(CACHE_NAME);
      throw error;
    } finally { clearTimeout(timer); }
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const versions = (await caches.keys()).filter((name) => name.startsWith(CACHE_PREFIX));
    // Keep the immediately previous build's immutable chunks for already-open players.
    const older = versions.filter((name) => name !== CACHE_NAME);
    await Promise.all(older.slice(0, Math.max(0, older.length - 1)).map((name) => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', (event) => {
  if (event.data?.type === 'ACTIVATE_UPDATE') self.skipWaiting();
  else if (event.data?.type === 'GET_APP_VERSION') event.ports?.[0]?.postMessage({ type: 'APP_VERSION', version: APP_VERSION, build: BUILD });
});

function routeEntry(pathname) {
  const normalized = pathname.replace(/\/+$/, '') || '/';
  return ROUTES[normalized];
}

function scopedPath(pathname) {
  if (!BASE_PATH) return pathname;
  if (pathname === BASE_PATH) return '/';
  return pathname.startsWith(BASE_PATH + '/') ? pathname.slice(BASE_PATH.length) : null;
}

async function shellResponse(key, rsc) {
  const cache = await caches.open(CACHE_NAME);
  const response = await cache.match(key);
  if (!response) return new Response('本机应用资源已被系统清理，请联网重新打开应用。', {
    status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' },
  });
  if (!rsc) return response;
  // Next's client router may fetch a route with an RSC header instead of its exported .txt URL.
  const headers = new Headers(response.headers);
  headers.set('Content-Type', 'text/x-component');
  return new Response(response.body, { status: response.status, headers });
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  const pathname = scopedPath(url.pathname);
  if (pathname === null || pathname.startsWith('/api/') || request.headers.has('range')) return;

  const route = routeEntry(pathname);
  const rsc = request.headers.get('rsc') === '1';
  if (rsc && route?.rsc) {
    event.respondWith(shellResponse(route.rsc, true));
    return;
  }
  if (request.mode === 'navigate') {
    // The original navigation URL and query remain in the address bar; only the static shell is reused.
    const page = route?.html || (FILES.has(url.pathname) && url.pathname.endsWith('.html') ? url.pathname : null);
    if (page) event.respondWith(shellResponse(page, false));
    return;
  }
  const previousBuildAsset = /^\/_next\/static\/.*\.(?:js|css|woff2?|ttf)$/.test(pathname);
  if (!FILES.has(url.pathname) && !previousBuildAsset) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(url.pathname);
    if (cached) return cached;
    // This version's immutable asset may belong to the previously open app generation.
    // No new responses are written at runtime, so URLs with private query data never become cache keys.
    const older = await caches.match(url.pathname);
    if (older) return older;
    return fetch(request);
  })());
});
