// SPDX-License-Identifier: AGPL-3.0-or-later
import { common } from '@kit.AbilityKit';
import { fileIo, picker } from '@kit.CoreFileKit';
import { util } from '@kit.ArkTS';
import { webview } from '@kit.ArkWeb';

export const LOCAL_ORIGIN: string = 'https://vip.localhost';
const MAX_JSON_CHARS: number = 8 * 1024 * 1024;

class BridgeRequest {
  id: string = '';
  filename: string = '';
  text: string = '';
}

class BridgeResult {
  status: string;
  message: string;

  constructor(status: string, message: string = '') {
    this.status = status;
    this.message = message;
  }
}

export function isLocalPage(url: string): boolean {
  return url === LOCAL_ORIGIN || url.startsWith(LOCAL_ORIGIN + '/');
}

// Only these two methods are registered in JavaScriptProxy.methodList.
// Remote frames are blocked by navigation interception and response CSP.
export class NativeBridge {
  private controller: webview.WebviewController;
  private getContext: () => common.UIAbilityContext;
  private busy: boolean = false;

  constructor(controller: webview.WebviewController, getContext: () => common.UIAbilityContext) {
    this.controller = controller;
    this.getContext = getContext;
  }

  private trusted(): boolean {
    try {
      return isLocalPage(this.controller.getUrl());
    } catch (_) {
      return false;
    }
  }

  private parse(input: string): BridgeRequest | undefined {
    if (!this.trusted() || typeof input !== 'string' || input.length > MAX_JSON_CHARS) {
      return undefined;
    }
    try {
      const request = JSON.parse(input) as BridgeRequest;
      if (request === null || typeof request !== 'object' ||
        typeof request.id !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(request.id)) {
        return undefined;
      }
      return request;
    } catch (_) {
      return undefined;
    }
  }

  private reply(id: string, status: string, message: string = ''): void {
    if (!this.trusted()) {
      return;
    }
    const result = JSON.stringify(new BridgeResult(status, message));
    // Both arguments are encoded as JSON literals. Never interpolate raw input as code.
    this.controller.runJavaScript('window.__VIP_HARMONY_RESOLVE && window.__VIP_HARMONY_RESOLVE(' +
      JSON.stringify(id) + ',' + JSON.stringify(result) + ')').catch(() => {});
  }

  saveFile(input: string): void {
    const request = this.parse(input);
    if (!request) {
      return;
    }
    if (typeof request.filename !== 'string' ||
      !/^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$/.test(request.filename) || request.filename.includes('..') ||
      typeof request.text !== 'string' || request.text.length === 0 || request.text.length > MAX_JSON_CHARS) {
      this.reply(request.id, 'error', '文件名或配置大小不符合要求');
      return;
    }
    const bytes = new util.TextEncoder().encodeInto(request.text);
    this.saveBytes(request.id, request.filename, bytes);
  }

  shareSource(input: string): void {
    const request = this.parse(input);
    if (!request) {
      return;
    }
    try {
      // This path is fixed. A caller cannot export arbitrary app files or URLs.
      const bytes = this.getContext().resourceManager.getRawFileContentSync('web/source-code.tar.gz');
      if (bytes.byteLength === 0 || bytes.byteLength > 128 * 1024 * 1024) {
        this.reply(request.id, 'error', '随包源码不完整');
        return;
      }
      this.saveBytes(request.id, 'VIP-films-source-code.tar.gz', bytes);
    } catch (_) {
      this.reply(request.id, 'error', '未找到随包 AGPL 源码');
    }
  }

  private async saveBytes(id: string, filename: string, bytes: Uint8Array): Promise<void> {
    if (this.busy) {
      this.reply(id, 'error', '请先完成当前文件选择');
      return;
    }
    this.busy = true;
    try {
      const options = new picker.DocumentSaveOptions();
      options.newFileNames = [filename];
      // DEFAULT invokes the system save dialog; DOWNLOAD mode is deliberately unused.
      options.pickerMode = picker.DocumentPickerMode.DEFAULT;
      const uris = await new picker.DocumentViewPicker(this.getContext()).save(options);
      if (uris.length === 0) {
        this.reply(id, 'cancelled');
        return;
      }
      // Only the URI explicitly selected by the user is opened.
      const file = await fileIo.open(uris[0], fileIo.OpenMode.WRITE_ONLY | fileIo.OpenMode.CREATE |
        fileIo.OpenMode.TRUNC);
      try {
        let offset: number = 0;
        while (offset < bytes.byteLength) {
          const chunk = bytes.slice(offset, Math.min(offset + 65536, bytes.byteLength));
          const written = await fileIo.write(file.fd, chunk.buffer as ArrayBuffer);
          if (written <= 0 || written > chunk.byteLength) {
            throw new Error('Incomplete write');
          }
          offset += written;
        }
      } finally {
        await fileIo.close(file);
      }
      this.reply(id, 'saved');
    } catch (_) {
      // No selected URI, file contents or private exception details enter logs/callbacks.
      this.reply(id, 'error', '保存未完成，可重试或取消');
    } finally {
      this.busy = false;
    }
  }
}
