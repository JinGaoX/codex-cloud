// SPDX-License-Identifier: AGPL-3.0-or-later
import { common } from '@kit.AbilityKit';
import { webview } from '@kit.ArkWeb';
import { window } from '@kit.ArkUI';
import { picker } from '@kit.CoreFileKit';
import { LOCAL_ORIGIN, NativeBridge, isLocalPage } from '../bridge/NativeBridge';
import { ASSET_ROUTES } from '../generated/AssetManifest';

@Entry
@Component
struct Index {
  private controller: webview.WebviewController = new webview.WebviewController();
  private bridge: NativeBridge = new NativeBridge(this.controller,
    () => this.getUIContext().getHostContext() as common.UIAbilityContext);
  private fullScreenHandler: FullScreenExitHandler | null = null;

  private response(url: string): WebResourceResponse | null {
    if (!isLocalPage(url)) {
      return null;
    }
    // Paths never become raw file paths directly. Only build-time manifest entries can be served.
    let route = url.substring(LOCAL_ORIGIN.length).split('?')[0].split('#')[0];
    if (route === '') {
      route = '/';
    }
    const asset = ASSET_ROUTES.get(route);
    const response = new WebResourceResponse();
    response.setResponseCode(asset ? 200 : 404);
    response.setReasonMessage(asset ? 'OK' : 'Not Found');
    response.setResponseEncoding('utf-8');
    response.setResponseMimeType(asset ? asset.mime : 'text/plain');
    response.setResponseData(asset ? $rawfile('web/' + asset.file) : 'Local resource not found');
    response.setResponseHeader([
      { headerKey: 'Cache-Control', headerValue: 'no-store' },
      { headerKey: 'X-Content-Type-Options', headerValue: 'nosniff' },
      // JavaScriptProxy is visible in all frames. Keep this app single-frame and bundled-script only.
      { headerKey: 'Content-Security-Policy', headerValue: "frame-src 'none'; object-src 'none'; " +
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:; base-uri 'self'; frame-ancestors 'none'" }
    ]);
    response.setResponseIsReady(true);
    return response;
  }

  private external(url: string): void {
    // Never hand arbitrary intent/file/javascript schemes to the system.
    if (!/^https:\/\/[^\s]+$/i.test(url) || url.length > 4096) {
      return;
    }
    const context = this.getUIContext().getHostContext() as common.UIAbilityContext;
    context.startAbility({ action: 'ohos.want.action.viewData', uri: url }).catch(() => {});
  }

  private async fullScreen(enabled: boolean): Promise<void> {
    try {
      const context = this.getUIContext().getHostContext() as common.UIAbilityContext;
      const appWindow = await window.getLastWindow(context);
      await appWindow.setWindowLayoutFullScreen(enabled);
      await appWindow.setWindowSystemBarEnable(enabled ? [] : ['status', 'navigation']);
    } catch (_) {
      // Older device/window modes may not allow system-bar changes; video still plays.
    }
  }

  onBackPress(): boolean {
    if (this.fullScreenHandler) {
      this.fullScreenHandler.exitFullScreen();
      return true;
    }
    try {
      if (this.controller.accessBackward()) {
        this.controller.backward();
        return true;
      }
    } catch (_) {}
    return false;
  }

  aboutToDisappear(): void {
    try {
      this.controller.deleteJavaScriptRegister('VIPHarmony');
    } catch (_) {}
  }

  build() {
    Column() {
      Web({ src: LOCAL_ORIGIN + '/', controller: this.controller })
        .javaScriptAccess(true)
        .domStorageAccess(true)
        .databaseAccess(true)
        .fileAccess(false)
        .geolocationAccess(false)
        .mixedMode(MixedMode.None)
        .onlineImageAccess(true)
        .mediaPlayGestureAccess(true)
        .multiWindowAccess(false)
        .allowWindowOpenMethod(false)
        .javaScriptProxy({
          object: this.bridge,
          name: 'VIPHarmony',
          methodList: ['saveFile', 'shareSource'],
          controller: this.controller,
          // API 12: native permission checks the calling frame, not only the top-level URL.
          permission: '{"javascriptProxyPermission":{"urlPermissionList":' +
            '[{"scheme":"https","host":"vip.localhost","port":"443","path":"/"}]}}'
        })
        .onInterceptRequest((event) => event ? this.response(event.request.getRequestUrl()) : null)
        .onLoadIntercept((event) => {
          if (!event) {
            return true;
          }
          const url = event.data.getRequestUrl();
          // No iframe may load, even a same-origin iframe. Remote fetch/media requests are unaffected.
          if (!event.data.isMainFrame()) {
            return true;
          }
          if (isLocalPage(url)) {
            return false;
          }
          if (event.data.isRequestGesture()) {
            this.external(url);
          }
          return true;
        })
        .onShowFileSelector((event) => {
          if (!event) {
            return false;
          }
          const options = new picker.DocumentSelectOptions();
          options.maxSelectNumber = 1;
          options.fileSuffixFilters = ['JSON 配置|.json'];
          const context = this.getUIContext().getHostContext() as common.UIAbilityContext;
          new picker.DocumentViewPicker(context).select(options)
            .then((uris: string[]) => event.result.handleFileList(uris))
            .catch(() => event.result.handleFileList([]));
          return true;
        })
        .onFullScreenEnter((event) => {
          this.fullScreenHandler = event.handler;
          this.fullScreen(true);
        })
        .onFullScreenExit(() => {
          this.fullScreenHandler = null;
          this.fullScreen(false);
        })
        .width('100%')
        .height('100%')
    }
    .width('100%')
    .height('100%')
  }
}
