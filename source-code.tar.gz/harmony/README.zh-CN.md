# PPS影音 · HarmonyOS 平板工程

此目录是供华为 MatePad 11.5S（用户当前 HarmonyOS 7）继续编译、签名和真机验证的 ArkTS Stage 工程。前端、海报和 AGPL 对应源码随应用打包，首页不依赖远程站点或电脑服务器。影片搜索、榜单和播放本身仍需联网及可用片源。包版本 personal.24，versionCode 2200224；目标 SDK 配置保持官方 CLI 模板的 6.0.2(22)，不根据设备版本猜写 SDK 编号，最终兼容性以实际编译与设备测试为准。

**当前状态：源工程已准备；尚未经过 Harmony SDK 编译，也没有可安装的 HAP。** 不应把本目录、`harmony-dist/` 或未签名 HAP 当作已完成安装验收的应用。

2026-10-29 再次检查：本机常见目录、PATH 与安装注册项仍未发现 DevEco/SDK/JDK；官方 CLI 可运行，但不能代替 SDK。官方 DevEco 与 CLT 下载页实际重定向至华为账号登录页，已请用户本人登录；没有绕过登录、获取签名证书或安装真机。共享前端全屏修复和完整本地构建见 [本次记录](../docs/fullscreen-harmony.zh-CN.md)。下方 2026-10-27 日志为历史环境证据。

## 保留的行为

- 使用 PPS影音名称、用户提供的PPS图标、共享前端及平板响应式布局，不另做一套网页 UI。
- `bundleName` 固定为 `org.libretv.personal`，Web origin 固定为 `https://vip.localhost`。收藏、历史、播放进度、片源管理、定时和其他现有数据逻辑复用共享前端。
- 此 origin 是应用内部的虚拟地址，通过 ArkWeb 拦截器精确返回随包文件；没有远程 `server.url`，不会请求公网获取首页。不要改成真实网站、`file://` 或新域名，否则旧数据所属 origin 会发生变化。
- 不清空 Cookie、DOM storage、IndexedDB 或浏览历史，不注册网站 Service Worker，不调用 Capacitor API。
- 未申请广泛文件存储、相机、位置等权限；只申请联网权限。导入、导出配置均使用系统文档选择器，文件保存在用户选择的位置。
- `关于`页继续保留原有 LibreTV / AGPL 声明；对应源码 `source-code.tar.gz` 随包，可经系统保存对话框导出。
- 网页/PWA 与原生应用各有自己的沙箱。本工程不偷偷复制浏览器数据，也不承诺自动同步。可先从旧版本导出 JSON，再在新应用中手动导入。

## 构建资源

在**仓库根目录**执行：

```powershell
npm run build:harmony
node scripts/prepare-harmony.mjs
node scripts/prepare-harmony.mjs --check
```

`build:harmony` 由根构建脚本产生独立的 `harmony-dist/`。`prepare-harmony` 校验构建标识、appId 和 origin 后，复制到本目录 `entry/src/main/resources/rawfile/web/`，生成 `entry/src/main/ets/generated/AssetManifest.ets` 及 SHA-256 资源清单。它不编译或签名应用，不改手机 PWA 的 `out/` / `pages-dist/`。

生成目录已忽略入库。没有先构建前端时，脚本会直接报错；不要手动放入另一平台的产物。资源检查会拒绝 Service Worker、API 服务目录、安装描述文件、符号链接和常见签名密钥。版本名要与根 `package.json` 一致；更新时显式增加 `AppScope/app.json5` 的 `versionCode`，保持 `bundleName` 不变。

## 本机实测与缺少的环境（2026-10-27）

已定向检查 PATH、常见安装位置和安装注册项。本机未发现 DevEco Studio、HarmonyOS SDK、CLT、HDC、Hvigor 或 JDK；不排除未列入 PATH 的其他便携安装，本次未做全盘扫描。

官方 `@deveco/deveco-cli@1.3.9` 安装在仓库忽略目录 `artifacts/harmony-tools/`，没有改全局工具或系统安全设置。实际调用以下命令：

```powershell
# 仓库根目录
node artifacts/harmony-tools/node_modules/@deveco/deveco-cli/cli.js check arkts --project harmony
# 进入 harmony 后
node ../artifacts/harmony-tools/node_modules/@deveco/deveco-cli/cli.js build --build-mode debug --assemble-type assembleHap
```

两项均退出码 `1`，错误同为：

```text
DevEco Studio installation not found in default locations.
Set DEVECO_CLI_STUDIO_PATH to a DevEco Studio installation,
or set DEVECO_CLI_CLT_PATH to a Command Line Tools installation.
```

真实日志保存在本机 `artifacts/harmony-checks/arkts-check.log` 与 `artifacts/harmony-checks/build-debug.log`。CLI 能运行不代表 SDK 已安装；本次没有以普通 TypeScript 检查代替 ArkTS/Hvigor 验收。

工程结构参考上述官方 CLI 内的 `templates/application`；目标 SDK 为 `6.0.2(22)`，最低兼容 `5.0.0(12)`。选择器、桥权限及拦截器等采用 API 12 或更早接口。最低版本配置和 API 文档核对仍需 SDK 的兼容检查与真机验证确认。

## 在当前电脑上完成工具、签名和安装

1. 从华为官方 [DevEco Studio](https://developer.huawei.com/consumer/cn/deveco-studio/) 或 [Command Line Tools](https://developer.huawei.com/consumer/cn/download/command-line-tools-for-hmos) 获取工具。若下载页要求账号，需由用户本人登录；本工程没有保存账号或绕过登录。通过官方 SDK 管理器安装工程实际支持的 SDK、Hvigor、OHPM 和设备工具，再确认 HarmonyOS 7 平板兼容性。仅装 npm CLI 不够。
2. 工具装在非默认位置时，在当前 PowerShell 设置 `DEVECO_CLI_STUDIO_PATH` 或 `DEVECO_CLI_CLT_PATH`，值为实际安装目录。重跑上面的 ArkTS 检查与构建，先修正真实编译错误，再继续签名。
3. **不要把签名口令、证书或自动签名配置写入此公开模板。** 推荐先将准备好的整个 `harmony/` 复制到仓库忽略的 `artifacts/harmony-device/` 新目录，再用 DevEco Studio 打开该副本。在副本内登录自己的华为开发者账号，使用单设备自动签名；个人证书/Profile 留在本机。根源码归档对公开模板中的非空签名配置会拒绝打包。
4. 平板开启开发者模式和 USB 调试，用数据线连接电脑，在平板确认信任。DevEco Studio 中选择这台设备，完成调试签名并运行。调试 HAP 只能安装到签名 Profile 登记的 UDID 设备；没有签名、账号或设备授权时，不能承诺给任意平板直接安装。
5. 后续更新沿用相同 `bundleName`、origin 和签名身份，递增 `versionCode`。覆盖安装，不卸载旧应用，不执行 `hdc uninstall`、清数据或清 ArkWeb 存储。每次更新前可从应用导出配置备份。

如果未来需要无需开发者调试连接的长期分发，还须另行决定正式签名与分发渠道；本工程没有自动申请发布证书或上线。

## 必须在平板上验证

- 冷启动、断网启动均能看到随包首页及海报；联网后能搜索和播放。电脑关闭不应影响首页启动。
- 搜索记录、收藏、历史、播放进度、片源配置、定时、三平台精选与原前端一致，杀后台重开后仍在。
- 横竖屏布局、触控拖动、全屏进入/退出、系统返回键（先退出全屏，再回上一页）、声音和字幕表现正常。
- 导出 JSON 必须出现系统保存对话框；取消不产生成功提示；重新导入该 JSON 后片源/收藏等数据正确。APK/iOS/网页沙箱的数据不应被自动清除。
- 点击外部项目链接打开系统浏览器。第三方 iframe 不得获得 `VIPHarmony` 桥；任意未知 `https://vip.localhost/...` 资源返回本地 404。
- `关于`页能导出随包源码，解压后可获得完整对应源码和 AGPL 声明，且没有私人配置、证书或口令。
- 片源 CORS、编解码、媒体手势、文件选择和默认 443 桥权限最终以该平板的 ArkWeb 实测为准。有源打不开时要记录具体网络/解码错误，不能通过放开全部文件权限或忽略证书检查掩盖。

## 安全边界

`ASSET_ROUTES` 是构建时生成的精确白名单。查询串不参与文件映射，例如 `/watch?source=...` 映射到 `watch.html`；未知地址、编码穿越和未列出的文件不会回退到网络，也不会映射应用沙箱任意路径。其他域的 API/媒体请求仍由 ArkWeb 正常联网并接受 CORS 和 TLS 检查；没有新增开放代理。

`javaScriptProxy.permission` 将调用方限制在 `https` / `vip.localhost` / `443`，只注册 `saveFile` 和 `shareSource`。另加 `frame-src 'none'` / `object-src 'none'` CSP、禁止所有子框架导航、禁止远程脚本，并拦截外部主页面导航。方法内部再次核对顶层地址及请求大小，保存只处理用户在系统选择器确认的 URI。JSON 请求和文本均上限 8 Mi 字符，文件名白名单且拒绝 `..`。不启用 `setPathAllowingUniversalAccess`，不关闭同源或 TLS 验证。

官方依据：[本地资源跨域方案](https://developer.huawei.com/consumer/cn/doc/HarmonyOS-Guides/web-cross-origin)、[前端调用应用侧函数](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides/web-in-page-app-function-invoking)、[Hvigor 命令](https://developer.huawei.com/consumer/en/doc/harmonyos-guides/ide-hvigor-commandline)、[调试证书与签名](https://developer.huawei.com/consumer/en/doc/app/agc-help-add-debugcert-0000001914263178)。
