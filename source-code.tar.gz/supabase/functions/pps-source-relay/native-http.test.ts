// Regression coverage for the actual Deno 2.1 TCP/TLS transport.
import assert from 'node:assert/strict';
Deno.env.set('PPS_RELAY_TEST', '1');
const { readHttpResponse, pinnedRequest, createRelayHandler } = await import('./index.ts');
const encode = (text: string) => new TextEncoder().encode(text);
function socket(text: string, fragment = 7) {
  const data = encode(text); let offset = 0;
  return { read: async (buffer: Uint8Array) => {
    if (offset === data.length) return null;
    const count = Math.min(fragment, buffer.length, data.length - offset);
    buffer.set(data.subarray(offset, offset + count)); offset += count; return count;
  }, write: async (buffer: Uint8Array) => buffer.length, close: () => {} };
}
const signal = () => new AbortController().signal;

Deno.test('fragmented content-length and UTF8 bodies survive byte boundaries', async () => {
  const body = '{"list":[{"name":"测试"}]}';
  const result = await readHttpResponse(socket(`HTTP/1.1 200 OK\r\nContent-Length: ${encode(body).length}\r\nContent-Type: text/html\r\n\r\n${body}`, 1), signal());
  assert.equal(result.status, 200); assert.equal(new TextDecoder().decode(result.body), body);
});
Deno.test('chunked bodies, extensions, trailers and interim responses are decoded', async () => {
  const result = await readHttpResponse(socket('HTTP/1.1 100 Continue\r\n\r\nHTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n4;fixture=yes\r\n{"li\r\n7\r\nst":[]}\r\n0\r\nX-Info: fixture\r\n\r\n', 2), signal());
  assert.equal(new TextDecoder().decode(result.body), '{"list":[]}');
});
Deno.test('short bodies, invalid chunk framing and ambiguous headers are rejected', async () => {
  const invalid = [
    'HTTP/1.1 200 OK\r\nContent-Length: 9\r\n\r\nshort',
    'HTTP/1.1 200 OK\r\nContent-Length: 1\r\nContent-Length: 1\r\n\r\nx',
    'HTTP/1.1 200 OK\r\nContent-Length: 1\r\nTransfer-Encoding: chunked\r\n\r\nx',
    'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n1\r\nxBAD',
    'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n0\r\ninvalid trailer\r\n\r\n',
    'HTTP/1.1 200 OK\r\n folded: bad\r\n\r\nx',
    'HTTP/1.1 101 Switching Protocols\r\n\r\n',
  ];
  for (const text of invalid) await assert.rejects(() => readHttpResponse(socket(text), signal()));
});
Deno.test('large declared/chunk sizes and stalled reads stop before unbounded body consumption', async () => {
  for (const text of ['HTTP/1.1 200 OK\r\nContent-Length: 3145729\r\n\r\n', 'HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n300001\r\n']) {
    await assert.rejects(() => readHttpResponse(socket(text), signal()));
  }
  const controller = new AbortController();
  const pending = readHttpResponse({ read: () => new Promise(() => {}) }, controller.signal);
  controller.abort(); await assert.rejects(() => pending);
});
Deno.test('native transport dials only the numeric IP, uses original hostname for TLS and closes it', async () => {
  const originalConnect = Deno.connect, originalStartTls = Deno.startTls;
  const calls: unknown[] = []; let closed = 0; let request = '';
  const connection = socket('HTTP/1.1 200 OK\r\nContent-Length: 11\r\n\r\n{"list":[]}');
  connection.close = () => { closed++; };
  connection.write = async bytes => { request += new TextDecoder().decode(bytes); return bytes.length; };
  try {
    Reflect.set(Deno, 'connect', async (options: unknown) => { calls.push(options); return connection; });
    Reflect.set(Deno, 'startTls', async (_connection: unknown, options: unknown) => { calls.push(options); return connection; });
    const result = await pinnedRequest(new URL('https://media.example.org/api?ac=list'), { address: '8.8.8.8', family: 4 }, signal());
    assert.equal(result.status, 200); assert.deepEqual(calls, [{ hostname: '8.8.8.8', port: 443 }, { hostname: 'media.example.org' }]);
    assert(request.includes('Host: media.example.org\r\n')); assert(!request.includes('Authorization')); assert(!request.includes('Cookie'));
    assert.equal(closed, 1);
  } finally { Reflect.set(Deno, 'connect', originalConnect); Reflect.set(Deno, 'startTls', originalStartTls); }
});
Deno.test('cancelled TCP dial closes a late connection instead of leaking a socket', async () => {
  const originalConnect = Deno.connect; let finish!: (value: unknown) => void; let closed = 0;
  try {
    Reflect.set(Deno, 'connect', () => new Promise<unknown>(resolve => { finish = resolve; }));
    const controller = new AbortController();
    const pending = pinnedRequest(new URL('http://media.example.org/api?ac=list'), { address: '8.8.8.8', family: 4 }, controller.signal);
    controller.abort(); await assert.rejects(() => pending);
    finish({ ...socket(''), close: () => { closed++; } }); await Promise.resolve(); await Promise.resolve();
    assert.equal(closed, 1);
  } finally { Reflect.set(Deno, 'connect', originalConnect); }
});
Deno.test('diagnostic logs retain a fixed stage/reason but never URL, query, user or raw error', async () => {
  const logs: Record<string, unknown>[] = [];
  const owner = '11111111-1111-4111-8111-111111111111', url = 'https://cms.example.org/api?token=private-fixture';
  const handler = createRelayHandler({ supabaseUrl: 'https://fixture.supabase.co', anonKey: 'fixture' }, {
    backendFetch: (async input => String(input).includes('/auth/v1/user') ? Response.json({ id: owner }) : Response.json([{ record_key: url, payload: { source: { url } } }])) as typeof fetch,
    resolve: async () => [{ address: '8.8.8.8', family: 4 }],
    upstream: async () => { throw new Error('TLS handshake failed for ' + url + ' Bearer fixture.claims.signature'); },
    log: event => { logs.push(event); },
  });
  const result = await handler(new Request('https://fixture.supabase.co/functions/v1/pps-source-relay', { method: 'POST', headers: { authorization: 'Bearer fixture.claims.signature', 'content-type': 'application/json' }, body: JSON.stringify({ url: url + '&ac=list' }) }));
  assert.equal(result.status, 502); assert.equal(logs[0].stage, 'upstream'); assert.equal(logs[0].reason, 'TLS_HANDSHAKE');
  assert(result.headers.get('X-PPS-Request-ID'));
  const saved = JSON.stringify(logs); for (const secret of [url, owner, 'private-fixture', 'fixture.claims.signature', 'TLS handshake failed']) assert(!saved.includes(secret));
});
