// Optional public-network transport smoke; no Supabase account or secrets.
import assert from 'node:assert/strict';
import { lookup } from 'node:dns/promises';
Deno.env.set('PPS_RELAY_TEST', '1');
const { pinnedRequest, isPublicAddress } = await import('./index.ts');
const target = new URL('https://jsonplaceholder.typicode.com/todos/1');
let addresses = await lookup(target.hostname, { all: true, verbatim: true });
let resolver = 'system';
// A local soft-router may deliberately return Fake-IP 198.18/15. The product
// correctly refuses that range. For this public TLS transport-only smoke, use
// a public DoH answer instead; this does not alter OS/router DNS or production.
if (addresses.some(item => !isPublicAddress(item.address))) {
  const doh = new URL('https://cloudflare-dns.com/dns-query');
  doh.search = new URLSearchParams({ name: target.hostname, type: 'A' }).toString();
  const answer = await fetch(doh, { headers: { Accept: 'application/dns-json' }, signal: AbortSignal.timeout(8000) });
  assert.equal(answer.status, 200);
  const data = await answer.json();
  addresses = (data.Answer || []).filter((item: { type: number }) => item.type === 1).map((item: { data: string }) => ({ address: item.data, family: 4 }));
  resolver = 'public DoH for local Fake-IP test only';
}
assert(addresses.length && addresses.every(item => isPublicAddress(item.address)));
const address = addresses.find(item => item.family === 4) || addresses[0];
const result = await pinnedRequest(target, address, AbortSignal.timeout(8000));
assert.equal(result.status, 200);
assert.equal(JSON.parse(new TextDecoder().decode(result.body)).id, 1);
const wrongIdentity = new URL(target);
wrongIdentity.hostname = 'pps-cert-negative-test.invalid';
await assert.rejects(() => pinnedRequest(wrongIdentity, address, AbortSignal.timeout(8000)));
console.log(JSON.stringify({ passed: true, runtime: 'Deno', transport: 'node:https numeric IP with original TLS SNI and identity', resolver, status: result.status, responseBytes: result.body.byteLength, wrongCertificateIdentityRejected: true, accountUsed: false }));
