# PPS 家庭账号片源请求中转

仅帮助已登录家庭账号访问已同步的点播 API；不转发影片、直播流、图片、Cookie 或用户令牌。用户令牌只交给原项目 Auth 和带 RLS 的记录查询；不使用 service_role，不增加付费项目或数据库。

## 部署和接口

在既有 Supabase 项目 Edge Functions 的 Dashboard 编辑器新建 `pps-source-relay`，把本目录 `index.ts` 完整粘贴并部署。其余测试文件不需要上传。运行时使用默认的 `SUPABASE_URL`、`SUPABASE_ANON_KEY`，无需导出管理密钥。函数只读当前账号 `pps_sync_records` 的 `sources` 非墓碑记录。

客户端 `POST /functions/v1/pps-source-relay`，带 `Authorization: Bearer <当前用户JWT>`、公开 `apikey` 和 `Content-Type: application/json`。body 仅为 `{ "url": "完整 AppleCMS GET URL" }`。成功返回 `{ "text": "原 JSON 文本", "url": "最终 API URL" }`；失败返回 `{ "error": "提示", "code": "语义码" }`，不能把失败当成空搜索结果。

Auth 必须实际返回有效用户，再使用该 JWT 通过 RLS 查询其账号片源。请求的域名、路径、静态查询参数须匹配 `payload.source.url`，仅 `ac`（list/detail/videolist）、`wd`、`ids`、`pg` 可变化。允许同域默认端口 HTTP 升级 HTTPS和末尾斜杠规范化，禁止反向降级。重定向最多两次且每次重新校验登记地址及 DNS。

默认 CORS 精确允许 `https://jingaox.github.io`、`http://localhost:8080`、`http://127.0.0.1:8080`。可用非秘密环境变量 `PPS_RELAY_ALLOWED_ORIGINS` 以逗号分隔替换，禁止通配符。没有 Origin 的 CLI 调用仍须同样登录、RLS 和地址验证。

当前官方 [Authorization headers](https://supabase.com/docs/guides/functions/auth-headers) 说明平台验证支持新旧签名并建议用户函数保留 `verify_jwt=true`。默认保留；若具体项目仍因旧版网关拒绝真实用户 JWT，可参照官方 [401 排查](https://supabase.com/kb/troubleshooting/edge-function-401-error-response) 仅对此函数关闭平台旧验证，函数内 Auth 验证仍为强制。不能把 anon key 当用户 JWT，也不能省略内层验证。

本项目本次部署的 Dashboard 明确标为“Verify JWT with legacy secret”，并说明只接受 legacy secret，建议自定义验证的函数关闭。因此仅本函数实际部署为 `verify_jwt=false`，已写入函数级配置。匿名及伪造 JWT 线上调用均由函数返回 `401/AUTH_REQUIRED`；正式项目 Auth 确认用户身份和原有 RLS 均保持强制，不允许匿名转发。

## 防护和限制

所有 DNS 答案必须为公网地址，私网、回环、保留、IPv4 映射 IPv6、Fake-IP 等均拒绝。实际 HTTP(S) 连接使用已经检查的数字 IP，原域名用于 Host、TLS SNI 和证书身份校验，避免检查后另一次 DNS 解析。无自定义代理、关闭证书验证或通用 URL 透传。接口正文最多 8 KiB，源 JSON 最多 3 MiB，总过程 12 秒、每次源请求最多 8 秒。响应必须能解析成含数组 `list` 的 AppleCMS JSON；部分源错误标注 `text/html` 仍可接受实际有效 JSON，HTML/XML/任意 JSON 均拒绝。

发送 `Accept-Encoding: identity`；不遵守且强行压缩的源会拒绝。每个 Edge 实例内每用户最多 16 并发、每分钟 240 请求；该限制不是分布式全局配额。没有缓存或日志保存账号令牌、源 URL/query、搜索内容或记录。免费平台额度、源的地域/防盗链和实际移动网络仍影响可用性；不保证全部片源可播。

## 验证

```powershell
npx --yes deno check --no-config supabase/functions/pps-source-relay/index.ts
npx --yes deno test --no-config --allow-env=PPS_RELAY_TEST supabase/functions/pps-source-relay/index.test.ts
npx --yes deno run --no-config --allow-env=PPS_RELAY_TEST --allow-net supabase/functions/pps-source-relay/network-smoke.ts
```

隔离测试不访问真实账号或网络，覆盖鉴权、RLS 参数、登记源、参数、SSRF、DNS 复查、重定向、响应格式/大小、超时取消和限速。可选网络 smoke 仅访问公开样例 JSON，验证本机 Deno 的数字 IP/TLS 原域名并拒绝错误证书身份；若本机 DNS 返回 Fake-IP，只在这项测试内改用公共 DoH 答案，不改变电脑或路由设置。通用 Deno 测试不等于 Supabase Edge Runtime 实测。

部署后必须检查允许/拒绝来源的预检、匿名和伪造 JWT 拒绝，并由真实家庭账号完成已同步源的搜索/详情及未登记源拒绝。只有预检/匿名 401 无法证明云端已执行 IP 固定连接或真实片源恢复。若项目额度暂停或真实账号尚未验证，应明确保留该未验证状态，不重复部署或读取用户密码。
