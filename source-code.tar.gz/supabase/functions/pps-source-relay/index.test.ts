// SPDX-License-Identifier: AGPL-3.0-or-later
// No real account, credential, database, or source network access in these tests.
import assert from 'node:assert/strict';
Deno.env.set('PPS_RELAY_TEST', '1');
const { createRelayHandler, isPublicAddress, matchesRegisteredSource } = await import('./index.ts');

const owner = '11111111-1111-4111-8111-111111111111';
const stored = 'https://cms.example.org/api.php/provide/vod/?token=fixture';
const url = stored + '&ac=videolist&wd=test&pg=1';
const bearer = 'Bearer fixture.claims.signature';
const jsonBytes = (value: unknown) => new TextEncoder().encode(JSON.stringify(value));
const upstreamJson = (value: unknown = { list: [] }, contentType = 'application/json') => ({ status: 200, headers: new Headers({ 'content-type': contentType }), body: jsonBytes(value) });
function fixture(options: {
  authStatus?: number; recordsStatus?: number; records?: unknown; now?: () => number;
  dns?: (host: string) => Promise<{ address: string; family: number }[]>;
  upstream?: (target: URL, address: { address: string; family: number }, signal: AbortSignal) => Promise<ReturnType<typeof upstreamJson>>;
} = {}) {
  const calls = { backend: [] as { url: URL; init?: RequestInit }[], upstream: [] as { url: URL; address: { address: string; family: number } }[], dns: [] as string[] };
  const handler = createRelayHandler({ supabaseUrl: 'https://fixture.supabase.co', anonKey: 'public-fixture' }, {
    backendFetch: (async (input: URL | RequestInfo, init?: RequestInit) => {
      const target = new URL(String(input)); calls.backend.push({ url: target, init });
      if (target.pathname === '/auth/v1/user') return Response.json({ id: owner }, { status: options.authStatus || 200 });
      assert.equal(target.pathname, '/rest/v1/pps_sync_records');
      assert.equal(target.searchParams.get('owner_id'), 'eq.' + owner);
      assert.equal(target.searchParams.get('kind'), 'eq.sources');
      assert.equal(target.searchParams.get('deleted'), 'eq.false');
      return Response.json(options.records ?? [{ record_key: stored, payload: { source: { url: stored } } }], { status: options.recordsStatus || 200 });
    }) as typeof fetch,
    resolve: async host => { calls.dns.push(host); return options.dns ? options.dns(host) : [{ address: '8.8.8.8', family: 4 }]; },
    upstream: async (target, address, signal) => {
      calls.upstream.push({ url: new URL(target), address });
      return options.upstream ? options.upstream(target, address, signal) : upstreamJson();
    },
    now: options.now,
  });
  const request = (value: unknown = { url }, init: RequestInit = {}) => new Request('https://fixture.supabase.co/functions/v1/pps-source-relay', {
    method: 'POST', headers: { origin: 'https://jingaox.github.io', authorization: bearer, 'content-type': 'application/json' },
    body: JSON.stringify(value), ...init,
  });
  return { handler, request, calls };
}
async function code(response: Response) { return (await response.json()).code; }

Deno.test('valid account source uses scoped RLS requests and only passes pinned IP to upstream', async () => {
  const f = fixture(); const response = await f.handler(f.request());
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { text: '{"list":[]}', url });
  assert.equal(response.headers.get('access-control-allow-origin'), 'https://jingaox.github.io');
  assert.equal(response.headers.get('cache-control'), 'no-store');
  assert(f.calls.backend.every(call => new Headers(call.init?.headers).get('authorization') === bearer));
  assert.deepEqual(f.calls.upstream[0].address, { address: '8.8.8.8', family: 4 });
});
Deno.test('preflight requires exact origin and carries no wildcard or credential grant', async () => {
  const f = fixture();
  const allowed = await f.handler(f.request(undefined, { method: 'OPTIONS', body: undefined }));
  assert.equal(allowed.status, 204); assert.equal(f.calls.backend.length, 0);
  assert.equal(allowed.headers.get('access-control-allow-credentials'), null);
  const denied = await f.handler(f.request({}, { headers: { origin: 'https://jingaox.github.io.attacker.org' } }));
  assert.equal(denied.status, 403); assert.equal(denied.headers.get('access-control-allow-origin'), null);
});
Deno.test('no-origin CLI callers still need verified account authentication', async () => {
  const f = fixture({ authStatus: 401 });
  const result = await f.handler(f.request({}, { headers: { authorization: bearer, 'content-type': 'application/json' } }));
  assert.equal(result.status, 401); assert.equal(await code(result), 'AUTH_REQUIRED');
  assert.equal(f.calls.upstream.length, 0);
});
Deno.test('missing bearer is rejected without contacting Auth, DB, or source', async () => {
  const f = fixture(); const result = await f.handler(f.request({}, { headers: { 'content-type': 'application/json' } }));
  assert.equal(await code(result), 'AUTH_REQUIRED'); assert.equal(f.calls.backend.length, 0);
});
Deno.test('Auth/database outages are errors, not account bypass or an empty success', async () => {
  for (const options of [{ authStatus: 503 }, { recordsStatus: 503 }]) {
    const f = fixture(options); const result = await f.handler(f.request());
    assert.equal(result.status, 503); assert.equal(await code(result), 'RELAY_UNAVAILABLE'); assert.equal(f.calls.upstream.length, 0);
  }
});
Deno.test('only sources already saved to the same account are approved', async () => {
  const f = fixture({ records: [] }); const result = await f.handler(f.request());
  assert.equal(result.status, 403); assert.equal(await code(result), 'SOURCE_NOT_SYNCED'); assert.equal(f.calls.dns.length, 0);
});
Deno.test('source identity is canonical, not raw-case/hash/whitespace spelling', async () => {
  const raw = ' HTTPS://CMS.EXAMPLE.ORG/api.php/provide/vod/?token=fixture#local-label ';
  const f = fixture({ records: [{ record_key: stored, payload: { source: { url: raw } } }] });
  assert.equal((await f.handler(f.request())).status, 200);
});
Deno.test('static source query tokens cannot be removed, replaced, duplicated, or extended', async () => {
  for (const target of [url.replace('token=fixture&', ''), url.replace('token=fixture', 'token=other'), url + '&token=other', url + '&next=http://127.0.0.1/']) {
    const f = fixture(); const result = await f.handler(f.request({ url: target }));
    assert.equal(await code(result), 'SOURCE_NOT_SYNCED'); assert.equal(f.calls.upstream.length, 0);
  }
  assert(matchesRegisteredSource(new URL(url.replace('/vod/', '/vod')), stored));
});
Deno.test('only read-only CMS list/detail/videolist parameters are accepted', async () => {
  for (const target of [url.replace('videolist', 'delete'), url + '&ac=list', url.replace('pg=1', 'pg=0'), url + '&ids=1%0D%0AHeader', url + '&wd=' + 'x'.repeat(257)]) {
    const f = fixture(); assert.equal(await code(await f.handler(f.request({ url: target }))), 'SOURCE_BLOCKED');
    assert.equal(f.calls.upstream.length, 0);
  }
});
Deno.test('private/reserved IPv4 and IPv6 forms are denied including mapped/numeric addresses', () => {
  for (const ip of ['127.0.0.1', '0.0.0.0', '10.1.2.3', '100.64.0.1', '172.16.2.3', '192.168.1.1', '169.254.169.254', '198.18.0.1', '192.0.2.1', '224.0.0.1', '255.255.255.255', '::1', '::', '::ffff:127.0.0.1', 'fc00::1', 'fe80::1', '2001:db8::1', '2001:2::1', '2002:7f00:1::1', '3fff::1']) assert.equal(isPublicAddress(ip), false, ip);
  for (const ip of ['8.8.8.8', '1.1.1.1', '2606:4700:4700::1111', '2001:4860:4860::8888']) assert.equal(isPublicAddress(ip), true, ip);
});
Deno.test('URL credentials, odd schemes, local hostnames and nonstandard ports are blocked', async () => {
  for (const target of ['http://2130706433/?ac=list', 'http://0x7f000001/?ac=list', 'http://[::ffff:127.0.0.1]/?ac=list', 'http://localhost/?ac=list', 'http://service.internal/?ac=list', 'file:///etc/passwd?ac=list', 'https://user:pass@cms.example.org/?ac=list', 'https://cms.example.org:9090/?ac=list']) {
    const f = fixture(); assert.equal(await code(await f.handler(f.request({ url: target }))), 'SOURCE_BLOCKED', target);
  }
});
Deno.test('DNS answers with any non-public A/AAAA block the entire request before connection', async () => {
  for (const address of ['10.0.0.1', '::ffff:10.0.0.1', 'fe80::1']) {
    const f = fixture({ dns: async () => [{ address: '8.8.8.8', family: 4 }, { address, family: address.includes(':') ? 6 : 4 }] });
    assert.equal(await code(await f.handler(f.request())), 'SOURCE_BLOCKED'); assert.equal(f.calls.upstream.length, 0);
  }
});
Deno.test('redirect targets are revalidated and private or unregistered paths never connect', async () => {
  for (const location of ['http://169.254.169.254/latest/meta-data/?ac=list', 'https://cms.example.org/private?ac=list', 'https://other.example.org/api?ac=list']) {
    const f = fixture({ upstream: async () => ({ status: 302, headers: new Headers({ location }), body: new Uint8Array() }) });
    assert.equal(await code(await f.handler(f.request())), 'SOURCE_BLOCKED'); assert.equal(f.calls.upstream.length, 1);
  }
});
Deno.test('DNS is checked again on redirect and the first checked address is pinned', async () => {
  let resolutions = 0;
  const f = fixture({ dns: async () => [{ address: ++resolutions === 1 ? '8.8.8.8' : '127.0.0.1', family: 4 }], upstream: async () => ({ status: 302, headers: new Headers({ location: url.replace('pg=1', 'pg=2') }), body: new Uint8Array() }) });
  assert.equal(await code(await f.handler(f.request())), 'SOURCE_BLOCKED');
  assert.equal(f.calls.upstream.length, 1); assert.equal(f.calls.upstream[0].address.address, '8.8.8.8');
});
Deno.test('registered HTTP source may upgrade to HTTPS on the same host/path/query, never downgrade', async () => {
  const httpStored = stored.replace('https:', 'http:');
  assert(matchesRegisteredSource(new URL(url), httpStored));
  assert.equal(matchesRegisteredSource(new URL(url.replace('https:', 'http:')), stored), false);
  const f = fixture({ records: [{ record_key: httpStored, payload: { source: { url: httpStored } } }], upstream: async target => target.protocol === 'http:'
    ? { status: 301, headers: new Headers({ location: url }), body: new Uint8Array() } : upstreamJson() });
  assert.equal((await f.handler(f.request({ url: url.replace('https:', 'http:') }))).status, 200);
  assert.equal(f.calls.upstream.length, 2);
});
Deno.test('valid JSON labelled text/html (standard AppleCMS APIs) is accepted', async () => {
  const f = fixture({ upstream: async () => upstreamJson({ list: [{ vod_id: 1 }] }, 'text/html;charset=utf-8') });
  assert.equal((await f.handler(f.request())).status, 200);
});
Deno.test('HTML, invalid JSON, XML and non-CMS JSON are never relayed as content', async () => {
  for (const value of ['<html>login</html>', '<rss/>', '{bad', '[]', '{"secret":"not CMS"}']) {
    const f = fixture({ upstream: async () => ({ status: 200, headers: new Headers({ 'content-type': 'text/html' }), body: new TextEncoder().encode(value) }) });
    const response = await f.handler(f.request()); assert.equal(response.status, 502); assert.equal(await code(response), 'UPSTREAM_INVALID');
  }
});
Deno.test('upstream status and response-size failures are bounded semantic errors', async () => {
  const f = fixture({ upstream: async () => ({ ...upstreamJson(), status: 503 }) });
  assert.equal(await code(await f.handler(f.request())), 'UPSTREAM_FAILED');
  const large = fixture({ upstream: async () => ({ ...upstreamJson(), body: new Uint8Array(3 * 1024 * 1024 + 1) }) });
  assert.equal(await code(await large.handler(large.request())), 'UPSTREAM_TOO_LARGE');
});
Deno.test('extra body fields, oversized JSON, and non-JSON request are rejected', async () => {
  for (const value of [{ url, headers: { authorization: 'stolen' } }, { url: 'x'.repeat(9000) }, []]) {
    const f = fixture(); const response = await f.handler(f.request(value)); assert([400, 413].includes(response.status)); assert.equal(f.calls.upstream.length, 0);
  }
});
Deno.test('cancelled DNS lookup exits promptly and releases account concurrent slot', async () => {
  const controller = new AbortController();
  const f = fixture({ dns: () => new Promise(() => undefined) });
  const result = f.handler(f.request({ url }, { signal: controller.signal }));
  setTimeout(() => controller.abort(), 10);
  assert.equal(await code(await result), 'RELAY_TIMEOUT');
});
Deno.test('modest per-account burst limiter is enforced without source requests or credential output', async () => {
  const f = fixture({ now: () => 1000 });
  for (let i = 0; i < 240; i++) assert.equal((await f.handler(f.request())).status, 200);
  const denied = await f.handler(f.request()); assert.equal(denied.status, 429); assert.equal(await code(denied), 'RATE_LIMITED');
  assert.equal(f.calls.upstream.length, 240);
});
