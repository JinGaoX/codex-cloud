// SPDX-License-Identifier: AGPL-3.0-or-later
// Account-private AppleCMS JSON relay. Never proxies media, cookies, or bearer
// tokens to sources. This single file can be deployed from Supabase Dashboard.
import { request as httpRequest, type IncomingMessage } from 'node:http';
import { request as httpsRequest } from 'node:https';
import { lookup } from 'node:dns/promises';
import { isIP } from 'node:net';
import { checkServerIdentity } from 'node:tls';

declare const Deno: {
  env: { get(name: string): string | undefined };
  serve(handler: (request: Request) => Promise<Response>): unknown;
};

const MAX_BODY = 8192;
const MAX_RESPONSE = 3 * 1024 * 1024;
const TOTAL_TIMEOUT = 12000;
const API_PARAMS = new Set(['ac', 'wd', 'ids', 'pg']);
const DEFAULT_ORIGINS = ['https://jingaox.github.io', 'http://localhost:8080', 'http://127.0.0.1:8080'];

class RelayError extends Error {
  constructor(public status: number, public code: string, message: string) { super(message); }
}
const blocked = () => new RelayError(403, 'SOURCE_BLOCKED', '该片源地址或请求参数不允许通过账号中转');
const unavailable = () => new RelayError(503, 'RELAY_UNAVAILABLE', '账号中转暂时不可用，请稍后重试');
type Address = { address: string; family: number };
type Upstream = { status: number; headers: Headers; body: Uint8Array };
type Dependencies = {
  backendFetch?: typeof fetch;
  resolve?: (host: string) => Promise<Address[]>;
  upstream?: (url: URL, address: Address, signal: AbortSignal) => Promise<Upstream>;
  now?: () => number;
};
export type RelayConfig = { supabaseUrl: string; anonKey: string; allowedOrigins?: string[] };

/** Conservative global-unicast-only policy, including IPv4-mapped IPv6. */
export function isPublicAddress(raw: string): boolean {
  const ip = raw.toLowerCase().replace(/^\[|\]$/g, '');
  if (isIP(ip) === 4) {
    const [a, b, c] = ip.split('.').map(Number);
    return !(a === 0 || a === 10 || a === 127 || a >= 224
      || (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254)
      || (a === 172 && b >= 16 && b <= 31) || (a === 192 && (b === 168 || b === 0 || (b === 88 && c === 99)))
      || (a === 198 && (b === 18 || b === 19 || (b === 51 && c === 100)))
      || (a === 203 && b === 0 && c === 113));
  }
  if (isIP(ip) !== 6 || ip.includes('%')) return false;
  // Accept only 2000::/3. This excludes loopback, ULA, link-local, multicast,
  // IPv4-mapped, translation, unspecified and other non-global address spaces.
  const first = Number.parseInt(ip.split(':')[0], 16);
  if (!Number.isFinite(first) || first < 0x2000 || first > 0x3fff) return false;
  const normalized = new URL(`http://[${ip}]/`).hostname.slice(1, -1);
  const second = Number.parseInt(normalized.split(':')[1] || '0', 16);
  return !((first === 0x2001 && second < 0x200) || /^2001:db8(?::|$)/.test(normalized)
    || first === 0x2002 || first >= 0x3ffe); // special-use, documentation, Teredo, 6to4, 6bone
}

function safeUrl(raw: unknown): URL {
  if (typeof raw !== 'string' || raw.length > 4096 || /[\u0000-\u0020\u007f\\]/.test(raw)) throw blocked();
  let url: URL;
  try { url = new URL(raw); } catch { throw blocked(); }
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.hash
    || (url.port && !['80', '443'].includes(url.port))) throw blocked();
  const host = url.hostname.replace(/^\[|\]$/g, '');
  if (!host || host.endsWith('.') || (!isIP(host) && (!host.includes('.')
    || /(?:^|\.)(?:localhost|local|internal|home|lan|test|invalid|example|onion)$/.test(host)))) throw blocked();
  if (isIP(host) && !isPublicAddress(host)) throw blocked();
  return url;
}

/** Static query pairs must match the stored source; only four CMS controls vary. */
export function matchesRegisteredSource(target: URL, stored: string): boolean {
  let base: URL;
  try { base = safeUrl(stored); } catch { return false; }
  const apiPath = (value: string) => value.replace(/\/+$/, '') || '/';
  const sameOrigin = base.origin === target.origin;
  const secureUpgrade = base.protocol === 'http:' && target.protocol === 'https:'
    && base.hostname === target.hostname && !base.port && !target.port;
  if ((!sameOrigin && !secureUpgrade) || apiPath(base.pathname) !== apiPath(target.pathname)) return false;
  const keys = new Set([...base.searchParams.keys(), ...target.searchParams.keys()]);
  for (const key of keys) {
    if (API_PARAMS.has(key)) continue;
    if (JSON.stringify(base.searchParams.getAll(key)) !== JSON.stringify(target.searchParams.getAll(key))) return false;
  }
  return true;
}

function validateCmsParams(url: URL): void {
  for (const key of API_PARAMS) if (url.searchParams.getAll(key).length > 1) throw blocked();
  if (!['list', 'detail', 'videolist'].includes(url.searchParams.get('ac') || '')) throw blocked();
  const wd = url.searchParams.get('wd');
  const ids = url.searchParams.get('ids');
  const pg = url.searchParams.get('pg');
  if (wd !== null && (wd.length > 256 || /[\u0000-\u001f\u007f]/.test(wd))) throw blocked();
  if (ids !== null && !/^[A-Za-z0-9_,.-]{1,2048}$/.test(ids)) throw blocked();
  if (pg !== null && (!/^[1-9]\d{0,4}$/.test(pg) || Number(pg) > 10000)) throw blocked();
}

async function boundedBody(body: ReadableStream<Uint8Array> | null, limit: number, signal: AbortSignal): Promise<Uint8Array> {
  if (!body) return new Uint8Array();
  const reader = body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  const onAbort = () => { void reader.cancel().catch(() => undefined); };
  signal.addEventListener('abort', onAbort, { once: true });
  try {
    for (;;) {
      signal.throwIfAborted();
      const next = await reader.read();
      signal.throwIfAborted();
      if (next.done) break;
      total += next.value.byteLength;
      if (total > limit) {
        await reader.cancel();
        throw new RelayError(413, 'BODY_TOO_LARGE', '数据超过允许大小');
      }
      chunks.push(next.value);
    }
  } finally { signal.removeEventListener('abort', onAbort); reader.releaseLock(); }
  const joined = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { joined.set(chunk, offset); offset += chunk.byteLength; }
  return joined;
}

function abortable<T>(operation: Promise<T>, signal: AbortSignal): Promise<T> {
  signal.throwIfAborted();
  return new Promise((resolve, reject) => {
    const abort = () => reject(signal.reason || new Error('Aborted'));
    signal.addEventListener('abort', abort, { once: true });
    operation.then(resolve, reject).finally(() => signal.removeEventListener('abort', abort));
  });
}

/**
 * Connect to the checked numeric IP, never the original DNS name. Host, TLS SNI
 * and certificate identity remain the registered hostname. No Agent/proxy or
 * createConnection hook is used; the caller's credentials are never forwarded.
 */
export function pinnedRequest(url: URL, address: Address, signal: AbortSignal): Promise<Upstream> {
  return new Promise((resolve, reject) => {
    signal.throwIfAborted();
    const originalHost = url.hostname.replace(/^\[|\]$/g, '');
    if (!isPublicAddress(address.address) || isIP(address.address) !== address.family) return reject(blocked());
    const options = {
      hostname: address.address, family: address.family, port: Number(url.port || (url.protocol === 'https:' ? 443 : 80)),
      method: 'GET', path: url.pathname + url.search, agent: false as const, signal,
      headers: { Host: url.host, Accept: 'application/json', 'Accept-Encoding': 'identity', 'User-Agent': 'PPS-Account-Source/1.0' },
      ...(url.protocol === 'https:' ? {
        servername: isIP(originalHost) ? undefined : originalHost,
        rejectUnauthorized: true,
        checkServerIdentity: (_host: string, cert: Parameters<typeof checkServerIdentity>[1]) => checkServerIdentity(originalHost, cert),
      } : {}),
    };
    const receive = (response: IncomingMessage) => {
      const headers = new Headers();
      for (const [key, value] of Object.entries(response.headers)) {
        if (Array.isArray(value)) headers.set(key, value.join(', '));
        else if (typeof value === 'string') headers.set(key, value);
      }
      const status = response.statusCode || 502;
      // Redirects are inspected by the caller; their bodies are not consumed.
      if (status >= 300 && status < 400) { response.destroy(); resolve({ status, headers, body: new Uint8Array() }); return; }
      if (headers.get('content-encoding') && headers.get('content-encoding') !== 'identity') {
        response.destroy(); reject(new RelayError(502, 'UPSTREAM_INVALID', '片源没有按要求返回未压缩 JSON')); return;
      }
      if (Number(headers.get('content-length')) > MAX_RESPONSE) {
        response.destroy(); reject(new RelayError(502, 'UPSTREAM_TOO_LARGE', '片源响应过大')); return;
      }
      const chunks: Uint8Array[] = [];
      let total = 0;
      response.on('data', (part: Uint8Array) => {
        total += part.byteLength;
        if (total > MAX_RESPONSE) { response.destroy(); reject(new RelayError(502, 'UPSTREAM_TOO_LARGE', '片源响应过大')); }
        else chunks.push(part);
      });
      response.on('error', reject);
      response.on('aborted', () => reject(new RelayError(502, 'UPSTREAM_FAILED', '片源连接中断')));
      response.on('end', () => {
        const body = new Uint8Array(total);
        let offset = 0;
        for (const part of chunks) { body.set(part, offset); offset += part.byteLength; }
        resolve({ status, headers, body });
      });
    };
    const outgoing = url.protocol === 'https:' ? httpsRequest(options, receive) : httpRequest(options, receive);
    outgoing.once('error', reject);
    outgoing.end();
  });
}

export function createRelayHandler(config: RelayConfig, dependencies: Dependencies = {}) {
  const backendFetch = dependencies.backendFetch || fetch;
  const resolveDns = dependencies.resolve || ((hostname: string) => lookup(hostname, { all: true, verbatim: true }));
  const getUpstream = dependencies.upstream || pinnedRequest;
  const now = dependencies.now || Date.now;
  const origins = new Set((config.allowedOrigins || DEFAULT_ORIGINS).filter((value) => {
    try { const u = new URL(value); return ['http:', 'https:'].includes(u.protocol) && u.origin === value && !u.username && !u.password; }
    catch { return false; }
  }));
  // Per-isolate abuse limits supplement authentication and platform quotas.
  // They are deliberately not presented as a distributed/global rate limit.
  const users = new Map<string, { start: number; count: number; active: number }>();
  return async (request: Request): Promise<Response> => {
    const origin = request.headers.get('origin');
    const headers = new Headers({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', Vary: 'Origin', 'X-Content-Type-Options': 'nosniff' });
    if (origin && origins.has(origin)) {
      headers.set('Access-Control-Allow-Origin', origin);
      headers.set('Access-Control-Allow-Methods', 'POST, OPTIONS');
      headers.set('Access-Control-Allow-Headers', 'authorization, apikey, content-type, x-client-info');
      headers.set('Access-Control-Max-Age', '600');
    }
    const json = (value: unknown, status = 200) => new Response(JSON.stringify(value), { status, headers });
    if (origin && !origins.has(origin)) return json({ error: '该网站不允许调用账号中转', code: 'ORIGIN_BLOCKED' }, 403);
    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });
    if (request.method !== 'POST') return json({ error: '仅支持 POST', code: 'METHOD_NOT_ALLOWED' }, 405);
    const controller = new AbortController();
    if (request.signal.aborted) controller.abort();
    const timer = setTimeout(() => controller.abort(), TOTAL_TIMEOUT);
    const signal = controller.signal;
    const abort = () => controller.abort();
    request.signal.addEventListener('abort', abort, { once: true });
    let slot: { start: number; count: number; active: number } | undefined;
    try {
      const authorization = request.headers.get('authorization') || '';
      if (!/^Bearer [A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(authorization) || authorization.length > 8192) {
        throw new RelayError(401, 'AUTH_REQUIRED', '请先登录家庭账号');
      }
      let backend: URL;
      try { backend = new URL(config.supabaseUrl); } catch { throw unavailable(); }
      if (backend.protocol !== 'https:' || !backend.hostname.endsWith('.supabase.co') || backend.pathname !== '/' || backend.search || backend.username || backend.password || !config.anonKey) throw unavailable();
      const backendHeaders = { apikey: config.anonKey, Authorization: authorization, Accept: 'application/json' };
      let authResponse: Response;
      try { authResponse = await backendFetch(new URL('/auth/v1/user', backend), { headers: backendHeaders, redirect: 'error', signal }); }
      catch { throw unavailable(); }
      if ([401, 403].includes(authResponse.status)) throw new RelayError(401, 'AUTH_REQUIRED', '登录已失效，请重新登录');
      if (!authResponse.ok) throw unavailable();
      let user: { id?: unknown };
      try { user = JSON.parse(new TextDecoder().decode(await boundedBody(authResponse.body, 128 * 1024, signal))); }
      catch { throw unavailable(); }
      if (!user || typeof user.id !== 'string' || !/^[a-f0-9-]{36}$/i.test(user.id)) throw new RelayError(401, 'AUTH_REQUIRED', '无法确认家庭账号');

      const instant = now();
      if (users.size > 2048) for (const [id, value] of users) if (!value.active && instant - value.start >= 60000) users.delete(id);
      slot = users.get(user.id);
      if (!slot) { slot = { start: instant, count: 0, active: 0 }; users.set(user.id, slot); }
      if (instant - slot.start >= 60000) { slot.start = instant; slot.count = 0; }
      if (slot.active >= 16 || slot.count >= 240) { slot = undefined; throw new RelayError(429, 'RATE_LIMITED', '请求较多，请稍后重试'); }
      slot.count++; slot.active++;

      if (!request.headers.get('content-type')?.toLowerCase().startsWith('application/json')) throw new RelayError(400, 'INVALID_REQUEST', '请求必须为 JSON');
      if (Number(request.headers.get('content-length')) > MAX_BODY) throw new RelayError(413, 'BODY_TOO_LARGE', '请求过大');
      let body: { url?: unknown };
      try { body = JSON.parse(new TextDecoder().decode(await boundedBody(request.body, MAX_BODY, signal))); }
      catch (error) { if (error instanceof RelayError) throw error; throw new RelayError(400, 'INVALID_REQUEST', '请求格式不正确'); }
      if (!body || typeof body !== 'object' || Array.isArray(body) || Object.keys(body).some(key => key !== 'url')) throw new RelayError(400, 'INVALID_REQUEST', '请求格式不正确');
      let target = safeUrl(body.url);
      validateCmsParams(target);

      const recordsUrl = new URL('/rest/v1/pps_sync_records', backend);
      recordsUrl.search = new URLSearchParams({ select: 'record_key,payload', owner_id: `eq.${user.id}`, kind: 'eq.sources', deleted: 'eq.false', limit: '1000' }).toString();
      let recordResponse: Response;
      try { recordResponse = await backendFetch(recordsUrl, { headers: backendHeaders, redirect: 'error', signal }); }
      catch { throw unavailable(); }
      if ([401, 403].includes(recordResponse.status)) throw new RelayError(401, 'AUTH_REQUIRED', '登录或账号同步权限已失效');
      if (!recordResponse.ok) throw unavailable();
      let records: unknown;
      try { records = JSON.parse(new TextDecoder().decode(await boundedBody(recordResponse.body, 2 * 1024 * 1024, signal))); }
      catch { throw unavailable(); }
      if (!Array.isArray(records)) throw unavailable();
      const sourceUrls: string[] = records.flatMap(row => {
        const value = row?.payload?.source?.url;
        if (typeof value !== 'string') return [];
        try {
          const normalized = new URL(value.trim());
          normalized.hash = '';
          const safe = safeUrl(normalized.href);
          return row.record_key === safe.href ? [safe.href] : [];
        } catch { return []; }
      });
      if (!sourceUrls.some(stored => matchesRegisteredSource(target, stored))) throw new RelayError(403, 'SOURCE_NOT_SYNCED', '请先把该点播源同步到当前家庭账号');

      for (let redirects = 0; redirects <= 2; redirects++) {
        signal.throwIfAborted();
        const hostname = target.hostname.replace(/^\[|\]$/g, '');
        const addresses: Address[] = isIP(hostname) ? [{ address: hostname, family: isIP(hostname) }] : await abortable(resolveDns(hostname), signal);
        signal.throwIfAborted();
        if (!addresses.length || addresses.length > 32 || addresses.some(x => !isPublicAddress(x.address) || isIP(x.address) !== x.family)) throw blocked();
        // Prefer IPv4 for sources that publish broken/unreachable AAAA records.
        const address = addresses.find(x => x.family === 4) || addresses[0];
        const sourceController = new AbortController();
        const abortSource = () => sourceController.abort();
        signal.addEventListener('abort', abortSource, { once: true });
        const sourceTimer = setTimeout(abortSource, 8000);
        let result: Upstream;
        try { result = await abortable(getUpstream(target, address, sourceController.signal), sourceController.signal); }
        catch (error) {
          if (sourceController.signal.aborted) throw new RelayError(504, 'RELAY_TIMEOUT', '片源响应超时，请切换其他片源');
          throw error;
        } finally { clearTimeout(sourceTimer); signal.removeEventListener('abort', abortSource); }
        signal.throwIfAborted();
        if ([301, 302, 303, 307, 308].includes(result.status)) {
          const location = result.headers.get('location');
          if (!location || redirects === 2) throw new RelayError(502, 'UPSTREAM_FAILED', '片源重定向过多或无效');
          let redirected: URL;
          try { redirected = safeUrl(new URL(location, target).href); } catch { throw blocked(); }
          validateCmsParams(redirected);
          if (!sourceUrls.some(stored => matchesRegisteredSource(redirected, stored))) throw blocked();
          target = redirected;
          continue;
        }
        if (result.status < 200 || result.status >= 300) throw new RelayError(502, 'UPSTREAM_FAILED', '片源请求失败，请切换其他片源');
        if (result.body.byteLength > MAX_RESPONSE) throw new RelayError(502, 'UPSTREAM_TOO_LARGE', '片源响应过大');
        // Some AppleCMS APIs incorrectly label valid JSON as text/html. Accept
        // only the bounded, parsed JSON object/list below; never render markup.
        let text: string;
        let data: unknown;
        try { text = new TextDecoder('utf-8', { fatal: true }).decode(result.body); data = JSON.parse(text); }
        catch { throw new RelayError(502, 'UPSTREAM_INVALID', '片源 JSON 无法读取'); }
        if (!data || typeof data !== 'object' || Array.isArray(data) || !Array.isArray((data as { list?: unknown }).list)) throw new RelayError(502, 'UPSTREAM_INVALID', '片源没有返回 AppleCMS list 列表');
        return json({ text, url: target.href });
      }
      throw new RelayError(502, 'UPSTREAM_FAILED', '片源请求失败');
    } catch (error) {
      if (signal.aborted) return json({ error: '账号中转或片源请求超时，请稍后重试', code: 'RELAY_TIMEOUT' }, 504);
      if (error instanceof RelayError) return json({ error: error.message, code: error.code }, error.status);
      // Never include upstream URL, DNS address, API token, or error stack.
      return json({ error: '片源连接失败，请切换其他片源', code: 'UPSTREAM_FAILED' }, 502);
    } finally {
      if (slot) slot.active--;
      clearTimeout(timer);
      request.signal.removeEventListener('abort', abort);
    }
  };
}

if (typeof Deno !== 'undefined' && Deno.env.get('PPS_RELAY_TEST') !== '1') {
  const origins = Deno.env.get('PPS_RELAY_ALLOWED_ORIGINS');
  Deno.serve(createRelayHandler({
    supabaseUrl: Deno.env.get('SUPABASE_URL') || '',
    anonKey: Deno.env.get('SUPABASE_ANON_KEY') || '',
    ...(origins ? { allowedOrigins: origins.split(',').map(value => value.trim()).filter(Boolean) } : {}),
  }));
}
