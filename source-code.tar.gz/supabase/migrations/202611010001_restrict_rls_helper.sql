-- SPDX-License-Identifier: AGPL-3.0-or-later
-- Supabase's optional automatic-RLS helper is an event-trigger function, not
-- a client RPC. Preserve its body, owner and event-trigger registration while
-- removing unnecessary public/client EXECUTE grants.
-- This does not alter existing application tables or disable automatic RLS.
do $migration$
declare
  v_function oid := pg_catalog.to_regprocedure('public.rls_auto_enable()');
  v_definition record;
begin
  if v_function is null then
    if exists (
      select 1 from pg_catalog.pg_proc p
      join pg_catalog.pg_namespace n on n.oid = p.pronamespace
      where n.nspname = 'public' and p.proname = 'rls_auto_enable'
    ) then
      raise exception using errcode = '55000',
        message = 'Unexpected rls_auto_enable signature; no privileges changed';
    end if;
    -- Projects created without the optional helper need no change.
    raise notice 'public.rls_auto_enable() is absent; no privileges changed';
    return;
  end if;

  select p.prorettype, p.prosecdef, p.prokind, p.pronargs, r.rolname as owner_name
    into v_definition
    from pg_catalog.pg_proc p
    join pg_catalog.pg_roles r on r.oid = p.proowner
    where p.oid = v_function;
  if not found or v_definition.prorettype <> 'pg_catalog.event_trigger'::regtype
      or not v_definition.prosecdef or v_definition.prokind <> 'f'
      or v_definition.pronargs <> 0
      or v_definition.owner_name in ('anon', 'authenticated') then
    raise exception using errcode = '55000',
      message = 'Unexpected automatic-RLS helper definition; no privileges changed';
  end if;

  revoke execute on function public.rls_auto_enable() from public, anon, authenticated;
end;
$migration$;
