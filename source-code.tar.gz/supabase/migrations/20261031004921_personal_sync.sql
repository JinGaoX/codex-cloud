-- SPDX-License-Identifier: AGPL-3.0-or-later
-- Optional personal sync only. Supabase Auth owns credentials and token verification.
-- Existing browser-local data is neither read nor imported by this migration.

create schema if not exists pps_private;
revoke all on schema pps_private from public, anon;
grant usage on schema pps_private to authenticated;

create table public.pps_sync_heads (
  owner_id uuid primary key references auth.users(id) on delete cascade,
  revision bigint not null default 0 check (revision >= 0 and revision <= 9007199254740991)
);

create table public.pps_sync_records (
  owner_id uuid not null references auth.users(id) on delete cascade,
  kind text not null check (kind in ('sources', 'history', 'progress', 'favorites')),
  record_key text not null check (length(record_key) between 1 and 4096),
  payload jsonb,
  revision bigint not null check (revision > 0 and revision <= 9007199254740991),
  deleted boolean not null,
  updated_at timestamptz not null default clock_timestamp(),
  primary key (owner_id, kind, record_key),
  constraint pps_sync_payload_shape check (
    (deleted and payload is null) or
    (not deleted and jsonb_typeof(payload) = 'object' and octet_length(payload::text) <= 65536)
  )
);

-- A cursor scans only this account's changes, not all households' records.
create index pps_sync_records_owner_revision_idx
  on public.pps_sync_records (owner_id, revision);

alter table public.pps_sync_heads enable row level security;
alter table public.pps_sync_heads force row level security;
alter table public.pps_sync_records enable row level security;
alter table public.pps_sync_records force row level security;

-- Revoke Supabase projects' possible default grants before adding the exact grants.
revoke all on public.pps_sync_heads, public.pps_sync_records from public, anon, authenticated;
grant select on public.pps_sync_heads, public.pps_sync_records to authenticated;

create policy pps_sync_heads_owner_select on public.pps_sync_heads
  for select to authenticated using ((select auth.uid()) = owner_id);
create policy pps_sync_records_owner_select on public.pps_sync_records
  for select to authenticated using ((select auth.uid()) = owner_id);

-- The privileged write function is outside the exposed public schema. The public
-- wrapper below is SECURITY INVOKER; there is no general-purpose SQL/data endpoint.
create function pps_private.sync_personal_records(
  p_changes jsonb default '[]'::jsonb,
  p_cursor bigint default 0
)
returns jsonb
language plpgsql
security definer
set search_path = ''
as $function$
declare
  v_owner uuid := auth.uid();
  v_revision bigint;
  v_change jsonb;
  v_existing public.pps_sync_records%rowtype;
  v_expected bigint;
  v_conflicts jsonb := '[]'::jsonb;
  v_records jsonb;
begin
  if v_owner is null or not exists (select 1 from auth.users as u where u.id = v_owner) then
    raise exception using errcode = '42501', message = 'Authentication required';
  end if;
  if p_cursor is null or p_cursor < 0 or p_cursor > 9007199254740991 then
    raise exception using errcode = '22023', message = 'Invalid sync cursor';
  end if;
  if jsonb_typeof(p_changes) is distinct from 'array' then
    raise exception using errcode = '22023', message = 'Changes must be an array';
  end if;
  if jsonb_array_length(p_changes) > 500 or octet_length(p_changes::text) > 2097152 then
    raise exception using errcode = '22023', message = 'Sync batch too large';
  end if;

  -- Validate the entire batch before creating a head or modifying any record.
  for v_change in select value from jsonb_array_elements(p_changes) loop
    if jsonb_typeof(v_change) is distinct from 'object' then
      raise exception using errcode = '22023', message = 'Invalid sync change';
    end if;
    if exists (select 1 from jsonb_object_keys(v_change) as k(name)
      where k.name not in ('kind', 'key', 'baseRevision', 'payload')) then
      raise exception using errcode = '22023', message = 'Unknown sync change field';
    end if;
    if jsonb_typeof(v_change->'kind') is distinct from 'string' or
       v_change->>'kind' not in ('sources', 'history', 'progress', 'favorites') or
       jsonb_typeof(v_change->'key') is distinct from 'string' or
       length(v_change->>'key') not between 1 and 4096 or
       jsonb_typeof(v_change->'baseRevision') is distinct from 'number' then
      raise exception using errcode = '22023', message = 'Invalid sync identity or revision';
    end if;
    if (v_change->>'baseRevision')::numeric < 0 or
       (v_change->>'baseRevision')::numeric > 9007199254740991 or
       trunc((v_change->>'baseRevision')::numeric) <> (v_change->>'baseRevision')::numeric then
      raise exception using errcode = '22023', message = 'Invalid base revision';
    end if;
    if not (v_change ? 'payload') or
       jsonb_typeof(v_change->'payload') not in ('object', 'null') or
       octet_length((v_change->'payload')::text) > 65536 then
      raise exception using errcode = '22023', message = 'Invalid sync payload';
    end if;
  end loop;
  if exists (
    select 1 from jsonb_array_elements(p_changes) as c(value)
    group by c.value->>'kind', c.value->>'key' having count(*) > 1
  ) then
    raise exception using errcode = '22023', message = 'Duplicate record in sync batch';
  end if;

  insert into public.pps_sync_heads(owner_id) values (v_owner)
    on conflict (owner_id) do nothing;
  select h.revision into v_revision from public.pps_sync_heads as h
    where h.owner_id = v_owner for update;

  if p_cursor > v_revision then
    raise exception using errcode = '22023', message = 'Sync cursor is ahead of server';
  end if;

  -- One per-account lock covers conflict checking and writing. No external I/O or
  -- user-supplied owner is involved, and one conflict rejects the complete batch.
  for v_change in select value from jsonb_array_elements(p_changes) loop
    select r.* into v_existing from public.pps_sync_records as r
      where r.owner_id = v_owner and r.kind = v_change->>'kind'
        and r.record_key = v_change->>'key';
    v_expected := (v_change->>'baseRevision')::bigint;
    if coalesce(v_existing.revision, 0) <> v_expected then
      v_conflicts := v_conflicts || jsonb_build_array(jsonb_build_object(
        'kind', v_change->>'kind', 'key', v_change->>'key',
        'payload', v_existing.payload, 'revision', coalesce(v_existing.revision, 0),
        'deleted', coalesce(v_existing.deleted, true),
        'updatedAt', floor(extract(epoch from v_existing.updated_at) * 1000)::bigint
      ));
    end if;
  end loop;

  if jsonb_array_length(v_conflicts) = 0 then
    for v_change in select value from jsonb_array_elements(p_changes) loop
      if v_revision >= 9007199254740991 then
        raise exception using errcode = '22023', message = 'Sync revision exhausted';
      end if;
      v_revision := v_revision + 1;
      insert into public.pps_sync_records(owner_id, kind, record_key, payload, revision, deleted, updated_at)
        values (v_owner, v_change->>'kind', v_change->>'key',
          case when v_change->'payload' = 'null'::jsonb then null else v_change->'payload' end,
          v_revision, v_change->'payload' = 'null'::jsonb, clock_timestamp())
        on conflict (owner_id, kind, record_key) do update set
          payload = excluded.payload, revision = excluded.revision,
          deleted = excluded.deleted, updated_at = excluded.updated_at;
    end loop;
    if jsonb_array_length(p_changes) > 0 then
      update public.pps_sync_heads set revision = v_revision where owner_id = v_owner;
    end if;
  end if;

  select coalesce(jsonb_agg(jsonb_build_object(
    'kind', r.kind, 'key', r.record_key, 'payload', r.payload,
    'revision', r.revision, 'deleted', r.deleted,
    'updatedAt', floor(extract(epoch from r.updated_at) * 1000)::bigint
  ) order by r.revision, r.kind, r.record_key), '[]'::jsonb)
    into v_records from public.pps_sync_records as r
    where r.owner_id = v_owner and r.revision > p_cursor;

  return jsonb_build_object('revision', v_revision,
    'accepted', jsonb_array_length(v_conflicts) = 0,
    'records', v_records, 'conflicts', v_conflicts);
end;
$function$;

revoke all on function pps_private.sync_personal_records(jsonb, bigint) from public, anon;
grant execute on function pps_private.sync_personal_records(jsonb, bigint) to authenticated;

create function public.pps_sync(p_changes jsonb default '[]'::jsonb, p_cursor bigint default 0)
returns jsonb
language sql
security invoker
set search_path = ''
as $function$
  select pps_private.sync_personal_records(p_changes, p_cursor);
$function$;

revoke all on function public.pps_sync(jsonb, bigint) from public, anon;
grant execute on function public.pps_sync(jsonb, bigint) to authenticated;

comment on function public.pps_sync(jsonb, bigint) is
  'Account-private CAS sync. NULL payload is a durable tombstone. All changes are rejected on any conflict.';
