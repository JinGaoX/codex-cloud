// SPDX-License-Identifier: AGPL-3.0-or-later
// Upgrade + mixed-version integration tests in isolated PostgreSQL/WASM.
// Does not contact Supabase or read any real account, token, or payload.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');
const { PGlite } = require(process.env.PPS_PGLITE_PATH || path.join(root, 'artifacts/backend-tests/node_modules/@electric-sql/pglite'));
const original = path.join(root, 'supabase/migrations/20261031004921_personal_sync.sql');
const upgrade = path.join(root, 'supabase/migrations/202611070001_all_account_sync_v2.sql');
const reportPath = process.env.PPS_SYNC_V2_REPORT || path.join(root, 'artifacts/account-sync-v2/backend-security.json');
const A = '11111111-1111-4111-8111-111111111111';
const B = '22222222-2222-4222-8222-222222222222';
const UNKNOWN = '33333333-3333-4333-8333-333333333333';
const oldKinds = ['sources', 'history', 'progress', 'favorites'];
const liveKinds = ['liveSources', 'liveFavorites', 'liveRecent'];
const change = (kind, key, baseRevision, payload) => ({ kind, key, baseRevision, payload });
const checks = [];
let db;
async function check(name, run) { await run(); checks.push({ name, passed: true }); }
async function role(name, uid = '') {
  assert(['postgres', 'authenticated', 'anon'].includes(name));
  await db.exec('reset role');
  await db.query("select set_config('request.jwt.claim.sub', $1, false)", [uid]);
  if (name !== 'postgres') await db.exec('set role ' + name);
}
async function sync(version = 2, changes = [], cursor = 0) {
  const rpc = version === 1 ? 'pps_sync' : 'pps_sync_v2';
  return (await db.query(`select public.${rpc}($1::jsonb, $2::bigint) as result`, [JSON.stringify(changes), cursor])).rows[0].result;
}
async function rejects(run, code) {
  try { await run(); } catch (error) { assert.equal(error.code, code, error.message); return; }
  assert.fail('Expected PostgreSQL rejection: ' + code);
}
async function snapshot() {
  return {
    heads: (await db.query('select * from public.pps_sync_heads order by owner_id')).rows,
    records: (await db.query('select * from public.pps_sync_records order by owner_id,kind,record_key')).rows,
    rls: (await db.query("select relname,relrowsecurity,relforcerowsecurity,relacl from pg_class where oid in ('public.pps_sync_heads'::regclass,'public.pps_sync_records'::regclass) order by relname")).rows,
    policies: (await db.query("select schemaname,tablename,policyname,permissive,roles,cmd,qual,with_check from pg_policies where tablename in ('pps_sync_heads','pps_sync_records') order by tablename,policyname")).rows,
  };
}

(async () => {
  db = await PGlite.create();
  await db.exec(`
    create role anon nologin; create role authenticated nologin;
    create schema auth; create table auth.users(id uuid primary key);
    create function auth.uid() returns uuid language sql stable as
      $$select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid$$;
    grant usage on schema auth to anon, authenticated;
    grant execute on function auth.uid() to anon, authenticated;
    insert into auth.users values ('${A}'), ('${B}');
  `);
  await db.exec(fs.readFileSync(original, 'utf8'));
  await role('authenticated', A);
  await sync(1, oldKinds.map(kind => change(kind, 'old-' + kind, 0, { fixture: kind })));
  await role('authenticated', B);
  await sync(1, [change('sources', 'old-sources', 0, { fixture: 'account-b' })]);
  await role('postgres');
  const before = await snapshot();
  await db.exec(fs.readFileSync(upgrade, 'utf8'));
  await check('upgrade preserves all existing rows, revisions, timestamps, RLS, grants and policies', async () => {
    assert.deepEqual(await snapshot(), before);
  });
  await check('both public RPCs are invokers, both private writers are definers, all have empty search_path', async () => {
    const { rows } = await db.query("select n.nspname,p.prosecdef,p.proconfig from pg_proc p join pg_namespace n on n.oid=p.pronamespace where p.oid in ('public.pps_sync(jsonb,bigint)'::regprocedure,'public.pps_sync_v2(jsonb,bigint)'::regprocedure,'pps_private.sync_personal_records(jsonb,bigint)'::regprocedure,'pps_private.sync_personal_records_v2(jsonb,bigint)'::regprocedure)");
    assert.equal(rows.length, 4);
    assert(rows.every(x => x.prosecdef === (x.nspname === 'pps_private') && x.proconfig.includes('search_path=""')));
    const grants = (await db.query("select has_function_privilege('anon','public.pps_sync_v2(jsonb,bigint)','execute') as anon,has_function_privilege('authenticated','public.pps_sync_v2(jsonb,bigint)','execute') as auth,has_function_privilege('anon','pps_private.sync_personal_records_v2(jsonb,bigint)','execute') as private_anon")).rows[0];
    assert.deepEqual(grants, { anon: false, auth: true, private_anon: false });
  });
  await check('anonymous callers including forged subject cannot use either RPC, writer, or table', async () => {
    await role('anon', A);
    await rejects(() => sync(1), '42501'); await rejects(() => sync(2), '42501');
    await rejects(() => db.query('select pps_private.sync_personal_records_v2()'), '42501');
    await rejects(() => db.query('select * from public.pps_sync_records'), '42501');
  });
  await check('missing/deleted Auth identities cannot use v1 or v2', async () => {
    for (const uid of ['', UNKNOWN]) {
      await role('authenticated', uid);
      await rejects(() => sync(1), '42501'); await rejects(() => sync(2), '42501');
    }
  });
  await check('v2 atomically creates all three live kinds with original global CAS revisions', async () => {
    await role('authenticated', A);
    const result = await sync(2, [
      change('liveSources', 'live-a', 0, { id: 'live-a', name: 'Fixture M3U', url: 'https://fixture.invalid/list.m3u', enabled: true }),
      change('liveFavorites', 'channel-a', 0, { id: 'channel-a', name: 'Fixture channel' }),
      change('liveRecent', 'channel-a', 0, { id: 'channel-a', watchedAt: 12345 }),
    ], 4);
    assert.equal(result.accepted, true); assert.equal(result.revision, 7);
    assert.deepEqual(result.records.map(x => [x.kind, x.revision]), liveKinds.map((kind, i) => [kind, i + 5]));
  });
  await check('v1 zero-cursor and incremental reads never expose new kinds but do advance the common head', async () => {
    const all = await sync(1);
    assert.equal(all.revision, 7); assert.equal(all.records.length, 4);
    assert(all.records.every(x => oldKinds.includes(x.kind)));
    const liveOnlyDelta = await sync(1, [], 4);
    assert.equal(liveOnlyDelta.revision, 7); assert.deepEqual(liveOnlyDelta.records, []);
  });
  await check('v1 remains writable after hidden v2 changes and both versions see the same VOD data', async () => {
    const result = await sync(1, [change('sources', 'old-sources', 1, { fixture: 'old client update' })], 7);
    assert.equal(result.accepted, true); assert.equal(result.revision, 8);
    assert.equal(result.records.length, 1); assert.equal(result.records[0].kind, 'sources');
    assert.equal((await sync(2, [], 7)).records[0].payload.fixture, 'old client update');
  });
  await check('v1 rejects every live write, including a mixed batch, without partially writing VOD', async () => {
    for (const kind of liveKinds) {
      await rejects(() => sync(1, [change('favorites', 'must-not-exist', 0, {}), change(kind, 'x', 0, {})], 8), '22023');
    }
    const result = await sync(2);
    assert.equal(result.revision, 8); assert(!result.records.some(x => x.key === 'must-not-exist'));
  });
  await check('upgrade pull at cursor zero recovers live records older than the last legacy cursor', async () => {
    assert.deepEqual((await sync(2, [], 8)).records, []);
    const full = await sync(2, [], 0);
    assert.equal(full.revision, 8); assert.equal(full.records.length, 7);
    assert.equal(full.records.filter(x => liveKinds.includes(x.kind)).length, 3);
  });
  await check('B cannot read A live records, and identical B keys are independent', async () => {
    await role('authenticated', B);
    assert.equal((await sync(2)).records.length, 1);
    assert.deepEqual((await db.query("select * from public.pps_sync_records where kind like 'live%'")).rows, []);
    const conflict = await sync(2, [change('liveSources', 'live-a', 5, { enabled: false })], 1);
    assert.equal(conflict.accepted, false); assert.equal(conflict.conflicts[0].revision, 0);
    assert.equal(conflict.conflicts[0].payload, null);
    assert.equal((await sync(2, [change('liveSources', 'live-a', 0, { enabled: false })], 1)).revision, 2);
    await role('authenticated', A);
    assert.equal((await sync(2)).records.find(x => x.kind === 'liveSources').payload.enabled, true);
  });
  await check('one stale live record rejects a mixed VOD/live batch atomically', async () => {
    const result = await sync(2, [change('favorites', 'must-not-exist', 0, {}), change('liveSources', 'live-a', 0, { enabled: false })], 8);
    assert.equal(result.accepted, false); assert.equal(result.revision, 8);
    assert.equal(result.conflicts[0].revision, 5); assert.deepEqual(result.records, []);
    assert(!(await sync(2)).records.some(x => x.key === 'must-not-exist'));
  });
  await check('current live source updates sync enabled state while stale writes remain conflicts', async () => {
    const result = await sync(2, [change('liveSources', 'live-a', 5, { id: 'live-a', name: 'Renamed', url: 'https://fixture.invalid/new.m3u', enabled: false })], 8);
    assert.equal(result.accepted, true); assert.equal(result.revision, 9);
    assert.equal(result.records[0].payload.enabled, false);
    assert.equal((await sync(2, [change('liveSources', 'live-a', 5, { enabled: true })], 9)).accepted, false);
  });
  await check('all live deletions produce durable tombstones and stale devices cannot resurrect them', async () => {
    const result = await sync(2, [change('liveSources', 'live-a', 9, null), change('liveFavorites', 'channel-a', 6, null), change('liveRecent', 'channel-a', 7, null)], 9);
    assert.equal(result.revision, 12); assert.equal(result.records.length, 3);
    assert(result.records.every(x => x.deleted && x.payload === null));
    for (let i = 0; i < liveKinds.length; i++) {
      const key = i ? 'channel-a' : 'live-a';
      const stale = await sync(2, [change(liveKinds[i], key, i ? i + 5 : 9, {})], 12);
      assert.equal(stale.accepted, false); assert.equal(stale.conflicts[0].revision, 10 + i);
      assert.equal(stale.conflicts[0].deleted, true); assert.equal(stale.conflicts[0].payload, null);
    }
    assert.deepEqual((await sync(1, [], 9)).records, []);
    assert.equal((await sync(2, [], 9)).records.length, 3);
    assert.deepEqual((await sync(2, [], 12)).records, []);
  });
  await check('authenticated cannot directly insert, update, delete, truncate or change ownership', async () => {
    await rejects(() => db.query("insert into public.pps_sync_records values ($1,'liveSources','x','{}',500,false,now())", [A]), '42501');
    await rejects(() => db.query('update public.pps_sync_records set owner_id=$1', [B]), '42501');
    await rejects(() => db.query('delete from public.pps_sync_records'), '42501');
    await rejects(() => db.query('truncate public.pps_sync_records'), '42501');
  });
  const bad = [
    ['forged owner field', [{ ...change('liveSources', 'x', 0, {}), owner_id: B }], 12],
    ['unknown kind', [change('liveOther', 'x', 0, {})], 12],
    ['non-array changes', {}, 12], ['null changes', null, 12], ['non-object change', [null], 12],
    ['empty key', [change('liveSources', '', 0, {})], 12],
    ['string revision', [change('liveSources', 'x', '0', {})], 12],
    ['fractional revision', [change('liveSources', 'x', 0.5, {})], 12],
    ['unsafe revision', [change('liveSources', 'x', 9007199254740992, {})], 12],
    ['missing payload', [{ kind: 'liveSources', key: 'x', baseRevision: 0 }], 12],
    ['array payload', [change('liveSources', 'x', 0, [])], 12],
    ['large payload', [change('liveSources', 'x', 0, { s: 'x'.repeat(65536) })], 12],
    ['duplicate identity', [change('liveSources', 'x', 0, {}), change('liveSources', 'x', 0, {})], 12],
    ['large batch', Array.from({ length: 501 }, (_, i) => change('liveRecent', 'x' + i, 0, {})), 12],
    ['large total payload', Array.from({ length: 40 }, (_, i) => change('liveRecent', 'x' + i, 0, { s: 'x'.repeat(60000) })), 12],
    ['negative cursor', [], -1], ['ahead cursor', [], 13],
  ];
  for (const [name, changes, cursor] of bad) await check('v2 rejects ' + name + ' without modifying data', async () => {
    await rejects(() => sync(2, changes, cursor), '22023');
    assert.equal((await sync(2)).revision, 12);
  });
  await check('hostile caller search_path cannot redirect v1 or v2 privileged writes', async () => {
    await db.exec('create temporary table pps_sync_records(payload text); set search_path=pg_temp,public;');
    assert.equal((await sync(2, [change('liveRecent', 'channel-a', 12, { watchedAt: 20000 })], 12)).revision, 13);
    assert.equal((await sync(1, [change('favorites', 'new-vod', 0, {})], 13)).revision, 14);
    assert.equal((await db.query('select count(*)::int as n from pg_temp.pps_sync_records')).rows[0].n, 0);
    await db.exec('reset search_path');
  });
  await check('reapplying the upgrade preserves existing old/live rows and all ownership policies', async () => {
    await role('postgres');
    const prior = await snapshot();
    await db.exec(fs.readFileSync(upgrade, 'utf8'));
    assert.deepEqual(await snapshot(), prior);
  });
  await check('Auth deletion cascades VOD and live rows and blocks the old user subject', async () => {
    await db.query('delete from auth.users where id=$1', [B]);
    assert.equal((await db.query('select count(*)::int as n from public.pps_sync_records where owner_id=$1', [B])).rows[0].n, 0);
    await role('authenticated', B);
    await rejects(() => sync(1), '42501'); await rejects(() => sync(2), '42501');
  });
  const report = { passed: true, checks, engine: 'PGlite PostgreSQL/WASM', migration: path.relative(root, upgrade).replaceAll('\\', '/'), cloudContacted: false, realAccountsCreated: false, limitations: ['Auth gateway/JWT validation uses an auth.uid fixture; production must verify real JWTs.', 'This does not measure concurrent transactions, cloud availability, or browser behavior.'] };
  fs.mkdirSync(path.dirname(reportPath), { recursive: true });
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ passed: true, checks: checks.length, report: reportPath }));
})().catch(error => {
  console.error(error);
  console.error(JSON.stringify({ passed: false, completedChecks: checks.length, lastCompleted: checks.at(-1)?.name }));
  process.exitCode = 1;
}).finally(async () => { await db?.close(); });
