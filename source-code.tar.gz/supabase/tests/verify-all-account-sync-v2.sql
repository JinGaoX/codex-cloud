-- Read-only deployment verification: metadata only, no user IDs or payloads.
select c.conname, pg_catalog.pg_get_constraintdef(c.oid) as definition
from pg_catalog.pg_constraint c
where c.conrelid = 'public.pps_sync_records'::regclass
  and c.conname = 'pps_sync_records_kind_check';

select c.relname, c.relrowsecurity, c.relforcerowsecurity,
  pg_catalog.has_table_privilege('anon', c.oid, 'select') as anon_select,
  pg_catalog.has_table_privilege('authenticated', c.oid, 'select') as authenticated_select,
  pg_catalog.has_table_privilege('authenticated', c.oid, 'insert,update,delete,truncate') as authenticated_write
from pg_catalog.pg_class c
where c.oid in ('public.pps_sync_heads'::regclass, 'public.pps_sync_records'::regclass)
order by c.relname;

select p.oid::regprocedure::text as function_name, p.prosecdef, p.proconfig,
  pg_catalog.has_function_privilege('anon', p.oid, 'execute') as anon_execute,
  pg_catalog.has_function_privilege('authenticated', p.oid, 'execute') as authenticated_execute
from pg_catalog.pg_proc p
where p.oid in (
  'public.pps_sync(jsonb,bigint)'::regprocedure,
  'public.pps_sync_v2(jsonb,bigint)'::regprocedure,
  'pps_private.sync_personal_records(jsonb,bigint)'::regprocedure,
  'pps_private.sync_personal_records_v2(jsonb,bigint)'::regprocedure
)
order by function_name;

select policyname, tablename, cmd, roles, qual, with_check
from pg_catalog.pg_policies
where schemaname = 'public' and tablename in ('pps_sync_heads', 'pps_sync_records')
order by tablename, policyname;
