// SPDX-License-Identifier: AGPL-3.0-or-later
// Executes the real migration in in-memory PostgreSQL/WASM. It does not contact
// Supabase, create real accounts, or modify any user's existing database.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');
const { PGlite } = require(path.join(root, 'artifacts/backend-tests/node_modules/@electric-sql/pglite'));
const migration = path.join(root, 'supabase/migrations/20261031004921_personal_sync.sql');
const reportPath = path.join(root, 'artifacts/account-sync-2026-10-31/backend-security.json');
const A = '11111111-1111-4111-8111-111111111111';
const B = '22222222-2222-4222-8222-222222222222';
const UNKNOWN = '33333333-3333-4333-8333-333333333333';
const change = (kind, key, baseRevision, payload) => ({ kind, key, baseRevision, payload });
const checks = [];
let db;
async function check(name, run) {
  await run();
  checks.push({ name, passed: true });
}
async function role(name, uid = '') {
  assert(['postgres', 'authenticated', 'anon'].includes(name));
  await db.exec('reset role');
  await db.query("select set_config('request.jwt.claim.sub', $1, false)", [uid]);
  if (name !== 'postgres') await db.exec('set role ' + name);
}
async function sync(changes = [], cursor = 0) {
  return (await db.query('select public.pps_sync($1::jsonb, $2::bigint) as result', [JSON.stringify(changes), cursor])).rows[0].result;
}
async function rejects(run, code) {
  try { await run(); } catch (error) {
    assert.equal(error.code, code, error.message);
    return;
  }
  assert.fail('Expected PostgreSQL rejection: ' + code);
}

(async () => {
  db = await PGlite.create();
  await db.exec(`
    create role anon nologin;
    create role authenticated nologin;
    create schema auth;
    create table auth.users(id uuid primary key);
    create function auth.uid() returns uuid language sql stable as
      $$select nullif(current_setting('request.jwt.claim.sub', true), '')::uuid$$;
    grant usage on schema auth to anon, authenticated;
    grant execute on function auth.uid() to anon, authenticated;
    insert into auth.users values ('${A}'), ('${B}');
  `);
  await db.exec(fs.readFileSync(migration, 'utf8'));

  await check('both exposed tables enable and force RLS', async () => {
    const { rows } = await db.query("select relrowsecurity, relforcerowsecurity from pg_class where oid in ('public.pps_sync_heads'::regclass, 'public.pps_sync_records'::regclass)");
    assert.equal(rows.length, 2);
    assert(rows.every(x => x.relrowsecurity && x.relforcerowsecurity));
  });
  await check('public wrapper is invoker; private writer is definer with empty search_path', async () => {
    const { rows } = await db.query("select n.nspname, p.prosecdef, p.proconfig from pg_proc p join pg_namespace n on n.oid=p.pronamespace where p.oid in ('public.pps_sync(jsonb,bigint)'::regprocedure,'pps_private.sync_personal_records(jsonb,bigint)'::regprocedure)");
    assert.equal(rows.find(x => x.nspname === 'public').prosecdef, false);
    assert.equal(rows.find(x => x.nspname === 'pps_private').prosecdef, true);
    assert(rows.every(x => x.proconfig.includes('search_path=""')));
  });
  await check('anon has no RPC access even with a forged subject setting', async () => {
    await role('anon', A);
    await rejects(() => sync(), '42501');
    await rejects(() => db.query('select * from public.pps_sync_records'), '42501');
    await rejects(() => db.query('select pps_private.sync_personal_records()'), '42501');
  });
  await check('authenticated without an identity cannot call RPC', async () => {
    await role('authenticated');
    await rejects(() => sync(), '42501');
  });
  await check('a deleted or unknown Auth user cannot use an otherwise populated subject', async () => {
    await role('authenticated', UNKNOWN);
    await rejects(() => sync(), '42501');
  });
  await check('forged owner argument is rejected before any write', async () => {
    await role('authenticated', A);
    await rejects(() => sync([{ ...change('history', 'film', 0, { title: 'fixture' }), owner_id: B }]), '22023');
    assert.equal((await db.query('select count(*)::int as n from public.pps_sync_heads')).rows[0].n, 0);
  });
  await check('A creates history and progress atomically, with monotonically increasing revisions', async () => {
    const result = await sync([
      change('history', 'film', 0, { title: 'fixture', owner_id: B }),
      change('progress', 'episode', 0, { position: 600, duration: 7200 }),
    ]);
    assert.equal(result.accepted, true);
    assert.equal(result.revision, 2);
    assert.deepEqual(result.records.map(x => x.revision), [1, 2]);
    assert(result.records.every(x => Number.isInteger(x.updatedAt) && x.updatedAt > 0));
    // A field in application payload is data, not the SQL ownership column.
    assert((await db.query('select owner_id from public.pps_sync_records')).rows.every(x => x.owner_id === A));
  });
  await check('B initial sync and direct SELECT never reveal A records or head', async () => {
    await role('authenticated', B);
    const result = await sync();
    assert.equal(result.revision, 0);
    assert.deepEqual(result.records, []);
    assert.deepEqual((await db.query('select * from public.pps_sync_records')).rows, []);
    assert((await db.query('select owner_id from public.pps_sync_heads')).rows.every(x => x.owner_id === B));
  });
  await check('B guessing A record and revision only gets B missing-record conflict', async () => {
    const result = await sync([change('progress', 'episode', 2, { position: 99 })]);
    assert.equal(result.accepted, false);
    assert.deepEqual(result.records, []);
    assert.deepEqual(result.conflicts, [{ kind: 'progress', key: 'episode', payload: null, revision: 0, deleted: true, updatedAt: null }]);
  });
  await check('identical key in B is independently writable without affecting A', async () => {
    const result = await sync([change('progress', 'episode', 0, { position: 10 })]);
    assert.equal(result.accepted, true);
    assert.equal(result.revision, 1);
    await role('authenticated', A);
    const a = await sync();
    assert.equal(a.records.find(x => x.kind === 'progress').payload.position, 600);
    assert.equal(a.records.length, 2);
  });
  await check('authenticated cannot directly INSERT UPDATE DELETE or TRUNCATE even own rows', async () => {
    await rejects(() => db.query("insert into public.pps_sync_heads values ($1, 500)", [A]), '42501');
    await rejects(() => db.query('update public.pps_sync_heads set revision=500'), '42501');
    await rejects(() => db.query('delete from public.pps_sync_records'), '42501');
    await rejects(() => db.query('truncate public.pps_sync_records'), '42501');
  });
  await check('a fresh version may deliberately rewind progress; it does not take maximum seconds', async () => {
    const result = await sync([change('progress', 'episode', 2, { position: 30 })], 2);
    assert.equal(result.accepted, true);
    assert.equal(result.revision, 3);
    assert.equal(result.records[0].payload.position, 30);
  });
  await check('offline stale progress is a conflict and cannot overwrite newer session', async () => {
    const result = await sync([change('progress', 'episode', 2, { position: 700 })], 2);
    assert.equal(result.accepted, false);
    assert.equal(result.revision, 3);
    assert.equal(result.conflicts[0].revision, 3);
    assert.equal(result.conflicts[0].payload.position, 30);
  });
  await check('mixed conflicting batch makes no partial new writes', async () => {
    const result = await sync([
      change('favorites', 'favorite', 0, { name: 'should not be inserted' }),
      change('progress', 'episode', 2, { position: 700 }),
    ], 3);
    assert.equal(result.accepted, false);
    assert.equal(result.revision, 3);
    assert.deepEqual(result.records, []);
    assert.equal((await db.query("select count(*)::int as n from public.pps_sync_records where kind='favorites'")).rows[0].n, 0);
  });
  await check('explicit conflict resolution using current revision is accepted', async () => {
    const result = await sync([change('progress', 'episode', 3, { position: 5 })], 3);
    assert.equal(result.accepted, true);
    assert.equal(result.revision, 4);
  });
  await check('deletion produces durable tombstone and advances cursor', async () => {
    const result = await sync([change('history', 'film', 1, null)], 4);
    assert.equal(result.accepted, true);
    assert.equal(result.revision, 5);
    assert.equal(result.records[0].deleted, true);
    assert.equal(result.records[0].payload, null);
  });
  await check('an offline stale write cannot resurrect a deleted record', async () => {
    const result = await sync([change('history', 'film', 1, { title: 'old device' })], 4);
    assert.equal(result.accepted, false);
    assert.equal(result.conflicts[0].revision, 5);
    assert.equal(result.conflicts[0].deleted, true);
    assert.equal(result.conflicts[0].payload, null);
  });
  await check('a later device pulls tombstones and same-cursor polls return no duplicates', async () => {
    const delta = await sync([], 4);
    assert.equal(delta.records.length, 1);
    assert.equal(delta.records[0].deleted, true);
    assert.deepEqual((await sync([], 5)).records, []);
  });
  await check('explicit re-add with tombstone current revision remains possible', async () => {
    const result = await sync([change('history', 'film', 5, { title: 'intentional rewatch' })], 5);
    assert.equal(result.accepted, true);
    assert.equal(result.records[0].deleted, false);
    assert.equal(result.records[0].revision, 6);
  });
  await check('temporary names and hostile caller search_path do not redirect privileged writes', async () => {
    await db.exec("create temporary table pps_sync_records(payload text); set search_path=pg_temp, public;");
    const result = await sync([change('sources', 'source', 0, { url: 'https://fixture.invalid/api' })], 6);
    assert.equal(result.accepted, true);
    assert.equal(result.revision, 7);
    assert.equal((await db.query('select count(*)::int as n from pg_temp.pps_sync_records')).rows[0].n, 0);
    await db.exec('reset search_path');
  });

  const bad = [
    ['non-array changes', {}, 7],
    ['null changes', null, 7],
    ['non-object change', [null], 7],
    ['unknown kind', [change('users', 'x', 0, {})], 7],
    ['empty key', [change('sources', '', 0, {})], 7],
    ['oversize key', [change('sources', 'x'.repeat(4097), 0, {})], 7],
    ['string base revision', [change('sources', 'x', '0', {})], 7],
    ['negative base revision', [change('sources', 'x', -1, {})], 7],
    ['fractional base revision', [change('sources', 'x', 0.5, {})], 7],
    ['unsafe integer base revision', [change('sources', 'x', 9007199254740992, {})], 7],
    ['array payload', [change('sources', 'x', 0, [])], 7],
    ['missing payload', [{ kind: 'sources', key: 'x', baseRevision: 0 }], 7],
    ['oversize payload', [change('sources', 'x', 0, { s: 'x'.repeat(65536) })], 7],
    ['duplicate key', [change('sources', 'x', 0, {}), change('sources', 'x', 0, {})], 7],
    ['oversize row count', Array.from({ length: 501 }, (_, i) => change('sources', 's' + i, 0, {})), 7],
    ['oversize total batch', Array.from({ length: 40 }, (_, i) => change('sources', 's' + i, 0, { s: 'x'.repeat(60000) })), 7],
    ['negative cursor', [], -1],
    ['cursor ahead of server', [], 8],
  ];
  for (const [name, changes, cursor] of bad) await check('rejects ' + name + ' without modifying data', async () => {
    await rejects(() => sync(changes, cursor), '22023');
    assert.equal((await sync([], 7)).revision, 7);
  });
  await check('deleting Auth user cascades records and prevents old-subject access', async () => {
    await role('postgres');
    await db.query('delete from auth.users where id=$1', [B]);
    assert.equal((await db.query('select count(*)::int as n from public.pps_sync_heads where owner_id=$1', [B])).rows[0].n, 0);
    assert.equal((await db.query('select count(*)::int as n from public.pps_sync_records where owner_id=$1', [B])).rows[0].n, 0);
    await role('authenticated', B);
    await rejects(() => sync(), '42501');
  });
  const report = { passed: true, checks, engine: 'PGlite 0.5.13 (real PostgreSQL compiled to WASM)', migration: path.relative(root, migration).replaceAll('\\', '/'), cloudContacted: false, realAccountsCreated: false, limitations: ['Auth gateway/JWT verification is simulated with an auth.uid fixture; production Supabase must verify real JWTs.', 'This is not a multi-process load or concurrent transaction test, nor a production advisor run.'] };
  fs.mkdirSync(path.dirname(reportPath), { recursive: true });
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ passed: true, checks: checks.length, engine: report.engine, report: reportPath }));
})().catch(error => {
  console.error(error);
  console.error(JSON.stringify({ passed: false, completedChecks: checks.length, lastCompleted: checks.at(-1)?.name }));
  process.exitCode = 1;
}).finally(async () => { await db?.close(); });
