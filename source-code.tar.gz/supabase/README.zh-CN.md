# PPS影音个人账号同步数据库

该目录只包含可审查的数据库迁移和隔离测试，不含项目密钥、账号密码或用户记录。Supabase Auth 负责注册、登录、密码验证及令牌签发；不能把 `service_role` / secret key 放入网页。浏览器只应使用 publishable key（旧项目可兼容 anon key）和当前用户的访问令牌。

## 同步接口

新版调用 `rpc('pps_sync_v2', { p_changes, p_cursor })`。输入变化示例：

```json
{"kind":"progress","key":"稳定的来源和分集标识","baseRevision":12,"payload":{"position":300}}
```

- `kind` 允许 `sources`、`history`、`progress`、`favorites`、`liveSources`、`liveFavorites`、`liveRecent`。
- `sources` 为点播源；`liveSources` 为直播订阅（含启用状态），`liveFavorites` 为直播频道收藏，`liveRecent` 为直播最近观看。频道列表、节目单、测速缓存等可重新获取的数据不上传。
- `key` 由客户端稳定定位记录，1–4096 字符，不按片名猜测影片。
- `baseRevision` 是最后读取的服务器版本；首次创建为 0。客户端时间不参与覆盖决策。
- `payload` 为对象，或以 `null` 表示删除。删除保存为有版本的墓碑，旧设备不能盲目恢复已删记录。
- 每批最多 500 条、整个 JSON 最多 2 MiB，每个 payload 最多 64 KiB。

结果为 `{revision, accepted, records, conflicts}`。记录格式是 `{kind, key, payload, revision, deleted, updatedAt}`，其中 `updatedAt` 是服务器毫秒时间。请求旧的非零版本但服务器没有该记录时，冲突项返回 `revision:0`、`deleted:true`、`payload:null`、`updatedAt:null`。

任一冲突都会拒绝整批写入；客户端需保存本机未同步值并明确选择使用哪方记录，不能简单选较大的播放秒数。成功结果也包含这次写入的记录。`records` 为版本大于请求 `p_cursor` 的所有本账号记录，按版本排序；将响应的 `revision` 保存为下次游标。空批可用来拉取变化。客户端不能提交超前于服务器的游标。

旧版 `pps_sync` 保留原四种 kind 的读写，新 kind 写入会拒绝，响应也不包含直播记录。两个协议共用账号版本号。因此升级到 v2 的设备须进行一次 `p_cursor: 0` 全量拉取，保留本机待上传变更及其 `baseRevision`，再恢复增量同步，不能直接沿用 v1 游标跳过已有直播记录。

## 已有项目升级

已有 .32/.34 账号系统只需在原项目 SQL Editor 执行 `migrations/202611070001_all_account_sync_v2.sql`，不要重跑最初的建表迁移。新增迁移自带事务，保留用户、现有记录、时间、版本号、RLS、表权限与旧版接口；不需要创建新账号或更换公开连接配置。完成后运行只读 `tests/verify-all-account-sync-v2.sql` 核对约束、函数与权限。不要把服务角色、数据库密码或管理会话放入网页。

## 权限边界

两张公开表均启用并强制 RLS。`anon` 无访问权；`authenticated` 只能读取 `owner_id = auth.uid()` 的行，无直接写权限。公开 RPC 是 invoker 薄包装，实际写入位于未暴露的 `pps_private` schema，definer 函数固定空 search_path，并对每次调用检查 `auth.uid()` 与现存 Auth 用户。所有查询和写入都明确带此 owner 条件；任何用户提交的 owner 字段都不能改变权限。

服务器以每个账号的一行锁覆盖检查与写入，分配单调递增版本。迁移不读取、上传或清空已有浏览器资料。此迁移应仅应用到为 PPS影音确认的项目；不要直接修改不明来源的既有项目。

## 本地数据库测试

在仓库根目录执行。测试依赖隔离安装在已忽略的 artifacts 内，不进入产品 dependencies：

```powershell
npm install --prefix artifacts/backend-tests --no-audit --no-fund --save-exact @electric-sql/pglite@0.5.13
node supabase/tests/personal-sync.cjs
node supabase/tests/all-account-sync-v2.cjs
$env:PPS_SYNC_TEST_V2='1'
$env:PPS_SYNC_TEST_REPORT='artifacts/account-sync-v2/legacy-compatibility.json'
node supabase/tests/personal-sync.cjs
```

若复用另一个隔离目录已安装的 PGlite，可用 `PPS_PGLITE_PATH` 指定其包目录。`all-account-sync-v2.cjs` 覆盖有旧资料的原地升级、v1/v2 混用、升级游标、直播订阅启停、删除墓碑、冲突、跨账号隔离和权限。设置 `PPS_SYNC_TEST_V2=1` 后，原有测试会在升级后的数据库上再次执行，以验证旧版行为。

测试在内存中的真实 PostgreSQL/WASM 执行同一份迁移，用两个虚构用户检查数据库级隔离、匿名拒绝、伪造 owner、直接写拒绝、批次冲突无部分提交、重看回退、删除墓碑和旧设备补传等。真实 Auth 网关验证由 fixture 模拟；这不替代已部署 Supabase 的真实 JWT/RLS 检查、advisor 结果或多人并发压测。

迁移文件由官方 `supabase migration new personal_sync` 生成。尚未部署前可审查；应用后的迁移不得改写，应追加后续迁移。部署前后需运行项目的数据库 Security/Performance Advisors，并核对 Auth 注册、邮件、免费档及所在网络访问情况。这里没有自动创建云项目或部署。
