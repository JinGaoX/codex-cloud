﻿param(
    [ValidateSet('Start', 'Stop', 'Status', 'Open')]
    [string]$Action = 'Start'
)

$ErrorActionPreference = 'Stop'
$appDirectory = Split-Path -Parent $PSScriptRoot
$expectedVersion = (Get-Content -LiteralPath (Join-Path $appDirectory 'package.json') -Raw | ConvertFrom-Json).version
$runtimeDirectory = Join-Path $appDirectory 'artifacts\local-service'
$stateFile = Join-Path $runtimeDirectory 'service.json'
$openStateFile = Join-Path $runtimeDirectory 'last-open.json'
$openCooldownSeconds = 5
$nextCli = Join-Path $appDirectory 'node_modules\next\dist\bin\next'
$siteUrl = 'http://localhost:8080'
$healthUrl = 'http://127.0.0.1:8080/api/status'
New-Item -ItemType Directory -Path $runtimeDirectory -Force | Out-Null
$serviceMutex = New-Object System.Threading.Mutex($false, 'Local\VIPTV-Local-8080-Management')
$lockTaken = $false
$openMutex = $null
$openLockTaken = $false
try {
    # Ignore overlapping clicks before they can queue for service startup.
    if ($Action -eq 'Open') {
        $openMutex = New-Object System.Threading.Mutex($false, 'Local\VIPTV-Local-8080-Open')
        try { $openLockTaken = $openMutex.WaitOne(0) }
        catch [System.Threading.AbandonedMutexException] { $openLockTaken = $true }
        if (-not $openLockTaken) {
            Write-Output 'VIP影视 is already opening.'
            exit 0
        }
    }

    try { $lockTaken = $serviceMutex.WaitOne(30000) }
    catch [System.Threading.AbandonedMutexException] { $lockTaken = $true }
    if (-not $lockTaken) { throw 'Another VIP影视 management action is still running. Try again shortly.' }

function Get-VIP影视Process {
    if (-not (Test-Path -LiteralPath $stateFile)) { return $null }
    $serviceState = Get-Content -LiteralPath $stateFile -Raw | ConvertFrom-Json
    $serviceProcess = Get-CimInstance Win32_Process -Filter "ProcessId=$($serviceState.pid)" -ErrorAction SilentlyContinue
    if ($serviceProcess -and $serviceProcess.Name -eq 'node.exe' -and
        $serviceProcess.CommandLine.Contains($nextCli)) {
        return $serviceProcess
    }
    return $null
}

function Get-VIP影视Health {
    try {
        # The service binds IPv4 only; avoid localhost's IPv6 fallback delay.
        return Invoke-RestMethod -Uri $healthUrl -TimeoutSec 3
    } catch { return $null }
}

function Test-VIP影视Health($health) {
    return [bool]($health -and ($health.passwordRequired -or $health.verified) -and $health.version -eq $expectedVersion)
}

function Test-RecentVIP影视Open {
    if (-not (Test-Path -LiteralPath $openStateFile)) { return $false }
    try {
        $lastOpen = Get-Content -LiteralPath $openStateFile -Raw | ConvertFrom-Json
        $openedAt = [DateTimeOffset]::Parse([string]$lastOpen.openedAt)
        $secondsSinceOpen = ([DateTimeOffset]::UtcNow - $openedAt).TotalSeconds
        return ($secondsSinceOpen -ge 0 -and $secondsSinceOpen -lt $openCooldownSeconds)
    } catch {
        # A missing or damaged timestamp must not prevent opening the app.
        return $false
    }
}

function Open-VIP影视Site {
    Start-Process $siteUrl
    # Timestamp the successful browser launch, including after a long cold start.
    @{ openedAt = [DateTimeOffset]::UtcNow.ToString('o') } |
        ConvertTo-Json | Set-Content -LiteralPath $openStateFile -Encoding UTF8
}

if ($Action -eq 'Stop') {
    $serviceProcess = Get-VIP影视Process
    if ($serviceProcess) {
        Stop-Process -Id $serviceProcess.ProcessId -Force
        Write-Output 'VIP影视 stopped.'
    } else { Write-Output 'VIP影视 is not running.' }
    if (Test-Path -LiteralPath $stateFile) { Remove-Item -LiteralPath $stateFile }
    exit 0
}

if ($Action -eq 'Status') {
    $serviceProcess = Get-VIP影视Process
    $health = if ($serviceProcess) { Get-VIP影视Health } else { $null }
    [pscustomobject]@{
        running = [bool]$serviceProcess
        healthy = [bool]$health
        pid = if ($serviceProcess) { $serviceProcess.ProcessId } else { $null }
        version = if ($health) { $health.version } else { $null }
        url = $siteUrl
    } | ConvertTo-Json
    exit 0
}

# A healthy running service needs no process lookup or startup polling to open.
if ($Action -eq 'Open') {
    $health = Get-VIP影视Health
    if (Test-VIP影视Health $health) {
        if (Test-RecentVIP影视Open) {
            Write-Output 'VIP影视 was just opened; duplicate click ignored.'
            exit 0
        }
        Open-VIP影视Site
        Write-Output "VIP影视 $($health.version) is running at $siteUrl"
        exit 0
    }
}

$serviceProcess = Get-VIP影视Process
if (-not $serviceProcess) {
    if (-not (Test-Path -LiteralPath (Join-Path $appDirectory '.next\BUILD_ID'))) {
        throw 'Production build is missing. Run npm ci and npm run build in the app folder.'
    }
    $listener = Get-NetTCPConnection -State Listen -LocalPort 8080 -ErrorAction SilentlyContinue
    if ($listener) { throw 'Port 8080 is already in use. VIP影视 was not started.' }
    $nodePath = (Get-Command node.exe -ErrorAction Stop).Source
    $previousNoAuth = $env:LOCAL_NO_AUTH
    try {
      $env:LOCAL_NO_AUTH = 'true'
    $serviceProcess = Start-Process -FilePath $nodePath -ArgumentList @(
        ('"' + $nextCli + '"'), 'start', '--hostname', '127.0.0.1', '--port', '8080'
    ) -WorkingDirectory $appDirectory -WindowStyle Hidden -PassThru `
        -RedirectStandardOutput (Join-Path $runtimeDirectory 'stdout.log') `
        -RedirectStandardError (Join-Path $runtimeDirectory 'stderr.log')
    } finally { $env:LOCAL_NO_AUTH = $previousNoAuth }
    @{
        pid = $serviceProcess.Id
        appDirectory = $appDirectory
        startedAt = [DateTime]::UtcNow.ToString('o')
    } | ConvertTo-Json | Set-Content -LiteralPath $stateFile -Encoding UTF8
}

$healthy = $false
for ($attempt = 0; $attempt -lt 30; $attempt++) {
    $health = Get-VIP影视Health
    if (Test-VIP影视Health $health) {
        $healthy = $true
        break
    }
    if (-not (Get-VIP影视Process)) { break }
    Start-Sleep -Milliseconds 500
}
if (-not $healthy) { throw "VIP影视 did not become healthy. Check $runtimeDirectory\stderr.log" }
Write-Output "VIP影视 $($health.version) is running at $siteUrl"
if ($Action -eq 'Open') { Open-VIP影视Site }
} finally {
    if ($lockTaken) { $serviceMutex.ReleaseMutex() }
    $serviceMutex.Dispose()
    if ($openLockTaken) { $openMutex.ReleaseMutex() }
    if ($openMutex) { $openMutex.Dispose() }
}
