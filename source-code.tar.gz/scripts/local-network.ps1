﻿# Local desktop transport only. No system proxy or application data is changed.
function Get-PPSNetworkConfiguration([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        return [pscustomobject]@{ Mode = 'default'; Hash = 'default'; ProxyUrl = $null; ProxyUri = $null; BrowserPath = $null; ProfileDirectory = $null }
    }
    try { $config = Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json }
    catch { throw 'PPS network configuration is not valid JSON. No fallback was started.' }
    if ($config.mode -ne 'pps-direct') { throw 'Unsupported PPS network mode. No fallback was started.' }
    $proxyUri = $null
    if (-not [Uri]::TryCreate([string]$config.proxyUrl, [UriKind]::Absolute, [ref]$proxyUri) -or
        $proxyUri.Scheme -ne 'http' -or $proxyUri.UserInfo -or $proxyUri.Query -or $proxyUri.Fragment -or
        $proxyUri.AbsolutePath -ne '/' -or $proxyUri.Port -lt 1) {
        throw 'PPS direct transport requires a plain HTTP LAN proxy URL without credentials, path or query.'
    }
    $address = $null
    if (-not [Net.IPAddress]::TryParse($proxyUri.Host, [ref]$address) -or
        $address.AddressFamily -ne [Net.Sockets.AddressFamily]::InterNetwork) {
        throw 'PPS direct transport requires a LAN IPv4 address.'
    }
    $octets = $address.GetAddressBytes()
    if (-not ($octets[0] -eq 10 -or $octets[0] -eq 127 -or
        ($octets[0] -eq 172 -and $octets[1] -ge 16 -and $octets[1] -le 31) -or
        ($octets[0] -eq 192 -and $octets[1] -eq 168))) {
        throw 'PPS direct transport must stay inside the LAN or loopback network.'
    }
    $browser = [string]$config.browserPath
    $profile = [string]$config.profileDirectory
    if (-not [IO.Path]::IsPathRooted($browser) -or -not (Test-Path -LiteralPath $browser -PathType Leaf) -or
        @('chrome.exe', 'msedge.exe') -notcontains [IO.Path]::GetFileName($browser).ToLowerInvariant()) {
        throw 'PPS requires an existing Chrome or Edge executable for its dedicated window.'
    }
    if (-not [IO.Path]::IsPathRooted($profile) -or -not $env:LOCALAPPDATA) {
        throw 'PPS requires a dedicated browser profile inside its LocalAppData directory.'
    }
    $browser = [IO.Path]::GetFullPath($browser)
    $profile = [IO.Path]::GetFullPath($profile).TrimEnd('\', '/')
    $profileRoot = [IO.Path]::GetFullPath((Join-Path $env:LOCALAPPDATA 'PPS影音')).TrimEnd('\', '/')
    if (-not $profile.StartsWith($profileRoot + '\', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'PPS dedicated profile must be below LocalAppData\PPS影音; existing Chrome profiles are not accepted.'
    }
    $proxyUrl = $proxyUri.GetLeftPart([UriPartial]::Authority)
    $identity = 'pps-direct' + "`n" + $proxyUrl + "`n" + $browser.ToLowerInvariant() + "`n" + $profile.ToLowerInvariant()
    $hasher = [Security.Cryptography.SHA256]::Create()
    try { $hash = ([BitConverter]::ToString($hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($identity)))).Replace('-', '').ToLowerInvariant() }
    finally { $hasher.Dispose() }
    return [pscustomobject]@{ Mode = 'pps-direct'; Hash = $hash; ProxyUrl = $proxyUrl; ProxyUri = $proxyUri; BrowserPath = $browser; ProfileDirectory = $profile }
}

function Test-PPSServiceNetwork([string]$StateFile, $Network) {
    if (-not (Test-Path -LiteralPath $StateFile -PathType Leaf)) { return ($Network.Mode -eq 'default') }
    try { $state = Get-Content -LiteralPath $StateFile -Raw -Encoding UTF8 | ConvertFrom-Json }
    catch { return $false }
    if ($Network.Mode -eq 'default') { return (-not $state.networkHash -or $state.networkHash -eq 'default') }
    return ($state.networkHash -eq $Network.Hash -and $state.networkMode -eq $Network.Mode)
}

function Test-PPSProxyAvailable($Network, [int]$TimeoutMs = 3000) {
    if ($Network.Mode -ne 'pps-direct') { return $true }
    $connection = New-Object Net.Sockets.TcpClient
    $operation = $null
    try {
        $operation = $connection.BeginConnect($Network.ProxyUri.Host, $Network.ProxyUri.Port, $null, $null)
        if (-not $operation.AsyncWaitHandle.WaitOne($TimeoutMs)) { return $false }
        $connection.EndConnect($operation)
        return $connection.Connected
    } catch { return $false }
    finally {
        if ($operation) { $operation.AsyncWaitHandle.Close() }
        $connection.Close()
    }
}

function Assert-PPSProxyAvailable($Network) {
    if (-not (Test-PPSProxyAvailable $Network)) {
        throw 'PPS direct transport is unavailable. No ordinary browser or alternative network route was started.'
    }
}

function Get-PPSBrowserArguments($Network, [string]$SiteUrl) {
    if ($Network.Mode -ne 'pps-direct') { throw 'Dedicated browser arguments require pps-direct mode.' }
    return @(
        ('--user-data-dir="' + $Network.ProfileDirectory + '"'),
        ('--proxy-server=' + $Network.ProxyUrl),
        '--proxy-bypass-list=localhost;127.0.0.1;[::1]',
        '--no-first-run', '--no-default-browser-check',
        ('--app="' + $SiteUrl + '"')
    )
}

function Assert-PPSBrowserNetwork($Network) {
    if ($Network.Mode -ne 'pps-direct') { return }
    $imageName = [IO.Path]::GetFileName($Network.BrowserPath)
    $profileValue = [Regex]::Escape($Network.ProfileDirectory)
    $proxyValue = [Regex]::Escape($Network.ProxyUrl)
    $profileArgument = '(?:^|\s)--user-data-dir=(?:"' + $profileValue + '"|' + $profileValue + ')(?=\s|$)'
    $proxyArgument = '(?:^|\s)--proxy-server=(?:"' + $proxyValue + '"|' + $proxyValue + ')(?=\s|$)'
    $processes = Get-CimInstance Win32_Process -Filter ("Name='" + $imageName + "'") -ErrorAction Stop
    foreach ($process in $processes) {
        $command = [string]$process.CommandLine
        if ($command.IndexOf('--type=', [StringComparison]::OrdinalIgnoreCase) -ge 0 -or
            -not [Regex]::IsMatch($command, $profileArgument, [Text.RegularExpressions.RegexOptions]::IgnoreCase)) { continue }
        if (-not [Regex]::IsMatch($command, $proxyArgument, [Text.RegularExpressions.RegexOptions]::IgnoreCase)) {
            throw 'The dedicated PPS browser is already using different proxy settings. Close only that PPS window and open it again. No fallback was started.'
        }
    }
}

function Invoke-PPSNodeEnvironment($Network, [scriptblock]$Action) {
    $names = @('LOCAL_NO_AUTH', 'HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'NODE_USE_ENV_PROXY')
    $previous = @{}
    foreach ($name in $names) { $previous[$name] = [Environment]::GetEnvironmentVariable($name, 'Process') }
    try {
        $env:LOCAL_NO_AUTH = 'true'
        if ($Network.Mode -eq 'pps-direct') {
            $env:HTTP_PROXY = $Network.ProxyUrl
            $env:HTTPS_PROXY = $Network.ProxyUrl
            $env:NO_PROXY = 'localhost,127.0.0.1,::1'
            $env:NODE_USE_ENV_PROXY = '1'
        }
        & $Action
    } finally {
        foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name, $previous[$name], 'Process') }
    }
}
