// Convert the existing PPS artwork to Android launcher densities; do not redraw it.
import sharp from 'sharp';
import { mkdir, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const res = path.join(root, 'android/app/src/main/res');
const original = path.join(root, 'public/icons/pps-original.jpg');
for (const [density, scale] of Object.entries({ mdpi: 1, hdpi: 1.5, xhdpi: 2, xxhdpi: 3, xxxhdpi: 4 })) {
  const folder = path.join(res, 'mipmap-' + density);
  await mkdir(folder, { recursive: true });
  const legacy = await sharp(original).resize(Math.round(48 * scale), Math.round(48 * scale)).png().toBuffer();
  await Promise.all(['ic_launcher.png', 'ic_launcher_round.png'].map(name => writeFile(path.join(folder, name), legacy)));
  const size = Math.round(108 * scale), content = Math.round(66 * scale);
  const inset = Math.floor((size - content) / 2);
  await sharp(original).resize(content, content).extend({ top: inset, left: inset,
    right: size - content - inset, bottom: size - content - inset, background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .png().toFile(path.join(folder, 'ic_launcher_foreground.png'));
}
await writeFile(path.join(res, 'values/ic_launcher_background.xml'), '<?xml version="1.0" encoding="utf-8"?>\n<resources><color name="ic_launcher_background">#0B0E14</color></resources>\n');
console.log('Generated Android icons from existing PPS artwork.');
