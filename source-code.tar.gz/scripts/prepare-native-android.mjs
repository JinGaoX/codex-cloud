/** Sync the bundled Android app; this does not compile, sign or install an APK. */
import { existsSync, readFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const markerPath = path.join(root, 'android-dist/android-build.json');
const expectedIdentity = { mode: 'android', appId: 'org.libretv.personal', origin: 'https://localhost' };
if (!existsSync(markerPath)) throw new Error('Run npm run build:android before syncing Android.');
const marker = JSON.parse(readFileSync(markerPath, 'utf8'));
if (Object.entries(expectedIdentity).some(([key, value]) => marker[key] !== value)
  || marker.bundled !== true || marker.remoteServer !== false) {
  throw new Error('Android bundle identity is invalid; refusing to sync a remote or different app.');
}

function cap(args) {
  const result = spawnSync(process.execPath, [path.join(root, 'node_modules/@capacitor/cli/bin/capacitor'), ...args], {
    cwd: root, stdio: 'inherit', windowsHide: true,
    env: { ...process.env, CI: '1', CAPACITOR_PLATFORM: 'android' },
  });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status || 1);
}

if (!existsSync(path.join(root, 'android/app/build.gradle'))) cap(['add', 'android']);
cap(['sync', 'android']);
const assets = path.join(root, 'android/app/src/main/assets');
const bundled = JSON.parse(readFileSync(path.join(assets, 'capacitor.config.json'), 'utf8'));
if (bundled.appId !== expectedIdentity.appId || bundled.webDir !== 'android-dist'
  || bundled.server?.url || bundled.server?.hostname !== 'localhost' || bundled.server?.androidScheme !== 'https'
  || bundled.server?.allowNavigation || bundled.server?.cleartext === true
  || bundled.android?.allowMixedContent === true || bundled.plugins?.CapacitorHttp?.enabled !== false
  || bundled.plugins?.SystemBars?.insetsHandling !== 'native'
  || bundled.plugins?.SystemBars?.initialViewportFitValueHint !== 'contain') {
  throw new Error('Bundled Android configuration changed its local identity or transport boundary.');
}
const web = path.join(assets, 'public');
for (const file of ['index.html', 'watch.html', 'live.html', 'android-build.json', 'source-code.tgz']) {
  if (!existsSync(path.join(web, file))) throw new Error(`Missing bundled Android resource: ${file}`);
}
for (const file of ['sw.js', 'sw-standalone.js', 'offline.html', 'install.html', 'LibreTV.mobileconfig', 'update-repair.html', 'api']) {
  if (existsSync(path.join(web, file))) throw new Error(`Unexpected website/server resource in Android: ${file}`);
}
const copiedMarker = JSON.parse(readFileSync(path.join(web, 'android-build.json'), 'utf8'));
if (copiedMarker.mode !== 'android' || copiedMarker.origin !== expectedIdentity.origin) {
  throw new Error('The Android project did not receive the selected app bundle.');
}
console.log('Bundled Android project ready at https://localhost. Compile and sign its APK separately; sync alone does not produce an installable APK.');
