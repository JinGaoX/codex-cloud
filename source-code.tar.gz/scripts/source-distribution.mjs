// Generate the modified program's public source offer for AGPL deployments.
// Deliberately allowlist project source: never archive .git, env files, runtime
// exports, private API configuration, node_modules, caches, or build output.
import { existsSync, mkdirSync, readFileSync, renameSync, rmSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { assertUnsignedHarmonyProfile } from './source-distribution-safety.mjs';
import { assertPublicSyncConfiguration } from './validate-public-sync.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
assertPublicSyncConfiguration(root);
for (const entry of ['harmony/build-profile.json5', 'harmony/entry/build-profile.json5']) {
  const profile = path.join(root, entry);
  if (existsSync(profile)) assertUnsignedHarmonyProfile(readFileSync(profile, 'utf8'));
}
const entries = [
  'src', 'public', 'docs', 'scripts', 'ios', 'harmony', 'supabase', 'capacitor.config.ts', '.github', 'LICENSE', 'README.md',
  'CHANGELOG.private.zh-CN.md', 'UPSTREAM.md', 'LOCAL_CODEX_HANDOFF.zh-CN.md', 'package.json', 'package-lock.json',
  'next.config.ts', 'next-env.d.ts', 'tsconfig.json', 'tailwind.config.ts',
  'postcss.config.mjs', 'eslint.config.mjs', 'vitest.config.ts', 'vercel.json',
  'Dockerfile', 'docker-compose.yml', '.dockerignore', '.gitignore', '.env.example',
].filter((entry) => existsSync(path.join(root, entry)));
mkdirSync(path.join(root, 'public'), { recursive: true });
// Build outside the archived tree, then replace atomically: parallel platform
// builds must not copy or serve a half-written corresponding-source offer.
const temporary = path.join(path.dirname(root), `.libretv-source-${process.pid}.tar.gz`);
const result = spawnSync('tar', [
  '--exclude=public/source-code.tar.gz', '--exclude=*.local', '--exclude=*.log',
  '--exclude=ios/App/App/public', '--exclude=ios/App/App/capacitor.config.json',
  '--exclude=ios/App/build', '--exclude=ios/DerivedData', '--exclude=xcuserdata',
  '--exclude=harmony/entry/src/main/resources/rawfile/web',
  '--exclude=harmony/entry/src/main/resources/rawfile/web.prepare',
  '--exclude=harmony/entry/src/main/ets/generated/AssetManifest.ets',
  '--exclude=harmony/oh_modules', '--exclude=harmony/entry/oh_modules',
  '--exclude=harmony/.hvigor', '--exclude=harmony/.idea',
  '--exclude=harmony/.deveco', '--exclude=harmony/.cxx', '--exclude=harmony/node_modules',
  '--exclude=harmony/build', '--exclude=harmony/entry/build',
  '--exclude=harmony/sdk', '--exclude=harmony/SDK', '--exclude=harmony/.sdk',
  '--exclude=harmony/signing', '--exclude=harmony/.signing', '--exclude=harmony/local.properties',
  '--exclude=supabase/.temp', '--exclude=supabase/.branches', '--exclude=supabase/node_modules',
  '--exclude=supabase/.env', '--exclude=supabase/.env.*', '--exclude=supabase/.git',
  '--exclude=*.local.*', '--exclude=*.hap', '--exclude=*.hsp', '--exclude=*.app',
  '--exclude=.env', '--exclude=.env.*',
  '--exclude=*.p7b', '--exclude=*.cer', '--exclude=*.csr', '--exclude=*.pfx',
  '--exclude=*.pem', '--exclude=*.key', '--exclude=*.keystore', '--exclude=*.jks',
  '--exclude=*.p12', '--exclude=*.mobileprovision', '--exclude=*.ipa',
  '--exclude=.DS_Store', '-czf', temporary, ...entries,
], { cwd: root, stdio: 'inherit' });
if (result.error || result.status !== 0) {
  rmSync(temporary, { force: true });
  if (result.error) throw result.error;
  process.exit(result.status || 1);
}
renameSync(temporary, path.join(root, 'public/source-code.tar.gz'));
console.log('Generated public/source-code.tar.gz from public source allowlist.');
