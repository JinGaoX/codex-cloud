/** Resize/format the user-supplied square artwork; no redraw, crop, or new dependency. */
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import sharp from 'sharp';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const input = path.resolve(process.argv[2] || path.join(root, 'public/icons/pps-original.jpg'));
if (!existsSync(input)) throw new Error('Usage: node scripts/export-brand-icons.mjs /absolute/path/to/square-artwork');
const metadata = await sharp(input).metadata();
if (!metadata.width || metadata.width !== metadata.height) throw new Error('Use square artwork; refuse to distort or crop the supplied image.');
const png = (size) => sharp(input).rotate().resize(size, size, { fit: 'contain' }).png().toBuffer();
async function exportPng(relative, size) {
  const target = path.join(root, relative);
  mkdirSync(path.dirname(target), { recursive: true });
  writeFileSync(target, await png(size));
}
// Retain existing public paths so installed apps keep the same manifest identity.
for (const size of [48, 96, 144, 192, 512]) await exportPng(`public/icons/vip-icon-${size}.png`, size);
await exportPng('public/icons/vip-apple-touch-icon.png', 180);
await exportPng('public/player-poster.png', 512);
await exportPng('ios/App/App/Assets.xcassets/AppIcon.appiconset/AppIcon-512@2x.png', 1024);
await exportPng('harmony/AppScope/resources/base/media/vip_icon.png', 512);
await exportPng('harmony/entry/src/main/resources/base/media/vip_icon.png', 512);

// ICO directory with PNG payloads, supported by current browsers and Windows.
const sizes = [16, 32, 48, 256], images = await Promise.all(sizes.map(png));
const directory = Buffer.alloc(6 + sizes.length * 16);
directory.writeUInt16LE(1, 2); directory.writeUInt16LE(sizes.length, 4);
let offset = directory.length;
images.forEach((bytes, index) => {
  const entry = 6 + index * 16, size = sizes[index];
  directory[entry] = directory[entry + 1] = size === 256 ? 0 : size;
  directory.writeUInt16LE(1, entry + 4); directory.writeUInt16LE(32, entry + 6);
  directory.writeUInt32LE(bytes.length, entry + 8); directory.writeUInt32LE(offset, entry + 12);
  offset += bytes.length;
});
writeFileSync(path.join(root, 'public/favicon.ico'), Buffer.concat([directory, ...images]));
console.log('Exported PPS影音 artwork for web/PWA, Windows, iOS and Harmony; image content unchanged.');
