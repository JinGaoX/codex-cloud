import nextEnv from '@next/env';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

/** Fail before Next embeds a mistaken privileged key into any public artifact. */
export function validatePublicSyncEnvironment(environment) {
  const endpoint = environment.NEXT_PUBLIC_SYNC_URL?.trim() || '';
  const key = environment.NEXT_PUBLIC_SYNC_PUBLISHABLE_KEY?.trim() || '';
  const publicEnvironment = {
    NEXT_PUBLIC_SYNC_URL: endpoint,
    NEXT_PUBLIC_SYNC_PUBLISHABLE_KEY: key,
    NEXT_PUBLIC_SYNC_ALLOW_SIGNUP: environment.NEXT_PUBLIC_SYNC_ALLOW_SIGNUP === 'true' ? 'true' : 'false',
  };
  if (!endpoint && !key) return publicEnvironment;
  if (!endpoint || !key) throw new Error('Public sync configuration is incomplete; both NEXT_PUBLIC_SYNC_* values are required.');
  let url;
  try { url = new URL(endpoint); }
  catch { throw new Error('NEXT_PUBLIC_SYNC_URL must be a valid HTTPS origin.'); }
  if (endpoint.length > 512 || url.protocol !== 'https:' || !url.hostname || url.username || url.password || url.pathname !== '/' || endpoint.includes('?') || endpoint.includes('#')) {
    throw new Error('NEXT_PUBLIC_SYNC_URL must be a plain HTTPS origin.');
  }
  let anonymousJwt = false;
  try {
    const parts = key.split('.');
    anonymousJwt = parts.length === 3 && parts.every((part) => /^[A-Za-z0-9_-]+$/.test(part))
      && JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8')).role === 'anon';
  } catch { /* Reject opaque privileged or malformed keys without printing them. */ }
  if (key.length > 4096 || (!/^sb_publishable_[A-Za-z0-9_-]{8,}$/.test(key) && !anonymousJwt)) {
    throw new Error('NEXT_PUBLIC_SYNC_PUBLISHABLE_KEY must be publishable/anon. Refusing to build a privileged key into browser assets.');
  }
  return publicEnvironment;
}

const script = fileURLToPath(import.meta.url);

/** Use Next's precedence/expansion in isolation; never import root secrets into the build parent. */
export function readPublicSyncEnvironment(root = process.cwd()) {
  const result = spawnSync(process.execPath, [script, '--read-public-environment', path.resolve(root)], {
    encoding: 'utf8', env: process.env, windowsHide: true,
  });
  if (result.error) throw new Error('Unable to read public sync build configuration.');
  if (result.status !== 0) throw new Error(result.stderr.trim() || 'Invalid public sync build configuration.');
  return JSON.parse(result.stdout);
}

export function assertPublicSyncConfiguration(root = process.cwd()) {
  readPublicSyncEnvironment(root);
}

if (process.argv[1] && path.resolve(process.argv[1]) === script && process.argv[2] === '--read-public-environment') {
  try {
    nextEnv.loadEnvConfig(process.argv[3], false, { info() {}, error() {} }, true);
    process.stdout.write(JSON.stringify(validatePublicSyncEnvironment(process.env)));
  } catch (error) {
    process.stderr.write(error instanceof Error ? error.message : 'Invalid public sync build configuration.');
    process.exitCode = 1;
  }
}
