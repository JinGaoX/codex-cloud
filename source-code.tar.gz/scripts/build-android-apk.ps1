param(
    [string]$ToolchainRoot = (Join-Path $env:LOCALAPPDATA 'PPSAndroidBuild'),
    [string]$SigningRoot = (Join-Path $env:LOCALAPPDATA 'PPSAndroidSigning'),
    [string]$OutputDirectory = '',
    [switch]$InstrumentRelease
)
$ErrorActionPreference = 'Stop'
$sourceRoot = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$ToolchainRoot = [IO.Path]::GetFullPath($ToolchainRoot)
$SigningRoot = [IO.Path]::GetFullPath($SigningRoot)
if (-not $OutputDirectory) { $OutputDirectory = Join-Path (Split-Path -Parent $sourceRoot) 'delivery' }
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
$jdk = Get-ChildItem -LiteralPath (Join-Path $ToolchainRoot 'jdk') -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'bin/javac.exe') } | Select-Object -First 1
$sdk = Join-Path $ToolchainRoot 'sdk'
if (-not $jdk -or -not (Test-Path -LiteralPath (Join-Path $sdk 'platforms/android-36/android.jar'))) { throw 'Install the project JDK21 and Android SDK36 first.' }
if (-not (Test-Path -LiteralPath (Join-Path $sourceRoot 'android/app/src/main/assets/public/android-build.json'))) { throw 'Build and sync the Android web bundle first.' }

# A fresh ASCII-only workspace avoids Android tool issues with Windows Unicode
# project paths, and cannot carry removed/stale web assets into a later APK.
$work = Join-Path $ToolchainRoot ('workspaces/pps-' + [DateTime]::UtcNow.ToString('yyyyMMddHHmmssfff'))
if (-not ([IO.Path]::GetFullPath($work)).StartsWith($ToolchainRoot + [IO.Path]::DirectorySeparatorChar)) { throw 'Invalid isolated Android build path.' }
New-Item -ItemType Directory -Path $work -Force | Out-Null
function Copy-BuildTree([string]$From, [string]$To) {
    New-Item -ItemType Directory -Path $To -Force | Out-Null
    foreach ($entry in Get-ChildItem -LiteralPath $From -Force) {
        if ($entry.Name -in @('build', '.gradle', '.idea', 'local.properties')) { continue }
        $target = Join-Path $To $entry.Name
        if ($entry.PSIsContainer) { Copy-BuildTree $entry.FullName $target }
        else { Copy-Item -LiteralPath $entry.FullName -Destination $target }
    }
}
Copy-BuildTree (Join-Path $sourceRoot 'android') (Join-Path $work 'android')
Copy-Item -LiteralPath (Join-Path $sourceRoot 'package.json') -Destination $work
foreach ($package in @('android', 'app', 'filesystem', 'share')) {
    Copy-BuildTree (Join-Path $sourceRoot ('node_modules/@capacitor/' + $package)) (Join-Path $work ('node_modules/@capacitor/' + $package))
}
# Capacitor resolves a dependency junction to its original checkout when syncing.
# This isolated build carries its own native modules, so bind those four modules
# to the copied workspace rather than a previous checkout's generated paths.
$capacitorSettings = @('// Isolated workspace module paths; regenerated for this build.')
foreach ($package in @('android', 'app', 'filesystem', 'share')) {
    $moduleName = 'capacitor-' + $package
    $moduleDirectory = if ($package -eq 'android') { 'capacitor' } else { 'android' }
    $modulePath = '../node_modules/@capacitor/' + $package + '/' + $moduleDirectory
    if (-not (Test-Path -LiteralPath (Join-Path (Join-Path $work 'android') ($modulePath + '/build.gradle')))) { throw 'Copied Capacitor native module is incomplete.' }
    $capacitorSettings += "include ':$moduleName'"
    $capacitorSettings += "project(':$moduleName').projectDir = new File('$modulePath')"
}
$capacitorSettings | Set-Content -LiteralPath (Join-Path $work 'android/capacitor.settings.gradle') -Encoding ASCII
('sdk.dir=' + $sdk.Replace('\', '/')) | Set-Content -LiteralPath (Join-Path $work 'android/local.properties') -Encoding ASCII

New-Item -ItemType Directory -Path $SigningRoot -Force | Out-Null
$keyPath = Join-Path $SigningRoot 'pps-family-release.p12'
$secretPath = Join-Path $SigningRoot 'signing-password.dpapi'
$aliasName = 'pps-family'
$names = @('JAVA_HOME', 'ANDROID_HOME', 'ANDROID_SDK_ROOT', 'GRADLE_USER_HOME', 'PPS_ANDROID_KEYSTORE', 'PPS_ANDROID_STORE_PASSWORD', 'PPS_ANDROID_KEY_ALIAS', 'PPS_ANDROID_KEY_PASSWORD')
$previous = @{}
foreach ($name in $names) { $previous[$name] = [Environment]::GetEnvironmentVariable($name, 'Process') }
try {
    $env:JAVA_HOME = $jdk.FullName
    $env:ANDROID_HOME = $sdk
    $env:ANDROID_SDK_ROOT = $sdk
    $env:GRADLE_USER_HOME = Join-Path $ToolchainRoot 'gradle'
    if ((Test-Path -LiteralPath $keyPath) -ne (Test-Path -LiteralPath $secretPath)) { throw 'Signing key/password state is incomplete; refusing to replace the update identity.' }
    if (-not (Test-Path -LiteralPath $keyPath)) {
        $randomBytes = New-Object byte[] 32
        $generator = [Security.Cryptography.RandomNumberGenerator]::Create()
        try { $generator.GetBytes($randomBytes) } finally { $generator.Dispose() }
        $signingPassword = [Convert]::ToBase64String($randomBytes)
        $securePassword = ConvertTo-SecureString $signingPassword -AsPlainText -Force
        $securePassword | ConvertFrom-SecureString | Set-Content -LiteralPath $secretPath -Encoding ASCII
        $env:PPS_ANDROID_STORE_PASSWORD = $signingPassword
        $env:PPS_ANDROID_KEY_PASSWORD = $signingPassword
        & (Join-Path $jdk.FullName 'bin/keytool.exe') -genkeypair -alias $aliasName -keyalg RSA -keysize 3072 -validity 36500 -storetype PKCS12 -keystore $keyPath -storepass:env PPS_ANDROID_STORE_PASSWORD -keypass:env PPS_ANDROID_KEY_PASSWORD -dname 'CN=PPS Family, OU=Personal, O=PPS, C=CN' -noprompt
        if ($LASTEXITCODE -ne 0) { throw 'Release signing key generation failed.' }
    }
    $encryptedPassword = (Get-Content -LiteralPath $secretPath -Raw).Trim()
    $securePassword = ConvertTo-SecureString $encryptedPassword
    $signingPassword = (New-Object Net.NetworkCredential('', $securePassword)).Password
    $env:PPS_ANDROID_KEYSTORE = $keyPath
    $env:PPS_ANDROID_STORE_PASSWORD = $signingPassword
    $env:PPS_ANDROID_KEY_PASSWORD = $signingPassword
    $env:PPS_ANDROID_KEY_ALIAS = $aliasName
    Push-Location (Join-Path $work 'android')
    try {
        $gradleTasks = @('--no-daemon', '--console=plain', 'testDebugUnitTest', 'assembleRelease')
        if ($InstrumentRelease) { $gradleTasks += @('assembleReleaseAndroidTest', '-PppsInstrumentRelease=true') }
        & '.\gradlew.bat' @gradleTasks
        if ($LASTEXITCODE -ne 0) { throw 'Android compilation or native route tests failed.' }
    } finally { Pop-Location }
    $apk = Join-Path $work 'android/app/build/outputs/apk/release/app-release.apk'
    if (-not (Test-Path -LiteralPath $apk)) { throw 'Signed release APK was not generated.' }
    $apksigner = Join-Path $sdk 'build-tools/36.0.0/apksigner.bat'
    & $apksigner verify --verbose --print-certs $apk
    if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed.' }
    New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
    $version = (Get-Content -LiteralPath (Join-Path $sourceRoot 'package.json') -Raw | ConvertFrom-Json).version
    $badging = & (Join-Path $sdk 'build-tools/36.0.0/aapt.exe') dump badging $apk
    if ($LASTEXITCODE -ne 0) { throw 'Cannot read APK package identity.' }
    $packageLine = $badging | Where-Object { $_ -like 'package:*' } | Select-Object -First 1
    if ($packageLine -notmatch "name='org.libretv.personal' versionCode='([0-9]+)' versionName='([^']+)'") { throw 'APK package identity is not PPS.' }
    $versionCode = [int]$Matches[1]
    if ($Matches[2] -ne $version) { throw 'APK version does not match its selected source.' }
    $configuredVersion = [int]((Get-Content -LiteralPath (Join-Path $sourceRoot 'android/version.properties') | Where-Object { $_ -match '^versionCode=' }) -replace '^versionCode=', '')
    if ($versionCode -ne $configuredVersion) { throw 'APK update code does not match its selected source.' }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $apkArchive = [IO.Compression.ZipFile]::OpenRead($apk)
    try {
        $sourceEntry = $apkArchive.GetEntry('assets/public/source-code.tgz')
        if (-not $sourceEntry -or $sourceEntry.Length -le 0) { throw 'APK is missing its exact corresponding source archive.' }
        $sourceStream = $sourceEntry.Open()
        try { if ($sourceStream.ReadByte() -ne 31 -or $sourceStream.ReadByte() -ne 139) { throw 'APK source archive lost its gzip bytes during packaging.' } }
        finally { $sourceStream.Dispose() }
        $configEntry = $apkArchive.GetEntry('assets/capacitor.config.json')
        if (-not $configEntry) { throw 'APK is missing its native configuration.' }
        $configReader = [IO.StreamReader]::new($configEntry.Open())
        try { $packedConfig = $configReader.ReadToEnd() | ConvertFrom-Json } finally { $configReader.Dispose() }
        if ($packedConfig.appId -ne 'org.libretv.personal' -or $packedConfig.server.url -or $packedConfig.server.hostname -ne 'localhost' -or $packedConfig.server.androidScheme -ne 'https' -or $packedConfig.android.allowMixedContent -ne $false -or $packedConfig.android.webContentsDebuggingEnabled -ne $false -or $packedConfig.plugins.SystemBars.insetsHandling -ne 'native' -or $packedConfig.plugins.SystemBars.initialViewportFitValueHint -ne 'contain') { throw 'Actual APK does not contain the approved local Android configuration.' }
        $forbiddenAssets = @($apkArchive.Entries.FullName | Where-Object { $_ -match '(^|/)(\.env|local\.properties|signing-password\.dpapi)|\.(p12|jks|keystore|aab)$|^assets/public/(sw[^/]*\.js|api/|install\.html|offline\.html)' })
        if ($forbiddenAssets.Count -ne 0) { throw 'APK contains an unexpected build, private or website runtime resource.' }
    } finally { $apkArchive.Dispose() }
    $destination = Join-Path $OutputDirectory ('PPS-' + $version + '-universal.apk')
    Copy-Item -LiteralPath $apk -Destination $destination -Force
    $digest = (Get-FileHash -LiteralPath $destination -Algorithm SHA256).Hash.ToLowerInvariant()
    $digest | Set-Content -LiteralPath ($destination + '.sha256') -Encoding ASCII
    if ($InstrumentRelease) {
        $testApk = Join-Path $work 'android/app/build/outputs/apk/androidTest/release/app-release-androidTest.apk'
        if (-not (Test-Path -LiteralPath $testApk)) { throw 'Release runtime test APK was not generated.' }
        $qaDirectory = Join-Path $OutputDirectory 'qa'
        New-Item -ItemType Directory -Path $qaDirectory -Force | Out-Null
        Copy-Item -LiteralPath $testApk -Destination (Join-Path $qaDirectory 'pps-release-runtime-test.apk') -Force
    }
    [pscustomobject]@{ appId = 'org.libretv.personal'; version = $version; versionCode = $versionCode; apk = $destination; bytes = (Get-Item -LiteralPath $destination).Length; sha256 = $digest; signed = $true; finalized = $false; workspace = $work } | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $OutputDirectory 'build-report.json') -Encoding UTF8
    Write-Output ('Verified universal APK: ' + $destination)
} finally {
    $signingPassword = $null
    foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name, $previous[$name], 'Process') }
}
