param(
    [Parameter(Mandatory = $true)][string]$PreviousApk,
    [string]$ToolchainRoot = (Join-Path $env:LOCALAPPDATA 'PPSAndroidBuild'),
    [string]$SigningRoot = (Join-Path $env:LOCALAPPDATA 'PPSAndroidSigning'),
    [string]$OutputDirectory = '',
    [switch]$InstrumentRelease
)
$ErrorActionPreference = 'Stop'
$sourceRoot = [IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$PreviousApk = [IO.Path]::GetFullPath($PreviousApk)
$ToolchainRoot = [IO.Path]::GetFullPath($ToolchainRoot)
$SigningRoot = [IO.Path]::GetFullPath($SigningRoot)
if (-not $OutputDirectory) { $OutputDirectory = Join-Path (Split-Path -Parent $sourceRoot) 'delivery' }
$OutputDirectory = [IO.Path]::GetFullPath($OutputDirectory)
if (-not (Test-Path -LiteralPath $PreviousApk -PathType Leaf)) { throw 'The previous release APK is required for update identity verification.' }
foreach ($file in @('pps-family-release.p12', 'signing-password.dpapi')) {
    if (-not (Test-Path -LiteralPath (Join-Path $SigningRoot $file) -PathType Leaf)) { throw 'Existing update signing material is required; this update cannot generate a new identity.' }
}
$aapt = Join-Path $ToolchainRoot 'sdk/build-tools/36.0.0/aapt.exe'
$apksignerJar = Join-Path $ToolchainRoot 'sdk/build-tools/36.0.0/lib/apksigner.jar'
$jdk = Get-ChildItem -LiteralPath (Join-Path $ToolchainRoot 'jdk') -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'bin/java.exe') } | Select-Object -First 1
if (-not $jdk -or -not (Test-Path -LiteralPath $aapt) -or -not (Test-Path -LiteralPath $apksignerJar)) { throw 'The project JDK and Android SDK36 build tools are required.' }
$java = Join-Path $jdk.FullName 'bin/java.exe'
function Read-ApkIdentity([string]$Apk) {
    $badging = & $aapt dump badging $Apk
    if ($LASTEXITCODE -ne 0) { throw 'Cannot read APK identity.' }
    $package = $badging | Where-Object { $_ -like 'package:*' } | Select-Object -First 1
    if ($package -notmatch "name='org.libretv.personal' versionCode='([0-9]+)' versionName='([^']+)'") { throw 'APK is not the expected PPS application.' }
    [pscustomobject]@{ code = [int]$Matches[1]; version = $Matches[2] }
}
function Read-SignerFingerprint([string]$Apk) {
    $certificate = & $java -jar $apksignerJar verify --verbose --print-certs $Apk
    if ($LASTEXITCODE -ne 0) { throw 'APK signature verification failed.' }
    $line = $certificate | Where-Object { $_ -match '^Signer #1 certificate SHA-256 digest: ([0-9a-fA-F]+)$' } | Select-Object -First 1
    if (-not $line -or $line -notmatch '^Signer #1 certificate SHA-256 digest: ([0-9a-fA-F]+)$') { throw 'APK release certificate fingerprint is unavailable.' }
    $Matches[1].ToLowerInvariant()
}
$previousDigest = (Get-FileHash -LiteralPath $PreviousApk -Algorithm SHA256).Hash.ToLowerInvariant()
$previousIdentity = Read-ApkIdentity $PreviousApk
$previousCertificate = Read-SignerFingerprint $PreviousApk
$version = (Get-Content -LiteralPath (Join-Path $sourceRoot 'package.json') -Raw | ConvertFrom-Json).version
$code = [int]((Get-Content -LiteralPath (Join-Path $sourceRoot 'android/version.properties') | Where-Object { $_ -match '^versionCode=' }) -replace '^versionCode=', '')
if ($code -le $previousIdentity.code) { throw 'An update must increase Android versionCode.' }
$expectedDestination = Join-Path $OutputDirectory ('PPS-' + $version + '-universal.apk')
if ($expectedDestination -eq $PreviousApk) { throw 'The update must not overwrite the previous release artifact.' }
& (Join-Path $PSScriptRoot 'build-android-apk.ps1') -ToolchainRoot $ToolchainRoot -SigningRoot $SigningRoot -OutputDirectory $OutputDirectory -InstrumentRelease:$InstrumentRelease
$builtIdentity = Read-ApkIdentity $expectedDestination
$builtCertificate = Read-SignerFingerprint $expectedDestination
if ($builtIdentity.code -ne $code -or $builtIdentity.version -ne $version -or $builtCertificate -ne $previousCertificate) { throw 'Update identity or original release certificate changed.' }
if ((Get-FileHash -LiteralPath $PreviousApk -Algorithm SHA256).Hash.ToLowerInvariant() -ne $previousDigest) { throw 'The previous APK changed during this update build.' }

# The exact corresponding source is shipped in the APK. Extract those bytes,
# never make a new archive from a possibly changed checkout after compilation.
Add-Type -AssemblyName System.IO.Compression.FileSystem
$sourceName = 'PPS-' + $version + '-corresponding-source.tar.gz'
$sourceDestination = Join-Path $OutputDirectory $sourceName
$archive = [IO.Compression.ZipFile]::OpenRead($expectedDestination)
try {
    $entry = $archive.GetEntry('assets/public/source-code.tgz')
    if (-not $entry -or $entry.Length -le 0) { throw 'The exact APK source archive is missing.' }
    $input = $entry.Open()
    try {
        $output = [IO.File]::Create($sourceDestination)
        try { $input.CopyTo($output) } finally { $output.Dispose() }
    } finally { $input.Dispose() }
} finally { $archive.Dispose() }
$sourceBytes = [IO.File]::OpenRead($sourceDestination)
try { if ($sourceBytes.ReadByte() -ne 31 -or $sourceBytes.ReadByte() -ne 139) { throw 'Extracted corresponding source is not gzip.' } }
finally { $sourceBytes.Dispose() }
$sourceDigest = (Get-FileHash -LiteralPath $sourceDestination -Algorithm SHA256).Hash.ToLowerInvariant()
$sourceDigest | Set-Content -LiteralPath ($sourceDestination + '.sha256') -Encoding ASCII
$reportPath = Join-Path $OutputDirectory 'build-report.json'
$report = Get-Content -LiteralPath $reportPath -Raw | ConvertFrom-Json
$updateMetadata = @{
    updateFromVersionCode = $previousIdentity.code
    updateFromApkSha256 = $previousDigest
    sameSigningCertificate = $true
    signingCertificateSha256 = $builtCertificate
    correspondingSource = $sourceDestination
    correspondingSourceSha256 = $sourceDigest
}
foreach ($property in $updateMetadata.GetEnumerator()) { $report | Add-Member -NotePropertyName $property.Key -NotePropertyValue $property.Value -Force }
$report | ConvertTo-Json | Set-Content -LiteralPath $reportPath -Encoding UTF8
Write-Output ('Verified same-signature update and exact corresponding source: ' + $expectedDestination)
