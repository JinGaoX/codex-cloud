/** Fail closed: DevEco may write signing credentials into the public build profile. */
export function assertUnsignedHarmonyProfile(source) {
  let profile;
  try {
    // Public templates intentionally use strict JSON (valid JSON5). Do not eval JSON5.
    if (typeof source !== 'string' || source.length > 512 * 1024) throw new Error();
    profile = JSON.parse(source);
    if (!profile || typeof profile !== 'object' || Array.isArray(profile)) throw new Error();
  } catch {
    throw new Error('鸿蒙公开构建配置必须保持为无签名的 JSON 模板；请将本机签名配置单独保存。');
  }
  function inspect(value) {
    if (typeof value === 'string' && /-----BEGIN (?:[A-Z ]*PRIVATE KEY|CERTIFICATE)-----/.test(value)) {
      throw new Error('拒绝归档包含签名材料的鸿蒙构建配置。');
    }
    if (!value || typeof value !== 'object') return;
    for (const [key, child] of Object.entries(value)) {
      if (key === 'signingConfigs') {
        if (!Array.isArray(child) || child.length !== 0) {
          throw new Error('拒绝归档非空鸿蒙 signingConfigs；请将签名配置移至本机忽略文件。');
        }
      } else if (/signingConfig|password|passphrase|private.?key|secret|keyalias|keystore|storefile|certpath|certificate|profilepath|^profile$/i.test(key)) {
        // Field names are sufficient; never include credential values in diagnostics.
        throw new Error('拒绝归档包含签名或口令字段的鸿蒙构建配置。');
      }
      inspect(child);
    }
  }
  inspect(profile);
}
