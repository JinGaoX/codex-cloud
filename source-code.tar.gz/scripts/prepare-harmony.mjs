/** Bundle the Harmony-only static export. This never compiles, signs, or installs a HAP. */
import { cpSync, existsSync, lstatSync, mkdirSync, readFileSync, readdirSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const origin = 'https://vip.localhost';
const appId = 'org.libretv.personal';
const source = path.join(root, 'harmony-dist');
const project = path.join(root, 'harmony');
const destination = path.join(project, 'entry/src/main/resources/rawfile/web');
const generated = path.join(project, 'entry/src/main/ets/generated/AssetManifest.ets');
const mimeTypes = {
  '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json',
  '.txt': 'text/x-component', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.gif': 'image/gif',
  '.woff': 'font/woff', '.woff2': 'font/woff2', '.ttf': 'font/ttf', '.wasm': 'application/wasm',
  '.webmanifest': 'application/manifest+json', '.gz': 'application/gzip', '.avif': 'image/avif',
};

function safeChild(base, relative) {
  if (!relative || path.isAbsolute(relative) || relative.includes('\\') || relative.includes('%') ||
    relative.split('/').some(part => !part || part === '.' || part === '..' || /[\u0000-\u001f?#]/u.test(part))) {
    throw new Error(`Unsafe resource path: ${relative}`);
  }
  const target = path.resolve(base, ...relative.split('/'));
  if (!target.startsWith(path.resolve(base) + path.sep)) throw new Error('Resource escaped the export root.');
  return target;
}

function listFiles(base, relative = '') {
  const files = [];
  for (const name of readdirSync(path.join(base, relative)).sort()) {
    const nameRelative = relative ? `${relative}/${name}` : name;
    const file = safeChild(base, nameRelative);
    const info = lstatSync(file);
    if (info.isSymbolicLink()) throw new Error(`Symlink is not a bundled asset: ${nameRelative}`);
    if (info.isDirectory()) files.push(...listFiles(base, nameRelative));
    else if (info.isFile()) files.push({ file: nameRelative, bytes: info.size,
      sha256: createHash('sha256').update(readFileSync(file)).digest('hex'),
      mime: mimeTypes[path.extname(nameRelative).toLowerCase()] || 'application/octet-stream' });
    else throw new Error(`Unexpected resource type: ${nameRelative}`);
  }
  return files;
}

function validateExport() {
  if (!existsSync(source)) throw new Error('Run npm run build:harmony before preparing the Harmony project.');
  const marker = JSON.parse(readFileSync(path.join(source, 'harmony-build.json'), 'utf8'));
  if (marker.mode !== 'harmony' || marker.appId !== appId || marker.bundled !== true ||
    marker.remoteServer !== false || marker.origin !== origin) {
    throw new Error('Refusing non-Harmony assets, a remote shell, or a changed storage origin.');
  }
  for (const name of ['index.html', 'watch.html', 'source-code.tar.gz']) {
    if (!existsSync(path.join(source, name))) throw new Error(`Missing bundled resource: ${name}`);
  }
  const files = listFiles(source);
  for (const item of files) {
    if (/^(?:api(?:\/|$)|sw(?:-standalone)?\.js$|install\.html$|LibreTV\.mobileconfig$|\.env(?:\.|$))/iu.test(item.file) ||
      /(?:^|\/)(?:signing|node_modules|oh_modules|\.git)(?:\/|$)/iu.test(item.file) ||
      /\.(?:p12|pfx|p7b|cer|csr|jks|keystore)$/iu.test(item.file)) {
      throw new Error(`Forbidden server, installer, or private resource: ${item.file}`);
    }
  }
  if (!files.some(item => item.file.startsWith('_next/') && item.file.endsWith('.js'))) {
    throw new Error('Missing shared frontend JavaScript.');
  }
  if (files.find(item => item.file === 'source-code.tar.gz').bytes === 0) throw new Error('Empty AGPL source archive.');
  return files;
}

function routesFor(files) {
  const routes = new Map();
  function add(route, item) {
    if (routes.has(route) && routes.get(route).file !== item.file) throw new Error(`Ambiguous route: ${route}`);
    routes.set(route, item);
  }
  for (const item of files) {
    add('/' + item.file, item);
    if (item.file === 'index.html') add('/', item);
    else if (item.file.endsWith('/index.html')) {
      add('/' + item.file.slice(0, -11), item);
      add('/' + item.file.slice(0, -10), item);
    } else if (item.file.endsWith('.html')) {
      add('/' + item.file.slice(0, -5), item);
      add('/' + item.file.slice(0, -5) + '/', item);
    }
  }
  return routes;
}

const files = validateExport();
const routes = routesFor(files);
const manifest = {
  schema: 1, mode: 'harmony', origin, appId,
  version: JSON.parse(readFileSync(path.join(root, 'package.json'), 'utf8')).version,
  files, routes: Object.fromEntries([...routes].map(([route, item]) => [route, item.file])),
};
if (process.argv.includes('--check')) {
  const disk = JSON.parse(readFileSync(path.join(destination, 'asset-manifest.json'), 'utf8'));
  if (JSON.stringify(disk) !== JSON.stringify(manifest)) throw new Error('Bundled manifest is stale. Run prepare-harmony again.');
  for (const item of files) {
    const actual = createHash('sha256').update(readFileSync(safeChild(destination, item.file))).digest('hex');
    if (actual !== item.sha256) throw new Error(`Bundled asset checksum mismatch: ${item.file}`);
  }
  const actualFiles = listFiles(destination).map(item => item.file).filter(file => file !== 'asset-manifest.json');
  if (JSON.stringify(actualFiles) !== JSON.stringify(files.map(item => item.file))) throw new Error('Unexpected bundled files.');
  console.log(`Harmony assets verified: ${files.length} files, ${routes.size} exact routes; ${origin}. No HAP compiled.`);
} else {
  // The only recursive replacement target is the fixed generated directory inside this project.
  const expected = path.join(root, 'harmony/entry/src/main/resources/rawfile/web');
  if (path.resolve(destination) !== path.resolve(expected)) throw new Error('Invalid generated target.');
  const staging = destination + '.prepare';
  if (existsSync(staging)) throw new Error('A previous web.prepare directory exists; inspect it before retrying.');
  mkdirSync(path.dirname(destination), { recursive: true });
  cpSync(source, staging, { recursive: true, dereference: false });
  writeFileSync(path.join(staging, 'asset-manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
  rmSync(destination, { recursive: true, force: true });
  renameSync(staging, destination);
  mkdirSync(path.dirname(generated), { recursive: true });
  writeFileSync(generated, '// Generated by scripts/prepare-harmony.mjs. Do not edit.\n' +
    'export class BundledAsset {\n  file: string;\n  mime: string;\n' +
    '  constructor(file: string, mime: string) { this.file = file; this.mime = mime; }\n}\n' +
    'export const ASSET_ROUTES: Map<string, BundledAsset> = new Map<string, BundledAsset>([\n' +
    [...routes].map(([route, item]) => `  [${JSON.stringify(route)}, new BundledAsset(${JSON.stringify(item.file)}, ${JSON.stringify(item.mime)})]`).join(',\n') +
    '\n]);\n');
  for (const base of ['AppScope/resources/base/media', 'entry/src/main/resources/base/media']) {
    mkdirSync(path.join(project, base), { recursive: true });
    cpSync(path.join(root, 'public/icons/vip-icon-512.png'), path.join(project, base, 'vip_icon.png'));
  }
  // Version changes are explicit to preserve the native upgrade identity/versionCode contract.
  const app = JSON.parse(readFileSync(path.join(project, 'AppScope/app.json5'), 'utf8')).app;
  if (app.bundleName !== appId || app.versionName !== manifest.version) {
    throw new Error('Update Harmony AppScope versionName/versionCode explicitly before compiling; keep bundleName unchanged.');
  }
  console.log(`Harmony local assets prepared: ${files.length} files, ${routes.size} exact routes. Run --check to verify. This is a source project, not an installable HAP.`);
}
